<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
if(!isset($app))exit;
$current=current_user();if(!$current){header('Location: '.url('owner-login'));exit;}
$u=$app->one('SELECT id,role,is_active FROM users WHERE id=?',[(int)$current['id']]);if(!$u||!$u['is_active']||$u['role']!=='master'){http_response_code(403);exit('Solo la cuenta maestro puede instalar esta actualización.');}
header('Cache-Control: no-store');header('X-Content-Type-Options: nosniff');header('X-Frame-Options: SAMEORIGIN');
require __DIR__.'/files.php';
function r7_update_manifest():array {
 $m=json_decode((string)file_get_contents(__DIR__.'/manifest.json'),true,512,JSON_THROW_ON_ERROR);if(($m['version']??'')!=='1.7.7'||array_keys($m['files']??[])!==UPDATE_R7_FILES)throw new RuntimeException('Paquete incompleto. Vuelve a subir el ZIP original.');return $m;
}
function r7_update_target(string $name):string {
 if(!in_array($name,UPDATE_R7_FILES,true))throw new RuntimeException('Archivo no permitido.');$root=realpath(ROOT_PATH);$path=ROOT_PATH.'/'.$name;$parent=realpath(dirname($path));if(!$root||!$parent||($parent!==$root&&!str_starts_with($parent,$root.DIRECTORY_SEPARATOR))||is_link($path))throw new RuntimeException('Ruta de instalación no segura.');return $path;
}
function r7_update_states(array $m):array {
 $states=[];foreach($m['files'] as $name=>$info){$path=r7_update_target($name);$actual=is_file($path)?hash_file('sha256',$path):null;$states[$name]=$actual===$info['new']?'actualizado':($actual===null&&$info['old']===[]?'compatible':(in_array($actual,$info['old'],true)?'compatible':'distinto'));if(!is_file(__DIR__.'/payload/'.$name)||hash_file('sha256',__DIR__.'/payload/'.$name)!==$info['new'])throw new RuntimeException('El paquete no pasó su comprobación de integridad.');if(!is_writable(dirname($path))||(is_file($path)&&!is_writable($path)))throw new RuntimeException('Sin permiso para actualizar '.$name.'. Revisa sus permisos desde cPanel.');}return $states;
}
function r7_update_write(string $target,string $data):void {
 $mode=is_file($target)?(fileperms($target)&0777):0644;$tmp=tempnam(dirname($target),'.fisitaap-r7-');if(!$tmp)throw new RuntimeException('No se pudo preparar un archivo.');try{if(file_put_contents($tmp,$data)!==strlen($data)||!chmod($tmp,$mode)||!rename($tmp,$target))throw new RuntimeException('No se pudo guardar un archivo.');if(function_exists('opcache_invalidate'))opcache_invalidate($target,true);}finally{if(is_file($tmp))unlink($tmp);}
}
function r7_update_restore(string $backup,array $record):void {
 $names=UPDATE_R7_FILES;$names=array_merge(['index.php'],array_values(array_diff($names,['index.php'])));foreach($names as $name){$target=r7_update_target($name);if($record['files'][$name]===null){if(is_file($target)&&!unlink($target))throw new RuntimeException('No se pudo retirar el archivo nuevo.');}else r7_update_write($target,(string)file_get_contents($backup.'/'.$name));}
}
function r7_update_flags(App $app,array $values):void {foreach($values as $key=>$value)$app->exec('INSERT INTO settings(`key`,`value`) VALUES(?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)',[$key,$value]);}
function r7_update_permissions(App $app):void {
 $aliases=['extras'=>'opciones','opcionales'=>'opciones','combos'=>'opciones','promociones'=>'cupones','clientes-crear'=>'clientes','clientes-buscar'=>'clientes','clientes-historial'=>'clientes','credito'=>'clientes','proveedores'=>'compras','kpis'=>'reportes','mesas'=>'ventas','afiliados'=>'express','invitaciones'=>'express','entregas-historial'=>'repartidor','sucursal-detalle'=>'sucursales','contenido-anterior'=>'contenido'];foreach($aliases as $new=>$old)$app->exec('INSERT IGNORE INTO fisitaap_r1_permissions(role_id,section_key,action_key) SELECT role_id,?,action_key FROM fisitaap_r1_permissions WHERE section_key=?',[$new,$old]);
}
function r7_update_indexes(App $app):void {
 foreach ([
   ['fisitaap_r2_shift_links','idx_shift_link_shift','shift_id'],
   ['fisitaap_r2_snapshots','idx_snapshot_device_created','device_id,created_at'],
 ] as [$table,$name,$columns]) {
   if (!$app->one('SELECT INDEX_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND INDEX_NAME=?',[$table,$name]))
       $app->db->exec('ALTER TABLE '.$table.' ADD INDEX '.$name.' ('.$columns.')');
 }
}

function r7_update_apply(App $app,array $m):string {
 $states=r7_update_states($m);if(in_array('distinto',$states,true))throw new RuntimeException('Hay archivos diferentes de la copia revisada. No se reemplazó nada; solicita un paquete compatible.');
 $active=(string)($app->one('SELECT `value` FROM settings WHERE `key`="performance_177_active"')['value']??'0');if($active==='1'&&count(array_filter($states,fn($v)=>$v==='actualizado'))===count($states))return 'La actualización ya está instalada. No se duplicaron respaldos ni registros.';
 if($active==='1')throw new RuntimeException('La actualización figura activa, pero algunos archivos no coinciden. Revisa el respaldo antes de continuar.');
 $actual=[];foreach(UPDATE_R7_FILES as $name){$p=r7_update_target($name);$actual[$name]=is_file($p)?hash_file('sha256',$p):null;}$baseline=null;foreach($m['baselines'] as $version=>$hashes)if($actual===$hashes)$baseline=$version;if(!$baseline)throw new RuntimeException('La copia está parcialmente actualizada. No se modificó ningún archivo.');
 $before=['restructure_r1_active'=>(string)($app->one('SELECT `value` FROM settings WHERE `key`="restructure_r1_active"')['value']??'0'),'restructure_r2_active'=>(string)($app->one('SELECT `value` FROM settings WHERE `key`="restructure_r2_active"')['value']??'0'),'restructure_r3_active'=>(string)($app->one('SELECT `value` FROM settings WHERE `key`="restructure_r3_active"')['value']??'0'),'qa_174_active'=>(string)($app->one('SELECT `value` FROM settings WHERE `key`="qa_174_active"')['value']??'0'),'qa_175_active'=>(string)($app->one('SELECT `value` FROM settings WHERE `key`="qa_175_active"')['value']??'0'),'performance_177_active'=>$active];$backup=__DIR__.'/backups/'.gmdate('Ymd-His').'-'.bin2hex(random_bytes(6));if(!mkdir($backup,0750,true))throw new RuntimeException('No se pudo crear el respaldo.');$record=['version'=>'1.7.7','baseline'=>$baseline,'files'=>$actual,'settings'=>$before];
 foreach($actual as $name=>$hash)if($hash!==null){$p=$backup.'/'.$name;if(!is_dir(dirname($p))&&!mkdir(dirname($p),0750,true))throw new RuntimeException('No se pudo preparar el respaldo.');if(!copy(r7_update_target($name),$p)||hash_file('sha256',$p)!==$hash)throw new RuntimeException('No se pudo verificar el respaldo.');}
 if(file_put_contents($backup.'/record.json',json_encode($record,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR))===false)throw new RuntimeException('No se pudo registrar el respaldo.');$changed=false;
 try{r7_update_indexes($app);
  if(false){
  $sql=(string)file_get_contents(__DIR__.'/migration-r1.sql');if(hash('sha256',$sql)!==$m['migration_r1_sha256'])throw new RuntimeException('El esquema del paquete fue modificado.');foreach(array_filter(array_map('trim',explode(';',$sql))) as $statement)$app->db->exec($statement);require_once __DIR__.'/payload/app/schema_r2.php';schema_r2($app);require_once __DIR__.'/payload/app/schema_r3.php';schema_r3($app);
  }
  $app->db->beginTransaction();r7_update_permissions($app);$app->db->commit();$record['watermark']=r7_update_watermark($app);if(file_put_contents($backup.'/record.json',json_encode($record,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR))===false)throw new RuntimeException('No se pudo registrar el estado inicial.');$changed=true;
  foreach(UPDATE_R7_FILES as $name)r7_update_write(r7_update_target($name),(string)file_get_contents(__DIR__.'/payload/'.$name));r7_update_flags($app,['restructure_r1_active'=>'1','restructure_r2_active'=>'1','restructure_r3_active'=>'1','qa_174_active'=>'1','qa_175_active'=>'1','performance_177_active'=>'1']);
  if(file_put_contents(__DIR__.'/backups/latest.json',json_encode(['directory'=>basename($backup)],JSON_THROW_ON_ERROR))===false)throw new RuntimeException('No se pudo registrar la restauración.');return 'Actualización 1.7.7 instalada. Abre el panel y prueba una venta antes de comenzar el trabajo del negocio.';
 }catch(Throwable $ex){if($app->db->inTransaction())$app->db->rollBack();r7_update_flags($app,$before);if($changed)r7_update_restore($backup,$record);throw $ex;}
}
function r7_update_watermark(App $app):array {
 $out=[];foreach(['audit_logs','orders','sales','purchases','fisitaap_r3_gift_cards','fisitaap_r3_gift_entries','fisitaap_r3_objects','fisitaap_r3_sectors'] as $table){$out[$table]=$app->one('SELECT COUNT(*) n FROM '.$table)['n'];}
 foreach(['audit_logs','orders','sales','purchases'] as $table)$out[$table.'_last']=$app->one('SELECT COALESCE(MAX(id),0) last FROM '.$table)['last'];
 $out['rooms']=$app->one('SELECT COALESCE(SUM(revision),0) n FROM fisitaap_r3_room_versions')['n'];
 $out['settings']=hash('sha256',json_encode($app->all('SELECT tenant_id,setting_key,value FROM fisitaap_r2_settings ORDER BY tenant_id,setting_key'),JSON_THROW_ON_ERROR));return $out;
}
function r7_update_rollback(App $app,array $m):string {
 // A file rollback is suitable before using the new modules. It cannot undo their business transactions.
 $latest=json_decode((string)file_get_contents(__DIR__.'/backups/latest.json'),true,512,JSON_THROW_ON_ERROR);$directory=(string)($latest['directory']??'');if(!preg_match('/^[0-9]{8}-[0-9]{6}-[a-f0-9]{12}$/',$directory))throw new RuntimeException('Respaldo no válido.');$backup=__DIR__.'/backups/'.$directory;$record=json_decode((string)file_get_contents($backup.'/record.json'),true,512,JSON_THROW_ON_ERROR);if(($record['version']??'')!=='1.7.7'||array_keys($record['files']??[])!==UPDATE_R7_FILES||!isset($m['baselines'][$record['baseline']??''])||$record['files']!==$m['baselines'][$record['baseline']])throw new RuntimeException('El respaldo no corresponde a este paquete.');
 if(!isset($record['watermark'])||$record['watermark']!==r7_update_watermark($app))throw new RuntimeException('Ya se usaron funciones nuevas o cambiaron datos. Para conservar ventas, inventario y cajas, solicita revisión con el respaldo completo antes de volver atrás.');
 foreach($m['files'] as $name=>$info){$p=r7_update_target($name);if(!is_file($p)||hash_file('sha256',$p)!==$info['new'])throw new RuntimeException('Hay cambios posteriores. No se sobrescribirán.');$hash=$record['files'][$name];if($hash!==null&&(!is_file($backup.'/'.$name)||hash_file('sha256',$backup.'/'.$name)!==$hash))throw new RuntimeException('El respaldo está incompleto o fue modificado.');if(!is_writable(dirname($p))||!is_writable($p))throw new RuntimeException('No se puede restaurar por los permisos.');}
 $app->db->beginTransaction();try{if($record['settings']['restructure_r1_active']!=='1'){$app->exec("UPDATE users u JOIN fisitaap_r1_user_roles a ON a.user_id=u.id AND a.tenant_id=u.tenant_id SET u.role=a.previous_role WHERE u.role='manager' AND a.previous_role IN ('manager','editor','kitchen','cashier')");$app->exec('DELETE FROM fisitaap_r1_user_roles');}r7_update_flags($app,$record['settings']);$app->db->commit();}catch(Throwable $ex){if($app->db->inTransaction())$app->db->rollBack();throw $ex;}r7_update_restore($backup,$record);return 'Archivos anteriores restaurados. Se conservaron los datos y las asignaciones de roles de la versión anterior.';
}
$message='';$error='';$states=[];
try{
 if(PHP_VERSION_ID<80100||!extension_loaded('pdo_mysql')||!extension_loaded('mbstring')||!extension_loaded('SimpleXML'))throw new RuntimeException('Se requiere PHP 8.1 o superior con PDO MySQL, mbstring y SimpleXML.');$manifest=r7_update_manifest();
 if(is_post()){$token=(string)($_POST['csrf']??'');if($token===''||!hash_equals((string)($_SESSION['csrf']??''),$token)){http_response_code(403);exit('Sesión vencida. Recarga la página.');}if(($_POST['quiet_confirm']??'')!=='yes')throw new RuntimeException('Confirma que guardaste un respaldo completo y que las cajas están detenidas.');if(!is_dir(__DIR__.'/backups')&&!mkdir(__DIR__.'/backups',0750,true))throw new RuntimeException('No se pudo preparar el respaldo.');$lock=fopen(__DIR__.'/backups/update.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))throw new RuntimeException('Otra instalación está en curso.');try{$operation=(string)($_POST['operation']??'');$message=match($operation){'apply'=>r7_update_apply($app,$manifest),'rollback'=>r7_update_rollback($app,$manifest),default=>throw new RuntimeException('Operación desconocida.')};}finally{flock($lock,LOCK_UN);fclose($lock);}}
 $states=r7_update_states($manifest);
}catch(Throwable $ex){error_log('FISITAAP speed installer: '.get_class($ex));$error=$ex instanceof PDOException?'La base de datos no permitió preparar la actualización. Solicita revisión.':$ex->getMessage();}
?><!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actualizar FISITAAP</title><style>body{font:16px system-ui;background:#eff4f5;color:#18343f;margin:0;padding:24px}main{max-width:900px;margin:auto;background:white;padding:28px;border-radius:16px}p,li{line-height:1.6}table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #ddd;text-align:left;overflow-wrap:anywhere}.notice{padding:16px;background:#e1f4e8;border-radius:10px}.error{background:#ffebe6;color:#832d20}button,.button{display:inline-block;background:#075d83;color:white;border:0;border-radius:8px;padding:12px 18px;margin:12px 8px 0 0;font:inherit;text-decoration:none;cursor:pointer}button:disabled{opacity:.4;cursor:default}label{display:block;margin:20px 0}small{color:#546871}</style></head><body><main><h1>FISITAAP · Actualización 1.7.7</h1><p>Acelera el panel, reduce consultas del resumen, carga solo los recursos del módulo abierto y añade índices para las búsquedas frecuentes.</p><p><strong>Antes de instalar:</strong> guarda un respaldo de todos los archivos y de la base de datos desde cPanel. Detén las cajas mientras instalas. El respaldo automático de este paquete cubre los archivos que reemplaza.</p>
<?php if($message):?><p class="notice"><?=e($message)?></p><?php endif?><?php if($error):?><p class="notice error"><?=e($error)?></p><?php endif?>
<?php if($states):?><h2>Comprobación de compatibilidad</h2><table><tr><th>Archivo</th><th>Estado</th></tr><?php foreach($states as $file=>$status):?><tr><td><?=e($file)?></td><td><?=e($status)?></td></tr><?php endforeach?></table><?php endif?>
<form method="post"><?=csrf_field()?><label><input type="checkbox" name="quiet_confirm" value="yes" required> Guardé un respaldo completo y las cajas están detenidas.</label><button name="operation" value="apply" <?=(!$states||in_array('distinto',$states,true)||$error)?'disabled':''?>>Instalar actualización</button><?php if(is_file(__DIR__.'/backups/latest.json')):?><button name="operation" value="rollback" onclick="return confirm('Solo se puede volver atrás antes de usar las funciones nuevas. ¿Continuar?')">Volver atrás antes de usarla</button><?php endif?></form><p><a class="button" href="<?=e(url('master'))?>">Abrir panel maestro</a></p><small>Si aparece «distinto», la instalación se detiene para conservar tus cambios. Si ya usaste las funciones nuevas, volver atrás necesita revisar el respaldo completo y las ventas de Windows.</small></main></body></html>
