'use strict';
const {app, BrowserWindow, dialog, safeStorage, Menu} = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const {createLocalServer} = require('./server');
let service;
app.requestSingleInstanceLock() || app.quit();
app.on('second-instance', () => { const w=BrowserWindow.getAllWindows()[0]; if(w){w.restore();w.focus();} });
app.whenReady().then(async () => {
  const dir=app.getPath('userData');
  service=await createLocalServer({dataDir:dir, port:18766, tokenCodec:{
    encode: token => {if(!safeStorage.isEncryptionAvailable())throw new Error('Windows no permite proteger la conexión. Revisa tu sesión de Windows.');return safeStorage.encryptString(token).toString('base64');},
    decode: value => safeStorage.decryptString(Buffer.from(value,'base64'))
  }});
  const modeFile=path.join(dir,'modo.json');
  const clientURL=value=>{const u=new URL(value);if(u.protocol!=='http:'||!/^\d{1,3}(\.\d{1,3}){3}$/.test(u.hostname)||u.port!=='18766'||u.username||u.password||u.hostname.split('.').some(x=>Number(x)>255)||! /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u.hostname))throw new Error('El archivo debe señalar un equipo central de la red del local.');return u.origin;};
  let win;
  const open=url=>{
    const previous=win;
    win=new BrowserWindow({width:1360,height:900,minWidth:900,minHeight:650,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
    previous?.close();
    const origin=new URL(url).origin;
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    win.webContents.on('will-navigate',(event,destination)=>{if(new URL(destination).origin!==origin)event.preventDefault();});
    win.webContents.session.setPermissionRequestHandler((_web,_permission,callback)=>callback(false));
    win.loadURL(url);
  };
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {label:'FISITAAP',submenu:[
      {label:'Usar este equipo como central',click:()=>{fs.rmSync(modeFile,{force:true});open(service.url);}},
      {label:'Conectar a otro equipo central',click:async()=>{
        const selected=await dialog.showOpenDialog({title:'Selecciona el archivo de conexión que descargaste del equipo central',properties:['openFile'],filters:[{name:'Conexión FISITAAP',extensions:['fisitaap']} ]});
        if(selected.canceled)return;
        try{const data=JSON.parse(fs.readFileSync(selected.filePaths[0],'utf8'));const url=clientURL(data.url);fs.writeFileSync(modeFile,JSON.stringify({url}),{mode:0o600});open(url);}
        catch(error){dialog.showErrorBox('No se pudo conectar',error.message);}
      }},
      {label:'Abrir carpeta de respaldos',click:()=>require('electron').shell.openPath(path.join(dir,'backups'))},
      {type:'separator'},{role:'quit',label:'Salir'}
    ]},
    {label:'Edición',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'}]},
    {label:'Vista',submenu:[{role:'reload',label:'Recargar'},{role:'zoomIn'},{role:'zoomOut'},{role:'resetZoom'}]},
    {label:'Imprimir',submenu:[{label:'Imprimir comprobante visible',click:()=>win?.webContents.print({printBackground:true})}]}
  ]));
  let destination=service.url;if(fs.existsSync(modeFile)){try{destination=clientURL(JSON.parse(fs.readFileSync(modeFile,'utf8')).url);}catch{fs.rmSync(modeFile,{force:true});}}open(destination);
}).catch(error=>{dialog.showErrorBox('FISITAAP no pudo abrir',error.message);app.quit();});
app.on('before-quit',()=>service?.close());
app.on('window-all-closed',()=>app.quit());
