<?php
declare(strict_types=1);

// This installer is deliberately independent of the updated index and panel.
require dirname(__DIR__).'/app/bootstrap.php';
if (!isset($app)) exit;
$current = current_user();
if (!$current) { header('Location: '.url('owner-login')); exit; }
$user = $app->one('SELECT id,role,is_active FROM users WHERE id=?', [(int)$current['id']]);
if (!$user || !$user['is_active'] || $user['role'] !== 'master') {
    http_response_code(403); exit('Solo la cuenta maestro puede instalar esta actualización.');
}
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

const UPDATE_R1_FILES = ['app/admin.php','app/admin_v1.php','app/core.php','app/restructure_r1.php','app/v1.php','index.php'];

function update_manifest_r1(): array
{
    $manifest = json_decode((string)file_get_contents(__DIR__.'/manifest.json'), true, 512, JSON_THROW_ON_ERROR);
    if (($manifest['version']??'') !== '1.5.0-R1' || array_keys($manifest['files']??[]) !== UPDATE_R1_FILES) throw new RuntimeException('El paquete de actualización está incompleto.');
    return $manifest;
}

function update_target_r1(string $relative): string
{
    if (!in_array($relative, UPDATE_R1_FILES, true)) throw new RuntimeException('Archivo no permitido.');
    $root = realpath(ROOT_PATH);
    $target = ROOT_PATH.'/'.$relative;
    $parent = realpath(dirname($target));
    if ($parent === false || ($parent !== $root && !str_starts_with($parent, $root.DIRECTORY_SEPARATOR)) || is_link($target)) throw new RuntimeException('La ruta de instalación no es segura.');
    return $target;
}

function update_file_state_r1(array $manifest): array
{
    $states = [];
    foreach ($manifest['files'] as $relative=>$hashes) {
        $target = update_target_r1($relative);
        $actual = is_file($target) ? hash_file('sha256', $target) : null;
        $states[$relative] = $actual === $hashes['new'] ? 'actualizado' : ($actual === $hashes['old'] ? 'compatible' : 'distinto');
        if (!is_file(__DIR__.'/payload/'.$relative) || hash_file('sha256', __DIR__.'/payload/'.$relative) !== $hashes['new']) throw new RuntimeException('La integridad del paquete no coincide. Vuelve a subir el ZIP original.');
        if (!is_writable(dirname($target)) || (is_file($target) && !is_writable($target))) throw new RuntimeException('El servidor no permite actualizar '. $relative .'. Revisa los permisos desde cPanel.');
    }
    return $states;
}

function update_write_r1(string $target, string $contents): void
{
    $mode = is_file($target) ? (fileperms($target)&0777) : 0644;
    $tmp = tempnam(dirname($target), '.fisitaap-r1-');
    if ($tmp === false) throw new RuntimeException('No se pudo preparar el archivo de actualización.');
    try {
        if (file_put_contents($tmp, $contents) !== strlen($contents) || !chmod($tmp, $mode) || !rename($tmp, $target)) throw new RuntimeException('No se pudo guardar un archivo de actualización.');
        if (function_exists('opcache_invalidate')) opcache_invalidate($target, true);
    } finally { if (is_file($tmp)) unlink($tmp); }
}

function update_restore_files_r1(string $backup, array $record): void
{
    // Restore the front controller first; it will no longer require the newly added helper.
    foreach (['index.php','app/admin.php','app/admin_v1.php','app/core.php','app/v1.php','app/restructure_r1.php'] as $relative) {
        $target = update_target_r1($relative);
        if ($record['files'][$relative] === null) {
            if (is_file($target) && !unlink($target)) throw new RuntimeException('No se pudo retirar el archivo nuevo.');
        } else update_write_r1($target, (string)file_get_contents($backup.'/'.$relative));
    }
}

function update_apply_r1(App $app, array $manifest): string
{
    $states = update_file_state_r1($manifest);
    if (in_array('distinto', $states, true)) throw new RuntimeException('Hay archivos diferentes a la copia que revisamos. No se ha reemplazado nada. Descarga esos archivos y solicita un paquete compatible.');
    if ($app->one("SELECT `value` FROM settings WHERE `key`='restructure_r1_active'")['value']??null) {
        if (count(array_filter($states,fn($v)=>$v==='actualizado')) === count($states)) return 'La actualización ya está instalada. No se duplicó ningún respaldo ni registro.';
        throw new RuntimeException('La actualización figura activa pero sus archivos no coinciden. Restaura o revisa la instalación.');
    }
    // An exact baseline is required for the first installation and for a genuine rollback copy.
    if (count(array_filter($states,fn($v)=>$v==='compatible')) !== count($states)) throw new RuntimeException('La copia está parcialmente actualizada. No se modificó nada; revisa el respaldo antes de continuar.');
    $backup = __DIR__.'/backups/'.gmdate('Ymd-His').'-'.bin2hex(random_bytes(6));
    if (!mkdir($backup.'/app', 0750, true)) throw new RuntimeException('No se pudo crear el respaldo.');
    $record = ['version'=>'1.5.0-R1','files'=>[],'active_before'=>'0'];
    foreach ($manifest['files'] as $relative=>$hashes) {
        $target = update_target_r1($relative);
        $record['files'][$relative] = $hashes['old'];
        if ($hashes['old'] !== null && (!copy($target, $backup.'/'.$relative) || hash_file('sha256',$backup.'/'.$relative) !== $hashes['old'])) throw new RuntimeException('No se pudo verificar el respaldo. No se actualizó la aplicación.');
    }
    if (file_put_contents($backup.'/record.json', json_encode($record, JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR)) === false) throw new RuntimeException('No se pudo registrar el respaldo.');
    $changed = false;
    try {
        $sql = (string)file_get_contents(__DIR__.'/migration.sql');
        if (hash('sha256',$sql) !== $manifest['migration_sha256']) throw new RuntimeException('El esquema del paquete no coincide.');
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $statement) $app->db->exec($statement);
        $changed = true;
        // The core and panel remain compatible before activation; install the entry point last.
        foreach (UPDATE_R1_FILES as $relative) update_write_r1(update_target_r1($relative), (string)file_get_contents(__DIR__.'/payload/'.$relative));
        $app->exec("INSERT INTO settings(`key`,`value`) VALUES('restructure_r1_active','1') ON DUPLICATE KEY UPDATE `value`='1'");
        if (file_put_contents(__DIR__.'/backups/latest.json', json_encode(['directory'=>basename($backup)],JSON_THROW_ON_ERROR)) === false) throw new RuntimeException('No se pudo registrar la ruta de restauración.');
        return 'Actualización 1.5.0-R1 instalada. El respaldo de los archivos se guardó correctamente. Puedes abrir el panel.';
    } catch (Throwable $e) {
        $app->exec("INSERT INTO settings(`key`,`value`) VALUES('restructure_r1_active','0') ON DUPLICATE KEY UPDATE `value`='0'");
        if ($changed) update_restore_files_r1($backup, $record);
        throw $e;
    }
}

function update_rollback_r1(App $app, array $manifest): string
{
    $latest = json_decode((string)file_get_contents(__DIR__.'/backups/latest.json'),true,512,JSON_THROW_ON_ERROR);
    $directory = (string)($latest['directory']??'');
    if (!preg_match('/^[0-9]{8}-[0-9]{6}-[a-f0-9]{12}$/', $directory)) throw new RuntimeException('No se encontró un respaldo válido de esta actualización.');
    $backup = __DIR__.'/backups/'.$directory;
    $record = json_decode((string)file_get_contents($backup.'/record.json'),true,512,JSON_THROW_ON_ERROR);
    if (($record['version']??'') !== '1.5.0-R1' || array_keys($record['files']??[]) !== UPDATE_R1_FILES) throw new RuntimeException('El registro de respaldo no es válido.');
    foreach ($manifest['files'] as $relative=>$hashes) {
        $target = update_target_r1($relative);
        if (!is_file($target) || hash_file('sha256',$target) !== $hashes['new']) throw new RuntimeException('Hay cambios posteriores a esta actualización. No se sobrescribirán; solicita revisión antes de restaurar.');
        if ($record['files'][$relative] !== $hashes['old']) throw new RuntimeException('El registro de respaldo no corresponde al paquete.');
        if ($hashes['old'] !== null && (!is_file($backup.'/'.$relative) || hash_file('sha256',$backup.'/'.$relative) !== $hashes['old'])) throw new RuntimeException('El respaldo está incompleto o fue modificado.');
        if (!is_writable(dirname($target)) || !is_writable($target)) throw new RuntimeException('No se pueden restaurar los archivos por sus permisos.');
    }
    $app->db->beginTransaction();
    try {
        // Keep the new tables inert for a future reinstall; never drop business records.
        $app->exec("UPDATE users u JOIN fisitaap_r1_user_roles a ON a.user_id=u.id AND a.tenant_id=u.tenant_id SET u.role=a.previous_role WHERE u.role='manager' AND a.previous_role IN ('manager','editor','kitchen','cashier')");
        $app->exec('DELETE FROM fisitaap_r1_user_roles');
        $app->exec("UPDATE settings SET `value`='0' WHERE `key`='restructure_r1_active'");
        $app->db->commit();
    } catch (Throwable $e) { if ($app->db->inTransaction()) $app->db->rollBack(); throw $e; }
    update_restore_files_r1($backup, $record);
    return 'Se restauraron los archivos anteriores y los perfiles originales de los colaboradores. Los productos, clientes y ventas no se eliminaron.';
}

$message = '';
$error = '';
$states = [];
try {
    if (PHP_VERSION_ID < 80100 || !extension_loaded('pdo_mysql') || !extension_loaded('mbstring')) throw new RuntimeException('Se requiere PHP 8.1 o superior con PDO MySQL y mbstring.');
    $manifest = update_manifest_r1();
    if (is_post()) {
        $submittedToken = (string)($_POST['csrf']??'');
        if (!hash_equals((string)($_SESSION['csrf']??''), $submittedToken) || $submittedToken === '') json_response(['ok'=>false,'error'=>'Sesión vencida. Recarga la página.'],403);
        if (($_POST['quiet_confirm']??'') !== 'yes') throw new RuntimeException('Confirma que tienes un respaldo completo y que las cajas no están en uso.');
        if (!is_dir(__DIR__.'/backups') && !mkdir(__DIR__.'/backups',0750,true)) throw new RuntimeException('No se pudo preparar la carpeta de respaldos.');
        $lock = fopen(__DIR__.'/backups/update.lock','c');
        if (!$lock || !flock($lock, LOCK_EX|LOCK_NB)) throw new RuntimeException('Otra instalación está en curso. Espera y vuelve a intentar.');
        try {
            $operation = (string)($_POST['operation']??'');
            if ($operation === 'apply') $message = update_apply_r1($app,$manifest);
            elseif ($operation === 'rollback') $message = update_rollback_r1($app,$manifest);
            else throw new RuntimeException('Operación desconocida.');
        } finally { flock($lock,LOCK_UN); fclose($lock); }
    }
    $states = update_file_state_r1($manifest);
} catch (Throwable $e) {
    error_log('FISITAAP R1 installer: '.get_class($e));
    $error = $e instanceof PDOException ? 'La base de datos no permitió preparar la actualización. No continúes: solicita revisión.' : $e->getMessage();
}
?><!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Actualizar FISITAAP</title>
<style>body{font:16px system-ui,sans-serif;background:#f2f6f8;color:#17313c;margin:0;padding:24px}main{max-width:780px;margin:auto;background:white;padding:28px;border-radius:16px}h1{font-size:28px}p,li{line-height:1.6}table{width:100%;border-collapse:collapse}td,th{text-align:left;border-bottom:1px solid #dde6eb;padding:12px;overflow-wrap:anywhere}.notice{padding:16px;border-radius:10px;background:#e2f4e9}.error{background:#fff0ec;color:#7f2818}button,a.button{display:inline-block;padding:12px 18px;margin:12px 8px 0 0;background:#075b86;color:white;border:0;border-radius:8px;font:inherit;text-decoration:none;cursor:pointer}button.secondary{background:#625560}label{display:block;margin:20px 0}small{color:#566975}</style></head><body><main>
<h1>Actualizar FISITAAP · 1.5.0-R1</h1>
<p>Primera entrega de la reestructuración: menús reorganizados y roles con permisos configurables.</p>
<p>Esta entrega todavía no incluye el instalador de Windows, ventas sin internet, el plano gráfico de mesas ni todas las funciones nuevas del PDF.</p>
<?php if ($message): ?><p class="notice" role="status"><?=e($message)?></p><?php endif ?>
<?php if ($error): ?><p class="notice error" role="alert"><?=e($error)?></p><?php endif ?>
<?php if ($states): ?><h2>Comprobación de archivos</h2><table><tr><th>Archivo</th><th>Estado</th></tr><?php foreach ($states as $file=>$state): ?><tr><td><?=e($file)?></td><td><?=e($state)?></td></tr><?php endforeach ?></table><?php endif ?>
<p><strong>Antes de continuar:</strong> guarda un respaldo de los archivos y de la base de datos desde cPanel. El respaldo automático de este paquete cubre solamente los archivos que reemplaza.</p>
<form method="post"><?=csrf_field()?><label><input type="checkbox" name="quiet_confirm" value="yes" required> Tengo un respaldo completo y las cajas no están en uso.</label>
<button name="operation" value="apply" <?=(!$states||in_array('distinto',$states,true)||$error)?'disabled':''?>>Instalar actualización</button>
<?php if (is_file(__DIR__.'/backups/latest.json')): ?><button class="secondary" name="operation" value="rollback" onclick="return confirm('Se restaurarán los archivos anteriores y los perfiles originales. ¿Continuar?')">Volver a la versión anterior</button><?php endif ?>
</form><p><a class="button" href="<?=e(url('master'))?>">Abrir panel maestro</a></p>
<small>Si algún archivo figura «distinto», la instalación se bloquea para preservar los cambios de tu aplicación. No reemplaces esos archivos manualmente.</small>
</main></body></html>
