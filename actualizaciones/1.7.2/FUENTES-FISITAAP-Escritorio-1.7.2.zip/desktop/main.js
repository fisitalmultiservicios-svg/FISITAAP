'use strict';
const {app, BrowserWindow, dialog, safeStorage, Menu, ipcMain} = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const {createLocalServer} = require('./server');
const crypto = require('node:crypto');
const {createPrintBridge,electronPrinter} = require('./print-bridge');
let service,printService;
if(!app.requestSingleInstanceLock()) {
  app.quit();
} else {
app.on('second-instance', () => { const w=BrowserWindow.getAllWindows()[0]; if(w){w.restore();w.focus();} });
app.whenReady().then(async () => {
  const dir=app.getPath('userData');
  service=await createLocalServer({dataDir:dir, port:18766, tokenCodec:{
    encode: token => {if(!safeStorage.isEncryptionAvailable())throw new Error('Windows no permite proteger la conexión. Revisa tu sesión de Windows.');return safeStorage.encryptString(token).toString('base64');},
    decode: value => safeStorage.decryptString(Buffer.from(value,'base64'))
  }});
  const printFile=path.join(dir,'impresoras.json');
  let printConfig=fs.existsSync(printFile)?JSON.parse(fs.readFileSync(printFile,'utf8')):{origin:'',printer:{type:'browser',width:80,name:''}};
  if(!printConfig.encryptedToken){if(!safeStorage.isEncryptionAvailable())throw new Error('Windows no permite proteger el código de impresión.');printConfig.encryptedToken=safeStorage.encryptString(crypto.randomBytes(32).toString('hex')).toString('base64');fs.writeFileSync(printFile,JSON.stringify(printConfig),{mode:0o600});}
  const token=()=>safeStorage.decryptString(Buffer.from(printConfig.encryptedToken,'base64'));
  printService=await createPrintBridge({dataDir:dir,allowPortConflict:true,getConfig:()=>({...printConfig,token:token()}),print:electronPrinter(require('electron'))});
  const trustedLocal=event=>{const u=new URL(event.senderFrame.url);if(!event.senderFrame.parent&&localOrigins.has(u.origin))return u;throw new Error('Abre la configuración desde el menú FISITAAP.');};
  const settingsOnly=event=>{const u=trustedLocal(event);if(u.origin!==new URL(service.url).origin||u.pathname!=='/print-settings.html')throw new Error('Abre Configurar impresoras en este equipo.');};
  const localOrigins=new Set([new URL(service.url).origin]);
  ipcMain.handle('fisitaap:printers',async event=>{settingsOnly(event);return event.sender.getPrintersAsync();});
  ipcMain.handle('fisitaap:settings',event=>{settingsOnly(event);return {origin:printConfig.origin,printer:printConfig.printer,token:token(),bridge:printService.status()};});
  ipcMain.handle('fisitaap:retry-print-bridge',event=>{settingsOnly(event);return printService.retry();});
  ipcMain.handle('fisitaap:save-settings',(event,value)=>{settingsOnly(event);const u=new URL(value.origin);if(u.protocol!=='https:'||u.username||u.password)throw new Error('Usa la dirección https:// de FISITAAP.');const width=Number(value.printer?.width);if(![58,80].includes(width))throw new Error('Selecciona papel de 58 u 80 mm.');const name=String(value.printer?.name||'').slice(0,150);printConfig={...printConfig,origin:u.origin,printer:{name,width,type:name?'usb':'browser'}};fs.writeFileSync(printFile,JSON.stringify(printConfig),{mode:0o600});return {ok:true};});
  ipcMain.handle('fisitaap:print',(event,job)=>{trustedLocal(event);return printService.print(job);});
  const modeFile=path.join(dir,'modo.json');
  const clientURL=value=>{const u=new URL(value);if(u.protocol!=='http:'||!/^\d{1,3}(\.\d{1,3}){3}$/.test(u.hostname)||u.port!=='18766'||u.username||u.password||u.hostname.split('.').some(x=>Number(x)>255)||! /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u.hostname))throw new Error('El archivo debe señalar un equipo central de la red del local.');return u.origin;};
  let win;
  const open=url=>{
    const previous=win;
    const origin=new URL(url).origin;localOrigins.add(origin);
    win=new BrowserWindow({width:1360,height:900,minWidth:900,minHeight:650,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,preload:path.join(__dirname,'preload.js')}});
    previous?.close();
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    win.webContents.on('will-navigate',(event,destination)=>{if(new URL(destination).origin!==origin)event.preventDefault();});
    win.webContents.session.setPermissionRequestHandler((_web,_permission,callback)=>callback(false));
    win.loadURL(url);
  };
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {label:'FISITAAP',submenu:[
      {label:'Usar este equipo como central',click:()=>{fs.rmSync(modeFile,{force:true});open(service.url);}},
      {label:'Abrir la versión web',click:()=>{const url=service.store.data.connection?.url;if(url)require('electron').shell.openExternal(url+'/owner-login');else dialog.showErrorBox('Conecta tu negocio','Conecta primero este equipo central con la web.');}},
      {label:'Conectar a otro equipo central',click:async()=>{
        const selected=await dialog.showOpenDialog({title:'Selecciona el archivo de conexión que descargaste del equipo central',properties:['openFile'],filters:[{name:'Conexión FISITAAP',extensions:['fisitaap']} ]});
        if(selected.canceled)return;
        try{const data=JSON.parse(fs.readFileSync(selected.filePaths[0],'utf8'));const url=clientURL(data.url);fs.writeFileSync(modeFile,JSON.stringify({url}),{mode:0o600});open(url);}
        catch(error){dialog.showErrorBox('No se pudo conectar',error.message);}
      }},
      {label:'Abrir carpeta de respaldos',click:()=>require('electron').shell.openPath(path.join(dir,'backups'))},
      {type:'separator'},{role:'quit',label:'Salir'}
    ]},
    {label:'Edición',submenu:[{role:'undo'},{role:'redo'},{type:'separator'},{role:'cut'},{role:'copy'},{role:'paste'}]},
    {label:'Vista',submenu:[{role:'reload',label:'Recargar'},{role:'zoomIn'},{role:'zoomOut'},{role:'resetZoom'}]},
    {label:'Imprimir',submenu:[{label:'Configurar impresoras',click:()=>{const w=new BrowserWindow({width:850,height:700,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,preload:path.join(__dirname,'preload.js')}});w.webContents.setWindowOpenHandler(()=>({action:'deny'}));w.webContents.on('will-navigate',(e,url)=>{if(url!==service.url+'/print-settings.html')e.preventDefault();});w.loadURL(service.url+'/print-settings.html');}},{label:'Imprimir comprobante visible',click:()=>win?.webContents.print({printBackground:true})}]}
  ]));
  let destination=service.url;if(fs.existsSync(modeFile)){try{destination=clientURL(JSON.parse(fs.readFileSync(modeFile,'utf8')).url);}catch{fs.rmSync(modeFile,{force:true});}}open(destination);
}).catch(error=>{dialog.showErrorBox('FISITAAP no pudo abrir',error.message);app.quit();});
app.on('before-quit',()=>{service?.close();printService?.close();});
app.on('window-all-closed',()=>app.quit());
}
