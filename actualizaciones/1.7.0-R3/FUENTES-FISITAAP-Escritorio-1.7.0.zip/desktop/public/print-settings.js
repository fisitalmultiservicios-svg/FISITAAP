'use strict';
(async()=>{
  const form=document.getElementById('printSettingsForm'),status=document.getElementById('printStatus');
  if(!window.fisitaapWindows){status.textContent='Abre esta pantalla desde el menú Impresión del programa Windows.';return;}
  try{
    const settings=await window.fisitaapWindows.settings(),printers=await window.fisitaapWindows.printers();
    form.elements.origin.value=settings.origin||'';form.elements.token.value=settings.token;form.elements.width.value=String(settings.printer?.width||80);
    for(const printer of printers){const o=document.createElement('option');o.value=printer.name;o.textContent=printer.displayName||printer.name;form.elements.printer.append(o);}
    form.elements.printer.value=settings.printer?.name||'';
    form.onsubmit=async event=>{event.preventDefault();try{const data=Object.fromEntries(new FormData(form));await window.fisitaapWindows.saveSettings({origin:data.origin,printer:{name:data.printer,width:Number(data.width),type:data.printer?'usb':'browser'}});status.textContent='Configuración guardada. Ya puedes imprimir desde la web y desde la caja local.';}catch(error){status.textContent=error.message;}};
  }catch(error){status.textContent=error.message;}
})();
