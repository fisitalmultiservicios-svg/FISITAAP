'use strict';
const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {createPrintBridge,normalizeJob,receiptHTML}=require('../print-bridge');
test('printer jobs validate paper, escape text and retain routing',()=>{
 assert.throws(()=>normalizeJob({id:'1',text:'Test',width:72}));
 const job=normalizeJob({id:'1',text:'<script>attack()</script>',printer:{type:'network',host:'192.168.1.70',width:58}});
 assert.equal(job.printer.host,'192.168.1.70');assert(receiptHTML(job).includes('&lt;script&gt;'));assert(!receiptHTML(job).includes('<script>'));
});
test('authenticated loopback bridge sends once, survives restart and does not expose PDFs cross-site',async()=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'fisitaap-print-')),cfg={token:'a'.repeat(64),origin:'https://web.test'};let prints=0;
 const print=async(job,{pdfFile})=>{prints++;fs.writeFileSync(pdfFile,'%PDF-1.7 fixture');return {status:'pdf_created'};};let service=await createPrintBridge({dataDir,port:0,getConfig:()=>cfg,print});
 const send=async(job,token=cfg.token,origin=cfg.origin)=>{const r=await fetch('http://127.0.0.1:'+service.port+'/print',{method:'POST',headers:{Origin:origin,'x-fisitaap-token':token,'Content-Type':'application/json'},body:JSON.stringify(job)});return {status:r.status,data:await r.json()};};
 const close=()=>new Promise(r=>service.server.close(r));
 try{
  const job={id:'sale-123',text:'Venta 123\nTOTAL CRC 1.243,01'};
  assert.equal((await send(job,'bad')).status,403);assert.equal((await send(job,cfg.token,'https://attacker.test')).status,403);
  const both=await Promise.all([send(job),send(job)]);assert.equal(prints,1);assert(both.every(r=>r.status===200));assert(both.some(r=>r.data.duplicate));
  const changed=await send({...job,text:'Changed'});assert.equal(changed.status,422);assert.equal(prints,1);
  await close();service=await createPrintBridge({dataDir,port:0,getConfig:()=>cfg,print});assert.equal((await send(job)).data.duplicate,true);assert.equal(prints,1);
  const url='http://127.0.0.1:'+service.port+both[0].data.pdf_url;assert.equal((await fetch(url)).status,403);const pdf=await fetch(url,{headers:{Origin:cfg.origin,'x-fisitaap-token':cfg.token}});assert.equal(pdf.status,200);assert((await pdf.text()).startsWith('%PDF'));
 }finally{await close();fs.rmSync(dataDir,{recursive:true,force:true});}
});
test('uncertain printer delivery requires deliberate reprint instead of sending twice',async()=>{
 const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'fisitaap-uncertain-'));let attempts=0;const s=await createPrintBridge({dataDir,port:0,print:async()=>{attempts++;throw new Error('Printer unavailable');}});
 try{await assert.rejects(s.print({id:'one',text:'Test'}));await assert.rejects(s.print({id:'one',text:'Test'}),/anterior no quedó confirmado/);assert.equal(attempts,1);}finally{await new Promise(r=>s.server.close(r));fs.rmSync(dataDir,{recursive:true,force:true});}
});
