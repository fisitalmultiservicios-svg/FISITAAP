'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('fisitaapWindows',{
  printers:()=>ipcRenderer.invoke('fisitaap:printers'),
  settings:()=>ipcRenderer.invoke('fisitaap:settings'),
  saveSettings:value=>ipcRenderer.invoke('fisitaap:save-settings',value),
  print:job=>ipcRenderer.invoke('fisitaap:print',job)
});
