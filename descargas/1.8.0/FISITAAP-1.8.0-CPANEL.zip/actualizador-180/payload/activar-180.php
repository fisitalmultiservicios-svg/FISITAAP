<?php
declare(strict_types=1);
define('FISITAAP_SITE_ROOT',__DIR__);
define('FISITAAP_CODE_PREFIX','releases/1.8.0-r9');
require __DIR__.'/releases/1.8.0-r9/activar-180.php';
