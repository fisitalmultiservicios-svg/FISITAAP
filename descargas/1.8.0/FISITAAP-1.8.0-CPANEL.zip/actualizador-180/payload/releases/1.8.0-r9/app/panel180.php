<?php
declare(strict_types=1);

function qa180_groups(array $user,?array $tenant):array {
    if($user['role']==='master')return ['Plataforma'=>['dashboard'=>'Bienvenida','empresas'=>'Negocios','planes'=>'Planes y suscripciones','modules'=>'Planes y módulos','escritorio'=>'Equipos y cajas'],'Web oficial'=>['contenido'=>'Diseño y página','bienvenida'=>'Imagen de bienvenida','contactos'=>'Contactos'],'Analítica'=>['kpis'=>'KPIs','reportes'=>'Reportes'],'Administración'=>['auditoria'=>'Bitácora','configuracion'=>'Configuración','qa'=>'Comprobar sitio','cache'=>'Caché','actualizar-sistema'=>'Actualizar sistema']];
    $physical=$tenant&&physical_store_v14($tenant);$groups=['Inicio'=>['dashboard'=>'Bienvenida'],'Catálogo'=>['categorias'=>'Categorías','productos'=>'Productos','extras'=>'Extras','opcionales'=>'Opcionales','combos'=>'Combos','promociones'=>'Promociones','pedidos'=>'Pedidos','cocina'=>'Cocina / monitor']];
    if($physical){$groups['Ventas']=['ventas'=>'Venta rápida','turnos'=>'Turnos'];if(($tenant['catalog_label']??'')==='Menú')$groups['Ventas']+=['mesas'=>'Mesas','cobro'=>'Cobrar cuentas','express-pendientes'=>'Express pendientes'];}
    $groups['Clientes']=['clientes-crear'=>'Crear cliente','clientes-buscar'=>'Buscar clientes','clientes-historial'=>'Historial','fidelizacion'=>'Fidelización'];if($physical)$groups['Clientes']+=['credito'=>'Crédito','cxc'=>'Cuentas por cobrar'];
    if($physical)$groups['Compras']=['proveedores'=>'Proveedores','compras'=>'Compras','cxp'=>'Cuentas por pagar','inventario'=>'Inventario'];
    $groups['Analítica']=['kpis'=>'KPIs','reportes'=>'Reportes'];$groups['Administración']=['configuracion'=>'Generales','sucursales'=>'Sucursales','contenido'=>'Diseño web','roles'=>'Roles y permisos','usuarios'=>'Usuarios','delivery'=>'Zonas de envío'];
    if($physical){$groups['Administración']+=['salones'=>'Salones y mesas','impresion'=>'Impresión','escritorio'=>'Equipos y cajas','cuentas-dinero'=>'Cuentas de dinero'];$groups['Entregas']=['afiliados'=>'Afiliados','invitaciones'=>'Invitaciones','entregas-historial'=>'Historial'];}
    $groups['Otros recursos']=['contactos'=>'Contactos','auditoria'=>'Bitácora'];if($user['role']==='tenant_admin')$groups['Administración']['actualizar-sistema']='Actualizar sistema';return $groups;
}

function qa180_welcome(App $app,array $user,?array $tenant):void {
    admin_shell_start('Bienvenida',$user,$tenant,'dashboard',true);$image=(string)r2_setting($app,0,'welcome_image180');
    if($user['role']==='master')echo '<div class="qa180-welcome-actions"><a class="btn btn-light" href="'.e(url('master/bienvenida')).'">Cambiar imagen de bienvenida</a></div>';
    echo '<section class="qa180-welcome" aria-label="Bienvenida a FISITAAP">';
    if($image)echo '<img src="'.e(public_media_url($image)).'" alt="Bienvenido a FISITAAP">';
    else echo '<div class="qa180-welcome-ad"><img src="'.e(url('assets/fisitapp-logo.webp')).'" alt="FISITAAP"><h1>Tu negocio, al día.</h1><p>Vende, atiende y organiza desde un solo lugar.</p><span>Web · Windows · Android</span></div>';
    echo '</section>';admin_shell_end();
}
function qa180_welcome_upload_limit():int {
    $limits=[5*1024*1024];
    $upload=ini_parse_quantity((string)ini_get('upload_max_filesize'));
    $post=ini_parse_quantity((string)ini_get('post_max_size'));
    if($upload>0)$limits[]=$upload;
    if($post>0)$limits[]=max(1,$post-65536); // Leave room for multipart fields.
    return min($limits);
}
function qa180_welcome_uploaded_image():string {
    $file=$_FILES['image']??null;
    if(!is_array($file)||is_array($file['error']??null)||!isset($file['error']))throw new DomainException('Elige una imagen antes de guardar. No se cambió tu bienvenida.');
    $error=(int)$file['error'];
    if(in_array($error,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true))throw new DomainException('El servidor rechazó la imagen por su tamaño. Elige una de hasta '.number_format(qa180_welcome_upload_limit()/1048576,1,',','').' MB. No se cambió tu bienvenida.');
    if($error===UPLOAD_ERR_NO_FILE)throw new DomainException('Elige una imagen antes de guardar. No se cambió tu bienvenida.');
    if($error!==UPLOAD_ERR_OK)throw new DomainException('No se recibió la imagen completa. Intenta cargarla de nuevo. No se cambió tu bienvenida.');
    if(!is_string($file['tmp_name']??null)||$file['tmp_name']===''||!is_file($file['tmp_name']))throw new DomainException('No se recibió la imagen. Intenta cargarla de nuevo. No se cambió tu bienvenida.');
    if((int)($file['size']??0)>qa180_welcome_upload_limit())throw new DomainException('La imagen supera el tamaño permitido. No se cambió tu bienvenida.');
    try{$image=upload_image('image');}catch(RuntimeException $error){throw new DomainException($error->getMessage().' No se cambió tu bienvenida.');}
    if(!$image)throw new DomainException('No se recibió la imagen. Intenta cargarla de nuevo. No se cambió tu bienvenida.');
    return $image;
}
function qa180_welcome_editor(App $app,array $user):void {
    if(is_post()){
        $postLimit=ini_parse_quantity((string)ini_get('post_max_size'));
        if($postLimit>0&&(int)($_SERVER['CONTENT_LENGTH']??0)>$postLimit){
            // PHP discards both POST and FILES when its request limit is exceeded.
            // Reject it without writing settings; there is no CSRF token to read.
            flash('error','La carga supera el límite del servidor. Elige una imagen más pequeña. No se cambió tu bienvenida.');redirect(url('master/bienvenida'));
        }
        verify_csrf();
        try{
            $clear=!empty($_POST['clear']);$file=$_FILES['image']??null;
            if($clear&&is_array($file)&&(int)($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE)throw new DomainException('Para subir una imagen, desmarca «Usar publicidad predeterminada». No se cambió tu bienvenida.');
            $image=$clear?'':qa180_welcome_uploaded_image();
            $app->db->beginTransaction();
            r2_set($app,0,'welcome_image180',$image);
            $saved=$app->one('SELECT value FROM fisitaap_r2_settings WHERE tenant_id=0 AND setting_key=?',['welcome_image180']);
            if(!$saved||(string)$saved['value']!==$image)throw new RuntimeException('Welcome image was not persisted');
            audit($app,null,(int)$user['id'],'welcome_image','configuration',null);
            $app->db->commit();
            flash('success',$clear?'Se restauró la bienvenida predeterminada.':'Bienvenida guardada. La imagen se mostrará en todos los negocios al abrir su bienvenida.');
        }catch(DomainException $error){if($app->db->inTransaction())$app->db->rollBack();flash('error',$error->getMessage());}
        catch(Throwable $error){if($app->db->inTransaction())$app->db->rollBack();error_log('FISITAAP welcome image: '.get_class($error));flash('error','No se pudo guardar la bienvenida. Intenta de nuevo o revisa la configuración con soporte.');}
        redirect(url('master/bienvenida'));
    }
    admin_shell_start('Imagen de bienvenida',$user,null,'contenido');
    echo '<p><a class="btn btn-light" href="'.e(url('master')).'">Ver bienvenida publicada</a></p>';
    $current=r2_setting($app,0,'welcome_image180');
    if($current!=='')echo '<section class="card admin-card"><h2>Imagen actual</h2><img src="'.e(public_media_url($current)).'" alt="Imagen de bienvenida actual" style="display:block;width:100%;max-height:280px;object-fit:contain"></section>';
    else echo '<section class="card admin-card"><p>Actualmente se muestra la bienvenida predeterminada. Aún no hay una imagen personalizada guardada para esta pantalla.</p></section>';
    echo '<section class="card admin-card"><p>Esta imagen se muestra dentro del panel de todos los negocios, incluso si tienen pendiente activar 1.8.0. La imagen de la portada pública se configura por separado en Diseño y página.</p><p>Usa una imagen horizontal JPG, PNG o WebP de hasta '.number_format(qa180_welcome_upload_limit()/1048576,1,',','').' MB. Se optimiza al guardarla y llena el espacio disponible sin deformarse; puede recortar los bordes.</p><form method="post" enctype="multipart/form-data">'.csrf_field().'<input type="hidden" name="MAX_FILE_SIZE" value="'.qa180_welcome_upload_limit().'"><label>Imagen<input class="input" type="file" name="image" accept="image/jpeg,image/png,image/webp"></label><label><input type="checkbox" name="clear"> Usar publicidad predeterminada de FISITAAP</label><button class="btn">Guardar bienvenida</button></form></section>';admin_shell_end();
}
function qa180_contacts(App $app,array $user,?array $tenant):void {
    $prefix=$tenant?'admin':'master';$scope=$tenant?'tenant_id=?':'tenant_id IS NULL';$args=$tenant?[$tenant['id']]:[];$selected=(int)($_GET['id']??$_POST['id']??0);
    if(is_post()){verify_csrf();try{if($tenant)qa180_permission($app,$user,'contactos','write');$status=(string)($_POST['status']??'');if(!in_array($status,['new','read','resolved'],true))throw new DomainException('Estado no disponible.');$row=$app->one('SELECT id FROM contacts WHERE id=? AND '.$scope,[$selected,...$args]);if(!$row)throw new DomainException('Este mensaje no está disponible.');$app->exec('UPDATE contacts SET status=? WHERE id=? AND '.$scope,[$status,$selected,...$args]);audit($app,$tenant?(int)$tenant['id']:null,(int)$user['id'],'contact_status','contact',$selected);flash('success','Estado guardado.');}catch(Throwable $error){flash('error',$error->getMessage());}redirect(url($prefix.'/contactos?id='.$selected));}
    $q=mb_substr(trim((string)($_GET['q']??'')),0,100);$filter=(string)($_GET['status']??'');$where=$scope;$params=$args;
    if($q!==''){$where.=' AND (name LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)';array_push($params,...array_fill(0,4,'%'.$q.'%'));}
    if(in_array($filter,['new','read','resolved'],true)){$where.=' AND status=?';$params[]=$filter;}
    $rows=$app->all('SELECT id,name,email,subject,status,created_at,LEFT(message,100) excerpt FROM contacts WHERE '.$where.' ORDER BY created_at DESC,id DESC LIMIT 200',$params);$detail=$selected?$app->one('SELECT * FROM contacts WHERE id=? AND '.$scope,[$selected,...$args]):null;
    admin_shell_start('Contactos',$user,$tenant,'contactos');echo '<section class="card admin-card"><form class="qa180-filter" method="get">'.field('Buscar en mensajes','q',$q).'<label>Estado<select class="input" name="status"><option value="">Todos</option>';foreach(['new'=>'Nuevos','read'=>'Leídos','resolved'=>'Resueltos'] as $key=>$label)echo '<option value="'.$key.'" '.($filter===$key?'selected':'').'>'.$label.'</option>';echo '</select></label><button class="btn">Buscar</button></form></section><div class="qa180-inbox"><section class="card admin-card qa180-inbox-list">';
    foreach($rows as $row)echo '<a class="qa180-message '.($selected===(int)$row['id']?'selected':'').' '.($row['status']==='new'?'unread':'').'" href="'.e(url($prefix.'/contactos?id='.$row['id'].'&status='.rawurlencode($filter).'&q='.rawurlencode($q))).'"><span>'.e($row['name']).'<small>'.e($row['created_at']).'</small></span><strong>'.e($row['subject']).'</strong><p>'.e($row['excerpt']).'</p></a>';
    if(!$rows)echo '<p>No hay mensajes con estos filtros.</p>';echo '</section><section class="card admin-card qa180-reading">';
    if($detail){echo '<h2>'.e($detail['subject']).'</h2><p><strong>'.e($detail['name']).'</strong> · '.e($detail['email']).'<br>'.e($detail['phone']).' · '.e($detail['created_at']).'</p><div class="qa180-message-body">'.nl2br(e($detail['message'])).'</div>'.r2_form('status',$selected).'<label>Estado<select class="input" name="status">';foreach(['new'=>'Nuevo','read'=>'Leído','resolved'=>'Resuelto'] as $key=>$label)echo '<option value="'.$key.'" '.($detail['status']===$key?'selected':'').'>'.$label.'</option>';echo '</select></label><button class="btn btn-light">Guardar estado</button></form>';}
    else echo '<h2>Bandeja de mensajes</h2><p>Selecciona un contacto para leerlo y cambiar su estado.</p>';echo '</section></div>';admin_shell_end();
}
function qa180_audit_label(string $action):string {
    return ['login'=>'Inició sesión','logout'=>'Cerró sesión','pos_payment'=>'Cobró una venta','pos_open'=>'Abrió una cuenta de venta','pos_quantity'=>'Cambió la cantidad de un producto','pos_void'=>'Canceló una venta','pos_send_kitchen'=>'Envió una comanda','r2_purchase'=>'Recibió una compra','r2_account_payment'=>'Registró un abono','update_settings'=>'Actualizó la configuración del negocio','r2_combo'=>'Guardó un combo','r2_modifier'=>'Guardó un extra u opcional','r3_print_copy'=>'Reimprimió una copia','print_copy'=>'Reimprimió una copia','contact_status'=>'Cambió el estado de un contacto','welcome_image'=>'Cambió la imagen de bienvenida','activate180'=>'Activó la actualización 1.8.0','update180'=>'Actualizó el negocio a 1.8.0','publish180'=>'Publicó la actualización 1.8.0'][$action]??ucfirst(str_replace('_',' ',preg_replace('/^r\d+_/','',$action)??$action));
}
function qa180_log(App $app,array $user,?array $tenant):void {
    [$from,$to]=valid_report_dates_v1();$who=(int)($_GET['user_id']??0);$q=mb_substr(trim((string)($_GET['q']??'')),0,100);$tid=$tenant?(int)$tenant['id']:(int)($_GET['tenant_id']??0);
    $where='a.user_id IS NOT NULL AND a.created_at>=? AND a.created_at<DATE_ADD(?,INTERVAL 1 DAY) AND a.action NOT IN("cache_clear","automatic_sync","snapshot","heartbeat","rate_limit")';$params=[$from,$to];
    if($tid){$where.=' AND a.tenant_id=?';$params[]=$tid;}if($who){$where.=' AND a.user_id=?';$params[]=$who;}if($q!==''){$where.=' AND (a.summary LIKE ? OR a.action LIKE ? OR u.name LIKE ?)';array_push($params,...array_fill(0,3,'%'.$q.'%'));}
    $rows=$app->all('SELECT a.*,u.name user_name,t.name tenant_name FROM audit_logs a JOIN users u ON u.id=a.user_id LEFT JOIN tenants t ON t.id=a.tenant_id WHERE '.$where.' ORDER BY a.id DESC LIMIT 400',$params);
    admin_shell_start('Bitácora',$user,$tenant,'auditoria');echo '<section class="card admin-card"><p>Acciones de usuarios. Las lecturas y tareas automáticas no generan entradas nuevas.</p><form class="qa180-filter" method="get">'.field('Desde','from',$from,true,'date').field('Hasta','to',$to,true,'date').field('Buscar acción o usuario','q',$q).'<button class="btn">Filtrar</button></form><div class="table-wrap"><table class="table"><tr><th>Fecha</th>'.(!$tenant?'<th>Negocio</th>':'').'<th>Usuario</th><th>Acción</th><th>Referencia</th></tr>';
    foreach($rows as $row)echo '<tr><td>'.e($row['created_at']).'</td>'.(!$tenant?'<td>'.e($row['tenant_name']??'Plataforma').'</td>':'').'<td>'.e($row['user_name']).'</td><td>'.e($row['summary']?:qa180_audit_label($row['action'])).'</td><td>'.e(($row['entity_type']??'').' #'.($row['entity_id']??'')).'</td></tr>';echo '</table></div></section>';admin_shell_end();
}
