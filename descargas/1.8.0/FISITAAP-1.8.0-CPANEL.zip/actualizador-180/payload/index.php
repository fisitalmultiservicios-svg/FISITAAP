<?php
declare(strict_types=1);
define('FISITAAP_SITE_ROOT',__DIR__);
define('FISITAAP_CODE_PREFIX','releases/1.8.0-r5');
require __DIR__.'/releases/1.8.0-r5/index.php';
