"""Construye el ZIP DIFERENCIAL de Clínicas sobre el archivo oficial 4.22, sin leer datos persistentes.

python tools/construir_clinicas.py --base-zip '/ruta/FISITAAP ERP - V4.22.zip'
"""
import argparse
import ast
import hashlib
import json
import zipfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
BASE_SHA256 = "a48406d04df00351d690bc4568e611b17449ff8a5035740cc0513fc0bacd20ad"
ARCHIVOS = (
    "app/auth.py", "app/clinicas.py", "app/clinicas_modelos.py", "app/db.py", "app/inventario.py",
    "app/main.py", "app/planes.py", "app/respaldo.py", "app/static/js/app.js", "app/static/js/menu.js",
    "app/static/js/pages/clinicas/index.js", "app/static/js/pages/ventas/factura-form.js", "NOVEDADES.txt",
    "ACTUALIZAR_CLINICAS.md", "docs/CLINICAS_ALCANCE.md", "docs/CLINICAS_VALIDACION.md",
    "tests/test_clinicas.py", "tests/test_permisos.py", "tests/test_planes.py", "tests/test_rol_avanzado.py",
    "tools/verificar_clinicas.py", "tools/construir_clinicas.py",
)


def huella(datos):
    return hashlib.sha256(datos).hexdigest()


def construir(base_zip, destino):
    if huella(base_zip.read_bytes()) != BASE_SHA256:
        raise ValueError("El ZIP base no coincide con el oficial 4.22 del informe")
    if "RESULTADO: VALIDADO EN ENTORNO AISLADO" not in (RAIZ / "docs/CLINICAS_VALIDACION.md").read_text(encoding="utf-8"):
        raise ValueError("Falta el resultado final de validación de este paquete")
    contenidos = {}
    cambios = []
    with zipfile.ZipFile(base_zip) as base:
        for n in base.namelist():
            if n.endswith("/"): continue
            actual = RAIZ / n
            if not actual.is_file(): raise ValueError(f"Falta archivo de la base: {n}")
            if n not in ARCHIVOS and huella(actual.read_bytes()) != huella(base.read(n)):
                raise ValueError(f"Cambio fuera de la lista autorizada del paquete: {n}")
        for n in ARCHIVOS:
            p = RAIZ / n
            if p.is_symlink() or not p.is_file(): raise ValueError(f"Archivo ausente o enlace: {n}")
            datos = p.read_bytes()
            if p.suffix == ".py": ast.parse(datos.decode("utf-8-sig"), filename=n)
            antes = huella(base.read(n)) if n in base.namelist() else None
            despues = huella(datos)
            if antes == despues: continue
            contenidos[n] = datos
            cambios.append({"ruta": n, "antes": antes, "despues": despues, "bytes": len(datos)})
    manifiesto = {"base": "FISITAAP ERP 4.22", "base_zip_sha256": BASE_SHA256, "modulo": "clinicas-1.0-rc1",
                  "fecha": "2026-11-11", "estado": "Candidato para instalación y aceptación; no instalado en cPanel",
                  "datos_persistentes_incluidos": False, "archivos": cambios}
    manifest_bytes = (json.dumps(manifiesto, ensure_ascii=False, indent=2) + "\n").encode()
    contenidos["MANIFIESTO_CLINICAS.json"] = manifest_bytes
    destino.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for n, datos in sorted(contenidos.items()):
            info = zipfile.ZipInfo(n, date_time=(2026, 11, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, datos)
    with zipfile.ZipFile(destino) as z:
        if z.testzip() is not None: raise ValueError("Falló la comprobación CRC del ZIP")
        if set(z.namelist()) != set(contenidos): raise ValueError("El ZIP no coincide con el manifiesto")
    (RAIZ / "MANIFIESTO_CLINICAS.json").write_bytes(manifest_bytes)
    print(f"{destino.name}: {len(contenidos)} archivos; {destino.stat().st_size} bytes")
    print("SHA-256:", huella(destino.read_bytes()))
    return destino


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base-zip", required=True, type=Path)
    p.add_argument("--salida", type=Path, default=RAIZ / "dist/FISITAAP_ERP_4.22_Clinicas_1.0-rc1_actualizacion.zip")
    a = p.parse_args()
    construir(a.base_zip, a.salida)
