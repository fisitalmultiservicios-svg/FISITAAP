"""Verificación de archivos antes/después de extraer la actualización. Solo lectura; no importa app ni abre data/."""
import argparse
import hashlib
import json
import sys
from pathlib import Path


def verificar(raiz, manifiesto):
    datos = json.loads(manifiesto.read_text(encoding="utf-8"))
    errores = []
    anteriores = actualizados = nuevos = 0
    for f in datos["archivos"]:
        relativo = Path(f["ruta"])
        crudo = raiz / relativo
        p = crudo.resolve()
        if relativo.is_absolute() or not p.is_relative_to(raiz.resolve()) or "data" in relativo.parts:
            errores.append(f"Ruta no válida en manifiesto: {relativo}"); continue
        camino = raiz
        enlace = False
        for parte in relativo.parts:
            camino = camino / parte
            enlace = enlace or camino.is_symlink()
        if enlace:
            errores.append(f"No se reemplaza un enlace simbólico: {relativo}"); continue
        if not p.exists():
            if f["antes"] is None: nuevos += 1
            else: errores.append(f"Falta archivo base: {relativo}")
            continue
        actual = hashlib.sha256(p.read_bytes()).hexdigest()
        if actual == f["despues"]: actualizados += 1
        elif f["antes"] and actual == f["antes"]: anteriores += 1
        else: errores.append(f"Contenido diferente a 4.22 y a este paquete: {relativo}")
    for e in errores: print("ERROR:", e)
    print(f"Base compatible: {anteriores}; ya actualizados: {actualizados}; nuevos por copiar: {nuevos}; conflictos: {len(errores)}")
    print("Esta verificación no abre bases ni comprueba claves, credenciales o servicios externos.")
    return 1 if errores else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raiz", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--manifiesto", type=Path)
    args = parser.parse_args()
    manifiesto = args.manifiesto or Path(__file__).resolve().parent.parent / "MANIFIESTO_CLINICAS.json"
    try:
        sys.exit(verificar(args.raiz.resolve(), manifiesto))
    except (ValueError, KeyError, OSError) as ex:
        print("ERROR: no se pudo verificar:", ex); sys.exit(2)
