"""Inventario (por empresa): bodegas, existencias por bodega, capas de costo y movimientos.

Todo cambio de existencias pasa por `registrar_movimiento`, que actualiza la tabla `existencia` y deja
la traza en `movimientoinventario` (inicial, ajuste, transferencia, venta, devolución, compra).

Costeo (3.75): cada entrada con costo abre una capa (`capacosto`); cada salida consume capas y anota qué consumió
(`consumocapa`). El método de la empresa (registro `inventario_config`) decide el costo de la salida: promedio ponderado
(como siempre), PEPS (las capas más viejas primero) o UEPS (las más nuevas primero). Las capas se llevan con cualquier
método, así cambiar de método no pierde la historia; la existencia anterior a las capas sale al costo promedio que tenía.
"""
from datetime import date, datetime, timezone
from typing import Any, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field as PField
from sqlalchemy import text
from sqlmodel import Field, Session, SQLModel, select

from .auth import Contexto, contexto, sesion_empresa, requiere
from .config import ahora_cr
from .db import Documento, DocumentoLinea, Producto, por_empresa


def _fecha_mov(valor: Optional[str]) -> str:
    """Fecha del movimiento: la indicada (AAAA-MM-DD válida) o la de hoy en Costa Rica (antes date.today() del servidor) (R279)."""
    if not valor:
        return ahora_cr().date().isoformat()
    try:
        return date.fromisoformat(str(valor)[:10]).isoformat()
    except ValueError:
        raise HTTPException(400, "Fecha inválida (use AAAA-MM-DD)")


def _validar_nombre_bodega(s: Session, empresa_id: int, nombre: str, excluir_id: Optional[int] = None) -> str:
    nombre = (nombre or "").strip()
    if not nombre:
        raise HTTPException(400, "La bodega requiere nombre")
    for b in s.exec(select(Bodega).where(Bodega.empresa_id == empresa_id)).all():
        if b.id != excluir_id and (b.nombre or "").strip().lower() == nombre.lower():
            raise HTTPException(400, f"Ya existe una bodega llamada '{b.nombre}'")
    return nombre


def _bodega_activa(s: Session, empresa_id: int, bid: int) -> "Bodega":
    b = _bodega(s, empresa_id, bid)
    if not b.activa:
        raise HTTPException(400, f"La bodega '{b.nombre}' está inactiva: actívela o elija otra")   # (R280)
    return b

from .auth import con_documentos  # noqa: E402  (3.87)
router = APIRouter(prefix="/api/inventario", tags=["inventario"], dependencies=[Depends(con_documentos)])   # 3.87: costos y existencias, no para los roles operativos


# ----------------------------------------------------------------------------- modelos
class Bodega(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    nombre: str
    direccion: Optional[str] = None
    observaciones: Optional[str] = None
    principal: bool = False
    activa: bool = True


class Existencia(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    producto_id: int = Field(index=True)
    bodega_id: int = Field(index=True)
    cantidad: float = 0
    costo_promedio: float = 0


class MovimientoInventario(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    fecha: str                              # AAAA-MM-DD
    producto_id: int = Field(index=True)
    bodega_id: int = Field(index=True)
    tipo: str                               # inicial | ajuste | transferencia | venta | devolucion | compra
    cantidad: float                         # positiva = entrada, negativa = salida
    costo_unitario: float = 0
    existencia_resultante: float = 0
    referencia: Optional[str] = None        # p. ej. "AJ-0003", "FE 00100001010000000012", "TR-0002"
    documento_id: Optional[int] = None
    ajuste_id: Optional[int] = None
    observaciones: Optional[str] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AjusteInventario(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    numero: int
    fecha: str
    bodega_id: int
    tipo: str = "ajuste"                    # ajuste | transferencia
    bodega_destino_id: Optional[int] = None
    observaciones: Optional[str] = None
    total: float = 0
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    clave: Optional[str] = None             # 3.87: de dónde viene la entrada (p. ej. «compra:12», la factura de compra): no entra dos veces


class CapaCosto(SQLModel, table=True):
    """Capa de costo (3.75): cada entrada con costo abre una capa; las salidas la consumen en orden PEPS (la más vieja
    primero) o UEPS (la más nueva primero). `cantidad` es lo que queda de la capa."""
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    producto_id: int = Field(index=True)
    bodega_id: int = Field(index=True)
    fecha: str                              # AAAA-MM-DD de la entrada; FECHA_BASE = existencia anterior a las capas
    cantidad: float = 0                     # lo que queda
    cantidad_inicial: float = 0
    costo_unitario: float = 0
    movimiento_id: Optional[int] = None     # entrada que la abrió
    referencia: Optional[str] = None
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ConsumoCapa(SQLModel, table=True):
    """Qué capas consumió cada salida (3.75): la traza del costo PEPS/UEPS de una venta, ajuste o transferencia."""
    id: Optional[int] = Field(default=None, primary_key=True)
    movimiento_id: int = Field(index=True)
    capa_id: Optional[int] = Field(default=None, index=True)   # None = parte sin capa (existencia negativa): al costo promedio
    cantidad: float = 0
    costo_unitario: float = 0


por_empresa(Bodega, Existencia, MovimientoInventario, AjusteInventario, CapaCosto, ConsumoCapa)

METODOS = ("promedio", "peps", "ueps")
NOMBRE_METODO = {"promedio": "Costo promedio ponderado", "peps": "PEPS (primero en entrar, primero en salir)",
                 "ueps": "UEPS (último en entrar, primero en salir)"}
CLAVE_CONFIG = "inventario_config"
FECHA_BASE = "1900-01-01"                   # capa de la existencia que ya había antes del costeo por capas


def config_costeo(s: Session, empresa_id: int) -> dict:
    """Método de costeo de la empresa y si las compras actualizan el costo del ítem (registro `inventario_config`, 3.75)."""
    from . import modulos
    c = modulos.leer(s, empresa_id, CLAVE_CONFIG, {}) or {}
    c = c if isinstance(c, dict) else {}
    m = str(c.get("metodo") or "promedio").lower()
    return {"metodo": m if m in METODOS else "promedio", "actualizar_costo_compras": c.get("actualizar_costo_compras") is not False}


def metodo_costeo(s: Session, empresa_id: int) -> str:
    return config_costeo(s, empresa_id)["metodo"]


# ----------------------------------------------------------------------------- lógica
def bodega_principal(s: Session, empresa_id: int) -> Bodega:
    b = s.exec(select(Bodega).where(Bodega.empresa_id == empresa_id, Bodega.principal == True)).first()  # noqa: E712
    if not b:
        b = s.exec(select(Bodega).where(Bodega.empresa_id == empresa_id)).first() or Bodega(empresa_id=empresa_id, nombre="Principal")
        b.principal = True
        s.add(b); s.commit(); s.refresh(b)
    return b


def _bodega(s: Session, empresa_id: int, bid: int) -> Bodega:
    b = s.get(Bodega, bid)
    if not b or b.empresa_id != empresa_id:
        raise HTTPException(404, "Bodega no encontrada")
    return b


def existencia(s: Session, producto_id: int, bodega_id: int) -> Existencia:
    ex = s.exec(select(Existencia).where(Existencia.producto_id == producto_id, Existencia.bodega_id == bodega_id)).first()
    if not ex:
        # INSERT OR IGNORE: con el índice único ux_existencia, si otro proceso creó la fila un instante antes no se duplica
        s.execute(text("INSERT OR IGNORE INTO existencia (producto_id, bodega_id, cantidad, costo_promedio) VALUES (:p, :b, 0, 0)"),
                  {"p": producto_id, "b": bodega_id})
        ex = s.exec(select(Existencia).where(Existencia.producto_id == producto_id, Existencia.bodega_id == bodega_id)).first()
    return ex


def _consumir_capas(s: Session, producto: Producto, bodega_id: int, antes: float, costo_antes: float, q: float, metodo: str) -> tuple[list, float, float]:
    """Consume `q` unidades de las capas del producto en la bodega (PEPS: fecha e id ascendentes; UEPS: descendentes).
    La existencia que había sin capa (anterior a 3.75 o entradas de la nube) se vuelve una capa base al costo promedio, que
    con PEPS es la primera en salir y con UEPS la última. Devuelve (consumos, cantidad que queda en capas, valor que queda)."""
    capas = list(s.exec(select(CapaCosto).where(CapaCosto.producto_id == producto.id, CapaCosto.bodega_id == bodega_id, CapaCosto.cantidad > 1e-9)).all())
    disponible = sum(float(c.cantidad) for c in capas)
    if antes > disponible + 1e-9:
        # su costo: el valor de toda la existencia al promedio, menos lo que valen las capas conocidas, entre lo que no tiene capa
        q_base = antes - disponible
        valor_base = antes * costo_antes - sum(float(c.cantidad) * float(c.costo_unitario) for c in capas)
        costo_base = valor_base / q_base if costo_antes > 0 else float(producto.costo or 0)
        base = CapaCosto(empresa_id=producto.empresa_id, producto_id=producto.id, bodega_id=bodega_id, fecha=FECHA_BASE, cantidad=q_base,
                         cantidad_inicial=q_base, costo_unitario=round(max(costo_base, 0.0), 6), referencia="Existencia anterior al costeo por capas")
        s.add(base); s.flush(); capas.append(base)
    capas.sort(key=lambda c: (c.fecha or "", c.id or 0), reverse=(metodo == "ueps"))
    pendiente, consumos = q, []
    for c in capas:
        if pendiente <= 1e-9:
            break
        tomar = min(float(c.cantidad), pendiente)
        c.cantidad = float(c.cantidad) - tomar
        if c.cantidad < 1e-9:
            c.cantidad = 0.0
        s.add(c)
        consumos.append(ConsumoCapa(movimiento_id=0, capa_id=c.id, cantidad=tomar, costo_unitario=float(c.costo_unitario)))
        pendiente -= tomar
    if pendiente > 1e-9:                           # existencia negativa: esa parte no tiene capa
        consumos.append(ConsumoCapa(movimiento_id=0, capa_id=None, cantidad=pendiente, costo_unitario=costo_antes))
    restan = [c for c in capas if c.cantidad > 1e-9]
    return consumos, sum(c.cantidad for c in restan), sum(c.cantidad * float(c.costo_unitario) for c in restan)


def registrar_movimiento(s: Session, *, producto: Producto, bodega_id: int, tipo: str, cantidad: float, fecha: str,
                         costo_unitario: float | None = None, referencia: str | None = None, documento_id: int | None = None,
                         ajuste_id: int | None = None, observaciones: str | None = None, permitir_negativo: bool = False,
                         metodo: str | None = None) -> MovimientoInventario:
    """Aplica un movimiento. Las entradas con costo recalculan el costo promedio ponderado y abren una capa de costo; las
    salidas consumen capas (3.75). Con PEPS o UEPS la salida sale al costo de las capas consumidas y el costo promedio de la
    existencia pasa a ser el de lo que queda; con promedio ponderado la salida sale al promedio, como siempre."""
    if producto.es_servicio or not producto.inventariable:
        raise HTTPException(400, f"'{producto.nombre}' no es inventariable")
    ex = existencia(s, producto.id, bodega_id)
    # UPDATE atómico: suma el delta sobre el valor que hay EN LA BASE al tomar el bloqueo de escritura (no sobre el leído
    # antes). Dos ventas simultáneas del mismo producto descontaban una sola vez: cada una partía de la misma lectura.
    permitir = bool(permitir_negativo or producto.venta_negativo)
    r = s.execute(text("UPDATE existencia SET cantidad = cantidad + :d WHERE id = :id AND (:ok = 1 OR :d >= 0 OR cantidad + :d >= -1e-9)"),
                  {"d": float(cantidad), "id": ex.id, "ok": 1 if permitir else 0})
    s.refresh(ex)                                  # cantidad real después del UPDATE
    if r.rowcount == 0:
        raise HTTPException(400, f"Existencias insuficientes de '{producto.nombre}': hay {ex.cantidad:g}, se requieren {abs(cantidad):g}")
    # Clínicas: no sacar por otra vía existencias identificadas en lotes. En dispensación el lote
    # se reduce antes de este movimiento, dentro de la misma transacción. Con cero lotes no cambia la operación ERP.
    if cantidad < 0 and s.execute(text("SELECT 1 FROM sqlite_master WHERE type='table' AND name='clinica_lote'")).scalar():
        identificado = s.execute(text("SELECT COALESCE(SUM(cantidad), 0) FROM clinica_lote WHERE empresa_id=:e AND producto_id=:p AND bodega_id=:b"),
                                 {"e": producto.empresa_id, "p": producto.id, "b": bodega_id}).scalar()
        if float(identificado or 0) > 0 and ex.cantidad < float(identificado) - 1e-9:
            raise HTTPException(409, "Esta salida consumiría existencias identificadas por lotes clínicos. Use Farmacia o ajuste primero la identificación del lote con su motivo")
    nueva = float(ex.cantidad)
    antes = nueva - float(cantidad)
    costo_antes = float(ex.costo_promedio or 0)
    metodo = metodo if metodo in METODOS else metodo_costeo(s, producto.empresa_id)
    costo_mov = float(costo_unitario) if costo_unitario is not None else costo_antes
    capa, consumos = None, []
    if cantidad > 0:
        con_costo = costo_unitario is not None and costo_unitario >= 0
        if con_costo:
            base = max(antes, 0)
            ex.costo_promedio = (base * costo_antes + cantidad * costo_unitario) / (base + cantidad) if (base + cantidad) else costo_unitario
            s.add(ex)
        # una entrada sin costo (devolución) vuelve al costo promedio que había, o al de referencia del ítem si no había
        costo_capa = float(costo_unitario) if con_costo else (costo_antes if costo_antes > 0 else float(producto.costo or 0))
        if not con_costo:
            costo_mov = costo_capa
        q_capa = max(0.0, min(float(cantidad), nueva))             # con existencia negativa, lo ya vendido no abre capa
        if q_capa > 1e-9:
            capa = CapaCosto(empresa_id=producto.empresa_id, producto_id=producto.id, bodega_id=bodega_id, fecha=fecha, cantidad=q_capa,
                             cantidad_inicial=q_capa, costo_unitario=costo_capa, referencia=referencia)
    elif cantidad < 0:
        q = -float(cantidad)
        consumos, q_restan, valor_restan = _consumir_capas(s, producto, bodega_id, antes, costo_antes, q, metodo)
        if metodo in ("peps", "ueps"):
            # lo que salió de capas va al costo de esas capas; la parte sin capa (existencia negativa) al costo indicado o al promedio
            resto = float(costo_unitario) if costo_unitario is not None else costo_antes
            for c in consumos:
                if c.capa_id is None:
                    c.costo_unitario = resto
            costo_mov = round(sum(c.cantidad * c.costo_unitario for c in consumos) / q, 6) if q else costo_antes
            if nueva > 1e-9 and q_restan > 1e-9 and abs(q_restan - nueva) < 1e-6:
                ex.costo_promedio = valor_restan / q_restan; s.add(ex)
        else:
            for c in consumos:
                if c.capa_id is None:
                    c.costo_unitario = costo_mov
    mov = MovimientoInventario(empresa_id=producto.empresa_id, fecha=fecha, producto_id=producto.id, bodega_id=bodega_id, tipo=tipo,
                               cantidad=cantidad, costo_unitario=costo_mov, existencia_resultante=nueva, referencia=referencia,
                               documento_id=documento_id, ajuste_id=ajuste_id, observaciones=observaciones)
    s.add(mov); s.flush()
    if capa is not None:
        capa.movimiento_id = mov.id; s.add(capa)
    for c in consumos:
        c.movimiento_id = mov.id; s.add(c)
    if capa is not None or consumos:
        s.flush()
    return mov


def capas_de(s: Session, empresa_id: int, producto_id: int, bodega_id: int | None = None) -> list[CapaCosto]:
    """Capas con existencia de un producto (todas las bodegas o una), de la más vieja a la más nueva."""
    stmt = select(CapaCosto).where(CapaCosto.empresa_id == empresa_id, CapaCosto.producto_id == producto_id, CapaCosto.cantidad > 1e-9)
    if bodega_id:
        stmt = stmt.where(CapaCosto.bodega_id == bodega_id)
    return sorted(s.exec(stmt).all(), key=lambda c: (c.fecha or "", c.id or 0))


def recalcular_promedios_desde_capas(s: Session, empresa_id: int) -> int:
    """Al pasar a PEPS o UEPS (3.75): el costo promedio de cada existencia pasa a ser el valor de sus capas entre la cantidad,
    cuando las capas cubren toda la existencia. Devuelve cuántas existencias cambiaron."""
    bodegas = {b.id for b in s.exec(select(Bodega).where(Bodega.empresa_id == empresa_id)).all()}
    if not bodegas:
        return 0
    por_ex: dict[tuple, list] = {}
    for c in s.exec(select(CapaCosto).where(CapaCosto.empresa_id == empresa_id, CapaCosto.cantidad > 1e-9)).all():
        por_ex.setdefault((c.producto_id, c.bodega_id), []).append(c)
    n = 0
    for ex in s.exec(select(Existencia).where(Existencia.bodega_id.in_(bodegas), Existencia.cantidad > 1e-9)).all():
        capas = por_ex.get((ex.producto_id, ex.bodega_id)) or []
        q = sum(float(c.cantidad) for c in capas)
        if q > 1e-9 and abs(q - float(ex.cantidad)) < 1e-6:
            prom = sum(float(c.cantidad) * float(c.costo_unitario) for c in capas) / q
            if abs(prom - float(ex.costo_promedio or 0)) > 1e-9:
                ex.costo_promedio = prom; s.add(ex); n += 1
    return n


def recetas(s: Session, empresa_id: int) -> dict[int, dict]:
    """Fichas técnicas (3.4): registro `recetas` de la empresa, {producto_id: {ingredientes: [{producto_id, cantidad}], rendimiento}}."""
    from . import modulos
    out = {}
    for r in (modulos.leer(s, empresa_id, "recetas", []) or []):
        if isinstance(r, dict) and r.get("producto_id") and isinstance(r.get("ingredientes"), list):
            out[int(r["producto_id"])] = r
    return out


def extras_items(s: Session, empresa_id: int) -> dict:
    """Datos adicionales de los ítems (registro items_extra, por id): contenido por unidad e impresora de comanda (3.10)."""
    from . import modulos
    x = modulos.leer(s, empresa_id, "items_extra", {}) or {}
    return x if isinstance(x, dict) else {}


def cantidad_ingrediente(ing: dict, p: Producto, extras: dict) -> float:
    """Cantidad del ingrediente en la unidad del inventario del producto (3.10): 180 g de carne en Kg → 0,18; 45 ml de una
    botella de 750 ml → 0,06. Sin conversión posible se toma tal cual (1:1)."""
    from .unidades import a_unidad_producto
    q = a_unidad_producto(float(ing.get("cantidad") or 0), ing.get("unidad"), p.unidad_medida, extras.get(str(p.id)) or {})
    return float(ing.get("cantidad") or 0) if q is None else q


def costo_receta(s: Session, empresa_id: int, r: dict, bodega_id: int | None = None, extras: dict | None = None) -> float:
    """Costo del plato: cada ingrediente (en la unidad del inventario) al costo promedio de la bodega (o al costo del producto), entre el rendimiento."""
    bid = bodega_id or bodega_principal(s, empresa_id).id
    extras = extras if extras is not None else extras_items(s, empresa_id)
    total = 0.0
    for ing in r.get("ingredientes") or []:
        p = s.get(Producto, int(ing.get("producto_id") or 0))
        if not p or p.empresa_id != empresa_id:
            continue
        ex = s.exec(select(Existencia).where(Existencia.producto_id == p.id, Existencia.bodega_id == bid)).first()
        costo = (ex.costo_promedio if ex and ex.costo_promedio else 0) or (p.costo or 0)
        total += cantidad_ingrediente(ing, p, extras) * float(costo)
    rend = float(r.get("rendimiento") or 1) or 1
    return round(total / rend, 4)


def descontar_por_venta(s: Session, empresa_id: int, doc_id: int, consecutivo: str, bodega_id: int | None, lineas: list[dict],
                        fecha: str, devolucion=False, permitir_negativo=False):
    """Descuenta (o devuelve, en notas de crédito) las existencias de los productos inventariables de un comprobante. Un ítem con
    ficha técnica (receta) rebaja sus ingredientes en proporción (3.4) y no a sí mismo."""
    bodega_id = bodega_id or bodega_principal(s, empresa_id).id
    recs = recetas(s, empresa_id)
    extras = extras_items(s, empresa_id) if recs else {}
    metodo = metodo_costeo(s, empresa_id)

    def rebajar(p: Producto, cant: float, nivel: int = 0):
        rec = recs.get(int(p.id))
        if rec and rec.get("ingredientes") and nivel < 6:
            rend = float(rec.get("rendimiento") or 1) or 1
            for ing in rec["ingredientes"]:
                pi = s.get(Producto, int(ing.get("producto_id") or 0))
                if not pi or pi.empresa_id != empresa_id or pi.es_servicio:
                    continue
                q = cant * cantidad_ingrediente(ing, pi, extras) / rend
                if q <= 0:
                    continue
                if recs.get(int(pi.id)) and not pi.inventariable:        # preparación con su propia receta (salsa, masa): sus ingredientes (3.18)
                    rebajar(pi, q, nivel + 1); continue
                if not pi.inventariable:
                    continue
                registrar_movimiento(s, producto=pi, bodega_id=bodega_id, tipo="devolucion" if devolucion else "venta",
                                     cantidad=q if devolucion else -q, fecha=fecha, referencia=consecutivo, documento_id=doc_id,
                                     observaciones=f"Receta: {p.nombre}", permitir_negativo=True, metodo=metodo)
            return
        if p.es_servicio or not p.inventariable:
            return
        registrar_movimiento(s, producto=p, bodega_id=bodega_id, tipo="devolucion" if devolucion else "venta",
                             cantidad=cant if devolucion else -cant, fecha=fecha, referencia=consecutivo, documento_id=doc_id,
                             permitir_negativo=permitir_negativo, metodo=metodo)

    for l in lineas:
        if not l.get("producto_id"):
            continue
        p = s.get(Producto, l["producto_id"])
        if not p or p.empresa_id != empresa_id:
            continue
        rebajar(p, float(l["cantidad"]))

def ingresar_por_compra(s: Session, empresa_id: int, doc_id: int | None, consecutivo: str, bodega_id: int | None, lineas: list[dict], fecha: str,
                        tipo_cambio: float = 1.0, actualizar_costo: bool | None = None, ajuste_id: int | None = None,
                        observaciones: str | None = None) -> list[MovimientoInventario]:
    """Factura de compra: entra como 'compra' con costo unitario = precio neto de la línea en colones (R110) y abre su capa de
    costo. Si la empresa lo tiene configurado (o se pide), el costo del ítem pasa a ser el de esta compra (3.75)."""
    bodega_id = bodega_id or bodega_principal(s, empresa_id).id
    cfg = config_costeo(s, empresa_id)
    if actualizar_costo is None:
        actualizar_costo = cfg["actualizar_costo_compras"]
    movs = []
    for l in lineas:
        if not l.get("producto_id"):
            continue
        p = s.get(Producto, l["producto_id"])
        if not p or p.empresa_id != empresa_id or p.es_servicio or not p.inventariable:
            continue
        costo = round(float(l.get("costo") or 0) * float(tipo_cambio or 1), 4)
        movs.append(registrar_movimiento(s, producto=p, bodega_id=bodega_id, tipo="compra", cantidad=float(l["cantidad"]), fecha=fecha,
                                         costo_unitario=costo, referencia=consecutivo, documento_id=doc_id, ajuste_id=ajuste_id,
                                         observaciones=observaciones, metodo=cfg["metodo"]))
        if actualizar_costo and costo > 0 and abs(float(p.costo or 0) - costo) > 1e-9:
            p.costo = costo; s.add(p)
    return movs


def siguiente_numero(s: Session, empresa_id: int, tipo: str) -> int:
    ult = s.exec(select(AjusteInventario).where(AjusteInventario.empresa_id == empresa_id, AjusteInventario.tipo == tipo)
                 .order_by(AjusteInventario.numero.desc())).first()
    return (ult.numero + 1) if ult else 1


def _sin_cajero(ctx: Contexto, que: str = "los costos del inventario") -> None:
    """3.87: el Cajero (solo caja) vende con las existencias, no ve costos, márgenes ni el valor del inventario (como en movimientos)."""
    from .auth import solo_pos
    if solo_pos(ctx.permisos):
        raise HTTPException(403, f"Su rol no tiene acceso a {que}")


def _producto(s: Session, empresa_id: int, pid: int) -> Producto:
    p = s.get(Producto, pid)
    if not p or p.empresa_id != empresa_id:
        raise HTTPException(404, f"Producto {pid} no existe")
    return p


# ----------------------------------------------------------------------------- endpoints: bodegas
@router.get("/bodegas")
def listar_bodegas(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    bodega_principal(s, ctx.empresa.id)
    return s.exec(select(Bodega).where(Bodega.empresa_id == ctx.empresa.id).order_by(Bodega.principal.desc(), Bodega.nombre)).all()


@router.post("/bodegas")
def crear_bodega(b: Bodega, ctx: Contexto = Depends(requiere('catalogos')), s: Session = Depends(sesion_empresa)):
    b.nombre = _validar_nombre_bodega(s, ctx.empresa.id, b.nombre)
    b.id, b.empresa_id = None, ctx.empresa.id
    if b.principal:
        b.activa = True                                     # la principal nunca nace inactiva
    if b.principal:
        for o in s.exec(select(Bodega).where(Bodega.empresa_id == ctx.empresa.id)).all():
            o.principal = False; s.add(o)
    s.add(b); s.commit(); s.refresh(b)
    return b


@router.put("/bodegas/{bid}")
def editar_bodega(bid: int, data: Bodega, ctx: Contexto = Depends(requiere('catalogos')), s: Session = Depends(sesion_empresa)):
    b = _bodega(s, ctx.empresa.id, bid)
    data.nombre = _validar_nombre_bodega(s, ctx.empresa.id, data.nombre, bid)         # (R280)
    if (data.principal or b.principal) and not data.activa:
        raise HTTPException(400, "La bodega principal no se puede desactivar")
    if data.principal and not b.principal:
        for o in s.exec(select(Bodega).where(Bodega.empresa_id == ctx.empresa.id)).all():
            o.principal = False; s.add(o)
    b.nombre, b.direccion, b.observaciones, b.activa = data.nombre, data.direccion, data.observaciones, data.activa
    b.principal = data.principal or b.principal
    s.add(b); s.commit(); s.refresh(b)
    return b


@router.delete("/bodegas/{bid}")
def borrar_bodega(bid: int, ctx: Contexto = Depends(requiere('catalogos')), s: Session = Depends(sesion_empresa)):
    b = s.get(Bodega, bid)
    if not b or b.empresa_id != ctx.empresa.id:
        return {"ok": True}
    if b.principal:
        raise HTTPException(400, "La bodega principal no se puede eliminar")
    existencias = s.exec(select(Existencia).where(Existencia.bodega_id == bid)).all()
    if any(abs(e.cantidad or 0) > 1e-6 for e in existencias):                  # tolerancia: 0,0000001 no es "tener existencias" (R280)
        raise HTTPException(400, "La bodega tiene existencias; trasládelas antes de eliminarla")
    for e in existencias:                                                       # filas en cero: no quedan huérfanas
        s.delete(e)
    s.delete(b); s.commit()
    return {"ok": True}


# ----------------------------------------------------------------------------- endpoints: existencias / valor / movimientos
def _existencias(s: Session, empresa_id: int, bodega_id: Optional[int], producto_id: Optional[int]) -> list[dict]:
    bodegas = {b.id for b in s.exec(select(Bodega).where(Bodega.empresa_id == empresa_id)).all()}
    stmt = select(Existencia).where(Existencia.bodega_id.in_(bodegas)) if bodegas else None
    if stmt is None:
        return []
    if bodega_id:
        stmt = stmt.where(Existencia.bodega_id == bodega_id)
    if producto_id:
        stmt = stmt.where(Existencia.producto_id == producto_id)
    por_producto: dict[int, dict] = {}
    for e in s.exec(stmt).all():
        d = por_producto.setdefault(e.producto_id, {"producto_id": e.producto_id, "cantidad": 0, "valor": 0, "bodegas": {}})
        d["cantidad"] += e.cantidad
        d["valor"] += e.cantidad * e.costo_promedio
        d["bodegas"][e.bodega_id] = {"cantidad": e.cantidad, "costo_promedio": e.costo_promedio}
    for d in por_producto.values():
        d["costo_promedio"] = (d["valor"] / d["cantidad"]) if d["cantidad"] else 0
    return list(por_producto.values())


@router.get("/existencias")
def existencias(bodega_id: Optional[int] = None, producto_id: Optional[int] = None, ctx: Contexto = Depends(contexto),
                s: Session = Depends(sesion_empresa)):
    """Existencias por producto (y por bodega) de la empresa activa, con costo promedio y valor."""
    out = _existencias(s, ctx.empresa.id, bodega_id, producto_id)
    from .auth import solo_pos
    if solo_pos(ctx.permisos):          # 3.87: a la caja solo le sirve la cantidad (agotados y porciones), sin costo ni valor
        return [{"producto_id": d["producto_id"], "cantidad": d["cantidad"], "bodegas": {b: {"cantidad": x["cantidad"]} for b, x in d["bodegas"].items()}} for d in out]
    return out


@router.get("/valor")
def valor_inventario(bodega_id: Optional[int] = None, hasta: Optional[str] = None, ctx: Contexto = Depends(contexto),
                     s: Session = Depends(sesion_empresa)):
    """Reporte de valor de inventario. Con `hasta` (AAAA-MM-DD) reconstruye las cantidades a esa fecha desde los movimientos."""
    _sin_cajero(ctx, "el valor del inventario")
    eid = ctx.empresa.id
    productos = {p.id: p for p in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.es_servicio == False)).all()}  # noqa: E712
    metodo = metodo_costeo(s, eid)
    if hasta:
        stmt = select(MovimientoInventario).where(MovimientoInventario.empresa_id == eid, MovimientoInventario.fecha <= hasta)
        if bodega_id:
            stmt = stmt.where(MovimientoInventario.bodega_id == bodega_id)
        # misma regla que registrar_movimiento y POR BODEGA (antes se mezclaban bodegas y se omitían entradas a costo 0) (R113)
        # Con PEPS/UEPS (3.75) el valor es la suma de lo que entró menos lo que salió, cada movimiento al costo con que se registró
        acum: dict[tuple, dict] = {}
        for m in s.exec(stmt.order_by(MovimientoInventario.id)).all():
            d = acum.setdefault((m.producto_id, m.bodega_id), {"cantidad": 0, "costo": 0, "valor": 0})
            if metodo in ("peps", "ueps"):
                d["valor"] += m.cantidad * float(m.costo_unitario or 0)
            elif m.cantidad > 0 and m.costo_unitario is not None and m.costo_unitario >= 0:
                base = max(d["cantidad"], 0)
                d["costo"] = (base * d["costo"] + m.cantidad * m.costo_unitario) / (base + m.cantidad) if (base + m.cantidad) else m.costo_unitario
            d["cantidad"] += m.cantidad
        por_prod: dict[int, dict] = {}
        for (pid, _b), v in acum.items():
            x = por_prod.setdefault(pid, {"cantidad": 0, "valor": 0})
            x["cantidad"] += v["cantidad"]
            x["valor"] += (max(v["valor"], 0.0) if v["cantidad"] > 1e-9 else 0.0) if metodo in ("peps", "ueps") else v["cantidad"] * v["costo"]
        items = [{"producto_id": pid, "cantidad": v["cantidad"], "costo_promedio": (v["valor"] / v["cantidad"]) if v["cantidad"] else 0} for pid, v in por_prod.items()]
    else:
        items = _existencias(s, eid, bodega_id, None)
    out, total = [], 0.0
    for it in items:
        p = productos.get(it["producto_id"])
        if not p:
            continue
        val = it["cantidad"] * it["costo_promedio"]
        total += val
        out.append({"producto_id": p.id, "nombre": p.nombre, "codigo": p.codigo, "cabys": p.cabys, "unidad_medida": p.unidad_medida,
                    "cantidad": it["cantidad"], "costo_promedio": it["costo_promedio"], "total": val, "activo": p.activo})
    out.sort(key=lambda x: x["nombre"].lower())
    return {"total": total, "items": out}


@router.get("/movimientos")
def movimientos(producto_id: Optional[int] = None, bodega_id: Optional[int] = None, limite: int = 200, tipo: Optional[str] = None,
                desde: Optional[str] = None, hasta: Optional[str] = None,
                ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Movimientos de inventario, los más recientes primero. Filtros: producto, bodega, tipo (venta, devolucion, compra, ajuste,
    transferencia, inicial), fechas AAAA-MM-DD; `limite` hasta 5000 (reportes)."""
    from .auth import solo_pos
    if solo_pos(ctx.permisos):
        raise HTTPException(403, "Su rol no tiene acceso a los movimientos de inventario")
    limite = max(1, min(int(limite or 200), 5000))
    stmt = select(MovimientoInventario).where(MovimientoInventario.empresa_id == ctx.empresa.id)
    if producto_id:
        stmt = stmt.where(MovimientoInventario.producto_id == producto_id)
    if bodega_id:
        stmt = stmt.where(MovimientoInventario.bodega_id == bodega_id)
    if tipo:
        stmt = stmt.where(MovimientoInventario.tipo == tipo)
    if desde:
        stmt = stmt.where(MovimientoInventario.fecha >= _fecha_iso(desde))
    if hasta:
        stmt = stmt.where(MovimientoInventario.fecha <= _fecha_iso(hasta) + "T23:59:59.999999")
    movs = s.exec(stmt.order_by(MovimientoInventario.id.desc()).limit(limite)).all()
    nombres = {p.id: p.nombre for p in s.exec(select(Producto).where(Producto.empresa_id == ctx.empresa.id)).all()}
    bodegas = {b.id: b.nombre for b in s.exec(select(Bodega).where(Bodega.empresa_id == ctx.empresa.id)).all()}
    return [{**m.model_dump(), "producto": nombres.get(m.producto_id), "bodega": bodegas.get(m.bodega_id)} for m in movs]


def _fecha_iso(f: str) -> str:
    try:
        return date.fromisoformat(str(f)[:10]).isoformat()
    except ValueError:
        raise HTTPException(400, "Fecha inválida (use AAAA-MM-DD)")


@router.get("/ventas-por-bodega")
def ventas_por_bodega(desde: str, hasta: str, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Ventas del período por bodega (Reportes › Ventas por bodega): cada línea vendida se asigna a la bodega de la que salió
    (movimiento de inventario de ese documento y producto); los servicios y lo que no movió inventario van en «Sin bodega».
    Montos en colones con el tipo de cambio de cada comprobante; costo = costo promedio al momento de la venta."""
    from . import resumen as _res, tipo_cambio as _tc
    if not (ctx.puede("reportes") or ctx.puede("ver_todo")):
        raise HTTPException(403, "Su rol no tiene acceso a los reportes")
    d1, d2 = _fecha_iso(desde), _fecha_iso(hasta)
    if d2 < d1:
        d1, d2 = d2, d1
    e = ctx.empresa
    tc = None
    try:
        t = _tc.obtener(); tc = _tc.aplicado(t.get("venta"), e.margen_cambiario if e.margen_cambiario is not None else 5.0)
    except Exception:  # noqa: BLE001
        tc = None
    docs = {d.id: d for d in s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente)).all()
            if d.tipo_documento in _res.VENTAS + _res.DEVOLUCIONES and d1 <= (d.fecha_emision or "")[:10] <= d2 and (d.estado or "") not in _res.EXCLUIR_ESTADOS}
    if getattr(ctx, "sucursal_fija", False) and ctx.sucursal is not None:   # 3.87: el amarrado a una sucursal, solo las ventas de ella
        from .sucursales import pertenece
        docs = {k: d for k, d in docs.items() if pertenece(d, ctx.sucursal)}
    if not docs:
        return {"tc_disponible": bool(tc), "filas": []}
    lineas = s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id.in_(list(docs)))).all()
    movs = s.exec(select(MovimientoInventario).where(MovimientoInventario.empresa_id == e.id, MovimientoInventario.documento_id.in_(list(docs)),
                                                     MovimientoInventario.tipo.in_(("venta", "devolucion")))).all()
    bodega_de: dict[tuple, int] = {}
    costo: dict[tuple, float] = {}
    for m in movs:
        k = (m.documento_id, m.producto_id)
        bodega_de.setdefault(k, m.bodega_id)
        costo[k] = costo.get(k, 0.0) + (-m.cantidad) * float(m.costo_unitario or 0)     # venta: cantidad negativa → costo positivo
    nombres = {b.id: b.nombre for b in s.exec(select(Bodega).where(Bodega.empresa_id == e.id)).all()}
    out: dict[Any, dict] = {}
    for l in lineas:
        d = docs.get(l.documento_id)
        if d is None:
            continue
        sg = -1 if d.tipo_documento in _res.DEVOLUCIONES else 1
        k = (l.documento_id, l.producto_id)
        bid = bodega_de.get(k)
        sin = "Sin bodega (servicios y ventas sin inventario)"
        fila = out.setdefault(bid, {"bodega_id": bid, "bodega": nombres.get(bid, sin) if bid else sin, "_docs": set(), "unidades": 0.0, "venta_crc": 0.0, "costo_crc": 0.0})
        fila["_docs"].add(l.documento_id)
        fila["unidades"] += sg * float(l.cantidad or 0)
        fila["venta_crc"] += _res._a_crc(d.moneda, sg * float(l.total or 0), _res.tc_doc(d), tc)
        if k in costo:
            fila["costo_crc"] += costo.pop(k)          # el costo promedio de inventario ya está en colones
    res = []
    for f in out.values():
        res.append({"bodega_id": f["bodega_id"], "bodega": f["bodega"], "documentos": len(f["_docs"]), "unidades": round(f["unidades"], 3),
                    "venta_crc": round(f["venta_crc"], 2), "costo_crc": round(f["costo_crc"], 2)})
    res.sort(key=lambda x: (x["bodega_id"] is None, -x["venta_crc"]))
    return _res.finitos({"tc_disponible": bool(tc), "filas": res})


# ----------------------------------------------------------------------------- endpoints: ajustes y transferencias
class LineaAjusteIn(BaseModel):
    producto_id: int
    tipo: Literal["incremento", "disminucion"] = "incremento"      # (R279)
    cantidad: float = PField(gt=0, le=1e12)
    costo_unitario: Optional[float] = PField(None, ge=0)


class AjusteIn(BaseModel):
    bodega_id: Optional[int] = None
    fecha: Optional[str] = None
    observaciones: Optional[str] = None
    lineas: list[LineaAjusteIn]


def _codigo(a: AjusteInventario) -> str:
    return f"{ {'transferencia': 'TR', 'compra': 'CO'}.get(a.tipo, 'AJ') }-{a.numero:04d}"


@router.get("/recetas/porciones")
def porciones_recetas(bodega_id: Optional[int] = None, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Porciones que alcanzan de cada receta con las existencias de la bodega (3.22): el ingrediente más escaso manda; una
    preparación con receta propia aporta las porciones que a su vez alcanzan de ella. {producto_id: porciones}."""
    eid = ctx.empresa.id
    bid = bodega_id or bodega_principal(s, eid).id
    recs = recetas(s, eid)
    if not recs:
        return {}
    extras = extras_items(s, eid)
    exist = {e.producto_id: float(e.cantidad or 0) for e in s.exec(select(Existencia).where(Existencia.bodega_id == bid)).all()}
    cache: dict[int, Optional[int]] = {}

    def porciones(pid: int, nivel: int = 0) -> Optional[int]:
        if pid in cache:
            return cache[pid]
        r = recs.get(pid)
        if not r or nivel > 5:
            return None
        rend = float(r.get("rendimiento") or 1) or 1
        mn: Optional[int] = None
        for ing in r.get("ingredientes") or []:
            p = s.get(Producto, int(ing.get("producto_id") or 0))
            if not p or p.empresa_id != eid or p.es_servicio:
                continue
            q = cantidad_ingrediente(ing, p, extras) / rend
            if q <= 0:
                continue
            if recs.get(int(p.id)) and not p.inventariable:
                disp = porciones(int(p.id), nivel + 1)
                if disp is None:
                    continue
                disp = float(disp)
            elif not p.inventariable:
                continue
            else:
                disp = exist.get(int(p.id), 0.0)
            n = int(max(0.0, disp) // q)
            mn = n if mn is None else min(mn, n)
        cache[pid] = mn
        return mn

    return {str(pid): porciones(int(pid)) for pid, r in recs.items() if r.get("vender") is not False and porciones(int(pid)) is not None}


@router.get("/recetas/costos")
def costos_recetas(bodega_id: Optional[int] = None, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Costo del plato de cada ficha técnica (3.4), con el precio de venta y el margen."""
    _sin_cajero(ctx)
    out = []
    extras = extras_items(s, ctx.empresa.id)
    for pid, r in recetas(s, ctx.empresa.id).items():
        p = s.get(Producto, pid)
        if not p or p.empresa_id != ctx.empresa.id:
            continue
        costo = costo_receta(s, ctx.empresa.id, r, bodega_id, extras)
        neto = float(p.precio or 0) / (1 + float(p.tarifa or 0) / 100) if p.precio else 0.0
        out.append({"producto_id": pid, "nombre": p.nombre, "precio": p.precio, "precio_neto": round(neto, 2), "costo": round(costo, 2),
                    "margen": round(neto - costo, 2), "margen_pct": round((neto - costo) / neto * 100, 1) if neto else None, "ingredientes": len(r.get("ingredientes") or [])})
    return out


@router.get("/ajustes")
def listar_ajustes(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _sin_cajero(ctx, "los ajustes de inventario")
    ajustes = s.exec(select(AjusteInventario).where(AjusteInventario.empresa_id == ctx.empresa.id).order_by(AjusteInventario.id.desc())).all()
    bodegas = {b.id: b.nombre for b in s.exec(select(Bodega).where(Bodega.empresa_id == ctx.empresa.id)).all()}
    return [{**a.model_dump(), "bodega": bodegas.get(a.bodega_id), "bodega_destino": bodegas.get(a.bodega_destino_id), "codigo": _codigo(a)}
            for a in ajustes]


@router.get("/ajustes/{aid}")
def detalle_ajuste(aid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _sin_cajero(ctx, "los ajustes de inventario")
    return _detalle_ajuste(s, ctx.empresa.id, aid)


def _detalle_ajuste(s: Session, empresa_id: int, aid: int) -> dict:
    a = s.get(AjusteInventario, aid)
    if not a or a.empresa_id != empresa_id:
        raise HTTPException(404)
    movs = s.exec(select(MovimientoInventario).where(MovimientoInventario.ajuste_id == aid)).all()
    productos = {p.id: p.nombre for p in s.exec(select(Producto).where(Producto.empresa_id == empresa_id)).all()}
    bodegas = {b.id: b.nombre for b in s.exec(select(Bodega).where(Bodega.empresa_id == empresa_id)).all()}
    return {**a.model_dump(), "codigo": _codigo(a), "bodega": bodegas.get(a.bodega_id), "bodega_destino": bodegas.get(a.bodega_destino_id),
            "metodo": metodo_costeo(s, empresa_id),
            "movimientos": _con_capas(s, [{**m.model_dump(), "producto": productos.get(m.producto_id), "bodega": bodegas.get(m.bodega_id)} for m in movs])}


def _con_capas(s: Session, movimientos: list[dict]) -> list[dict]:
    """Agrega a cada salida las capas que consumió (3.75): [{capa_id, fecha, cantidad, costo_unitario}]."""
    ids = [m["id"] for m in movimientos if m.get("id")]
    if not ids:
        return movimientos
    cons = s.exec(select(ConsumoCapa).where(ConsumoCapa.movimiento_id.in_(ids))).all()
    capas = {c.id: c for c in s.exec(select(CapaCosto).where(CapaCosto.id.in_([x.capa_id for x in cons if x.capa_id]))).all()} if cons else {}
    por_mov: dict[int, list] = {}
    for x in cons:
        c = capas.get(x.capa_id)
        por_mov.setdefault(x.movimiento_id, []).append({"capa_id": x.capa_id, "fecha": c.fecha if c else None, "cantidad": x.cantidad,
                                                        "costo_unitario": x.costo_unitario, "referencia": c.referencia if c else None})
    for m in movimientos:
        m["capas"] = por_mov.get(m["id"], [])
    return movimientos


@router.post("/ajustes")
def crear_ajuste(data: AjusteIn, ctx: Contexto = Depends(requiere('inventario')), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    if not data.lineas:
        raise HTTPException(400, "Agregue al menos un producto")
    bodega_id = data.bodega_id or bodega_principal(s, eid).id
    _bodega_activa(s, eid, bodega_id)
    fecha = _fecha_mov(data.fecha)
    a = AjusteInventario(empresa_id=eid, numero=siguiente_numero(s, eid, "ajuste"), fecha=fecha, bodega_id=bodega_id, observaciones=data.observaciones)
    s.add(a); s.flush()
    total = 0.0
    for l in data.lineas:
        p = _producto(s, eid, l.producto_id)
        signo = 1 if l.tipo == "incremento" else -1
        ex = existencia(s, p.id, bodega_id)
        # las disminuciones salen SIEMPRE al costo promedio (el costo enviado solo aplica a los incrementos) (R278)
        costo = l.costo_unitario if (signo > 0 and l.costo_unitario is not None) else (ex.costo_promedio or p.costo or 0)
        mov = registrar_movimiento(s, producto=p, bodega_id=bodega_id, tipo="ajuste", cantidad=signo * l.cantidad, fecha=fecha,
                                   costo_unitario=costo, referencia=_codigo(a), ajuste_id=a.id, observaciones=data.observaciones)
        total += mov.cantidad * float(mov.costo_unitario or 0)          # con PEPS/UEPS la disminución sale al costo de sus capas (3.75)
    a.total = total
    s.add(a); s.commit()
    return _detalle_ajuste(s, eid, a.id)


class LineaTransferenciaIn(BaseModel):
    producto_id: int
    cantidad: float = PField(gt=0, le=1e12)      # (R279)


class TransferenciaIn(BaseModel):
    origen_id: int
    destino_id: int
    fecha: Optional[str] = None
    observaciones: Optional[str] = None
    lineas: list[LineaTransferenciaIn]


@router.post("/transferencias")
def crear_transferencia(data: TransferenciaIn, ctx: Contexto = Depends(requiere('inventario')), s: Session = Depends(sesion_empresa)):
    eid = ctx.empresa.id
    if data.origen_id == data.destino_id:
        raise HTTPException(400, "La bodega de origen y destino deben ser distintas")
    if not data.lineas:
        raise HTTPException(400, "Agregue al menos un producto")
    _bodega_activa(s, eid, data.origen_id); _bodega_activa(s, eid, data.destino_id)
    fecha = _fecha_mov(data.fecha)
    a = AjusteInventario(empresa_id=eid, numero=siguiente_numero(s, eid, "transferencia"), fecha=fecha, bodega_id=data.origen_id,
                         tipo="transferencia", bodega_destino_id=data.destino_id, observaciones=data.observaciones)
    s.add(a); s.flush()
    ref = _codigo(a)
    metodo = metodo_costeo(s, eid)
    for l in data.lineas:
        p = _producto(s, eid, l.producto_id)
        # la salida fija el costo (con PEPS/UEPS, el de las capas que consumió) y la entrada abre su capa a ese mismo costo (3.75)
        salida = registrar_movimiento(s, producto=p, bodega_id=data.origen_id, tipo="transferencia", cantidad=-l.cantidad, fecha=fecha,
                                      referencia=ref, ajuste_id=a.id, observaciones=data.observaciones, metodo=metodo)
        registrar_movimiento(s, producto=p, bodega_id=data.destino_id, tipo="transferencia", cantidad=l.cantidad, fecha=fecha,
                             costo_unitario=float(salida.costo_unitario or 0), referencia=ref, ajuste_id=a.id, observaciones=data.observaciones, metodo=metodo)
    s.commit()
    return _detalle_ajuste(s, eid, a.id)


# ----------------------------------------------------------------------------- 3.75: método de costeo, capas y compras
class ConfigCosteoIn(BaseModel):
    metodo: Literal["promedio", "peps", "ueps"] = "promedio"
    actualizar_costo_compras: bool = True


@router.get("/config")
def ver_config(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Método de costeo de la empresa (promedio, PEPS o UEPS) y si las compras actualizan el costo del ítem."""
    return {**config_costeo(s, ctx.empresa.id), "nombres": NOMBRE_METODO}


@router.put("/config")
def guardar_config(data: ConfigCosteoIn, ctx: Contexto = Depends(requiere('configurar')), s: Session = Depends(sesion_empresa)):
    """Cambia el método. Al pasar a PEPS o UEPS, el costo promedio de cada existencia pasa a ser el valor de sus capas."""
    from . import modulos
    eid = ctx.empresa.id
    antes = config_costeo(s, eid)
    r = modulos._registro(s, eid, CLAVE_CONFIG)
    modulos.reemplazar(s, eid, CLAVE_CONFIG, {"metodo": data.metodo, "actualizar_costo_compras": bool(data.actualizar_costo_compras)}, (r.version or 0) if r else None)
    recalculados = recalcular_promedios_desde_capas(s, eid) if data.metodo in ("peps", "ueps") and data.metodo != antes["metodo"] else 0
    s.commit()
    return {**config_costeo(s, eid), "nombres": NOMBRE_METODO, "recalculados": recalculados}


@router.get("/capas")
def ver_capas(producto_id: int, bodega_id: Optional[int] = None, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Capas de costo con existencia de un ítem (de la más vieja a la más nueva), con la cantidad que queda de cada una."""
    _sin_cajero(ctx)
    eid = ctx.empresa.id
    _producto(s, eid, producto_id)
    bodegas = {b.id: b.nombre for b in s.exec(select(Bodega).where(Bodega.empresa_id == eid)).all()}
    capas = [{"id": c.id, "bodega_id": c.bodega_id, "bodega": bodegas.get(c.bodega_id), "fecha": c.fecha, "base": c.fecha == FECHA_BASE,
              "cantidad": c.cantidad, "cantidad_inicial": c.cantidad_inicial, "costo_unitario": c.costo_unitario, "referencia": c.referencia,
              "total": round(float(c.cantidad) * float(c.costo_unitario), 4)} for c in capas_de(s, eid, producto_id, bodega_id)]
    return {"metodo": metodo_costeo(s, eid), "capas": capas, "cantidad": sum(c["cantidad"] for c in capas), "valor": round(sum(c["total"] for c in capas), 4)}


class LineaCompraIn(BaseModel):
    producto_id: int
    cantidad: float = PField(gt=0, le=1e12)
    costo_unitario: float = PField(0, ge=0)        # en la moneda del documento (tipo_cambio lo pasa a colones)


class CompraInventarioIn(BaseModel):
    bodega_id: Optional[int] = None
    fecha: Optional[str] = None
    numero: Optional[str] = None                   # número del documento del proveedor
    proveedor: Optional[str] = None
    observaciones: Optional[str] = None
    tipo_cambio: float = PField(1, gt=0)
    recepcion_id: Optional[int] = None             # comprobante recibido del que viene (queda marcado como ya ingresado)
    actualizar_costo: Optional[bool] = None        # None = lo que diga la configuración
    lineas: list[LineaCompraIn]
    clave: Optional[str] = PField(None, max_length=80)   # 3.87: la misma clave (la factura de compra) no entra dos veces: 409


def registrar_compra(s: Session, eid: int, data: CompraInventarioIn, recibido=None) -> dict:
    """Entrada por compra (CO-0001…): un ajuste de tipo 'compra' con un movimiento 'compra' por línea, al costo de la factura.
    Si viene de un comprobante recibido lo deja marcado (no entra dos veces)."""
    if not data.lineas:
        raise HTTPException(400, "Agregue al menos un producto")
    if data.recepcion_id and recibido is None:
        from .recepcion import Recibido
        recibido = s.get(Recibido, data.recepcion_id)
        if not recibido or recibido.empresa_id != eid:
            raise HTTPException(404, "Comprobante recibido no encontrado")
    if recibido is not None and recibido.inventario_ajuste_id:
        raise HTTPException(409, f"Este comprobante ya entró al inventario ({recibido.inventario_codigo or recibido.inventario_ajuste_id})")
    clave = (data.clave or "").strip() or None
    if clave:                                      # 3.87: «Dar entrada al inventario» repetido (otro clic, otra persona, un guardado que falló)
        ya = s.exec(select(AjusteInventario).where(AjusteInventario.empresa_id == eid, AjusteInventario.clave == clave)).first()
        if ya:
            raise HTTPException(409, f"Esta compra ya entró al inventario ({_codigo(ya)})")
    bodega_id = data.bodega_id or bodega_principal(s, eid).id
    _bodega_activa(s, eid, bodega_id)
    fecha = _fecha_mov(data.fecha)
    lineas = []
    for l in data.lineas:
        p = _producto(s, eid, l.producto_id)
        if p.es_servicio or not p.inventariable:
            raise HTTPException(400, f"'{p.nombre}' no es inventariable: quítelo de la entrada")
        lineas.append({"producto_id": p.id, "cantidad": float(l.cantidad), "costo": float(l.costo_unitario or 0)})
    obs = " · ".join(x for x in [f"Compra {data.numero}" if data.numero else "Compra", (data.proveedor or "").strip(), (data.observaciones or "").strip()] if x)[:300]
    a = AjusteInventario(empresa_id=eid, numero=siguiente_numero(s, eid, "compra"), fecha=fecha, bodega_id=bodega_id, tipo="compra", observaciones=obs, clave=clave)
    s.add(a); s.flush()
    movs = ingresar_por_compra(s, eid, None, _codigo(a), bodega_id, lineas, fecha, float(data.tipo_cambio or 1), actualizar_costo=data.actualizar_costo,
                               ajuste_id=a.id, observaciones=obs)
    a.total = sum(float(m.cantidad) * float(m.costo_unitario or 0) for m in movs)
    s.add(a)
    if recibido is not None:
        recibido.inventario_ajuste_id, recibido.inventario_codigo = a.id, _codigo(a)
        recibido.inventario_en = ahora_cr().isoformat(timespec="seconds")
        s.add(recibido)
    s.commit()
    return _detalle_ajuste(s, eid, a.id)


@router.post("/compras")
def crear_compra(data: CompraInventarioIn, ctx: Contexto = Depends(requiere('inventario')), s: Session = Depends(sesion_empresa)):
    """Entrada de mercadería por una compra (manual o desde una factura de compra sin FEC)."""
    return registrar_compra(s, ctx.empresa.id, data)


# ----------------------------------------------------------------------------- por reponer (3.87)
def _sugerido(p: Producto, existencia: float) -> float:
    """Cuánto pedir: hasta la existencia máxima; sin máxima, hasta el doble de la mínima (al menos una unidad)."""
    import math
    minimo = float(p.existencia_minima or 0)
    tope = float(p.existencia_maxima) if p.existencia_maxima is not None and float(p.existencia_maxima) > minimo else minimo * 2
    q = max(tope - float(existencia), 0.0) or 1.0
    return float(math.ceil(q - 1e-9)) if (p.unidad_medida or "Unid") == "Unid" else round(q, 3)


def por_reponer(s: Session, empresa_id: int, bodega_id: Optional[int] = None, ids: Optional[set] = None, solo_conteo: bool = False) -> dict:
    """Ítems con existencia mínima cuya existencia (el total de las bodegas, o la de una) llegó a ese mínimo, con la cantidad
    sugerida, el costo y el proveedor habitual (la relación proveedor → ítem de la 3.75 más reciente). No cambia ningún cálculo:
    un ítem sin mínimo no sale nunca. Los ítems con ficha técnica no llevan existencias propias: se reponen sus ingredientes."""
    import re
    from .compras_inventario import relaciones
    from .db import Cliente
    con_min = [p for p in s.exec(select(Producto).where(Producto.empresa_id == empresa_id, Producto.existencia_minima != None)).all()  # noqa: E711
               if p.activo and not p.es_servicio and p.inventariable and (p.tipo or "Producto") not in ("Combo", "Surtido", "Servicio")]
    if con_min:
        con_receta = {pid for pid, r in recetas(s, empresa_id).items() if r.get("ingredientes")}
        con_min = [p for p in con_min if p.id not in con_receta]
    total = len(con_min)
    if ids is not None:
        con_min = [p for p in con_min if p.id in ids]
    if not con_min:
        return {"con_minimo": total, "items": []}
    ex = {x["producto_id"]: x for x in _existencias(s, empresa_id, bodega_id, None)}
    bajos = [(p, round(float((ex.get(p.id) or {}).get("cantidad") or 0), 4)) for p in con_min]
    bajos = [(p, q) for p, q in bajos if q <= float(p.existencia_minima) + 1e-9]
    if solo_conteo:                                    # 3.87: el Inicio solo cuenta: sin proveedor habitual ni contactos
        return {"con_minimo": total, "items": [{"producto_id": p.id} for p, _q in bajos]}
    habitual: dict = {}
    if bajos:
        for r in relaciones(s, empresa_id).values():
            if isinstance(r, dict) and r.get("producto_id"):
                pid = int(r["producto_id"])
                if pid not in habitual or str(r.get("actualizado") or "") > str(habitual[pid].get("actualizado") or ""):
                    habitual[pid] = r
    contactos: dict = {}
    if habitual:
        for c in s.exec(select(Cliente).where(Cliente.empresa_id == empresa_id, Cliente.activo == True)).all():  # noqa: E712
            k = re.sub(r"\D", "", c.numero_id or "")
            if k and (k not in contactos or (c.tipo in ("Proveedor", "Ambos") and contactos[k].tipo not in ("Proveedor", "Ambos"))):
                contactos[k] = c
    items = []
    for p, q in bajos:
        e = ex.get(p.id) or {}
        h = habitual.get(p.id)
        prov = None
        if h:
            c = contactos.get(re.sub(r"\D", "", str(h.get("emisor_id") or "")))
            prov = {"nombre": (c.nombre if c else None) or h.get("emisor") or h.get("emisor_id"), "identificacion": h.get("emisor_id"),
                    "contacto_id": c.id if c else None}
        costo = float(e.get("costo_promedio") or 0) or float(p.costo or 0)
        items.append({"producto_id": p.id, "codigo": p.codigo, "nombre": p.nombre, "categoria": p.categoria, "unidad_medida": p.unidad_medida,
                      "cabys": p.cabys, "codigo_tarifa": p.codigo_tarifa, "tarifa": p.tarifa, "existencia": q, "minimo": p.existencia_minima,
                      "maximo": p.existencia_maxima, "sugerido": _sugerido(p, q), "costo": round(costo, 4), "proveedor": prov})
    items.sort(key=lambda x: (((x["proveedor"] or {}).get("nombre") or "￿").lower(), x["nombre"].lower()))
    return {"con_minimo": total, "items": items}


@router.get("/reponer")
def reponer(bodega_id: Optional[int] = None, ids: Optional[str] = None, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Inventario › Por reponer (3.87). `ids` (1,2,3) limita a esos ítems: la orden de compra sugerida los pide así."""
    if not any(ctx.puede(p) for p in ("inventario", "gastos", "catalogos", "ver_todo")):
        raise HTTPException(403, "Su rol no ve la reposición del inventario")
    sel = None
    if ids:
        try:
            sel = {int(x) for x in str(ids).split(",") if x.strip()}
        except ValueError:
            raise HTTPException(400, "Lista de ítems inválida")
    if bodega_id:
        _bodega(s, ctx.empresa.id, bodega_id)
    return por_reponer(s, ctx.empresa.id, bodega_id, sel)
