"""Persistencia (SQLite + SQLModel).

Dos niveles de bases de datos:
- **Central** (`data/facturacr.db`): empresas, usuarios, autorizaciones, auditoría y catálogo CABYS.
- **Una por empresa** (`data/empresas/empresa_<id>.db`): clientes, productos, documentos, inventario y configuración.
  Se crea automáticamente la primera vez que se usa (al crear la cuenta) y las consultas de negocio solo abren esa base,
  de modo que ningún endpoint puede alcanzar datos de otra empresa aunque olvide un filtro.
"""
import os
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import event
from sqlmodel import Field, Session, SQLModel, create_engine

from .config import DATA_DIR, DB_URL

# Varios procesos (Passenger) escriben sobre los mismos archivos SQLite: WAL permite leer mientras otro escribe y un
# busy_timeout largo evita "database is locked" durante la importación CABYS o una firma lenta.
CONNECT_ARGS = {"check_same_thread": False, "timeout": 30}


def _pragmas(dbapi_conn, _record):
    c = dbapi_conn.cursor()
    try:
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA busy_timeout=30000")
    finally:
        c.close()


def _nuevo_engine(url: str):
    eng = create_engine(url, connect_args=CONNECT_ARGS)
    event.listen(eng, "connect", _pragmas)
    return eng


engine = _nuevo_engine(DB_URL)      # base CENTRAL
EMPRESAS_DIR = DATA_DIR / "empresas"
EMPRESAS_DIR.mkdir(exist_ok=True)
_engines: dict[int, tuple[object, int | None]] = {}     # eid -> (engine, inodo del archivo)

# Registro de tablas por nivel (los módulos auth/inventario agregan las suyas al importarse)
TABLAS_CENTRAL: list = []
TABLAS_EMPRESA: list = []


def central(*modelos):
    TABLAS_CENTRAL.extend(m.__table__ for m in modelos)


def por_empresa(*modelos):
    TABLAS_EMPRESA.extend(m.__table__ for m in modelos)


# ----------------------------------------------------------------------------- central
class Empresa(SQLModel, table=True):
    # AUTOINCREMENT: un id de empresa borrada nunca se reutiliza (su archivo .db podría seguir abierto en otro proceso)
    __table_args__ = {"sqlite_autoincrement": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    nombre: str
    nombre_comercial: Optional[str] = None
    tipo_id: str = "02"
    numero_id: str = ""
    actividad: str = ""
    provincia: int = 1
    canton: int = 1
    distrito: int = 1
    barrio: Optional[str] = None
    otras_senas: str = ""
    telefono: Optional[int] = None
    correo: str = ""
    sucursal: int = 1
    terminal: int = 1
    proveedor_sistemas: Optional[str] = None     # vacío = IT Core Sync (config.PROVEEDOR_SISTEMAS); solo cambia si se usa otro software
    registro_fiscal_8707: Optional[str] = None   # registro fiscal de bebidas alcohólicas (Ley 8707): Registrofiscal8707 del Emisor
    ambiente: str = "sandbox"
    factura_electronica: bool = True            # 3.61: apagado = comprobantes internos (sin XML, firma ni Hacienda)
    usuario_hacienda: Optional[str] = None
    password_hacienda: Optional[str] = None      # cifrado con la clave de la empresa (prefijo "enc:")
    p12_nombre: Optional[str] = None
    p12_pin: Optional[str] = None                # cifrado
    p12_vence: Optional[str] = None              # vencimiento de la llave criptográfica (ISO), para avisar antes de que venza
    smtp_host: Optional[str] = None
    smtp_puerto: int = 465
    smtp_usuario: Optional[str] = None
    smtp_password: Optional[str] = None          # cifrado
    smtp_remitente: Optional[str] = None
    smtp_seguridad: str = "ssl"                  # ssl (465) | starttls (587) | ninguna (25, solo redes internas)
    smtp_nombre: Optional[str] = None            # nombre visible del remitente ("IT Core Sync Facturación")
    smtp_copia: Optional[str] = None             # correo que recibe copia oculta de cada comprobante enviado
    # Correo saliente de Recursos humanos (comprobantes de pago de planilla); si no se configura se usa el SMTP general
    rrhh_smtp_host: Optional[str] = None
    rrhh_smtp_puerto: int = 465
    rrhh_smtp_seguridad: str = "ssl"
    rrhh_smtp_usuario: Optional[str] = None
    rrhh_smtp_password: Optional[str] = None     # cifrado
    rrhh_smtp_remitente: Optional[str] = None
    rrhh_smtp_nombre: Optional[str] = None
    rrhh_smtp_copia: Optional[str] = None
    rrhh_correo_auto: bool = True                # al marcar pagada una planilla se envían los comprobantes
    correo_automatico: bool = True               # enviar el comprobante al cliente en cuanto Hacienda lo acepte
    precio_acordado: Optional[float] = None       # 3.95: precio fijo por empresa (₡ al mes o al periodo del plan, sin IVA); vacío = precio de lista
    precio_acordado_nota: str = ""               # 3.95: lo que se ve en su plan (p. ej. «Paquete perfumería: caja + ventas en línea + RRHH»)
    aviso_rechazo: bool = True                   # 3.87: avisar por correo al dueño si Hacienda rechaza un comprobante o no lo responde en un día
    margen_cambiario: float = 5.0                # % sobre la venta BCCR del día para el tipo de cambio de los documentos
    enlaces_version: int = 1                     # entra en los enlaces públicos de consulta: al subirla se invalidan todos los emitidos
    imap_host: Optional[str] = None              # buzón donde llegan los comprobantes de proveedores (recepción)
    imap_puerto: int = 993
    imap_seguridad: str = "ssl"
    imap_usuario: Optional[str] = None
    imap_password: Optional[str] = None       # cifrada
    imap_carpeta: str = "INBOX"
    imap_dias: int = 60
    imap_ultima: Optional[str] = None
    imap_error: Optional[str] = None             # último error del buzón (se muestra en la pestaña Buzón) (R142)
    imap_intento: Optional[str] = None           # último intento de lectura (con error se reintenta a lo sumo cada hora)
    actividad_nombre: Optional[str] = None       # descripción de la actividad económica (se imprime en el PDF)
    sitio_web: Optional[str] = None
    logo_nombre: Optional[str] = None
    # Plan y extras (3.16): los asigna el administrador del sistema; sin plan = todo encendido (app/planes.py)
    plan: Optional[str] = None                   # código del plan del tipo de negocio (fac_250, pos, hotel…)
    extras: str = "[]"                           # JSON: contabilidad, rrhh, pos, hotel_completo, canales
    funciones: str = "[]"                        # JSON: funciones en prueba encendidas solo en esta empresa (3.58, app/planes.py FUNCIONES)
    modulos_ocultos: str = "[]"                  # JSON: módulos del plan apagados a mano en esta empresa (3.70): no salen en el menú ni en los permisos
    docs_extra: int = 0                          # paquetes de documentos comprados en el periodo
    plan_inicio: Optional[str] = None            # inicio del plan prepago anual (AAAA-MM-DD)
    habitaciones: int = 0                        # hotel: habitaciones contratadas (0 = sin límite)
    cajas: int = 0                               # punto de venta: cajas contratadas (0 = sin límite)
    limite_usuarios: int = 0                     # 0 = sin límite
    vence: Optional[str] = None                  # vencimiento del plan (AAAA-MM-DD); después, modo lectura
    aviso_plan: Optional[str] = None             # último recordatorio de vencimiento enviado («7:<vence>» o «v:<vence>») (3.17)
    bloqueada: bool = False
    bloqueo_motivo: Optional[str] = None
    mfa_sin_excepcion: bool = False              # 4.7: «Exigir la verificación en dos pasos sin excepción»: la renuncia de sus usuarios no vale aquí (auth.mfa_cubierto)
    es_demo: bool = False                        # empresa de demostración con datos de ejemplo (nunca se conecta a Hacienda)
    prueba_hasta: Optional[str] = None           # prueba gratis: AAAA-MM-DD; después no se puede entrar (vacío = cliente)
    tipo_negocio: str = "facturacion"            # facturacion | comercio | hospitalidad: lo fija el administrador del sistema al crear la cuenta (2.5)
    clave_cifrada: Optional[str] = None          # clave propia de la empresa, cifrada con la clave maestra del servidor
    creada: Optional[datetime] = Field(default_factory=lambda: datetime.now(timezone.utc))


class Cabys(SQLModel, table=True):
    """Catálogo oficial de bienes y servicios (13 dígitos) con su tarifa de IVA. Compartido por todas las empresas."""
    codigo: str = Field(primary_key=True, max_length=13)
    descripcion: str = Field(index=True)
    impuesto: float = 13
    categoria: Optional[str] = None
    subcategoria: Optional[str] = None
    incluye: Optional[str] = None
    excluye: Optional[str] = None
    busqueda: Optional[str] = Field(default=None, index=True)


class Auditoria(SQLModel, table=True):
    """Registro de acciones (quién hizo qué, cuándo y desde dónde)."""
    id: Optional[int] = Field(default=None, primary_key=True)
    fecha: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), index=True)
    usuario_id: Optional[int] = Field(default=None, index=True)
    correo: Optional[str] = None
    empresa_id: Optional[int] = Field(default=None, index=True)
    accion: str = Field(index=True)              # login, login_fallido, emitir, enviar_hacienda, config_empresa, bloquear_cuenta, ...
    detalle: Optional[str] = None
    ip: Optional[str] = None


central(Empresa, Cabys, Auditoria)


# ----------------------------------------------------------------------------- por empresa
class Cliente(SQLModel, table=True):
    # AUTOINCREMENT: en la instalación local los ids nuevos siguen por encima del rango de su terminal aunque se borren filas (3.13)
    __table_args__ = {"sqlite_autoincrement": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    nombre: str
    tipo_id: str = "01"
    numero_id: str
    correo: Optional[str] = None
    correo_facturas: Optional[str] = None    # «Enviar facturas a»: vacío = el correo principal (3.38)
    correo_cc: Optional[str] = None          # «Copia (CC) de las facturas» (3.38)
    telefono: Optional[int] = None
    actividad: Optional[str] = None
    tipo: str = "Cliente"                    # Cliente | Proveedor | Ambos
    nombre_comercial: Optional[str] = None
    provincia: Optional[int] = None
    canton: Optional[int] = None
    distrito: Optional[int] = None
    barrio: Optional[str] = None
    direccion: Optional[str] = None
    celular: Optional[int] = None
    termino_pago_dias: Optional[int] = None
    limite_credito: Optional[float] = None
    vendedor: Optional[str] = None
    enviar_estado_cuenta: bool = False
    comentarios: Optional[str] = None
    direcciones: Optional[str] = None       # 4.6: otras direcciones de entrega (casa, trabajo…): JSON [{nombre, detalle, enlace}]; la caja las ofrece al pedir Express
    activo: bool = True


class Producto(SQLModel, table=True):
    __table_args__ = {"sqlite_autoincrement": True}
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    codigo: Optional[str] = None
    nombre: str
    cabys: str
    precio: float
    moneda: str = "CRC"                     # moneda del precio (3.25): CRC o USD; el costo siempre va en la principal
    unidad_medida: str = "Unid"
    es_servicio: bool = False
    codigo_tarifa: str = "08"
    tarifa: float = 13.0
    otro_impuesto: Optional[str] = None      # JSON: Selectivo de Consumo o impuesto específico del ítem (3.41; fe.modelos.otro_impuesto)
    tipo: str = "Producto"                   # Producto | Servicio | Combo | Surtido
    descripcion: Optional[str] = None
    categoria: Optional[str] = None
    costo: float = 0
    inventariable: bool = True
    venta_negativo: bool = False
    partida_arancelaria: Optional[str] = None
    activo: bool = True
    imagen_nombre: Optional[str] = None
    es_venta: bool = True                    # apagado = insumo o preparación (3.18): sin CABYS, no sale en caja ni facturas
    # catálogo público de pedidos en línea (FISITAAP, 3.47)
    visible_catalogo: bool = False           # aparece en el catálogo web del negocio
    descripcion_publica: Optional[str] = None
    destacado: bool = False
    agotado: bool = False                    # se muestra, pero no se puede pedir
    existencia_minima: Optional[float] = None   # 3.87: al llegar aquí el ítem sale en Inventario › Por reponer (vacío = sin aviso)
    existencia_maxima: Optional[float] = None   # 3.87: hasta dónde se sugiere reponer (vacío = el doble del mínimo)


class Secuencia(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int
    tipo_documento: str
    ambiente: str = ""              # sandbox | produccion: cada ambiente lleva su propia serie (R91); '' = filas anteriores
    sucursal: int = 1               # 3.66: cada sucursal lleva su propia numeración (código de Hacienda)
    ultimo: int = 0


class Documento(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int
    tipo_documento: str
    clave: str = Field(index=True)
    consecutivo: str
    fecha_emision: str
    cliente_id: Optional[int] = None
    receptor_nombre: Optional[str] = None
    moneda: str = "CRC"
    tipo_cambio: float = 1          # del comprobante (ResumenFactura/TipoCambio); 1 en colones. Para consolidar montos en CRC/USD
    total: float = 0
    marca_id: Optional[int] = None  # marca (logo y nombre comercial) con que se emitió (3.45); vacío = la empresa
    impuesto: float = 0            # IVA neto (3.41: sin el Selectivo ni los específicos, que van en otros_impuestos)
    otros_impuestos: float = 0     # Selectivo de Consumo e impuestos específicos (3.41)
    estado: str = "generado"       # generado | firmado | enviado | aceptado | rechazado | error
    ambiente: str = "sandbox"      # ambiente de Hacienda en que se emitió (los de pruebas no se mezclan con producción)
    sucursal_id: Optional[int] = None   # 3.66: sucursal que lo emitió (los anteriores se reconocen por el código en el consecutivo)
    mensaje_hacienda: Optional[str] = None
    intentos_hacienda: int = 0     # reintentos de la cola (envío/consulta) con espera creciente
    ultimo_intento: Optional[str] = None
    xml_nombre: Optional[str] = None
    respuesta_nombre: Optional[str] = None
    correo_enviado: Optional[str] = None
    idempotencia: Optional[str] = Field(default=None, index=True)
    fecha_envio: Optional[str] = None            # cuándo pasó a 'enviado' (las 24 h del R96 se cuentan desde aquí)
    terminos: Optional[str] = None               # términos y condiciones impresos (R103)
    orden_compra: Optional[str] = None           # orden de compra del cliente (R103)   # clave del formulario: un reenvío tras un corte devuelve el mismo comprobante (R93)
    vendedor: Optional[str] = None
    fecha_vencimiento: Optional[str] = None
    pagado: float = 0
    acreditado: float = 0          # notas de crédito ACEPTADAS que rebajan esta factura (saldo = total − pagado − acreditado)
    referencia_clave: Optional[str] = Field(default=None, index=True)   # notas: clave del comprobante al que se refieren
    referencia_codigo: Optional[str] = None                             # notas: 01 anula, 02 corrige texto, 03 corrige monto… (R330)
    condicion_venta: Optional[str] = None   # 01 contado, 02 crédito, 10 crédito con IVA diferido (procede REP al cobrar)…
    otros_cargos: Optional[str] = None      # JSON [{tipo, detalle, porcentaje, monto}]: impuesto de servicio, timbres… (no van en las líneas; el total los incluye)
    exoneracion_id: Optional[int] = None    # exoneración del cliente aplicada (exoneraciones.ExoneracionCliente)
    exoneracion_numero: Optional[str] = None
    iva_exonerado: float = 0                # IVA que no se cobró por la exoneración (suma de MontoExoneracion)
    creado: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    sinc_en: Optional[str] = None                # instalación local: cuándo subió a la nube (3.12)
    sinc_estado: Optional[str] = None            # estado que tenía al subir (si cambia, se vuelve a subir)
    origen_sinc: Optional[str] = None            # nube: nombre de la instalación local que lo emitió
    importado_de: Optional[str] = None           # 3.27: histórico traído de otro sistema (no se reenvía, no cuenta en el plan, sin asientos automáticos)
    aviso_enviado: Optional[str] = None          # 3.87: aviso al dueño «estado:fecha» (rechazado, error, atascado; pendiente: lo junta la cola)


class DocumentoLinea(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    documento_id: int = Field(index=True)
    numero: int
    producto_id: Optional[int] = None
    cabys: str
    detalle: str
    cantidad: float
    unidad_medida: str
    precio_unitario: float
    descuento: float = 0
    codigo_tarifa: str = "08"
    tarifa: float = 13
    impuesto: float = 0                     # IVA neto de la línea (lo que va a la declaración de IVA)
    otros_impuestos: float = 0              # Selectivo de Consumo e impuestos específicos (3.41)
    impuestos_detalle: Optional[str] = None # JSON [{codigo, nombre, tarifa, monto}] de los otros impuestos (3.41)
    total: float = 0
    iva_exonerado: float = 0                # MontoExoneracion de la línea
    tarifa_exonerada: Optional[float] = None


class ConfigDocumento(SQLModel, table=True):
    """Campos visibles y textos por defecto de cada tipo de documento impreso (Configuración › Documentos)."""
    __tablename__ = "configdocumento2"
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(default=1, index=True)
    tipo: str = Field(index=True)
    titulo: Optional[str] = None
    campos: str = "[]"
    terminos: Optional[str] = None
    notas: Optional[str] = None


por_empresa(Cliente, Producto, Secuencia, Documento, DocumentoLinea, ConfigDocumento)


# ----------------------------------------------------------------------------- motores y sesiones
def _crear_tablas(eng) -> None:
    """4.16: entre la revisión y el CREATE TABLE otro proceso de Passenger puede crear la misma tabla nueva: esa petición, que puede ser una venta, no debe fallar."""
    from sqlalchemy.exc import OperationalError
    try:
        SQLModel.metadata.create_all(eng, tables=TABLAS_EMPRESA)
    except OperationalError as ex:
        if "already exists" not in str(ex).lower():
            raise
        SQLModel.metadata.create_all(eng, tables=TABLAS_EMPRESA)


def _asegurar_autoincrement(eng, tablas):
    """Instalación local (3.13): cliente y producto necesitan AUTOINCREMENT para que los ids nuevos sigan por encima del rango de
    la terminal aunque se borren filas. SQLite no lo cambia con ALTER: una base creada antes se reconstruye una sola vez."""
    from sqlalchemy import inspect, text
    insp = inspect(eng)
    for tabla in tablas:
        if not insp.has_table(tabla.name):
            continue
        with eng.begin() as conn:
            sql = conn.execute(text("SELECT sql FROM sqlite_master WHERE type='table' AND name=:n"), {"n": tabla.name}).scalar() or ""
            if "AUTOINCREMENT" in sql.upper():
                continue
            cols = ", ".join(f'"{c["name"]}"' for c in insp.get_columns(tabla.name))
            for idx in insp.get_indexes(tabla.name):
                conn.execute(text(f'DROP INDEX IF EXISTS "{idx["name"]}"'))
            conn.execute(text(f'ALTER TABLE "{tabla.name}" RENAME TO "{tabla.name}__vieja"'))
            tabla.create(conn)
            conn.execute(text(f'INSERT INTO "{tabla.name}" ({cols}) SELECT {cols} FROM "{tabla.name}__vieja"'))
            conn.execute(text(f'DROP TABLE "{tabla.name}__vieja"'))


def _agregar_columnas_faltantes(eng, tablas):
    """Migración mínima para SQLite: agrega columnas nuevas a tablas existentes (create_all no lo hace)."""
    from sqlalchemy import inspect, text
    insp = inspect(eng)
    with eng.begin() as conn:
        for tabla in tablas:
            if not insp.has_table(tabla.name):
                continue
            existentes = {c["name"] for c in insp.get_columns(tabla.name)}
            for col in tabla.columns:
                if col.name not in existentes:
                    tipo = col.type.compile(eng.dialect)
                    default = ""
                    if col.default is not None and getattr(col.default, "is_scalar", False):
                        v = col.default.arg
                        default = f" DEFAULT {int(v) if isinstance(v, bool) else repr(v) if isinstance(v, str) else v}"
                    try:
                        conn.execute(text(f'ALTER TABLE {tabla.name} ADD COLUMN {col.name} {tipo}{default}'))
                    except Exception as ex:  # otro proceso agregó la columna un instante antes
                        if "duplicate column" not in str(ex).lower():
                            raise


# Índices únicos de la base por empresa: red de seguridad contra consecutivos o claves repetidos
INDICES_EMPRESA = (
    "DROP INDEX IF EXISTS ux_secuencia",
    "DROP INDEX IF EXISTS ux_secuencia_amb",                       # 3.66: la serie es por sucursal
    "CREATE UNIQUE INDEX IF NOT EXISTS ux_secuencia_suc ON secuencia(empresa_id, tipo_documento, ambiente, sucursal)",
    "CREATE UNIQUE INDEX IF NOT EXISTS ux_documento_clave ON documento(clave)",
    "CREATE UNIQUE INDEX IF NOT EXISTS ux_documento_consecutivo ON documento(empresa_id, ambiente, tipo_documento, consecutivo)",
    # existencias: una fila por producto y bodega (dos movimientos simultáneos del primer ingreso creaban dos filas); antes
    # del índice se funden las duplicadas sumando cantidades
    "UPDATE existencia SET cantidad = (SELECT SUM(e2.cantidad) FROM existencia e2 WHERE e2.producto_id = existencia.producto_id AND e2.bodega_id = existencia.bodega_id) "
    "WHERE id IN (SELECT MIN(id) FROM existencia GROUP BY producto_id, bodega_id HAVING COUNT(*) > 1)",
    "DELETE FROM existencia WHERE id NOT IN (SELECT MIN(id) FROM existencia GROUP BY producto_id, bodega_id)",
    "CREATE UNIQUE INDEX IF NOT EXISTS ux_existencia ON existencia(producto_id, bodega_id)",
    # 3.73: consultas por fecha (caja, reportes, resumen), por cliente (estado de cuenta) y por estado (cola de Hacienda)
    "CREATE INDEX IF NOT EXISTS ix_documento_fecha_emision ON documento(fecha_emision)",
    "CREATE INDEX IF NOT EXISTS ix_documento_cliente_id ON documento(cliente_id)",
    "CREATE INDEX IF NOT EXISTS ix_documento_estado ON documento(estado)",
)


def _inodo(ruta) -> int | None:
    try:
        return ruta.stat().st_ino
    except FileNotFoundError:
        return None


_huella: dict = {}


def huella_esquema() -> int:
    """3.87: número que resume el esquema de las bases por empresa (tablas, columnas con su tipo y valor por defecto, índices, los
    índices de INDICES_EMPRESA y el modo local). Se guarda en cada base (PRAGMA user_version) después de migrarla: si al abrirla
    coincide, ya tiene todo y no se vuelve a revisar tabla por tabla (~30 ms por empresa en cada arranque). Cualquier tabla, columna
    o índice nuevo cambia el número; una base restaurada de otra versión o una empresa nueva traen otro número (o 0) y se migran."""
    import hashlib
    clave = (len(TABLAS_EMPRESA), os.environ.get("FE_MODO_LOCAL") == "1")
    if clave not in _huella:
        partes = [repr(clave[1]), repr(INDICES_EMPRESA), repr(_INDICES_SUELTOS)]
        for tabla in sorted(TABLAS_EMPRESA, key=lambda x: x.name):
            cols = []
            for c in tabla.columns:
                d = c.default.arg if c.default is not None and getattr(c.default, "is_scalar", False) else None
                cols.append((c.name, c.type.compile(engine.dialect), bool(c.nullable), bool(c.primary_key), repr(d)))
            idx = sorted((i.name or "", tuple(x.name for x in i.columns), bool(i.unique)) for i in tabla.indexes)
            partes.append(repr((tabla.name, cols, idx, tabla.dialect_options["sqlite"].get("autoincrement"))))
        h = int.from_bytes(hashlib.sha256(chr(10).join(partes).encode("utf-8")).digest()[:4], "big") & 0x7FFFFFFF
        _huella[clave] = h or 1
    return _huella[clave]


# cada índice en su propia transacción: si una base vieja tiene duplicados, ese índice espera (migrar_registros limpia
# los de registro) y los demás sí se crean (R237)
_INDICES_SUELTOS = ("CREATE UNIQUE INDEX IF NOT EXISTS ux_registro_clave ON registro(empresa_id, clave)",
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_pago_numero ON pago(empresa_id, numero)",
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_pago_idem ON pago(empresa_id, idempotencia) WHERE idempotencia IS NOT NULL",   # 4.8
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_ajuste_numero ON ajusteinventario(empresa_id, tipo, numero)",
                    "CREATE UNIQUE INDEX IF NOT EXISTS ux_pendiente_periodo ON facturapendiente(recurrente_id, periodo)")


def engine_empresa(eid: int):
    """Motor (y archivo .db) de una empresa; lo crea con sus tablas la primera vez.
    Se revalida contra el archivo real: si otro proceso borró y recreó la base, el motor cacheado se descarta.
    3.87: la base guarda la huella de su esquema (huella_esquema); si ya es la actual, no se revisan tablas, columnas ni índices."""
    ruta = EMPRESAS_DIR / f"empresa_{eid}.db"
    ino = _inodo(ruta)
    hit = _engines.get(eid)
    if hit is not None and hit[1] == ino and ino is not None:
        return hit[0]
    if hit is not None:
        hit[0].dispose()
    from . import inventario, clinicas_modelos  # noqa: F401  tablas por empresa, incluidas Clínicas
    from sqlalchemy import text
    eng = _nuevo_engine(f"sqlite:///{ruta}")
    huella = huella_esquema()
    try:
        with eng.connect() as conn:
            al_dia = ino is not None and conn.exec_driver_sql("PRAGMA user_version").scalar() == huella
    except Exception:  # noqa: BLE001  base dañada o bloqueada: se sigue por el camino de siempre
        al_dia = False
    if al_dia:
        _engines[eid] = (eng, _inodo(ruta))
        return eng
    _crear_tablas(eng)
    _agregar_columnas_faltantes(eng, TABLAS_EMPRESA)
    if os.environ.get("FE_MODO_LOCAL") == "1":
        _asegurar_autoincrement(eng, [Cliente.__table__, Producto.__table__])
    with eng.begin() as conn:
        for sql in INDICES_EMPRESA:
            conn.execute(text(sql))
    completos = True
    for sql in _INDICES_SUELTOS:
        try:
            with eng.begin() as conn:
                conn.execute(text(sql))
        except Exception:  # noqa: BLE001
            completos = False
    if completos:                                # 3.87: solo con todo al día se marca; si un índice esperó, se reintenta la próxima vez
        try:
            with eng.begin() as conn:
                conn.exec_driver_sql(f"PRAGMA user_version = {int(huella)}")
        except Exception:  # noqa: BLE001
            pass
    _engines[eid] = (eng, _inodo(ruta))
    return eng


def init_db():
    from . import auth, inventario, suscripcion  # noqa: F401  (registran sus tablas; suscripcion: pago con Tilopay 3.36)
    SQLModel.metadata.create_all(engine, tables=TABLAS_CENTRAL)
    _agregar_columnas_faltantes(engine, TABLAS_CENTRAL)
    # Empresas configuradas antes de existir smtp_seguridad: puerto 587 siempre fue STARTTLS (SSL en 587 nunca funciona).
    from sqlalchemy import text
    with engine.begin() as conn:
        conn.execute(text("UPDATE empresa SET smtp_seguridad='starttls' WHERE smtp_puerto=587 AND smtp_seguridad='ssl' AND smtp_host IS NOT NULL AND smtp_host<>''"))
        # Un rol personalizado que se llamara como un rol base nuevo (1.23: «Cajero») pasa a «Cajero (propio)» con sus mismos
        # permisos; si no, sus usuarios cambiarían de permisos en silencio y el rol no se podría editar.
        for base in auth.ROLES:
            try:
                filas = conn.execute(text("SELECT id, empresa_id, nombre FROM rolempresa WHERE lower(nombre) = :n"), {"n": base.lower()}).fetchall()
                for rid, eid, nombre in filas:
                    nuevo = f"{base} (propio)"
                    conn.execute(text("UPDATE rolempresa SET nombre = :nuevo WHERE id = :id"), {"nuevo": nuevo, "id": rid})
                    conn.execute(text("UPDATE usuarioempresa SET rol = :nuevo WHERE empresa_id = :e AND lower(rol) = :n"), {"nuevo": nuevo, "e": eid, "n": base.lower()})
            except Exception:  # noqa: BLE001  tabla aún inexistente en una instalación nueva
                pass


def get_session():
    """Sesión de la base CENTRAL."""
    with Session(engine) as s:
        yield s


def sesion_de(eid: int) -> Session:
    return Session(engine_empresa(eid))
