"""Clínicas sobre ERP 4.22. Solo nube, activación expresa, datos cifrados y permisos propios.

No implementa certificación de firma, diagnóstico automático ni conectores sanitarios externos.
Las firmas de entradas son atribuciones autenticadas al usuario, con correcciones append-only.
"""
import base64
import hashlib
import hmac
import json
import math
import os
import re
from types import SimpleNamespace
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from typing import Literal, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy import text
from sqlmodel import Session, select

from . import auth, inventario, modulos, planes, secretos
from .auth import Contexto, contexto, sesion_empresa
from .config import TZ_CR, ahora_cr
from .db import Cliente, Documento, Empresa, Producto, engine
from .clinicas_modelos import (
    ClinicaAdjunto, ClinicaAuditoria, ClinicaCargo, ClinicaCita, ClinicaDispensa,
    ClinicaEntrada, ClinicaEpisodio, ClinicaLote, ClinicaOrden, ClinicaPaciente, ClinicaProfesional,
    ClinicaRecurso, momento,
)

router = APIRouter(prefix="/api/clinicas", tags=["clinicas"])
PERMISOS = ("clinicas", "clinicas_configurar", "clinicas_atender", "clinicas_supervisar",
            "clinicas_mental", "clinicas_farmacia", "clinicas_laboratorio", "clinicas_auditar")
TIPOS_ENTRADA = {"soap", "alergia", "problema", "vitales", "dental", "periodontal", "tratamiento", "mental", "receta", "resultado", "nota"}
ESTADOS_CITA = {"confirmada": {"llegada", "cancelada", "no_asistio"}, "llegada": {"atendida", "cancelada"}}
ESTADOS_ORDEN = {"firmada": {"recolectada", "cancelada"}, "recolectada": {"recibida", "rechazada"},
                 "recibida": {"en_proceso", "rechazada"}, "en_proceso": {"completada"}}
CLAVE = Field(min_length=8, max_length=100, pattern=r"^[A-Za-z0-9_.:-]+$")


class EntradaBase(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False, str_strip_whitespace=True)


def acceso(permiso="clinicas"):
    def dep(ctx: Contexto = Depends(contexto)):
        if os.getenv("FE_MODO_LOCAL") == "1":
            raise HTTPException(403, "Clínicas requiere la aplicación en la nube; no se sincronizan expedientes al programa local")
        planes.exigir_modulo(ctx.empresa, "clinicas")
        # Los privilegios de superadmin y tokens generales NO conceden acceso clínico implícito.
        if ctx.token_api is not None or "clinicas" not in ctx.permisos or permiso not in ctx.permisos:
            raise HTTPException(403, "Su rol no tiene este permiso de Clínicas")
        if not getattr(ctx.usuario, "mfa_activo", False):
            raise HTTPException(403, {"codigo": "clinicas_mfa", "mensaje": "Active la verificación en dos pasos para usar Clínicas"})
        if not ctx.empresa.clave_cifrada:
            # El ERP crea la clave al dar de alta la empresa. No se reemplaza ni regenera desde este módulo.
            raise HTTPException(409, "La empresa no tiene clave de cifrado. Revise su configuración y respaldo")
        return ctx
    return dep


def _lock(s):
    # Bloqueo SQLite real, compartido entre workers Passenger; antes de leer saldos, versiones y agenda.
    s.execute(text("INSERT OR IGNORE INTO clinica_mutex(id, revision) VALUES(1, 0)"))
    s.execute(text("UPDATE clinica_mutex SET revision=revision+1 WHERE id=1"))


def _json(v):
    try:
        r = json.dumps(v, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    except (ValueError, TypeError):
        raise HTTPException(422, "Datos no válidos")
    if len(r.encode()) > 80000:
        raise HTTPException(413, "El registro excede 80 KB")
    return r


def _cifrar(ctx, v):
    return secretos.cifrar(ctx.empresa.clave_cifrada, _json(v))


def _abrir(ctx, v):
    try:
        return json.loads(secretos.descifrar(ctx.empresa.clave_cifrada, v))
    except (ValueError, TypeError):
        raise HTTPException(409, "No se pudo abrir el registro clínico; revise las claves del respaldo")


def _get(s, modelo, oid, ctx):
    obj = s.get(modelo, oid)
    if not obj or obj.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Registro no encontrado")
    return obj


def _lista(s, modelo, ctx):
    return s.exec(select(modelo).where(modelo.empresa_id == ctx.empresa.id)).all()


def _audit(s, ctx, accion, objeto):
    ultimo = s.exec(select(ClinicaAuditoria).where(ClinicaAuditoria.empresa_id == ctx.empresa.id).order_by(ClinicaAuditoria.id.desc()).limit(1)).first()
    previo = ultimo.huella if ultimo else "0" * 64
    creado = momento()
    uid = int(ctx.usuario.id)
    cuerpo = f"{ctx.empresa.id}|{uid}|{accion}|{objeto}|{creado}|{previo}"
    firma = hmac.new(auth.SECRET, cuerpo.encode(), hashlib.sha256).hexdigest()
    s.add(ClinicaAuditoria(empresa_id=ctx.empresa.id, usuario_id=uid, accion=accion,
                          objeto=str(objeto), previo=previo, huella=firma, creado=creado))


def _fecha(v):
    if not isinstance(v, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        raise HTTPException(422, "Fecha inválida; use AAAA-MM-DD")
    try:
        return date.fromisoformat(v).isoformat()
    except (TypeError, ValueError):
        raise HTTPException(422, "Fecha inválida; use AAAA-MM-DD")


def _dt(v):
    try:
        d = datetime.fromisoformat(v)
        if d.tzinfo is None:
            raise ValueError
        return d.astimezone(TZ_CR)
    except (TypeError, ValueError):
        raise HTTPException(422, "Indique fecha y hora con zona horaria (Costa Rica: -06:00)")


def _recurso(s, ctx, rid):
    r = _get(s, ClinicaRecurso, rid, ctx) if rid else None
    sid = getattr(ctx.sucursal, "id", None)
    if ctx.sucursal_fija and (not r or r.sucursal_id != sid):
        raise HTTPException(403, "El recurso no pertenece a su sucursal")
    return r


def _profesional(s, ctx, pid, propio=False):
    p = _get(s, ClinicaProfesional, pid, ctx)
    if not p.activo or p.vence < ahora_cr().date().isoformat():
        raise HTTPException(409, "El profesional está inactivo o tiene la credencial vencida")
    if propio and p.usuario_id != ctx.usuario.id and "clinicas_supervisar" not in ctx.permisos:
        raise HTTPException(403, "El episodio no está asignado a su usuario")
    return p


def _episodio(s, ctx, eid, clinico=False):
    ep = _get(s, ClinicaEpisodio, eid, ctx)
    _recurso(s, ctx, ep.recurso_id)
    if clinico:
        if "clinicas_atender" not in ctx.permisos:
            raise HTTPException(403, "Se requiere permiso de atención clínica")
        p = _get(s, ClinicaProfesional, ep.profesional_id, ctx)
        if p.usuario_id != ctx.usuario.id and "clinicas_supervisar" not in ctx.permisos:
            raise HTTPException(403, "El episodio no está asignado a su usuario")
    return ep


def _vigente(s, ctx):
    p = s.exec(select(ClinicaProfesional).where(ClinicaProfesional.empresa_id == ctx.empresa.id,
                                               ClinicaProfesional.usuario_id == ctx.usuario.id)).first()
    if not p:
        raise HTTPException(403, "Vincule su usuario a un profesional con credencial vigente")
    return _profesional(s, ctx, p.id)


class PacienteIn(EntradaBase):
    nombre: str = Field(min_length=2, max_length=160)
    tipo_id: str = Field(default="01", min_length=2, max_length=20)
    documento: str = Field(default="", max_length=40)
    nacimiento: Optional[str] = None
    telefono: str = Field(default="", max_length=40)
    correo: str = Field(default="", max_length=160)
    representante: str = Field(default="", max_length=300)
    consentimiento: Literal["pendiente", "aceptado", "revocado"] = "pendiente"
    cliente_id: Optional[int] = None
    activo: bool = True
    version: int = Field(default=1, ge=1)


def _datos_paciente(s, ctx, data):
    d = data.model_dump(exclude={"version", "cliente_id", "activo"})
    d["nombre"] = d["nombre"].strip()
    if len(d["nombre"]) < 2:
        raise HTTPException(422, "Indique el nombre del paciente")
    if data.nacimiento:
        n = _fecha(data.nacimiento)
        if n > ahora_cr().date().isoformat():
            raise HTTPException(422, "El nacimiento no puede estar en el futuro")
    if data.cliente_id:
        _get(s, Cliente, data.cliente_id, ctx)
    documento = re.sub(r"[^\w]", "", data.documento).upper()
    identidad = hmac.new(auth.SECRET, f"clinica:{ctx.empresa.id}:{data.tipo_id}:{documento}".encode(), hashlib.sha256).hexdigest() if documento else None
    return d, identidad


def _paciente_dict(ctx, p):
    return {**_abrir(ctx, p.datos), "id": p.id, "cliente_id": p.cliente_id, "activo": p.activo, "version": p.version}


@router.get("/capacidades")
def capacidades(ctx: Contexto = Depends(acceso())):
    return {"base": "4.22", "modulo": "clinicas-1.0-rc1", "permisos": sorted(set(PERMISOS) & ctx.permisos),
            "integraciones_externas": False, "modo_local": False,
            "firma": "Atribución al usuario autenticado; no firma digital certificada",
            "avisos": ["Interacciones farmacológicas requieren revisión del profesional", "No incluye portal de pacientes, LIS, PACS, receta nacional ni teleconsulta"]}


@router.get("/pacientes")
def pacientes(q: str = Query("", max_length=100), limite: int = Query(100, ge=1, le=200),
              desde: int = Query(0, ge=0), ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    _lock(s)
    filas = s.exec(select(ClinicaPaciente).where(ClinicaPaciente.empresa_id == ctx.empresa.id,
                                                ClinicaPaciente.id > desde).order_by(ClinicaPaciente.id).limit(5000)).all()
    salida = []
    for p in filas:
        d = _paciente_dict(ctx, p)
        if not q or q.casefold() in " ".join(str(d.get(k) or "") for k in ("nombre", "documento", "telefono")).casefold():
            salida.append(d)
            if len(salida) == limite:
                break
    _audit(s, ctx, "pacientes_buscar", "lista"); s.commit()
    return salida


@router.post("/pacientes")
def crear_paciente(data: PacienteIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    _lock(s)
    d, identidad = _datos_paciente(s, ctx, data)
    if identidad and s.exec(select(ClinicaPaciente.id).where(ClinicaPaciente.identidad == identidad)).first():
        raise HTTPException(409, "Ya existe un paciente con ese documento; revise la ficha existente")
    p = ClinicaPaciente(empresa_id=ctx.empresa.id, identidad=identidad, datos=_cifrar(ctx, d), cliente_id=data.cliente_id, activo=data.activo)
    s.add(p); s.flush(); _audit(s, ctx, "paciente_crear", str(p.id)); s.commit()
    return _paciente_dict(ctx, p)


@router.put("/pacientes/{pid}")
def editar_paciente(pid: int, data: PacienteIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    _lock(s); p = _get(s, ClinicaPaciente, pid, ctx)
    if p.version != data.version:
        raise HTTPException(409, "La ficha cambió; recárguela antes de guardar")
    d, identidad = _datos_paciente(s, ctx, data)
    if identidad and s.exec(select(ClinicaPaciente.id).where(ClinicaPaciente.identidad == identidad, ClinicaPaciente.id != pid)).first():
        raise HTTPException(409, "Otro paciente tiene ese documento")
    # Auditoría conserva el valor anterior cifrado en una entrada administrativa aparte, sin exponerlo en la central.
    anterior = {"ficha": _abrir(ctx, p.datos), "version": p.version, "paciente_id": pid}
    s.add(ClinicaEntrada(empresa_id=ctx.empresa.id, episodio_id=0, paciente_id=pid, tipo="ficha_anterior",
                        datos=_cifrar(ctx, anterior), autor_id=ctx.usuario.id, clave=f"ficha:{pid}:{p.version}"))
    p.datos = _cifrar(ctx, d); p.identidad = identidad; p.cliente_id = data.cliente_id; p.activo = data.activo; p.version += 1
    s.add(p); _audit(s, ctx, "paciente_editar", str(pid)); s.commit()
    return _paciente_dict(ctx, p)


class ProfesionalIn(EntradaBase):
    usuario_id: int = Field(gt=0)
    nombre: str = Field(min_length=2, max_length=120)
    especialidad: str = Field(min_length=2, max_length=100)
    colegiado: str = Field(min_length=1, max_length=60)
    vence: str
    activo: bool = True
    horario: dict[str, list[list[str]]] = Field(default_factory=dict)


@router.get("/profesionales")
def profesionales(ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    return [p.model_dump(exclude={"empresa_id", "horario"}) | {"horario": json.loads(p.horario)} for p in _lista(s, ClinicaProfesional, ctx)]


@router.get("/catalogo")
def catalogo(ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    if not (set(ctx.permisos) & {"clinicas_atender", "clinicas_farmacia", "facturar"}):
        raise HTTPException(403, "Su rol no usa el catálogo clínico")
    productos = [{"id": p.id, "nombre": p.nombre, "es_servicio": p.es_servicio, "inventariable": p.inventariable,
                  **({"moneda": p.moneda, "precio": p.precio} if ctx.puede("facturar") else {})}
                 for p in _lista(s, Producto, ctx) if p.activo]
    bodegas = [{"id": b.id, "nombre": b.nombre} for b in _lista(s, inventario.Bodega, ctx) if b.activa] if "clinicas_farmacia" in ctx.permisos else []
    return {"productos": productos, "bodegas": bodegas}


@router.put("/profesionales/{pid}")
def guardar_profesional(pid: int, data: ProfesionalIn, ctx: Contexto = Depends(acceso("clinicas_configurar")), s: Session = Depends(sesion_empresa)):
    _lock(s)
    _fecha(data.vence)
    with Session(engine) as central:
        miembro = central.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == ctx.empresa.id,
                                                                  auth.UsuarioEmpresa.usuario_id == data.usuario_id)).first()
        if not miembro:
            raise HTTPException(422, "El usuario debe pertenecer a esta empresa")
    for dia, tramos in data.horario.items():
        if dia not in list("0123456") or len(tramos) > 4:
            raise HTTPException(422, "Horario no válido")
        for tramo in tramos:
            try:
                if len(tramo) != 2 or not all(re.fullmatch(r"\d{2}:\d{2}", t) for t in tramo) or time.fromisoformat(tramo[0]) >= time.fromisoformat(tramo[1]):
                    raise ValueError
            except (ValueError, TypeError):
                raise HTTPException(422, "Horario no válido: use HH:MM de inicio y fin")
    if s.exec(select(ClinicaProfesional.id).where(ClinicaProfesional.usuario_id == data.usuario_id, ClinicaProfesional.id != pid)).first():
        raise HTTPException(409, "El usuario ya está vinculado a otro profesional")
    p = _get(s, ClinicaProfesional, pid, ctx) if pid else ClinicaProfesional(empresa_id=ctx.empresa.id, **data.model_dump(exclude={"horario"}))
    for k, v in data.model_dump(exclude={"horario"}).items():
        setattr(p, k, v)
    p.horario = _json(data.horario)
    s.add(p); s.flush(); _audit(s, ctx, "profesional_guardar", str(p.id)); s.commit(); s.refresh(p)
    return p.model_dump(exclude={"empresa_id"})


class RecursoIn(EntradaBase):
    nombre: str = Field(min_length=2, max_length=100)
    sucursal_id: Optional[int] = None
    activo: bool = True


@router.get("/recursos")
def recursos(ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    return [r.model_dump(exclude={"empresa_id"}) for r in _lista(s, ClinicaRecurso, ctx)
            if not ctx.sucursal_fija or r.sucursal_id == getattr(ctx.sucursal, "id", None)]


@router.put("/recursos/{rid}")
def guardar_recurso(rid: int, data: RecursoIn, ctx: Contexto = Depends(acceso("clinicas_configurar")), s: Session = Depends(sesion_empresa)):
    _lock(s)
    if data.sucursal_id:
        from .sucursales import Sucursal
        _get(s, Sucursal, data.sucursal_id, ctx)
    if ctx.sucursal_fija and data.sucursal_id != getattr(ctx.sucursal, "id", None):
        raise HTTPException(403, "Seleccione su sucursal")
    r = _get(s, ClinicaRecurso, rid, ctx) if rid else ClinicaRecurso(empresa_id=ctx.empresa.id, **data.model_dump())
    if rid:
        _recurso(s, ctx, rid)
    for k, v in data.model_dump().items():
        setattr(r, k, v)
    s.add(r); s.flush(); _audit(s, ctx, "recurso_guardar", str(r.id)); s.commit(); s.refresh(r)
    return r.model_dump(exclude={"empresa_id"})


class CitaIn(EntradaBase):
    paciente_id: int = Field(gt=0)
    profesional_id: int = Field(gt=0)
    recurso_id: Optional[int] = None
    inicio: str
    fin: str
    motivo: str = Field(default="", max_length=500)
    clave: str = CLAVE


def _cita_dict(ctx, c):
    motivo = _abrir(ctx, c.motivo)
    return c.model_dump(exclude={"empresa_id", "motivo", "clave"}) | {"motivo": motivo}


def _hueco(s, ctx, p, inicio, fin, rid):
    if inicio.date() != fin.date() or not timedelta(minutes=5) <= fin - inicio <= timedelta(hours=8):
        raise HTTPException(422, "La cita debe durar entre 5 minutos y 8 horas en un mismo día")
    tramos = json.loads(p.horario).get(str(inicio.weekday()), [])
    if not any(time.fromisoformat(a) <= inicio.time() and fin.time() <= time.fromisoformat(b) for a, b in tramos):
        raise HTTPException(409, "Fuera del horario configurado del profesional")
    cs = s.exec(select(ClinicaCita).where(ClinicaCita.empresa_id == ctx.empresa.id,
            ClinicaCita.estado.in_(["confirmada", "llegada", "atendida"]), ClinicaCita.inicio < fin.isoformat(), ClinicaCita.fin > inicio.isoformat())).all()
    if any(c.profesional_id == p.id or (rid and c.recurso_id == rid) for c in cs):
        raise HTTPException(409, "El profesional o recurso ya tiene una cita en ese horario")
    return cs


@router.get("/citas")
def citas(dia: str, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    _fecha(dia); _lock(s)
    cs = s.exec(select(ClinicaCita).where(ClinicaCita.empresa_id == ctx.empresa.id, ClinicaCita.inicio >= dia,
               ClinicaCita.inicio < (date.fromisoformat(dia) + timedelta(days=1)).isoformat()).order_by(ClinicaCita.inicio)).all()
    salida = []
    for c in cs:
        if ctx.sucursal_fija:
            r = s.get(ClinicaRecurso, c.recurso_id) if c.recurso_id else None
            if not r or r.sucursal_id != getattr(ctx.sucursal, "id", None):
                continue
        salida.append(_cita_dict(ctx, c))
    _audit(s, ctx, "agenda_consultar", dia); s.commit()
    return salida


@router.post("/citas")
def crear_cita(data: CitaIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    _lock(s)
    vieja = s.exec(select(ClinicaCita).where(ClinicaCita.clave == data.clave)).first()
    if vieja:
        if (vieja.paciente_id, vieja.profesional_id, vieja.recurso_id, vieja.inicio, vieja.fin) != (data.paciente_id, data.profesional_id, data.recurso_id, _dt(data.inicio).isoformat(), _dt(data.fin).isoformat()):
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        _recurso(s, ctx, vieja.recurso_id)
        return _cita_dict(ctx, vieja)
    paciente = _get(s, ClinicaPaciente, data.paciente_id, ctx)
    if not paciente.activo:
        raise HTTPException(409, "Paciente inactivo")
    p = _profesional(s, ctx, data.profesional_id)
    inicio, fin = _dt(data.inicio), _dt(data.fin)
    if p.vence < inicio.date().isoformat():
        raise HTTPException(409, "La credencial no está vigente para el día de la cita")
    r = _recurso(s, ctx, data.recurso_id)
    if r and not r.activo:
        raise HTTPException(409, "El recurso está inactivo")
    cs = _hueco(s, ctx, p, inicio, fin, data.recurso_id)
    if any(c.paciente_id == paciente.id for c in cs):
        raise HTTPException(409, "El paciente ya tiene otra cita en ese horario")
    c = ClinicaCita(empresa_id=ctx.empresa.id, **data.model_dump(exclude={"inicio", "fin", "motivo"}),
                    inicio=inicio.isoformat(), fin=fin.isoformat(), motivo=_cifrar(ctx, data.motivo))
    s.add(c); s.flush(); _audit(s, ctx, "cita_crear", str(c.id)); s.commit()
    return _cita_dict(ctx, c)


class EstadoIn(EntradaBase):
    estado: str = Field(max_length=30)
    version: int = Field(ge=1)


class MotivoIn(EntradaBase):
    motivo: str = Field(min_length=10, max_length=1000)


@router.post("/citas/{cid}/estado")
def estado_cita(cid: int, data: EstadoIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    _lock(s); c = _get(s, ClinicaCita, cid, ctx); _recurso(s, ctx, c.recurso_id)
    if c.version != data.version:
        raise HTTPException(409, "La cita cambió; recargue la agenda")
    if data.estado not in ESTADOS_CITA.get(c.estado, set()):
        raise HTTPException(409, "Transición de cita no permitida")
    if data.estado == "atendida":
        raise HTTPException(409, "La cita se marca atendida al cerrar su episodio clínico")
    if data.estado == "cancelada" and s.exec(select(ClinicaEpisodio.id).where(ClinicaEpisodio.cita_id == cid)).first():
        raise HTTPException(409, "La cita tiene un episodio clínico; cierre el episodio")
    c.estado = data.estado; c.version += 1; s.add(c)
    _audit(s, ctx, "cita_" + data.estado, str(cid)); s.commit()
    return _cita_dict(ctx, c)


class EpisodioIn(EntradaBase):
    paciente_id: int = Field(gt=0)
    profesional_id: int = Field(gt=0)
    cita_id: Optional[int] = None
    recurso_id: Optional[int] = None
    clave: str = CLAVE


@router.post("/episodios")
def abrir_episodio(data: EpisodioIn, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); _vigente(s, ctx)
    previo = s.exec(select(ClinicaEpisodio).where(ClinicaEpisodio.clave == data.clave)).first()
    if previo:
        _episodio(s, ctx, previo.id, True)
        if (previo.paciente_id, previo.profesional_id, previo.cita_id, previo.recurso_id) != (data.paciente_id, data.profesional_id, data.cita_id, data.recurso_id):
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        return previo.model_dump(exclude={"empresa_id", "clave"})
    p = _get(s, ClinicaPaciente, data.paciente_id, ctx)
    if not p.activo:
        raise HTTPException(409, "Paciente inactivo")
    _profesional(s, ctx, data.profesional_id, True)
    r = _recurso(s, ctx, data.recurso_id)
    if r and not r.activo:
        raise HTTPException(409, "El recurso está inactivo")
    if data.cita_id:
        c = _get(s, ClinicaCita, data.cita_id, ctx)
        if (c.paciente_id, c.profesional_id, c.recurso_id) != (data.paciente_id, data.profesional_id, data.recurso_id) or c.estado != "llegada":
            raise HTTPException(409, "Registre la llegada y compruebe paciente, profesional y recurso de la cita")
        if s.exec(select(ClinicaEpisodio.id).where(ClinicaEpisodio.cita_id == c.id)).first():
            raise HTTPException(409, "Esta cita ya tiene un episodio")
    ep = ClinicaEpisodio(empresa_id=ctx.empresa.id, **data.model_dump())
    s.add(ep); s.flush(); _audit(s, ctx, "episodio_abrir", str(ep.id)); s.commit(); s.refresh(ep)
    return ep.model_dump(exclude={"empresa_id", "clave"})


def _entrada_dict(ctx, en):
    datos = _abrir(ctx, en.datos)
    return en.model_dump(exclude={"empresa_id", "datos", "clave"}) | {"datos": datos}


@router.get("/pacientes/{pid}/expediente")
def expediente(pid: int, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); p = _get(s, ClinicaPaciente, pid, ctx)
    episodios = s.exec(select(ClinicaEpisodio).where(ClinicaEpisodio.paciente_id == pid).order_by(ClinicaEpisodio.id.desc())).all()
    autorizados = []
    for ep in episodios:
        try:
            _episodio(s, ctx, ep.id, True); autorizados.append(ep)
        except HTTPException as ex:
            if ex.status_code != 403:
                raise
    ids = [ep.id for ep in autorizados]
    ens = s.exec(select(ClinicaEntrada).where(ClinicaEntrada.paciente_id == pid, ClinicaEntrada.episodio_id.in_(ids)).order_by(ClinicaEntrada.id)).all() if ids else []
    ens = [e for e in ens if e.tipo != "mental" or "clinicas_mental" in ctx.permisos]
    docs = s.exec(select(ClinicaAdjunto).where(ClinicaAdjunto.episodio_id.in_(ids))).all() if ids else []
    salida = {"paciente": _paciente_dict(ctx, p), "episodios": [e.model_dump(exclude={"empresa_id", "clave"}) for e in autorizados],
            "entradas": [_entrada_dict(ctx, e) for e in ens],
            "adjuntos": [{"id": a.id, "episodio_id": a.episodio_id, "tamano": a.tamano, "creado": a.creado} for a in docs if not a.mental or "clinicas_mental" in ctx.permisos]}
    _audit(s, ctx, "expediente_leer", str(pid)); s.commit()
    return salida


@router.get("/pacientes/{pid}/episodios")
def episodios_cobro(pid: int, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    ctx.exigir("facturar"); _get(s, ClinicaPaciente, pid, ctx)
    salida = []
    for ep in s.exec(select(ClinicaEpisodio).where(ClinicaEpisodio.paciente_id == pid).order_by(ClinicaEpisodio.id.desc())).all():
        try:
            _episodio(s, ctx, ep.id)
        except HTTPException as ex:
            if ex.status_code == 403: continue
            raise
        salida.append(ep.model_dump(exclude={"empresa_id", "clave"}))
    return salida


class EntradaIn(EntradaBase):
    tipo: str = Field(max_length=30)
    datos: dict
    anterior_id: Optional[int] = None
    clave: str = CLAVE


def _validar_entrada(s, ctx, ep, data):
    if data.tipo not in TIPOS_ENTRADA - {"resultado"}:
        raise HTTPException(422, "Tipo de entrada no admitido")
    _json(data.datos)
    if not data.datos:
        raise HTTPException(422, "Complete el contenido de la entrada")
    requeridos = {"nota": ("texto",), "mental": ("texto",), "alergia": ("agente", "reaccion"),
                  "problema": ("detalle",), "tratamiento": ("objetivo", "fases")}
    for k in requeridos.get(data.tipo, ()):
        if not isinstance(data.datos.get(k), str) or not data.datos[k].strip():
            raise HTTPException(422, f"Complete el campo {k}")
    if data.tipo == "vitales":
        rangos = {"pulso": (0, 350), "temperatura": (10, 50), "saturacion": (-0.001, 100), "peso": (0, 700), "talla": (0, 300)}
        if not any(str(v).strip() for v in data.datos.values()):
            raise HTTPException(422, "Indique al menos un signo vital")
        for k, v in data.datos.items():
            if v in (None, ""): continue
            if k == "presion":
                if not re.fullmatch(r"\d{2,3}/\d{2,3}", str(v)):
                    raise HTTPException(422, "Presión: use sistólica/diastólica en mmHg")
                continue
            try:
                n = float(v); a, b = rangos[k]
                if not math.isfinite(n) or not a < n <= b: raise ValueError
            except (ValueError, TypeError, KeyError):
                raise HTTPException(422, "Signo vital o unidad no válidos")
    if data.tipo == "mental" and "clinicas_mental" not in ctx.permisos:
        raise HTTPException(403, "Se requiere el permiso de notas de salud mental")
    if data.tipo == "soap" and not all(isinstance(data.datos.get(k), str) and data.datos[k].strip() for k in ("subjetivo", "objetivo", "evaluacion", "plan")):
        raise HTTPException(422, "Complete los cuatro campos SOAP")
    if data.tipo in {"dental", "periodontal"}:
        dientes = data.datos.get("dientes")
        validos = {str(q * 10 + d) for q in range(1, 9) for d in range(1, 9 if q <= 4 else 6)}
        if not isinstance(dientes, dict) or not dientes or any(str(d) not in validos for d in dientes):
            raise HTTPException(422, "Use dientes con nomenclatura FDI válida")
    if data.tipo == "receta":
        d = data.datos
        if d.get("revision_alergias") is not True or d.get("revision_interacciones") is not True:
            raise HTTPException(422, "El profesional debe confirmar revisión de alergias e interacciones")
        for k in ("medicamento", "dosis", "frecuencia", "via", "duracion"):
            if not isinstance(d.get(k), str) or not d[k].strip():
                raise HTTPException(422, "Complete medicamento, dosis, frecuencia, vía y duración")
        try:
            cantidad = Decimal(str(d.get("cantidad")))
            if not cantidad.is_finite() or not 0 < cantidad <= 100000:
                raise ValueError
        except Exception:
            raise HTTPException(422, "Cantidad de receta inválida")
        if d.get("producto_id"):
            prod = _get(s, Producto, d["producto_id"], ctx)
            if prod.es_servicio or not prod.inventariable or not prod.activo:
                raise HTTPException(422, "La receta requiere un producto activo e inventariable")
        if not d.get("vence") or _fecha(d["vence"]) < ahora_cr().date().isoformat():
            raise HTTPException(422, "La receta requiere una fecha de vencimiento vigente")
    if data.anterior_id:
        en = _get(s, ClinicaEntrada, data.anterior_id, ctx)
        if en.episodio_id != ep.id or en.tipo != data.tipo:
            raise HTTPException(422, "La corrección debe referirse a una entrada del mismo episodio y tipo")
        if s.exec(select(ClinicaEntrada.id).where(ClinicaEntrada.anterior_id == en.id)).first():
            raise HTTPException(409, "Esa entrada ya fue corregida; corrija la entrada más reciente")
        if data.tipo == "receta":
            ids = _cadena_receta(s, ctx, en)
            dispensado = sum(Decimal(str(x.cantidad)) for x in s.exec(select(ClinicaDispensa).where(ClinicaDispensa.receta_id.in_(ids))).all())
            if Decimal(str(data.datos["cantidad"])) < dispensado:
                raise HTTPException(409, "La receta corregida no puede indicar menos cantidad de la ya dispensada")
            if dispensado and data.datos.get("producto_id") != _abrir(ctx, en.datos).get("producto_id"):
                raise HTTPException(409, "No cambie el producto de una receta ya dispensada; registre una prescripción nueva")


@router.post("/episodios/{eid}/entradas")
def crear_entrada(eid: int, data: EntradaIn, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); ep = _episodio(s, ctx, eid, True); _vigente(s, ctx)
    previa = s.exec(select(ClinicaEntrada).where(ClinicaEntrada.clave == data.clave)).first()
    if previa:
        if previa.episodio_id != eid or previa.tipo != data.tipo or _abrir(ctx, previa.datos) != data.datos or previa.anterior_id != data.anterior_id:
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        if previa.tipo == "mental" and "clinicas_mental" not in ctx.permisos:
            raise HTTPException(403, "Sin acceso a notas protegidas")
        return _entrada_dict(ctx, previa)
    if ep.estado != "en_proceso" and not data.anterior_id:
        raise HTTPException(409, "El episodio está cerrado; solo admite correcciones enlazadas")
    p = _get(s, ClinicaPaciente, ep.paciente_id, ctx)
    if _abrir(ctx, p.datos).get("consentimiento") != "aceptado":
        raise HTTPException(409, "Registre el consentimiento de atención antes de firmar")
    _validar_entrada(s, ctx, ep, data)
    en = ClinicaEntrada(empresa_id=ctx.empresa.id, episodio_id=eid, paciente_id=ep.paciente_id,
                       tipo=data.tipo, datos=_cifrar(ctx, data.datos), autor_id=ctx.usuario.id,
                       anterior_id=data.anterior_id, clave=data.clave)
    s.add(en); s.flush(); _audit(s, ctx, "entrada_firmar", str(en.id)); s.commit()
    return _entrada_dict(ctx, en)


@router.post("/recetas/{rid}/anular")
def anular_receta(rid: int, data: MotivoIn, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); en = _get(s, ClinicaEntrada, rid, ctx); _episodio(s, ctx, en.episodio_id, True); _vigente(s, ctx)
    if en.tipo != "receta": raise HTTPException(422, "No es una receta")
    if s.exec(select(ClinicaEntrada.id).where(ClinicaEntrada.anterior_id == rid)).first():
        raise HTTPException(409, "La receta ya se corrigió o se anuló")
    anula = ClinicaEntrada(empresa_id=ctx.empresa.id, episodio_id=en.episodio_id, paciente_id=en.paciente_id,
                          tipo="receta_cancelacion", datos=_cifrar(ctx, {"motivo": data.motivo, "receta_id": rid}),
                          autor_id=ctx.usuario.id, anterior_id=rid, clave=f"anular-receta:{rid}")
    s.add(anula); _audit(s, ctx, "receta_anular", str(rid)); s.commit()
    return {"receta_id": rid, "anulada": True}


@router.post("/episodios/{eid}/cerrar")
def cerrar_episodio(eid: int, data: EstadoIn, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); ep = _episodio(s, ctx, eid, True); _vigente(s, ctx)
    if ep.estado == "finalizado" and data.estado == "finalizado":
        return {"id": ep.id, "estado": ep.estado, "version": ep.version}
    if data.version != ep.version or data.estado != "finalizado":
        raise HTTPException(409, "El episodio cambió o el estado no es válido")
    if not s.exec(select(ClinicaEntrada.id).where(ClinicaEntrada.episodio_id == eid, ClinicaEntrada.tipo.in_(["soap", "nota", "mental", "dental"]))).first():
        raise HTTPException(409, "Registre una nota de atención antes de cerrar")
    ep.estado = "finalizado"; ep.version += 1; s.add(ep)
    if ep.cita_id:
        c = _get(s, ClinicaCita, ep.cita_id, ctx); c.estado = "atendida"; c.version += 1; s.add(c)
    _audit(s, ctx, "episodio_cerrar", str(eid)); s.commit()
    return {"id": ep.id, "estado": ep.estado, "version": ep.version}


class OrdenIn(EntradaBase):
    tipo: Literal["laboratorio", "imagen", "procedimiento"]
    detalle: str = Field(min_length=2, max_length=2000)
    clave: str = CLAVE


@router.post("/episodios/{eid}/ordenes")
def crear_orden(eid: int, data: OrdenIn, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); ep = _episodio(s, ctx, eid, True); _vigente(s, ctx)
    previa = s.exec(select(ClinicaOrden).where(ClinicaOrden.clave == data.clave)).first()
    if previa:
        if previa.episodio_id != eid or previa.tipo != data.tipo or _abrir(ctx, previa.datos) != {"detalle": data.detalle}:
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        return {"id": previa.id, "estado": previa.estado}
    if ep.estado != "en_proceso":
        raise HTTPException(409, "El episodio está cerrado")
    p = _get(s, ClinicaPaciente, ep.paciente_id, ctx)
    if _abrir(ctx, p.datos).get("consentimiento") != "aceptado":
        raise HTTPException(409, "Falta consentimiento de atención")
    o = ClinicaOrden(empresa_id=ctx.empresa.id, episodio_id=eid, tipo=data.tipo,
                     datos=_cifrar(ctx, {"detalle": data.detalle}), clave=data.clave)
    s.add(o); s.flush(); _audit(s, ctx, "orden_firmar", str(o.id)); s.commit()
    return {"id": o.id, "estado": o.estado}


@router.get("/ordenes")
def ordenes(ctx: Contexto = Depends(acceso("clinicas_laboratorio")), s: Session = Depends(sesion_empresa)):
    _lock(s); salida = []
    for o in _lista(s, ClinicaOrden, ctx):
        try:
            ep = _episodio(s, ctx, o.episodio_id)
        except HTTPException as ex:
            if ex.status_code == 403: continue
            raise
        salida.append(o.model_dump(exclude={"empresa_id", "datos", "clave"}) | {"datos": _abrir(ctx, o.datos), "paciente_id": ep.paciente_id})
    _audit(s, ctx, "ordenes_leer", "lista"); s.commit(); return salida


@router.post("/ordenes/{oid}/estado")
def estado_orden(oid: int, data: EstadoIn, ctx: Contexto = Depends(acceso("clinicas_laboratorio")), s: Session = Depends(sesion_empresa)):
    _lock(s); o = _get(s, ClinicaOrden, oid, ctx); _episodio(s, ctx, o.episodio_id)
    if data.version != o.version or data.estado not in ESTADOS_ORDEN.get(o.estado, set()) or data.estado == "completada":
        raise HTTPException(409, "Transición no permitida; complete mediante un resultado firmado")
    o.estado = data.estado; o.version += 1; s.add(o); _audit(s, ctx, "orden_" + data.estado, str(oid)); s.commit()
    return {"id": o.id, "estado": o.estado, "version": o.version}


class ResultadoIn(EntradaBase):
    informe: str = Field(min_length=2, max_length=20000)
    critico: bool = False
    notificado_a: str = Field(default="", max_length=160)
    version: int = Field(ge=1)
    clave: str = CLAVE


@router.post("/ordenes/{oid}/resultado")
def resultado(oid: int, data: ResultadoIn, ctx: Contexto = Depends(acceso("clinicas_laboratorio")), s: Session = Depends(sesion_empresa)):
    _lock(s); o = _get(s, ClinicaOrden, oid, ctx); ep = _episodio(s, ctx, o.episodio_id); _vigente(s, ctx)
    if data.critico and not data.notificado_a.strip():
        raise HTTPException(422, "El resultado crítico requiere registrar a quién se notificó")
    datos = {"orden_id": oid, "informe": data.informe, "critico": data.critico, "notificado_a": data.notificado_a}
    previo = s.exec(select(ClinicaEntrada).where(ClinicaEntrada.clave == data.clave)).first()
    if previo:
        if previo.episodio_id != ep.id or previo.tipo != "resultado" or _abrir(ctx, previo.datos) != datos:
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        return {"id": previo.id, "estado": o.estado}
    if o.estado != "en_proceso" or o.version != data.version:
        raise HTTPException(409, "La orden cambió o no está en proceso")
    en = ClinicaEntrada(empresa_id=ctx.empresa.id, episodio_id=ep.id, paciente_id=ep.paciente_id,
                        tipo="resultado", datos=_cifrar(ctx, datos), autor_id=ctx.usuario.id, clave=data.clave)
    s.add(en); o.estado = "completada"; o.version += 1; s.add(o); s.flush()
    _audit(s, ctx, "resultado_firmar", str(en.id)); s.commit()
    return {"id": en.id, "estado": o.estado}


@router.post("/episodios/{eid}/adjuntos")
async def adjuntar(eid: int, archivo: UploadFile = File(...), mental: bool = Form(False), ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    from .rrhh_docs import tipo_de_archivo
    datos = await archivo.read(5 * 1024 * 1024 + 1)
    if len(datos) > 5 * 1024 * 1024: raise HTTPException(413, "Máximo 5 MB")
    tipo = tipo_de_archivo(datos)
    if not tipo: raise HTTPException(422, "Solo PDF, JPG y PNG reconocidos por su contenido")
    _lock(s); _episodio(s, ctx, eid, True)
    if mental and "clinicas_mental" not in ctx.permisos:
        raise HTTPException(403, "Sin permiso para adjuntos protegidos de salud mental")
    total = sum(a.tamano for a in _lista(s, ClinicaAdjunto, ctx))
    if total + len(datos) > 200 * 1024 * 1024: raise HTTPException(413, "Límite de adjuntos por empresa: 200 MB")
    contenido = json.dumps({"base64": base64.b64encode(datos).decode(), "mime": tipo[1], "ext": tipo[0]})
    a = ClinicaAdjunto(empresa_id=ctx.empresa.id, episodio_id=eid, tamano=len(datos), mental=mental, datos=secretos.cifrar(ctx.empresa.clave_cifrada, contenido))
    s.add(a); s.flush(); _audit(s, ctx, "adjunto_subir", str(a.id)); s.commit(); return {"id": a.id, "tamano": a.tamano}


@router.get("/adjuntos/{aid}")
def descargar_adjunto(aid: int, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    _lock(s); a = _get(s, ClinicaAdjunto, aid, ctx); _episodio(s, ctx, a.episodio_id, True)
    if a.mental and "clinicas_mental" not in ctx.permisos:
        raise HTTPException(403, "Sin acceso a documentos protegidos de salud mental")
    d = _abrir(ctx, a.datos); _audit(s, ctx, "adjunto_descargar", str(aid)); s.commit()
    return Response(base64.b64decode(d["base64"]), media_type=d["mime"], headers={"Content-Disposition": f'attachment; filename="clinica-{aid}.{d["ext"]}"', "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


class LoteIn(EntradaBase):
    producto_id: int = Field(gt=0)
    bodega_id: int = Field(gt=0)
    numero: str = Field(min_length=1, max_length=80)
    vence: str
    cantidad: Decimal = Field(gt=0, le=100000000, decimal_places=3)


@router.get("/lotes")
def lotes(ctx: Contexto = Depends(acceso("clinicas_farmacia")), s: Session = Depends(sesion_empresa)):
    if ctx.sucursal_fija: raise HTTPException(403, "Farmacia requiere acceso a todas las sucursales en esta entrega")
    return [x.model_dump(exclude={"empresa_id"}) for x in _lista(s, ClinicaLote, ctx)]


@router.post("/lotes")
def registrar_lote(data: LoteIn, ctx: Contexto = Depends(acceso("clinicas_farmacia")), s: Session = Depends(sesion_empresa)):
    if ctx.sucursal_fija: raise HTTPException(403, "Farmacia requiere acceso a todas las sucursales en esta entrega")
    ctx.exigir("inventario"); _lock(s); _fecha(data.vence)
    p = _get(s, Producto, data.producto_id, ctx); b = _get(s, inventario.Bodega, data.bodega_id, ctx)
    if not b.activa or not p.activo or p.es_servicio or not p.inventariable or p.venta_negativo:
        raise HTTPException(422, "Seleccione producto y bodega activos; farmacia no admite venta en negativo")
    if s.exec(select(ClinicaLote.id).where(ClinicaLote.producto_id == p.id, ClinicaLote.bodega_id == b.id, ClinicaLote.numero == data.numero)).first():
        raise HTTPException(409, "El lote ya existe")
    asignado = sum(x.cantidad for x in _lista(s, ClinicaLote, ctx) if x.producto_id == p.id and x.bodega_id == b.id)
    ex = inventario.existencia(s, p.id, b.id)
    if Decimal(str(asignado)) + data.cantidad > Decimal(str(ex.cantidad)):
        raise HTTPException(409, "Reciba primero la compra en Inventario; el lote solo identifica existencias ya recibidas")
    l = ClinicaLote(empresa_id=ctx.empresa.id, **data.model_dump(exclude={"cantidad"}), cantidad=float(data.cantidad))
    s.add(l); s.flush(); _audit(s, ctx, "lote_registrar", str(l.id)); s.commit(); s.refresh(l); return l.model_dump(exclude={"empresa_id"})


@router.post("/lotes/{lid}/estado")
def estado_lote(lid: int, data: EstadoIn, ctx: Contexto = Depends(acceso("clinicas_farmacia")), s: Session = Depends(sesion_empresa)):
    if ctx.sucursal_fija: raise HTTPException(403, "Farmacia requiere acceso a todas las sucursales en esta entrega")
    _lock(s); l = _get(s, ClinicaLote, lid, ctx)
    if l.version != data.version:
        raise HTTPException(409, "El lote cambió; actualice la lista")
    if data.estado not in {"disponible", "cuarentena", "bloqueado", "retirado"}:
        raise HTTPException(422, "Estado no válido")
    l.estado = data.estado; l.version += 1; s.add(l); _audit(s, ctx, "lote_" + data.estado, str(lid)); s.commit(); s.refresh(l)
    return l.model_dump(exclude={"empresa_id"})


class AjusteLoteIn(EntradaBase):
    cantidad: Decimal = Field(ge=0, le=100000000, decimal_places=3)
    version: int = Field(ge=1)
    motivo: str = Field(min_length=10, max_length=1000)


@router.post("/lotes/{lid}/identificacion")
def ajustar_lote(lid: int, data: AjusteLoteIn, ctx: Contexto = Depends(acceso("clinicas_farmacia")), s: Session = Depends(sesion_empresa)):
    if ctx.sucursal_fija: raise HTTPException(403, "Farmacia requiere acceso a todas las sucursales en esta entrega")
    ctx.exigir("inventario"); _lock(s); l = _get(s, ClinicaLote, lid, ctx)
    if l.version != data.version: raise HTTPException(409, "El lote cambió; actualice la lista")
    otros = sum(Decimal(str(x.cantidad)) for x in _lista(s, ClinicaLote, ctx) if x.producto_id == l.producto_id and x.bodega_id == l.bodega_id and x.id != lid)
    stock = Decimal(str(inventario.existencia(s, l.producto_id, l.bodega_id).cantidad))
    if data.cantidad > Decimal(str(l.cantidad)) and otros + data.cantidad > stock:
        raise HTTPException(409, "El inventario recibido no alcanza para identificar esa cantidad")
    datos = {"lote_id": lid, "anterior": str(l.cantidad), "nueva": str(data.cantidad), "motivo": data.motivo}
    s.add(ClinicaEntrada(empresa_id=ctx.empresa.id, episodio_id=0, paciente_id=0, tipo="ajuste_lote", datos=_cifrar(ctx, datos),
                        autor_id=ctx.usuario.id, clave=f"lote:{lid}:v{l.version}"))
    l.cantidad = float(data.cantidad); l.version += 1; s.add(l)
    _audit(s, ctx, "lote_ajustar_identificacion", str(lid)); s.commit(); s.refresh(l)
    return l.model_dump(exclude={"empresa_id"})


@router.get("/recetas")
def recetas(ctx: Contexto = Depends(acceso("clinicas_farmacia")), s: Session = Depends(sesion_empresa)):
    if ctx.sucursal_fija: raise HTTPException(403, "Farmacia requiere acceso a todas las sucursales en esta entrega")
    _lock(s)
    ens = s.exec(select(ClinicaEntrada).where(ClinicaEntrada.empresa_id == ctx.empresa.id, ClinicaEntrada.tipo == "receta").order_by(ClinicaEntrada.id.desc()).limit(200)).all()
    corregidas = {e.anterior_id for e in ens if e.anterior_id}
    salida = []
    for en in ens:
        if en.id in corregidas: continue
        d = _entrada_dict(ctx, en)
        d["anulada"] = bool(s.exec(select(ClinicaEntrada.id).where(ClinicaEntrada.anterior_id == en.id, ClinicaEntrada.tipo == "receta_cancelacion")).first())
        ids = _cadena_receta(s, ctx, en)
        d["dispensado"] = sum(x.cantidad for x in s.exec(select(ClinicaDispensa).where(ClinicaDispensa.receta_id.in_(ids))).all())
        salida.append(d)
    _audit(s, ctx, "recetas_leer", "lista"); s.commit(); return salida


class DispensaIn(EntradaBase):
    receta_id: int = Field(gt=0)
    bodega_id: int = Field(gt=0)
    cantidad: Decimal = Field(gt=0, le=100000, decimal_places=3)
    clave: str = CLAVE


def _cadena_receta(s, ctx, en):
    ids = [en.id]
    while en.anterior_id:
        en = _get(s, ClinicaEntrada, en.anterior_id, ctx)
        if en.id in ids or len(ids) >= 100:
            raise HTTPException(409, "Revise la cadena de correcciones de la receta")
        ids.append(en.id)
    return ids


@router.post("/dispensas")
def dispensar(data: DispensaIn, ctx: Contexto = Depends(acceso("clinicas_farmacia")), s: Session = Depends(sesion_empresa)):
    if ctx.sucursal_fija: raise HTTPException(403, "Farmacia requiere acceso a todas las sucursales en esta entrega")
    ctx.exigir("inventario"); _lock(s); _vigente(s, ctx)
    previa = s.exec(select(ClinicaDispensa).where(ClinicaDispensa.clave == data.clave)).first()
    if previa:
        if previa.receta_id != data.receta_id or Decimal(str(previa.cantidad)) != data.cantidad or _abrir(ctx, previa.datos)["bodega_id"] != data.bodega_id:
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        return {"id": previa.id, "cantidad": previa.cantidad}
    en = _get(s, ClinicaEntrada, data.receta_id, ctx)
    if en.tipo != "receta" or s.exec(select(ClinicaEntrada.id).where(ClinicaEntrada.anterior_id == en.id)).first():
        raise HTTPException(409, "La receta no es válida o fue corregida")
    d = _abrir(ctx, en.datos)
    if d["vence"] < ahora_cr().date().isoformat(): raise HTTPException(409, "Receta vencida")
    p = _get(s, Producto, d.get("producto_id"), ctx) if d.get("producto_id") else None
    if not p or not p.activo or p.es_servicio or p.venta_negativo: raise HTTPException(422, "La receta no tiene un producto dispensable")
    b = _get(s, inventario.Bodega, data.bodega_id, ctx)
    if not b.activa: raise HTTPException(409, "Bodega inactiva")
    ids = _cadena_receta(s, ctx, en)
    ya = sum(Decimal(str(x.cantidad)) for x in s.exec(select(ClinicaDispensa).where(ClinicaDispensa.receta_id.in_(ids))).all())
    if ya + data.cantidad > Decimal(str(d["cantidad"])): raise HTTPException(409, "La cantidad excede lo pendiente de la receta")
    ls = s.exec(select(ClinicaLote).where(ClinicaLote.producto_id == p.id, ClinicaLote.bodega_id == b.id,
             ClinicaLote.estado == "disponible", ClinicaLote.vence >= ahora_cr().date().isoformat(), ClinicaLote.cantidad > 0).order_by(ClinicaLote.vence, ClinicaLote.id)).all()
    if sum(Decimal(str(l.cantidad)) for l in ls) < data.cantidad: raise HTTPException(409, "Lotes vigentes insuficientes")
    if Decimal(str(inventario.existencia(s, p.id, b.id).cantidad)) < data.cantidad: raise HTTPException(409, "Inventario insuficiente")
    pendiente = data.cantidad; consumidos = []
    for l in ls:
        n = min(pendiente, Decimal(str(l.cantidad)))
        if n <= 0: break
        l.cantidad = float(Decimal(str(l.cantidad)) - n); l.version += 1; s.add(l); s.flush()
        mov = inventario.registrar_movimiento(s, producto=p, bodega_id=b.id, tipo="ajuste", cantidad=-float(n),
                    fecha=ahora_cr().date().isoformat(), referencia=f"CLINICA receta {en.id}, lote {l.id}")
        consumidos.append({"lote_id": l.id, "cantidad": str(n), "movimiento_id": mov.id}); pendiente -= n
    disp = ClinicaDispensa(empresa_id=ctx.empresa.id, receta_id=en.id, datos=_cifrar(ctx, {"lotes": consumidos, "bodega_id": b.id}),
                          cantidad=float(data.cantidad), autor_id=ctx.usuario.id, clave=data.clave)
    s.add(disp); s.flush(); _audit(s, ctx, "dispensar", str(disp.id)); s.commit()
    return {"id": disp.id, "cantidad": disp.cantidad, "lotes": consumidos}


class CargoIn(EntradaBase):
    producto_id: int = Field(gt=0)
    cantidad: Decimal = Field(gt=0, le=10000, decimal_places=3)
    clave: str = CLAVE


@router.get("/episodios/{eid}/cargos")
def cargos(eid: int, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    ctx.exigir("facturar"); _episodio(s, ctx, eid)
    return [c.model_dump(exclude={"empresa_id", "clave"}) for c in _lista(s, ClinicaCargo, ctx) if c.episodio_id == eid]


@router.post("/episodios/{eid}/cargos")
def crear_cargo(eid: int, data: CargoIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    ctx.exigir("facturar"); _lock(s); _episodio(s, ctx, eid)
    previo = s.exec(select(ClinicaCargo).where(ClinicaCargo.clave == data.clave)).first()
    if previo:
        if previo.episodio_id != eid or previo.producto_id != data.producto_id or Decimal(str(previo.cantidad)) != data.cantidad:
            raise HTTPException(409, "Clave de reintento utilizada con otros datos")
        return previo.model_dump(exclude={"empresa_id", "clave"})
    p = _get(s, Producto, data.producto_id, ctx)
    if not p.activo or not p.es_servicio or p.inventariable:
        raise HTTPException(422, "Los cargos clínicos admiten servicios no inventariables; la dispensación se registra por separado")
    if p.moneda not in {"CRC", "USD"} or not math.isfinite(p.precio) or p.precio < 0:
        raise HTTPException(422, "El servicio necesita moneda CRC/USD y precio no negativo")
    c = ClinicaCargo(empresa_id=ctx.empresa.id, episodio_id=eid, producto_id=p.id, cantidad=float(data.cantidad),
                     moneda=p.moneda, precio=str(p.precio), clave=data.clave)
    s.add(c); s.flush(); _audit(s, ctx, "cargo_crear", str(c.id)); s.commit(); s.refresh(c); return c.model_dump(exclude={"empresa_id", "clave"})


@router.post("/cargos/{cid}/anular")
def anular_cargo(cid: int, data: MotivoIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    ctx.exigir("facturar"); _lock(s); c = _get(s, ClinicaCargo, cid, ctx); _episodio(s, ctx, c.episodio_id)
    if c.borrador_id or c.documento_id:
        raise HTTPException(409, "Libere el borrador o corrija el comprobante en Facturación antes de anular el cargo")
    if not c.anulado:
        s.add(ClinicaEntrada(empresa_id=ctx.empresa.id, episodio_id=0, paciente_id=0, tipo="cargo_anulacion",
                            datos=_cifrar(ctx, {"cargo_id": cid, "motivo": data.motivo}), autor_id=ctx.usuario.id, clave=f"anular-cargo:{cid}"))
        c.anulado = True; s.add(c); _audit(s, ctx, "cargo_anular", str(cid)); s.commit()
    return {"cargo_id": cid, "anulado": True}


class FacturarIn(EntradaBase):
    tipo_documento: Literal["01", "04"] = "04"
    moneda: Literal["CRC", "USD"] = "CRC"
    tipo_cambio: Optional[Decimal] = Field(default=None, gt=1, le=1000000, decimal_places=5)


def _marca(b):
    return b.creado.replace(tzinfo=None).isoformat()


@router.post("/episodios/{eid}/facturar")
def facturar(eid: int, data: FacturarIn, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    from .main import ComprobanteIn, _exo_borrador, _total_borrador
    from .tike_contratos import _linea_producto
    ctx.exigir("facturar"); _lock(s); ep = _episodio(s, ctx, eid)
    if data.moneda == "USD" and data.tipo_cambio is None:
        raise HTTPException(422, "Indique el tipo de cambio del documento en colones por dólar")
    ps = _get(s, ClinicaPaciente, ep.paciente_id, ctx)
    cliente = _get(s, Cliente, ps.cliente_id, ctx) if ps.cliente_id else None
    if data.tipo_documento == "01" and not cliente: raise HTTPException(422, "Vincule el contacto de facturación a la ficha del paciente")
    cs = s.exec(select(ClinicaCargo).where(ClinicaCargo.episodio_id == eid, ClinicaCargo.moneda == data.moneda,
                          ClinicaCargo.documento_id == None, ClinicaCargo.borrador_id == None, ClinicaCargo.anulado == False)).all()  # noqa: E711, E712
    if not cs: raise HTTPException(409, "No hay cargos pendientes en esa moneda")
    lineas = []
    for c in cs:
        p = _get(s, Producto, c.producto_id, ctx)
        if not p.activo or not p.es_servicio or p.inventariable: raise HTTPException(409, "El servicio cambió; revise el catálogo")
        lineas.append(_linea_producto(p, c.cantidad, float(c.precio), p.nombre))
    comp = ComprobanteIn(tipo_documento=data.tipo_documento, cliente_id=cliente.id if cliente else None, moneda=data.moneda,
                         tipo_cambio=data.tipo_cambio if data.moneda == "USD" else Decimal("1"),
                         lineas=lineas, observaciones="Servicios clínicos", extra={"clinica_episodio_id": eid})
    b = modulos.Borrador(empresa_id=ctx.empresa.id, tipo_documento=comp.tipo_documento, cliente_id=comp.cliente_id,
                        receptor_nombre=cliente.nombre if cliente else None, moneda=data.moneda,
                        total=_total_borrador(comp, _exo_borrador(s, ctx.empresa.id, comp, cliente)), datos=comp.model_dump_json(), usuario=ctx.usuario.correo)
    s.add(b); s.flush()
    comp.extra["clinica_borrador_marca"] = _marca(b)
    b.datos = comp.model_dump_json(); s.add(b)
    for c in cs:
        c.borrador_id = b.id; c.borrador_marca = _marca(b); s.add(c)
    _audit(s, ctx, "cargos_borrador", str(b.id)); s.commit()
    return {"borrador_id": b.id, "ruta": f"/ventas/facturas/nueva?borrador={b.id}", "total": b.total}


def enlazar_borrador(s, eid, b, documento_id=None):
    """Gancho ERP: mismo commit que emitir/eliminar. Sin lectura de datos clínicos."""
    for c in s.exec(select(ClinicaCargo).where(ClinicaCargo.empresa_id == eid, ClinicaCargo.borrador_id == b.id,
                                               ClinicaCargo.borrador_marca == _marca(b))).all():
        c.documento_id = documento_id
        if documento_id is None:
            c.borrador_id = None; c.borrador_marca = None
        s.add(c)
        sistema = SimpleNamespace(empresa=SimpleNamespace(id=eid), usuario=SimpleNamespace(id=0))
        _audit(s, sistema, "cargo_documento" if documento_id else "cargo_liberar_borrador", str(c.id))


def bloquear_edicion(s, eid, bid):
    b = s.get(modulos.Borrador, bid)
    if b and b.empresa_id == eid and s.exec(select(ClinicaCargo.id).where(ClinicaCargo.borrador_id == bid,
                  ClinicaCargo.borrador_marca == _marca(b), ClinicaCargo.documento_id == None)).first():  # noqa: E711
        raise HTTPException(409, "Este borrador tiene cargos clínicos reservados. Para cambiarlos, elimine el borrador y genere uno nuevo desde Clínicas")


def validar_emision(s, eid, data):
    if not data.borrador_id:
        if (data.extra or {}).get("clinica_episodio_id"):
            raise HTTPException(409, "Emita los cargos desde su borrador de Clínicas")
        return
    _lock(s)
    b = s.get(modulos.Borrador, data.borrador_id)
    cs = s.exec(select(ClinicaCargo).where(ClinicaCargo.empresa_id == eid, ClinicaCargo.borrador_id == data.borrador_id)).all()
    if not b or b.empresa_id != eid:
        if cs or (data.extra or {}).get("clinica_episodio_id"):
            raise HTTPException(409, "El borrador clínico ya se emitió o se eliminó")
        return
    cs = [c for c in cs if c.borrador_marca == _marca(b)]
    if not cs:
        if (data.extra or {}).get("clinica_episodio_id"):
            raise HTTPException(409, "La referencia del borrador clínico no es válida")
        return
    from .main import ComprobanteIn
    original = ComprobanteIn.model_validate_json(b.datos)
    if data.moneda == "USD" and data.tipo_cambio <= 1:
        raise HTTPException(422, "Revise el tipo de cambio del documento clínico en dólares")
    if (data.moneda, data.cliente_id, data.tipo_documento) != (original.moneda, original.cliente_id, original.tipo_documento) or [l.model_dump() for l in data.lineas] != [l.model_dump() for l in original.lineas]:
        raise HTTPException(409, "Los servicios, importes, moneda y cliente deben coincidir con el borrador clínico")
    if (data.extra or {}).get("clinica_borrador_marca") != _marca(b):
        raise HTTPException(409, "El borrador clínico cambió; vuelva a abrirlo desde Clínicas")


def liberar_documento(s, eid, doc):
    for c in s.exec(select(ClinicaCargo).where(ClinicaCargo.empresa_id == eid, ClinicaCargo.documento_id == doc.id)).all():
        c.documento_id = None; c.borrador_id = None; c.borrador_marca = None; s.add(c)
        sistema = SimpleNamespace(empresa=SimpleNamespace(id=eid), usuario=SimpleNamespace(id=0))
        _audit(s, sistema, "cargo_liberar_documento", str(c.id))


def liberar_si_acreditada(s, eid, clave):
    d = s.exec(select(Documento).where(Documento.empresa_id == eid, Documento.clave == clave)).first()
    if d and d.tipo_documento in ("01", "04") and Decimal(str(d.total or 0)) - Decimal(str(d.acreditado or 0)) <= Decimal("0.004"):
        liberar_documento(s, eid, d); s.commit()


@router.get("/resumen")
def resumen(dia: str, ctx: Contexto = Depends(acceso()), s: Session = Depends(sesion_empresa)):
    cs = citas(dia, ctx, s)
    return {"dia": dia, "citas": len(cs), "llegadas": sum(c["estado"] == "llegada" for c in cs),
            "atendidas": sum(c["estado"] == "atendida" for c in cs), "no_asistio": sum(c["estado"] == "no_asistio" for c in cs),
            "canceladas": sum(c["estado"] == "cancelada" for c in cs)}


@router.get("/auditoria")
def auditoria(desde: int = Query(0, ge=0), ctx: Contexto = Depends(acceso("clinicas_auditar")), s: Session = Depends(sesion_empresa)):
    _lock(s); _audit(s, ctx, "auditoria_leer", str(desde)); s.commit()
    return [x.model_dump(exclude={"empresa_id"}) for x in s.exec(select(ClinicaAuditoria).where(ClinicaAuditoria.id > desde).order_by(ClinicaAuditoria.id).limit(500)).all()]


@router.get("/pacientes/{pid}/exportar")
def exportar(pid: int, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    d = expediente(pid, ctx, s)
    _lock(s); _audit(s, ctx, "expediente_exportar", str(pid)); s.commit()
    return Response(json.dumps(d, ensure_ascii=False).encode(), media_type="application/json", headers={
        "Content-Disposition": f'attachment; filename="expediente-{pid}.json"', "Cache-Control": "no-store"})


@router.get("/pacientes/{pid}/pdf")
def expediente_pdf(pid: int, ctx: Contexto = Depends(acceso("clinicas_atender")), s: Session = Depends(sesion_empresa)):
    import io
    from html import escape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer
    d = expediente(pid, ctx, s)
    estilos = getSampleStyleSheet(); partes = []
    def par(t, estilo="BodyText"):
        partes.append(Paragraph(escape(str(t)).replace("\n", "<br/>"), estilos[estilo])); partes.append(Spacer(1, 6))
    par("Expediente clínico", "Title"); par(ctx.empresa.nombre, "Heading2")
    par(d["paciente"]["nombre"], "Heading2")
    par("Identificación: " + (d["paciente"]["documento"] or "Provisional"))
    par("Exportado: " + momento()); par("Contenido disponible según los permisos y asignaciones del usuario que exporta.")
    for en in d["entradas"]:
        par(f"{en['tipo']} #{en['id']} · Episodio {en['episodio_id']}", "Heading3")
        par(f"{en['creado']} · Autor {en['autor_id']}" + (f" · Corrige {en['anterior_id']}" if en['anterior_id'] else ""))
        for k, v in en["datos"].items():
            par(f"{k}: " + (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)))
    b = io.BytesIO(); SimpleDocTemplate(b).build(partes)
    _lock(s); _audit(s, ctx, "expediente_pdf", str(pid)); s.commit()
    return Response(b.getvalue(), media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="expediente-{pid}.pdf"', "Cache-Control": "no-store"})
