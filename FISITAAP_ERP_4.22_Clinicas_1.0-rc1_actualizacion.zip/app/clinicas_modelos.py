"""Tablas clínicas ADITIVAS por empresa. No contienen claves ni alteran tablas ERP."""
from typing import Optional

from sqlalchemy import DDL, UniqueConstraint, event
from sqlmodel import Field, SQLModel

from .config import ahora_cr
from .db import por_empresa


def momento():
    return ahora_cr().isoformat(timespec="microseconds")


class ClinicaMutex(SQLModel, table=True):
    __tablename__ = "clinica_mutex"
    id: int = Field(default=1, primary_key=True)
    revision: int = 0


class ClinicaPaciente(SQLModel, table=True):
    __tablename__ = "clinica_paciente"
    __table_args__ = (UniqueConstraint("empresa_id", "identidad"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    identidad: Optional[str] = None  # HMAC; documento y ficha solo en datos cifrados
    datos: str
    cliente_id: Optional[int] = None
    activo: bool = True
    version: int = 1
    creado: str = Field(default_factory=momento)


class ClinicaProfesional(SQLModel, table=True):
    __tablename__ = "clinica_profesional"
    __table_args__ = (UniqueConstraint("empresa_id", "usuario_id"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    usuario_id: int
    nombre: str
    especialidad: str
    colegiado: str
    vence: str
    activo: bool = True
    horario: str = "{}"  # día Python 0=lunes: [[HH:MM, HH:MM]]


class ClinicaRecurso(SQLModel, table=True):
    __tablename__ = "clinica_recurso"
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    nombre: str
    sucursal_id: Optional[int] = None
    activo: bool = True


class ClinicaCita(SQLModel, table=True):
    __tablename__ = "clinica_cita"
    __table_args__ = (UniqueConstraint("empresa_id", "clave"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    paciente_id: int = Field(index=True)
    profesional_id: int = Field(index=True)
    recurso_id: Optional[int] = None
    inicio: str = Field(index=True)
    fin: str
    motivo: str  # cifrado; no diagnóstico
    estado: str = "confirmada"
    version: int = 1
    clave: str


class ClinicaEpisodio(SQLModel, table=True):
    __tablename__ = "clinica_episodio"
    __table_args__ = (UniqueConstraint("empresa_id", "cita_id"), UniqueConstraint("empresa_id", "clave"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    paciente_id: int = Field(index=True)
    profesional_id: int
    recurso_id: Optional[int] = None
    cita_id: Optional[int] = None
    estado: str = "en_proceso"
    version: int = 1
    clave: str
    creado: str = Field(default_factory=momento)


class ClinicaEntrada(SQLModel, table=True):
    __tablename__ = "clinica_entrada"
    __table_args__ = (UniqueConstraint("empresa_id", "clave"), {"sqlite_autoincrement": True})
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    episodio_id: int = Field(index=True)
    paciente_id: int = Field(index=True)
    tipo: str = Field(index=True)
    datos: str  # JSON cifrado por empresa, siempre final; corrección = otra entrada
    autor_id: int
    anterior_id: Optional[int] = None
    clave: str
    creado: str = Field(default_factory=momento)


class ClinicaOrden(SQLModel, table=True):
    __tablename__ = "clinica_orden"
    __table_args__ = (UniqueConstraint("empresa_id", "clave"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    episodio_id: int = Field(index=True)
    tipo: str
    datos: str
    estado: str = "firmada"
    version: int = 1
    clave: str


class ClinicaLote(SQLModel, table=True):
    __tablename__ = "clinica_lote"
    __table_args__ = (UniqueConstraint("empresa_id", "producto_id", "bodega_id", "numero"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    producto_id: int
    bodega_id: int
    numero: str
    vence: str
    cantidad: float
    estado: str = "disponible"
    version: int = 1


class ClinicaDispensa(SQLModel, table=True):
    __tablename__ = "clinica_dispensa"
    __table_args__ = (UniqueConstraint("empresa_id", "clave"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    receta_id: int
    datos: str  # lotes y cantidades cifrados, vinculados al movimiento ERP
    cantidad: float
    autor_id: int
    clave: str
    creado: str = Field(default_factory=momento)


class ClinicaCargo(SQLModel, table=True):
    __tablename__ = "clinica_cargo"
    __table_args__ = (UniqueConstraint("empresa_id", "clave"),)
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    episodio_id: int = Field(index=True)
    producto_id: int
    cantidad: float
    moneda: str
    precio: str
    clave: str
    borrador_id: Optional[int] = None
    borrador_marca: Optional[str] = None
    documento_id: Optional[int] = None
    anulado: bool = False


class ClinicaAdjunto(SQLModel, table=True):
    __tablename__ = "clinica_adjunto"
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    episodio_id: int = Field(index=True)
    datos: str  # JSON cifrado con base64; sin archivos públicos; incluido en respaldo SQLite
    tamano: int
    mental: bool = False
    creado: str = Field(default_factory=momento)


class ClinicaAuditoria(SQLModel, table=True):
    __tablename__ = "clinica_auditoria"
    id: Optional[int] = Field(default=None, primary_key=True)
    empresa_id: int = Field(index=True)
    usuario_id: int
    accion: str
    objeto: str
    previo: str
    huella: str
    creado: str


MODELOS = (ClinicaMutex, ClinicaPaciente, ClinicaProfesional, ClinicaRecurso, ClinicaCita,
           ClinicaEpisodio, ClinicaEntrada, ClinicaOrden, ClinicaLote, ClinicaDispensa,
           ClinicaCargo, ClinicaAdjunto, ClinicaAuditoria)
por_empresa(*MODELOS)

# Historial append-only en la API y en SQL ordinario; no sustituye custodia externa de respaldos.
for modelo in (ClinicaEntrada, ClinicaAuditoria, ClinicaDispensa, ClinicaAdjunto):
    for operacion in ("UPDATE", "DELETE"):
        tabla = modelo.__tablename__
        event.listen(modelo.__table__, "after_create", DDL(
            f"CREATE TRIGGER IF NOT EXISTS {tabla}_{operacion.lower()} BEFORE {operacion} ON {tabla} "
            "BEGIN SELECT RAISE(ABORT, 'Registro clinico inmutable'); END"))
