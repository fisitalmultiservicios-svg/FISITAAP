// FISITAAP by Brillante Agencia (3.77): el menú, los tipos de negocio y las reglas de visibilidad en un solo lugar. Lo usan la aplicación del ERP
// (js/app.js, con su sesión) y la aplicación de Ventas en línea (/app/fisitaap/, js/fis/app.js, con su espejo de sesión): las dos
// arman el mismo árbol, así que el usuario ve un solo menú esté donde esté. Las funciones terminadas en «De» reciben la sesión
// (s) y, cuando hace falta, la función que dice si el hotel está activo.

// Pantalla de la aplicación de Ventas en línea: enlace externo con su clave (permiso pos, como la sección; 3.87: catálogos en CLAVES_CATALOGOS)
const fis = (clave, label) => ({ label, clave, href: '/app/fisitaap/#/' + clave, permiso: CLAVES_CATALOGOS.includes(clave) ? 'catalogos' : 'pos' });
// 3.87: lo único de Ventas en línea que ve el modo cajero (Cajero, Mesero): los pedidos que se atienden desde la caja
const CLAVES_CAJA = ['pedidos', 'express-pendientes'];
// 3.87: pantallas de Ventas en línea que guardan con 'catalogos' en el servidor (el catálogo web, los cupones y la edición de Mi página:
// pedidos.gestion y promociones.gestion); un rol propio con caja y sin catálogos las veía y al guardar recibía 403
const CLAVES_CATALOGOS = ['productos', 'extras', 'opcionales', 'combos', 'promociones', 'cupones', 'publicar', 'configuracion', 'contenido', 'delivery'];

export const MENU = [
  // 3.37: reorganización aprobada por Norman (croquis 21/10). Cada módulo es una entrada propia; los catálogos y ajustes viven en
  // Configuración; las direcciones de las pantallas no cambian. El orden y los agrupamientos por tipo de negocio están en menuTipo().
  { label: 'Inicio', ico: '⌂', to: '/inicio' },
  { label: 'Ingresos', ico: '↗', permisos: ['facturar', 'cobros', 'ver_todo'], children: [   // 3.87: como dentro de Contabilidad; el técnico de soporte no factura
    { label: 'Cotizaciones', to: '/ventas/cotizaciones' },
    { label: 'Remisiones', to: '/ventas/remisiones' },
    { label: 'Facturas de venta', to: '/ventas/facturas' },
    { label: 'Facturas recurrentes', to: '/ventas/recurrentes' },
    { label: 'Notas de crédito', to: '/ventas/notas-credito' },
    { label: 'Notas de débito', to: '/ventas/notas-debito' },
    { label: 'Pagos recibidos', to: '/ventas/pagos' },
    { label: 'Reportes', to: '/reportes/de-ingresos', permisos: ['facturar', 'reportes'], modulo: 'reportes' },   // 4.1: los reportes de cada módulo
  ] },
  { label: 'Compras', ico: '↙', permiso: 'gastos', children: [
    { label: 'Proveedores', to: '/contactos?tipo=Proveedor' },
    { label: 'Órdenes de compra', to: '/gastos/ordenes' },
    { label: 'Recepción de comprobantes', to: '/gastos/recepcion' },
    { label: 'Facturas de compra', to: '/gastos/compras' },
    { label: 'Notas de débito del proveedor', to: '/gastos/notas-debito' },
    { label: 'Pagos a proveedores', to: '/gastos/pagos' },
    { label: 'Pagos recurrentes', to: '/gastos/recurrentes' },
    { label: 'Reportes', to: '/reportes/de-compras', permisos: ['gastos', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Contactos', ico: '☺', children: [   // 4.1: submenú por tipo de contacto
    { label: 'Todos los contactos', to: '/contactos' },
    { label: 'Clientes', children: [   // 4.1: cada tipo con su lista y sus reportes
      { label: 'Lista de clientes', to: '/contactos?tipo=Cliente' },
      { label: 'Revendedoras y saldos', to: '/contactos/revendedoras', permisos: ['facturar', 'cobros', 'catalogos', 'ver_todo'] },   // 4.9: sin módulo (también sin Reportes)
      { label: 'Reportes', to: '/reportes/de-clientes', permisos: ['facturar', 'cobros', 'reportes'], modulo: 'reportes' },
    ] },
    { label: 'Proveedores', children: [
      { label: 'Lista de proveedores', to: '/contactos?tipo=Proveedor' },
      { label: 'Reportes', to: '/reportes/de-proveedores', permisos: ['gastos', 'reportes'], modulo: 'reportes' },
    ] },
    { label: 'Clientes y proveedores', children: [
      { label: 'Lista', to: '/contactos?tipo=Ambos' },
      { label: 'Reportes', to: '/reportes/de-ambos', permisos: ['facturar', 'cobros', 'gastos', 'reportes'], modulo: 'reportes' },
    ] },
    { label: 'Reportes de contactos', to: '/reportes/de-contactos', permisos: ['facturar', 'gastos', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Inventario', ico: '▦', permisos: ['catalogos', 'inventario', 'escribir', 'facturar', 'cobros', 'pos', 'gastos', 'contabilidad', 'reportes', 'documentos', 'configurar'], children: [   // 3.87: costos y valor no son para los roles operativos (el servidor los niega)
    { label: 'Ítems', to: '/inventario/items' },
    { label: 'Conteo físico', to: '/pos/inventario', permiso: 'inventario' },          // antes «Mercadería y conteo» en Punto de venta
    { label: 'Ajustes de inventario', to: '/inventario/ajustes' },
    { label: 'Traslados a otra empresa', to: '/inventario/traslados', permiso: 'inventario' },   // grupo de empresas (3.69)
    { label: 'Recetas y fichas técnicas', to: '/pos/recetas', permiso: 'catalogos' },   // antes en Punto de venta
    { label: 'Valor de inventario', to: '/inventario/valor' },
    { label: 'Por reponer', to: '/inventario/reponer', permisos: ['inventario', 'gastos', 'catalogos'] },   // 3.87: ítems en o bajo su existencia mínima (los mismos permisos que la ruta del servidor)
    { label: 'Importar y actualizar ítems', to: '/inventario/gestion', permiso: 'catalogos' },   // 3.87: todo lo de esa pantalla exige catálogos
    { label: 'Reportes', to: '/reportes/de-inventario', permisos: ['inventario', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Bancos', ico: '🏦', permiso: 'gastos', children: [
    { label: 'Bancos y cajas', to: '/bancos' },
    { label: 'Conciliaciones bancarias', to: '/bancos/conciliaciones' },
    { label: 'Reportes', to: '/reportes/de-bancos', permisos: ['gastos', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Contabilidad', ico: '≡', permiso: 'contabilidad', children: [
    { label: 'Asientos', to: '/contabilidad/asientos' },
    { label: 'Libro diario', to: '/contabilidad/libro-diario' },
    { label: 'Activos', to: '/contabilidad/activos' },
    { label: 'Presupuesto', to: '/contabilidad/presupuesto' },
    { label: 'Diferencial cambiario', to: '/contabilidad/diferencial' },
    { label: 'Reportes', to: '/reportes/de-contabilidad', permisos: ['contabilidad', 'reportes'], modulo: 'reportes' },
  ] },
  { label: 'Recursos humanos', ico: '👥', permiso: 'rrhh', children: [
    { label: 'Empleados', to: '/rrhh/empleados' },
    { label: 'Acciones de personal', to: '/rrhh/acciones' },   // 4.21
    { label: 'Horarios de trabajo', to: '/rrhh/horarios' },
    { label: 'Marcas de asistencia', to: '/rrhh/marcas' },
    { label: 'Planilla', children: [
      { label: 'Planilla del mes', to: '/rrhh/planilla' },
      { label: 'Horas extra', to: '/rrhh/horas-extra' },
      { label: 'Aguinaldo', to: '/rrhh/aguinaldo' },
    ] },
    { label: 'Novedades', children: [
      { label: 'Vacaciones', to: '/rrhh/vacaciones' },
      { label: 'Ausencias e incapacidades', to: '/rrhh/ausencias' },
      { label: 'Liquidaciones', to: '/rrhh/liquidaciones' },
    ] },
    { label: 'Reportes', to: '/rrhh/informes' },   // 4.1: antes «Informes» (mismo nombre en todos los módulos)
  ] },
  { label: 'Punto de venta', ico: '🛒', permiso: 'pos', children: [
    { label: 'Caja', to: '/pos/caja' },
    { label: 'Cierres de caja', to: '/pos/cierres' },
    { label: 'Reportes de caja', to: '/pos/reportes', permiso: 'cobros' },   // 3.58: ventas por día, producto, categoría y hora sin necesitar el módulo Reportes
    { label: 'Reportes', to: '/reportes/de-pos', permisos: ['cobros', 'reportes'], modulo: 'reportes' },   // 4.1: ventas, servicio 10 % y propinas
    { label: 'Servicio 10 % y propinas', to: '/pos/servicio' },
    { label: 'Pantalla del cliente', to: '/pos/pantalla' },
    { label: 'Pantalla de cocina', to: '/pos/cocina' },
  ] },
  // FISITAAP (3.57): un solo módulo extra, como RRHH o Contabilidad. Todo lo del negocio en línea vive aquí: su página, el catálogo
  // o menú, los pedidos, los clientes web, las entregas (extra «entregas» dentro de FISITAAP), las promociones, el asistente y la
  // configuración. Lo genérico (Contactos, Inventario, Punto de venta) queda fuera y FISITAAP se alimenta de eso. Antes (3.47 a 3.56)
  // eran tres menús sueltos: Pedidos en línea, Promociones y Entregas.
  // 3.74: FISITAAP embebido tal cual es hoy: abre su propia aplicación (/app/fisitaap/) con su menú y sus pantallas; lo que ya existe en
  // el ERP (ítems, caja, contactos, compras, reportes, usuarios…) lo enlaza desde allá. Las rutas viejas (#/fisitaap/…) saltan a ella.
  // 3.77: Ventas en línea es una sección con sus pantallas (la aplicación embebida en /app/fisitaap/): el mismo árbol se ve en el ERP y
  // dentro de Ventas en línea. clave = pantalla de esa aplicación; permiso pos en cada entrada para que el modo cajero vea lo mismo que antes.
  { label: 'Ventas en línea', ico: '🌐', img: '/img/fisitaap-icono.svg', permiso: 'pos', modulo: 'pedidos_online', href: '/app/fisitaap/#/resumen', children: [
    fis('resumen', 'Resumen'), fis('bienvenida', 'Bienvenida'), { ...fis('configurador', 'Configurador'), permiso: 'configurar' },
    { label: 'Catálogo web', permiso: 'catalogos', children: [fis('productos', 'Productos en línea'), fis('extras', 'Extras'), fis('opcionales', 'Grupos de opcionales'), fis('combos', 'Combos'), fis('promociones', 'Promociones'), fis('cupones', 'Códigos de descuento')] },
    { label: 'Pedidos web', permiso: 'pos', children: [fis('pedidos', 'Pedidos'), { ...fis('express-pendientes', 'Express pendientes'), tipos: ['restaurante'], modulo: 'entregas' }] },   // 3.87: Express y Zonas de envío solo con el extra Entregas
    { label: 'Clientes web', permiso: 'pos', children: [fis('clientes-historial', 'Historial de clientes'), fis('fidelizacion', 'Fidelización'), fis('contactos', 'Contactos de la página'),
      { label: 'Revendedoras y saldos', to: '/contactos/revendedoras', permisos: ['facturar', 'cobros', 'catalogos', 'ver_todo'] }] },   // 4.9: pantalla del ERP (el modo cajero no la ve)
    { label: 'Mi página', permiso: 'pos', children: [fis('publicar', 'Publicar y dominio'), fis('configuracion', 'Generales'), fis('contenido', 'Diseño de la página'), { ...fis('delivery', 'Zonas de envío'), modulo: 'entregas' }, fis('kpis', 'Reportes y KPIs')] },
    { label: 'Entregas', permiso: 'pos', modulo: 'entregas', children: [fis('afiliados', 'Motorizados afiliados'), fis('invitaciones', 'Invitaciones'), fis('entregas-historial', 'Historial de entregas')] },
  ] },
  // TiKe (3.52): tickets de soporte para empresas de servicios e IT; módulo «tike» (base de Servicios, extra en Facturación y Comercio)
  { label: 'Clínicas', ico: '✚', to: '/clinicas', permiso: 'clinicas', modulo: 'clinicas' },
  { label: 'TiKe', ico: '🎫', permiso: 'tike', modulo: 'tike', children: [
    { label: 'Tablero', to: '/tike/tablero' },
    { label: 'Tickets', to: '/tike/tickets' },
    { label: 'Mis tickets (celular)', to: '/tike/mio' },
    { label: 'Contratos de soporte', to: '/tike/contratos' },
    { label: 'Equipos del cliente', to: '/tike/equipos' },
    { label: 'Documentación del cliente', to: '/tike/documentacion' },
    { label: 'Reportes', to: '/tike/reportes' },   // 4.1: mismo nombre en todos los módulos
    { label: 'Configuración de TiKe', to: '/tike/configuracion' },
  ] },
  // Hotel (Hospitalidad): cada módulo es una entrada propia (croquis 21/10). hotel: true = solo con el hotel activo; los permisos son
  // los mismos de siempre (recepción y reservas: quien opera o cobra; ama de llaves, mantenimiento y seguridad: su permiso).
  { label: 'Recepción', ico: '🛎', hotel: true, permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Tablero del día', to: '/hotel/recepcion' },
    { label: 'Calendario de habitaciones', to: '/hotel/calendario' },
    { label: 'Huéspedes', to: '/hotel/huespedes' },
    { label: 'Cuentas externas', to: '/hotel/folios' },
    { label: 'Cierre del día', to: '/hotel/cierre' },
    { label: 'Reportes', to: '/hotel/reportes' },   // 4.1: la pantalla existía pero no estaba en el menú
  ] },
  { label: 'Reservaciones', ico: '📅', hotel: true, permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Reservaciones', to: '/hotel/reservaciones' },
    { label: 'Cotizaciones', to: '/hotel/cotizaciones' },
    { label: 'Lista de espera', to: '/hotel/espera' },
    { label: 'Grupos y rooming list', to: '/hotel/grupos' },
    { label: 'Depósitos en garantía', to: '/hotel/depositos' },
    { label: 'Agencias y empresas', to: '/hotel/agencias' },
    { label: 'Histórico', to: '/hotel/historico' },   // H21: búsqueda de reservas de cualquier fecha y estado, y por habitación
    { label: 'Reportes', to: '/hotel/reportes' },
  ] },
  { label: 'Servicios', ico: '🧖', hotel: true, modulo: 'hotel_completo', permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Agenda de servicios', to: '/hotel/servicios' },
    { label: 'Liquidación a proveedores', to: '/hotel/servicios?tab=proveedores' },
  ] },
  { label: 'Eventos y banquetes', ico: '🎉', hotel: true, modulo: 'hotel_completo', permisos: ['escribir', 'pos', 'cobros', 'facturar'], children: [
    { label: 'Eventos y cotizaciones', to: '/hotel/eventos' },
    { label: 'Calendario de salones', to: '/hotel/eventos?tab=calendario' },
  ] },
  { label: 'Ama de llaves', ico: '🧹', hotel: true, permiso: 'limpieza', children: [
    { label: 'Tablero de habitaciones', to: '/hotel/ama-de-llaves/tablero' },
    { label: 'Reportes de limpieza', to: '/hotel/ama-de-llaves/incidencias' },
    { label: 'Lavandería y blancos', to: '/hotel/ama-de-llaves/lavanderia', modulo: 'hotel_completo' },
  ] },
  { label: 'Mantenimiento', ico: '🔧', hotel: true, permiso: 'mantenimiento', children: [
    { label: 'Incidencias', to: '/hotel/mantenimiento/incidencias' },
    { label: 'Habitaciones fuera de servicio', to: '/hotel/mantenimiento/habitaciones' },
    { label: 'Preventivo programado', to: '/hotel/mantenimiento/preventivo' },
  ] },
  { label: 'Seguridad', ico: '🛡', hotel: true, permiso: 'seguridad', modulo: 'hotel_completo', children: [
    { label: 'Puesto de seguridad', to: '/hotel/seguridad' },
    { label: 'Bitácora de turno', to: '/hotel/seguridad/bitacora' },
    { label: 'Visitantes y vehículos', to: '/hotel/seguridad/visitantes' },
    { label: 'Incidentes', to: '/hotel/seguridad/incidentes' },
    { label: 'Objetos perdidos', to: '/hotel/seguridad/objetos' },
  ] },
  { label: 'Reportes', ico: '▤', modulo: 'reportes', children: [   // 4.2: menú con los tipos de reporte (3.57: se oculta si el plan no lo incluye)
    { label: 'Todos los reportes', to: '/reportes' },
    { label: 'Favoritos', to: '/reportes/favoritos' },
    { label: 'Reporte ejecutivo', to: '/reportes/ejecutivo', permisos: ['reportes'] },
    { label: 'Ejecutivo por módulo', to: '/reportes/modulos' },
    { label: 'Ventas', to: '/reportes/ventas', permisos: ['facturar', 'reportes'] },
    { label: 'Administrativos', to: '/reportes/administrativos', permisos: ['gastos', 'reportes', 'inventario'] },
    { label: 'Financieros', to: '/reportes/financieros', permisos: ['reportes', 'gastos'] },
    { label: 'Contables', to: '/reportes/contables', permisos: ['contabilidad', 'reportes'] },
    { label: 'Fiscales', to: '/reportes/fiscales', permisos: ['contabilidad', 'reportes'] },
    { label: 'Punto de venta', to: '/reportes/pos', permisos: ['pos', 'reportes'], tipos: ['comercio', 'restaurante', 'hospitalidad', 'servicios'] },
    { label: 'Para trabajar', to: '/reportes/para-trabajar' },
  ] },
  { label: 'Mis tareas', ico: '✓', to: '/tareas' },
  { label: 'Configuración', ico: '⚙', to: '/configuracion' },
  { label: 'Reportar problema', ico: '⚑', accion: 'reporte', hotel: true },
];
// FISITAAP by Brillante Agencia: icono de línea de cada sección del menú (los nombres son los trazos de iconos.js)
export const ICONO_MENU = { Inicio: 'overview', Ingresos: 'sales', Compras: 'box', Contactos: 'users', 'Contactos y fiado': 'users', Inventario: 'box', Bancos: 'wallet', Contabilidad: 'credit',
  'Recursos humanos': 'users', 'Punto de venta': 'store', 'Ventas en línea': 'store', TiKe: 'tool', Recepción: 'bed', Reservaciones: 'calendar', Servicios: 'gift', 'Eventos y banquetes': 'table',
  'Ama de llaves': 'check', Mantenimiento: 'settings', Seguridad: 'shield', Reportes: 'overview', 'Mis tareas': 'check', Configuración: 'settings', 'Reportar problema': 'help', Administración: 'shield' };

// Tipos de negocio (2.5): una sola base y tres versiones. El administrador del sistema fija el tipo al crear la cuenta y el cliente
// no lo cambia. El tipo decide qué módulos hay y en qué orden: Facturación (sin punto de venta ni hotel), Comercio (punto de venta
// primero) y Hospitalidad (todo dentro de Hotel, con el punto de venta anidado ahí).
export const TIPOS_NEGOCIO = { facturacion: 'Facturación', comercio: 'Comercio (punto de venta)', restaurante: 'Restaurante (mesas y ventas en línea)', hospitalidad: 'Hospitalidad (hotel)', servicios: 'Servicios e IT (TiKe)' };   // 3.51
const ORDEN_TIPO = {
  facturacion: ['Inicio', 'Ingresos', 'Compras', 'Contactos', 'Inventario', 'Bancos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  comercio: ['Inicio', 'Punto de venta', 'Inventario', 'Compras', 'Contactos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  restaurante: ['Inicio', 'Punto de venta', 'Ventas en línea', 'Inventario', 'Compras', 'Contactos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  servicios: ['Inicio', 'TiKe', 'Ingresos', 'Compras', 'Contactos', 'Inventario', 'Bancos', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración'],
  hospitalidad: ['Inicio', 'Recepción', 'Reservaciones', 'Servicios', 'Eventos y banquetes', 'Ama de llaves', 'Mantenimiento', 'Seguridad', 'Punto de venta',
                 'Contactos', 'Inventario', 'Contabilidad', 'Recursos humanos', 'Reportes', 'Mis tareas', 'Configuración', 'Reportar problema'],
};
const _menus = {};
export function menuTipo(tipo) {
  tipo = ORDEN_TIPO[tipo] ? tipo : 'facturacion';
  if (_menus[tipo]) return _menus[tipo];
  const por = Object.fromEntries(MENU.map(it => [it.label, it]));
  const sin = it => { const r = { ...it }; delete r.ico; delete r.permiso; delete r.permisos; return r; };
  // Comercio y Hospitalidad (croquis 21/10): Contabilidad agrupa lo administrativo (Ingresos, Bancos y, en el hotel, Compras), porque
  // lo usa el dueño o el contador, no la caja ni la recepción. En Comercio, Compras queda arriba: comprar mercadería es del día a día.
  const conta = (conCompras) => ({ label: 'Contabilidad', ico: '≡', permisos: ['contabilidad', 'gastos', 'facturar', 'cobros'], children: [
    { ...sin(por['Ingresos']), permisos: ['facturar', 'cobros', 'ver_todo'] },
    ...(conCompras ? [{ ...sin(por['Compras']), permiso: 'gastos' }] : []),
    { ...sin(por['Bancos']), permiso: 'gastos' },
    ...por['Contabilidad'].children.map(c => ({ ...c, permisos: ['contabilidad'] })),   // 3.87: con «permisos» también pasa ver_todo (Solo lectura), como en Facturación
  ] });
  const lista = ORDEN_TIPO[tipo].map(l => {
    if (l === 'Contabilidad' && tipo !== 'facturacion' && tipo !== 'servicios') return conta(tipo === 'hospitalidad');   // 3.87: Servicios ya tiene Ingresos y Bancos en la raíz (salían dos veces)
    if (l === 'Contactos' && (tipo === 'comercio' || tipo === 'restaurante')) return { ...por['Contactos'], label: 'Contactos y fiado' };
    return por[l];
  }).filter(Boolean);
  // Módulos que se contratan como extra (FISITAAP, TiKe): si el orden del tipo no los lista, van antes de «Mis tareas»; el plan decide
  // si se ven (modulo:). Arreglo 3.52: en Comercio y Hospitalidad no aparecían (3.47-3.51). 3.57: FISITAAP es una sola entrada.
  const extras = ['Ventas en línea', 'TiKe', 'Clínicas'].filter(l => !ORDEN_TIPO[tipo].includes(l) && por[l]).map(l => por[l]);
  if (extras.length) { const i = lista.findIndex(it => it.label === 'Mis tareas'); lista.splice(i < 0 ? lista.length : i, 0, ...extras); }
  return (_menus[tipo] = lista);
}
// Secciones que solo existen en algunos tipos (el menú no las muestra y la ruta tampoco abre)
const RUTA_TIPO = [['/hotel', ['hospitalidad']], ['/pos', ['comercio', 'hospitalidad', 'restaurante']]];
export { RUTA_TIPO };
export function rutaDeOtroTipoDe(s, path) { return RUTA_TIPO.some(([pre, tipos]) => path.startsWith(pre) && !tipos.includes(s.tipo)); }

// Permiso para ABRIR cada sección (el servidor además filtra los datos). estricto: no basta 'ver_todo'.
const PERMISO_RUTA = [['/clinicas', 'clinicas', true], ['/fisitaap', 'pos'], ['/pedidos', 'pos'], ['/promociones', 'pos'], ['/entregas', 'pos'], ['/tike', 'tike', true],   /* 3.57; 3.87: TiKe no se abre con ver_todo (el servidor lo niega) */ ['/rrhh', 'rrhh', true], ['/inventario/gestion', 'catalogos', true], ['/ventas/importar', 'configurar', true], ['/pos/recetas', 'catalogos'], ['/pos/reportes', 'cobros'], ['/pos/inventario', 'inventario'], ['/pos/configuracion', 'configurar', true], ['/pos', 'pos', true], ['/gastos', 'gastos'], ['/bancos', 'gastos'], ['/contabilidad', 'contabilidad'], ['/reportes/ejecutivo', 'reportes'],
  ['/configuracion/contabilidad-', 'contabilidad'], ['/configuracion/exportar', 'configurar', true], ['/configuracion/empresa', 'configurar', true], ['/configuracion/marcas', 'configurar', true], ['/configuracion/hacienda', 'configurar', true], ['/configuracion/integraciones', 'configurar', true], ['/configuracion/instalacion-local', 'configurar', true], ['/configuracion/suscripcion', 'configurar', true],   /* 3.32 */ ['/hotel/configuracion', 'configurar', true], ['/hotel/ama-de-llaves', 'limpieza'], ['/hotel/mantenimiento', 'mantenimiento'], ['/hotel/seguridad', 'seguridad']];
export { PERMISO_RUTA };
// 3.87: rutas que se abren con cualquiera de varios permisos: los mismos con que el servidor da sus datos (PERMISO_RUTA lleva uno por regla)
const PERMISO_RUTA_ALGUNO = [['/inventario/reponer', ['inventario', 'gastos', 'catalogos', 'ver_todo']],   // GET /api/inventario/reponer
  ['/inventario/traslados', ['inventario', 'gastos', 'facturar']],   // GET /api/traslados (el historial; trasladar pide inventario y facturar)
  ['/contactos/revendedoras', ['facturar', 'cobros', 'catalogos', 'ver_todo']], ['/contactos/estado-cuenta', ['facturar', 'cobros', 'catalogos', 'ver_todo']]];   // 4.9: GET /api/revendedoras y su estado de cuenta (lector_cuentas)
// 3.87: espejo de auth.PERMISOS_DOCUMENTOS: sin ninguno, el servidor niega comprobantes, pagos, costos e inventario (con_documentos)
const PERMISOS_DOCUMENTOS = ['escribir', 'pos', 'cobros', 'facturar', 'ver_todo', 'gastos', 'contabilidad', 'reportes', 'inventario', 'catalogos', 'documentos', 'configurar'];
// 3.87: permiso de cada sección de Configuración (#/configuracion/<sección>). Lo usan la portada (configuracion/hub.js, que solo
// muestra lo que el rol puede usar) y la ruta: antes la portada escondía la sección, pero escrita a mano abría con botones que daban
// 403. Con varios, los pide todos (Respaldos: configurar y usuarios, como el servidor). Lo que no está aquí sigue en PERMISO_RUTA.
export const PERMISO_CONFIG = {
  empresa: 'configurar', usuarios: 'usuarios', perfil: 'ver', 'centros-costos': 'contabilidad', monedas: 'configurar', exportar: 'configurar', respaldos: ['configurar', 'usuarios'], sucursales: 'configurar',
  hacienda: 'configurar', 'terminos-pago': 'configurar', numeraciones: 'facturar', documentos: 'documentos', vendedores: 'configurar', 'otros-cargos': 'configurar',
  plantillas: 'configurar', impuestos: 'configurar', retenciones: 'configurar', notificaciones: 'configurar', 'plantillas-correo': 'configurar', preferencias: 'ver',
  'campos-adicionales': 'catalogos', variantes: 'catalogos', integraciones: 'configurar', 'instalacion-local': 'configurar', ia: 'configurar', 'inventario-costeo': 'configurar',
  'historial-correos': 'ver_todo', 'historial-operaciones': 'ver_todo', suscripcion: ['ver_todo', 'escribir'],   /* 3.95: Administrador, Avanzado y Contador pagan el plan */
};
// Módulos que dependen del plan de la empresa (3.16): si el plan no los incluye, el menú no los muestra y la ruta tampoco abre
const RUTA_MODULO = [['/clinicas', 'clinicas'], ['/fisitaap', 'pedidos_online'], ['/pedidos', 'pedidos_online'], ['/promociones', 'pedidos_online'], ['/entregas', 'entregas'], ['/tike', 'tike'],   /* 3.57 */ ['/hotel/servicios', 'hotel_completo'], ['/hotel/eventos', 'hotel_completo'], ['/hotel/ama-de-llaves/lavanderia', 'hotel_completo'],
  ['/hotel/seguridad', 'hotel_completo'], ['/contabilidad', 'contabilidad'], ['/configuracion/contabilidad-', 'contabilidad'], ['/configuracion/centros-costos', 'contabilidad'],   /* 3.87 */ ['/rrhh', 'rrhh'], ['/reportes', 'reportes'], ['/pos', 'pos']];
export { RUTA_MODULO };
export const NOMBRES_MODULO = { clinicas: 'Clínicas', contabilidad: 'Contabilidad', rrhh: 'Recursos humanos', reportes: 'Reportes', pos: 'Punto de venta', hotel_completo: 'Hotel completo (servicios, eventos, lavandería y seguridad)', canales: 'Integración de canales', pedidos_online: 'Ventas en línea', entregas: 'Ventas en línea · Entregas', tike: 'TiKe' };
export function rutaSinModuloDe(s, path) { for (const [pre, m] of RUTA_MODULO) if (path.startsWith(pre) && !s.tieneModulo(m)) return m; return null; }
// modo cajero (rol Cajero): la sesión del ERP lo trae calculado; si no, se deduce de los permisos
export function modoCajeroDe(s) { if (s.modoCajero !== undefined) return !!s.modoCajero; return s.tipo !== 'facturacion' && !s.esAdmin && s.puede('pos') && (s.permisos || []).every(p => p === 'ver' || p === 'pos'); }
// 4.5: la ruta tal como la comparan los permisos, sin codificación: #/configuracion/%68acienda esquivaba PERMISO_CONFIG y PERMISO_RUTA
// (startsWith no la reconocía) y match() sí decodificaba el parámetro, así que la pantalla abría. Si no se puede decodificar, queda como vino.
export function decodificarRuta(path) { const p = String(path || ''); try { return decodeURIComponent(p); } catch { return p; } }
export function rutaPermitidaDe(s, path) {
  path = decodificarRuta(path);
  // modo cajero (rol Cajero): solo el punto de venta y su perfil
  if (modoCajeroDe(s) && !(path.startsWith('/pos') || path === '/configuracion/perfil')) return false;
  for (const [pre, tipos] of RUTA_TIPO) if (path.startsWith(pre) && !tipos.includes(s.tipo)) return false;   // tipo de negocio (2.5)
  if (rutaSinModuloDe(s, path)) return false;   // módulo no incluido en el plan (3.16)
  if (path.startsWith('/hotel/seguridad') && s.puede('escribir')) return true;   // 3.3
  // recepción, reservas, servicios, eventos, cierre y reportes del hotel: quien opera o cobra (3.20); ama de llaves y mantenimiento tienen lo suyo
  if (/^\/hotel\/(recepcion|reservaciones|calendario|huespedes|folios|cierre|grupos|depositos|agencias|servicios|eventos|reportes|espera|cotizaciones|historico)/.test(path)) return ['escribir', 'pos', 'cobros', 'facturar', 'ver_todo'].some(p => s.puede(p));
  // 3.87: Ingresos e Inventario no abren a los roles de un solo módulo (técnico de soporte, solo RRHH, camarera, técnico, seguridad):
  // el servidor les niega esos datos y la pantalla abría vacía con avisos 403 en vez de «Sin acceso»
  if (/^\/(ventas|inventario)(\/|$)/.test(path) && !PERMISOS_DOCUMENTOS.some(p => s.puede(p))) return false;
  for (const [pre, perms] of PERMISO_RUTA_ALGUNO) if (path.startsWith(pre)) return perms.some(p => s.puede(p));
  const seccion = path.startsWith('/configuracion/') && PERMISO_CONFIG[path.slice('/configuracion/'.length)];   // 3.87: lo mismo que la portada
  if (seccion) return [].concat(seccion).every(p => p === 'ver' || s.puede(p));   // 'ver' lo trae todo rol: Mi perfil siempre abre
  for (const [pre, perm, estricto] of PERMISO_RUTA) if (path.startsWith(pre)) return s.puede(perm) || (!estricto && s.puede('ver_todo'));
  return true;
}

// 4.7: Recursos humanos pide la verificación en dos pasos. Quien tiene el permiso en su rol pero todavía no la activó (la sesión trae
// rrhh_requiere_mfa y el servidor le quita el permiso) ve la sección con candado: una sola entrada que lleva a Mi perfil, a la tarjeta
// de la verificación, con el aviso. Al activarla, Mi perfil vuelve a leer la sesión y aparece el menú completo.
export const AVISO_RRHH_MFA = 'Active la verificación en dos pasos para ver Recursos humanos';
export const RUTA_RRHH_MFA = '/configuracion/perfil?aviso=rrhh';
// También en modo cajero: un rol propio con caja y Recursos humanos queda en modo cajero justamente porque el servidor le quitó «rrhh»
// (le falta la verificación). El Cajero de siempre nunca trae rrhh_requiere_mfa, así que para él no cambia nada.
export function rrhhConCandadoDe(s) { return !!(s && s.empresa_id && s.rrhhRequiereMfa && !s.puede('rrhh') && s.tieneModulo('rrhh')); }
export function candadoDe(s, it) { return it && it.permiso === 'rrhh' && it.children && rrhhConCandadoDe(s) ? { label: it.label, ico: it.ico, to: RUTA_RRHH_MFA, candado: true, aviso: AVISO_RRHH_MFA } : it; }

// Visibilidad del menú por módulo del plan, tipo de negocio, hotel activo y rol. hotelActivo: función (en el ERP lee los registros;
// en Ventas en línea, lo que trajo /api/arranque). La portada de aplicaciones y el cajón de Ventas en línea arman sus tarjetas y
// grupos con exactamente lo que el menú muestra a cada empresa.
export function hijoOkDe(s, hotelActivo, c) {
  if (c.modulo && !s.tieneModulo(c.modulo)) return false;
  if (c.tipos && !c.tipos.includes(s.tipo)) return false;                 // entrada de un tipo de negocio (3.77: Express pendientes solo en restaurante)
  if (c.to && !c.children) { const b = c.to.split('?')[0]; if (rutaDeOtroTipoDe(s, b) || rutaSinModuloDe(s, b)) return false; }   // p. ej. Conteo físico y Recetas solo con punto de venta (3.37)
  if (modoCajeroDe(s) && !((c.permiso === 'pos' && (!c.clave || CLAVES_CAJA.includes(c.clave))) || (c.to || '').startsWith('/pos'))) return false;   // 3.87: de Ventas en línea, solo los pedidos
  if (c.hotel && !hotelActivo()) return false;
  if (c.permiso === 'seguridad' && s.puede('escribir')) return true;   // recepción también usa el módulo de Seguridad (3.3)
  if (c.permisos) return c.permisos.some(p => s.puede(p)) || s.puede('ver_todo');
  if (!c.permiso) return true; return s.puede(c.permiso) || (!!c.children && s.puede('ver_todo'));
}
export function conHijosDe(s, hotelActivo, it) { return (it.children || []).some(c => hijoOkDe(s, hotelActivo, c) && (!c.children || conHijosDe(s, hotelActivo, c))); }
export function menuOkDe(s, hotelActivo, it) {
  if (it.modulo && !s.tieneModulo(it.modulo)) return false;        // módulo no incluido en el plan (3.16)
  // 4.7: Recursos humanos sin la verificación en dos pasos se muestra con candado (candadoDe), también en modo cajero. Va antes de
  // revisar los hijos: en modo cajero ninguna entrada de la sección es de la caja y el grupo se descartaba.
  if (it.permiso === 'rrhh' && rrhhConCandadoDe(s)) return true;
  if (it.hotel) return s.tipo === 'hospitalidad' && hijoOkDe(s, hotelActivo, it) && (!it.children || conHijosDe(s, hotelActivo, it));   // módulos del hotel (3.37): con el hotel activo y su permiso
  if (it.children && !conHijosDe(s, hotelActivo, it)) return false;    // grupo sin ninguna entrada visible para este rol (3.37)
  if (modoCajeroDe(s)) return it.permiso === 'pos';                     // cajero: solo el punto de venta
  if (it.permisos) return it.permisos.some(p => s.puede(p)) || s.puede('ver_todo');   // grupo con varias puertas (Contabilidad: contabilidad o gastos por Bancos)
  if (it.permiso === 'clinicas') return s.puede('clinicas');
  if (!it.permiso) return true; if (['rrhh', 'facturar', 'pos', 'configurar', 'tike'].includes(it.permiso)) return s.puede(it.permiso); return s.puede(it.permiso) || s.puede('ver_todo');   // 3.87: TiKe tampoco se abre con ver_todo
}
// El menú de la empresa activa ya filtrado a cualquier profundidad (lo que ve este usuario)
export function menuVisibleDe(s, hotelActivo) {
  if (!s.empresa_id) return [];
  const podar = items => items.filter(c => hijoOkDe(s, hotelActivo, c) && (!c.children || conHijosDe(s, hotelActivo, c))).map(c => c.children ? { ...c, children: podar(c.children) } : c);
  return menuTipo(s.tipo).filter(it => menuOkDe(s, hotelActivo, it)).map(it => candadoDe(s, it)).map(it => it.children ? { ...it, children: podar(it.children) } : it);   // 4.7: RRHH con candado
}
