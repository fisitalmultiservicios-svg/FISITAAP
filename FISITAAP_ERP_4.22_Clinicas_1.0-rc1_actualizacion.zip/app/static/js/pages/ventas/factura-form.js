// Nueva factura de venta / tiquete (backend real: POST /api/comprobantes; bodegas y existencias de /api/inventario)
import { api, toast, money, fmt, CAT, opts, hoy, monedas, mock, fecha, abrirArchivo } from '../../api.js';
import { store, sesion } from '../../app.js';
import ExoneracionRapida from '../contactos/exoneracion-rapida.js';

export default {
  props: ['params'],
  components: { ExoneracionRapida },
  data() {
    return {
      doc: null, ajustes: false, guardando: false, bodegas: [], existencias: {}, cotizacion: null,
      // Factura recurrente: params.recurrente ('nueva' o id) → se guarda la recurrencia en vez de emitir. params.pendiente → factura
      // generada por una recurrencia en su fecha: se revisa y se emite (queda marcada como emitida).
      modoRecurrente: !!this.params.recurrente, recurrenteId: this.params.recurrente && this.params.recurrente !== 'nueva' ? +this.params.recurrente : null,
      rec: { nombre: '', periodicidad: 'mensual', dia_emision: new Date().getDate(), mes_emision: new Date().getMonth() + 1, dia_semana: (new Date().getDay() + 6) % 7, dia_emision2: 31, dias_vencimiento: 0, inicio: hoy(), fin: '', activa: true },
      calendario: null, calTimer: null,
      MESES: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
      DIAS_SEMANA: ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'],
      pendiente: null, PERIODOS: { diaria: 'Diaria', semanal: 'Semanal', quincenal: 'Quincenal', mensual: 'Mensual', bimensual: 'Bimestral (cada 2 meses)', trimestral: 'Trimestral', semestral: 'Semestral', anual: 'Anual' },   // 'bimensual' = cada dos meses (R334)
      f: { tipo_documento: this.params.tipo || '01', cliente_id: null, actividad_emisor: null, condicion_venta: '01', condicion_venta_otros: '', plazo_credito: 30, medio_pago: '01', medio_pago_otros: '', moneda: 'CRC', tipo_cambio: 1,
           fecha: hoy(), vence: hoy(), vendedor: '', bodega_id: null, orden_compra: '', lineas: [], observaciones: '', terminos: '', exoneracion_id: undefined, marca_id: null },
      marcas: [],          // marcas de la empresa (3.45): logo y nombre comercial del documento
      exos: [],          // exoneraciones vigentes del cliente (se aplica la primera sola; «No aplicar» la quita)
      exoAuto: false, exosCargando: false, exoNueva: false,   // exoAuto: la eligió el sistema (si no aplica a ninguna línea se emite sin ella)
      venceManual: false, noEncontrado: false, duplicadoDe: '',
      // params.borrador: se edita un borrador guardado (sin consecutivo ni firma); al emitir, el borrador desaparece
      borradorId: this.params.borrador ? +this.params.borrador : null,
      // clave única de este formulario: si la red se corta después de emitir y se vuelve a pulsar, el servidor devuelve la misma factura (R93)
      idem: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random()), intentoFallido: false,
      CAT, opts, monedasOpc: monedas.opciones(),
    };
  },
  watch: {
    rec: { handler() { this.pedirCalendario(); }, deep: true, immediate: true },   /* vista previa del calendario (3.30) */
    'f.moneda'(v) { this.f.tipo_cambio = monedas.tc(v); },
    // vencimiento = fecha + plazo en ventas a crédito (contado: la misma fecha), salvo que el usuario lo haya cambiado a mano
    'f.condicion_venta'() { this.recalcularVence(); },
    // tras un intento fallido, cualquier cambio en el formulario es otra factura: clave de idempotencia nueva
    f: { deep: true, handler() { if (this.intentoFallido) { this.intentoFallido = false; this.idem = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random()); } } },
    'f.tipo_documento'(v) { if (!CAT.condicionVentaDe(v).some(o => o.value === this.f.condicion_venta)) this.f.condicion_venta = '01'; this.cargarExos(); },
    'f.plazo_credito'() { this.recalcularVence(); },
    'f.fecha'() { this.recalcularVence(); },
    'f.bodega_id'() { this.cargarExistencias(); },
    // al elegir o cambiar el cliente se cargan sus exoneraciones; un borrador conserva la que traía
    'f.cliente_id'(v, antes) { if (antes != null && v !== antes) this.f.exoneracion_id = undefined; this.cargarExos(); },
  },
  computed: {
    marcaSel() { return this.marcas.find(m => m.id === this.f.marca_id) || null; },
    marcaNombre() { return this.marcaSel ? this.marcaSel.nombre : (this.e?.nombre_comercial || this.e?.nombre || 'Mi empresa'); },
    ayudaTC() { const t = store.tc; return t && t.venta ? 'BCCR venta ₡' + fmt(t.venta, 2) + ' (' + t.fecha + ') + ' + t.margen + ' % de protección = ₡' + fmt(t.aplicado, 2) : ''; },
    store() { return store; },
    e() { return store.empresa; },
    numeroCliente() { const c = (store.clientes || []).find(x => x.id === this.f.cliente_id); return String((c && c.numero_id) || ''); },
    clienteSinId() { return !!this.f.cliente_id && !this.numeroCliente && this.f.tipo_documento !== '04'; },   /* 3.33 */
    exoSel() { return this.f.tipo_documento === '09' ? null : (this.exos.find(x => x.id === this.f.exoneracion_id) || null); },
    // con exoneración elegida pero sin ninguna línea que la tome, el servidor no emite: se avisa antes
    exoSinLineas() { const x = this.exoSel; return !!x && this.f.lineas.some(l => l.cabys || l.producto_id) && !this.f.lineas.some(l => l.codigo_tarifa !== '10' && (+l.tarifa || 0) > 0 && l.exonerar !== false && (!x.posee_cabys || (x.cabys || []).includes(String(l.cabys || '')))); },
    // actividad principal + secundarias (Empresa › Actividades secundarias) (R53)
    actividades() { const x = mock.get('empresa_extra', {}) || {}; return [this.e?.actividad, ...(x.secundarias || [])].filter((a, i, l) => a && l.indexOf(a) === i); },
    codSuc() { return String(sesion.sucursalActual?.codigo || this.e?.sucursal || 1).padStart(3, '0'); },   // 3.82: la sucursal con que se emite
    sucursalEmite() { return sesion.sucursalActual ? sesion.sucursalActual.nombre : 'Principal'; },
    numero() { const t = this.f.tipo_documento; return `${this.codSuc}${String(this.e?.terminal || 1).padStart(5, '0')}${t}…`; },
    // Existencias disponibles en la bodega elegida para los productos inventariables de las líneas
    disponibles() {
      const vistos = new Set(), out = [];
      for (const l of this.f.lineas) {
        if (!l.producto_id || vistos.has(l.producto_id)) continue;
        const p = store.productos.find(x => x.id == l.producto_id);
        if (!p || p.es_servicio || p.inventariable === false) continue;
        vistos.add(p.id);
        const disp = +(this.existencias[p.id] ?? 0);
        const pedida = this.f.lineas.filter(x => x.producto_id == p.id).reduce((s, x) => s + (+x.cantidad || 0), 0);
        out.push({ id: p.id, nombre: p.nombre, disponible: disp, falta: pedida > disp && !p.venta_negativo });
      }
      return out;
    },
  },
  methods: {
    esCredito() { return ['02', '08', '10'].includes(this.f.condicion_venta); },
    async cargarExos() {
      const cid = this.f.cliente_id;
      if (!cid || this.f.tipo_documento === '09') { this.exos = []; return; }
      this.exosCargando = true;
      try {
        const l = (await api('/api/clientes/' + cid + '/exoneraciones')).filter(x => x.activa && x.estado !== 'vencida' && !x.solo_notas);
        if (this.f.cliente_id !== cid) return;
        this.exos = l;
        if (this.f.exoneracion_id === undefined) { this.f.exoneracion_id = l.length ? l[0].id : undefined; this.exoAuto = !!l.length; }
        else if (this.f.exoneracion_id && !l.some(x => x.id === this.f.exoneracion_id)) { this.f.exoneracion_id = null; this.exoAuto = false; toast('La exoneración guardada ya no está vigente o se desactivó: elija otra o emita sin exoneración', 'err'); }
      } catch { this.exos = []; }
      if (this.f.cliente_id === cid) this.exosCargando = false;
    },
    async exoRegistrada(x) { this.exoNueva = false; await this.cargarExos(); if (x && this.exos.some(e => e.id === x.id)) { this.f.exoneracion_id = x.id; this.exoAuto = false; } },
    async verPdfExo(x) { try { await abrirArchivo('/api/exoneraciones/' + x.id + '/pdf'); } catch (e) { toast(e.message, 'err'); } },
    exoEtiqueta(x) { return x.numero + ' · exonera ' + (+x.tarifa).toLocaleString('es-CR') + ' % · ' + (x.fecha_vencimiento ? 'vence ' + fecha(x.fecha_vencimiento) : 'sin vencimiento') + (x.posee_cabys ? ' · ' + x.cabys.length + ' CABYS' : ''); },
    recalcularVence() {
      if (this.venceManual) return;
      const base = this.f.fecha || hoy();
      if (!this.esCredito()) { this.f.vence = base; return; }
      const d = new Date(base + 'T00:00:00'); d.setDate(d.getDate() + (+this.f.plazo_credito || 30));
      this.f.vence = d.toISOString().slice(0, 10);
    },
    money, fmt,
    async cargarExistencias() {
      if (!this.f.bodega_id) return;
      try { const l = await api('/api/inventario/existencias?bodega_id=' + this.f.bodega_id); this.existencias = {}; for (const e of l) this.existencias[e.producto_id] = e.cantidad; } catch {}
    },
    // Guarda la recurrencia (no emite nada): el servidor generará una factura pendiente en cada fecha programada.
    async guardarRecurrente() {
      if (this.f.tipo_documento !== '04' && !this.f.cliente_id) return toast('Seleccione el cliente', 'err');
      if (!this.f.lineas.some(l => l.detalle || l.producto_id)) return toast('Agregue al menos una línea', 'err');
      if (!this.rec.inicio) return toast('Indique la fecha de inicio', 'err');
      if (this.validarOtros() !== true) return;
      this.guardando = true;
      try {
        const body = { nombre: this.rec.nombre || '', cliente_id: this.f.cliente_id || null, tipo_documento: this.f.tipo_documento, condicion_venta: this.f.condicion_venta, plazo_credito: this.esCredito() ? (parseInt(this.f.plazo_credito, 10) || 30) : null,
                       condicion_venta_otros: this.f.condicion_venta === '99' ? (this.f.condicion_venta_otros || '').trim() : null, medio_pago_otros: this.f.medio_pago === '99' ? (this.f.medio_pago_otros || '').trim() : null,
                       medio_pago: this.f.medio_pago, moneda: this.f.moneda, ...this.calendarioBody(), actividad_emisor: this.f.actividad_emisor || null, dias_vencimiento: this.diasVence(),
                       lineas: this.f.lineas.map(l => ({ ...l, precio_unitario: l.precio_unitario ?? null })), observaciones: this.f.observaciones || null, terminos: this.f.terminos || null, vendedor: this.f.vendedor || null, activa: this.rec.activa !== false,
                       exoneracion_id: this.exoSel && !this.exoAuto ? this.exoSel.id : (this.f.exoneracion_id === null ? 0 : null) };   // elegida, «no aplicar» (0) o la vigente al emitir (vacío)
        const r = await api(this.recurrenteId ? '/api/recurrentes/' + this.recurrenteId : '/api/recurrentes', { method: this.recurrenteId ? 'PUT' : 'POST', body });
        toast('Factura recurrente guardada. Próxima emisión: ' + (r.proxima ? fecha(r.proxima) : '—'), 'ok');
        location.hash = '/ventas/recurrentes';
      } catch (e) { this.intentoFallido = true; toast(e.message, 'err'); }
      this.guardando = false;
    },
    // nueva factura a partir de un comprobante emitido: cliente, condiciones y líneas (sin consecutivo, con fecha de hoy y el tipo de cambio del día)
    cargarDeDocumento(d) {
      this.f.tipo_documento = ['01', '04'].includes(d.tipo_documento) ? d.tipo_documento : '01';
      this.f.cliente_id = d.cliente_id || null; this.f.condicion_venta = d.condicion_venta || '01'; this.f.moneda = d.moneda || 'CRC'; if (d.marca_id) this.f.marca_id = d.marca_id;
      this.f.observaciones = d.observaciones || ''; this.f.terminos = d.terminos || ''; this.f.vendedor = d.vendedor || ''; this.f.orden_compra = d.orden_compra || '';
      this.f.lineas = (d.lineas || []).map(l => ({ producto_id: l.producto_id || null, detalle: l.detalle || '', cabys: l.cabys || '', cantidad: +l.cantidad || 1, precio_unitario: l.precio_unitario ?? null, descuento: +l.descuento || 0,
                                                 descuento_pct: (+l.cantidad || 0) * (+l.precio_unitario || 0) > 0 ? Math.round((+l.descuento || 0) / ((+l.cantidad || 0) * (+l.precio_unitario || 0)) * 1e6) / 1e4 : 0,
                                                 codigo_tarifa: l.codigo_tarifa || '08', tarifa: +l.tarifa || 0, unidad_medida: l.unidad_medida || undefined }));
      this.duplicadoDe = d.consecutivo || ('comprobante #' + d.id);
    },
    cargarDeRecurrente(r) {
      if (r.exoneracion_id === 0) { this.f.exoneracion_id = null; this.exoAuto = false; } else if (r.exoneracion_id) { this.f.exoneracion_id = r.exoneracion_id; this.exoAuto = false; }
      this.f.tipo_documento = r.tipo_documento || '01'; this.f.cliente_id = r.cliente_id || null; this.f.condicion_venta = r.condicion_venta || '01'; this.f.plazo_credito = r.plazo_credito || 30;
      this.f.medio_pago = r.medio_pago || '01'; this.f.moneda = r.moneda || 'CRC'; this.f.observaciones = r.observaciones || ''; this.f.terminos = r.terminos || ''; this.f.vendedor = r.vendedor || '';
      this.f.condicion_venta_otros = r.condicion_venta_otros || ''; this.f.medio_pago_otros = r.medio_pago_otros || '';
      this.f.lineas = (r.lineas || []).map(l => ({ descuento_pct: l.descuento_pct, producto_id: l.producto_id || null, detalle: l.detalle || '', cabys: l.cabys || '', cantidad: +l.cantidad || 1, precio_unitario: l.precio_unitario ?? null, descuento: +l.descuento || 0, codigo_tarifa: l.codigo_tarifa || '08', tarifa: l.tarifa ?? 13, es_servicio: l.es_servicio, unidad_medida: l.unidad_medida, ...(l.exonerar === false ? { exonerar: false } : {}) }));
      const ini = new Date((r.inicio || hoy()) + 'T00:00:00');
      this.rec = { nombre: r.nombre || '', periodicidad: r.periodicidad || 'mensual', dia_emision: r.dia_emision || 1, mes_emision: r.mes_emision || (ini.getMonth() + 1), dia_semana: r.dia_semana ?? ((ini.getDay() + 6) % 7),
                   dia_emision2: r.dia_emision2 || null, quincena15: r.periodicidad === 'quincenal' && !r.dia_emision2, inicio: r.inicio || hoy(), fin: r.fin || '', activa: r.activa !== false,
                   dias_vencimiento: r.dias_vencimiento ?? (['02', '08', '10'].includes(r.condicion_venta) ? (+r.plazo_credito || 0) : 0) };
      if (r.actividad_emisor) this.f.actividad_emisor = r.actividad_emisor;
    },
    // 3.31: cada factura de la recurrencia vence N días después de su emisión (a crédito = el plazo de crédito)
    diasVence() { return this.esCredito() ? (parseInt(this.f.plazo_credito, 10) || 0) : Math.max(0, parseInt(this.rec.dias_vencimiento, 10) || 0); },
    // 3.30: lo que define el calendario (mes y día en anual/semestral/trimestral/bimestral, día de la semana, dos días en quincenal)
    calendarioBody() {
      const r = this.rec, p = r.periodicidad, meses = { bimensual: 1, trimestral: 1, semestral: 1, anual: 1 };
      return { periodicidad: p, inicio: r.inicio, fin: r.fin || null, dia_emision: +r.dia_emision || 1,
               mes_emision: meses[p] ? (+r.mes_emision || null) : null, dia_semana: p === 'semanal' ? +r.dia_semana : null,
               dia_emision2: p === 'quincenal' && !r.quincena15 ? (+r.dia_emision2 || 31) : null };
    },
    pedirCalendario() {
      clearTimeout(this.calTimer);
      if (!this.modoRecurrente || !this.rec.inicio) { this.calendario = null; return; }
      this.calTimer = setTimeout(async () => {
        try { this.calendario = await api('/api/recurrentes/calendario', { method: 'POST', body: { ...this.calendarioBody(), editando: !!this.recurrenteId } }); } catch (e) { this.calendario = null; }
      }, 250);
    },
    cuerpo() {
      // elegida por el sistema y sin líneas que la tomen: se emite sin exoneración; mientras cargan las del cliente se conserva la del borrador
      const exoId = this.exosCargando ? (this.f.exoneracion_id ?? null) : (this.exoSel && !(this.exoAuto && this.exoSinLineas) ? this.exoSel.id : null);
      return { ...this.f, exoneracion_id: exoId, cliente_id: this.f.cliente_id || null, bodega_id: this.f.bodega_id || null, plazo_credito: this.esCredito() ? (parseInt(this.f.plazo_credito, 10) || null) : null,
        extra: { ...(this.borradorId && this.f.extra?.clinica_episodio_id ? { clinica_episodio_id: this.f.extra.clinica_episodio_id, clinica_borrador_marca: this.f.extra.clinica_borrador_marca } : {}), terminos: this.f.terminos || '', orden_compra: this.f.orden_compra || '', cotizacion_id: this.cotizacion ? this.cotizacion.id : null, cotizacion_clave: this.cotizacion ? (this.cotizacion._clave || 'cotizaciones') : null }, lineas: this.f.lineas.map(l => ({ ...l, precio_unitario: l.precio_unitario ?? null })), observaciones: this.f.observaciones || null, vendedor: this.f.vendedor || null, fecha_vencimiento: this.f.vence || null, pendiente_id: this.pendiente ? this.pendiente.id : null, borrador_id: this.borradorId, idempotencia: this.idem, actividad_emisor: this.f.actividad_emisor || null,
        condicion_venta_otros: this.f.condicion_venta === '99' ? (this.f.condicion_venta_otros || '').trim() : null, medio_pago_otros: this.f.medio_pago === '99' ? (this.f.medio_pago_otros || '').trim() : null,
        terminos: (this.f.terminos || '').trim() || null, orden_compra: (this.f.orden_compra || '').trim() || null };   // van al comprobante y al PDF (R103)
    },
    // Borrador: se guarda en el servidor SIN emitir (no consume consecutivo, no se firma, no descuenta inventario y la cola
    // no lo envía). Antes «Guardar sin emitir» firmaba el comprobante y Hacienda lo recibía en minutos.
    async guardarBorrador() {
      if (!this.f.lineas.length) return toast('Agregue al menos una línea', 'err');
      this.guardando = true;
      try {
        const body = this.cuerpo(); delete body.borrador_id;   // pendiente_id se conserva: al emitir el borrador la pendiente queda emitida
        const b = this.borradorId ? await api('/api/borradores/' + this.borradorId, { method: 'PUT', body }) : await api('/api/borradores', { method: 'POST', body });
        this.borradorId = b.id;
        toast('Borrador guardado: no se ha emitido ni enviado a Hacienda. Lo encuentra en la lista como «Borrador».', 'ok');
        location.hash = '/ventas/facturas';
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    async cargarBorrador(b) {
      const d = b.datos || {};
      this.f = { ...this.f, ...d, condicion_venta_otros: d.condicion_venta_otros || '', medio_pago_otros: d.medio_pago_otros || '', vence: d.fecha_vencimiento || this.f.vence, lineas: (d.lineas || []).map(l => ({ ...l })) };
      this.venceManual = !!d.fecha_vencimiento;
      if (+d.tipo_cambio > 0) this.$nextTick(() => { this.f.tipo_cambio = +d.tipo_cambio; });   // el del borrador, no el del día
      const x = d.extra || {};
      this.f.terminos = x.terminos || ''; this.f.orden_compra = x.orden_compra || '';
      if (x.cotizacion_id != null && !this.cotizacion) { const cl = x.cotizacion_clave || 'cotizaciones', c = (mock.get(cl, []) || []).find(c => String(c.id) === String(x.cotizacion_id)); this.cotizacion = c ? { ...c, _clave: cl } : null; }
      if (d.pendiente_id && !this.pendiente) {   // el borrador venía de una factura recurrente pendiente: se emite como tal (una sola vez)
        try { const p = await api('/api/recurrentes/pendientes/' + d.pendiente_id); if (p.estado === 'pendiente') this.pendiente = p; } catch { /* la pendiente ya no existe: se emite como factura normal */ }
      }
      toast('Borrador cargado: revise y emita cuando esté listo', 'ok');
    },
    // Con '99 Otros' Hacienda exige describir la condición (5 a 100 caracteres) o el medio de pago (3 a 100)
    validarOtros() {
      if (this.esCredito() && !(parseInt(this.f.plazo_credito, 10) >= 1)) return toast('Indique el plazo de crédito en días (un número entero mayor que cero)', 'err');
      if (this.f.condicion_venta === '99' && (this.f.condicion_venta_otros || '').trim().length < 5) return toast('Con la condición de venta «Otros» describa cuál es (mínimo 5 caracteres)', 'err');
      if (this.f.medio_pago === '99' && (this.f.medio_pago_otros || '').trim().length < 3) return toast('Con el medio de pago «Otros» describa cuál es (mínimo 3 caracteres)', 'err');
      return true;
    },
    async emitir(modo = 'emitir') {
      if (!this.f.lineas.length) return toast('Agregue al menos una línea', 'err');
      if (this.validarOtros() !== true) return;
      this.guardando = true;
      try {
        const body = this.cuerpo();
        const d = await api('/api/comprobantes', { method: 'POST', body });
        this.idem = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
        this.marcarCotizacionFacturada(d.consecutivo, d.id);
        let estadoFinal = d.estado;
        if (modo === 'emitir' && d.estado === 'firmado') {
          try {
            await api(`/api/comprobantes/${d.id}/enviar`, { method: 'POST' });
            estadoFinal = 'enviado';
            // Hacienda procesa en segundos: se consulta una vez antes de volver a la lista para avisar de inmediato si rechazó.
            await new Promise(r => setTimeout(r, 4000));
            try { const c = await api(`/api/comprobantes/${d.id}/consultar`, { method: 'POST' }); estadoFinal = c.estado; if (c.estado === 'rechazado') toast('Hacienda RECHAZÓ el comprobante: ' + (c.mensaje_hacienda || ''), 'err'); } catch {}
          } catch (e) { toast('Firmada, pero no se pudo enviar ahora a Hacienda. Queda en cola y se reintentará automáticamente; no la vuelva a emitir. Detalle: ' + e.message, 'err'); }
        }
        if (estadoFinal !== 'rechazado') toast(`Comprobante ${d.consecutivo} ${estadoFinal}`, 'ok');
        if (modo === 'imprimir') window.open(`/api/comprobantes/${d.id}/pdf`, '_blank');
        location.hash = '/ventas/facturas';
      } catch (e) { toast(e.message, 'err'); }
      this.guardando = false;
    },
    // "Convertir a factura" desde Cotizaciones: precarga cliente, moneda, líneas y notas de la cotización (guardada en el navegador).
    cargarCotizacion(id, clave = 'cotizaciones') {
      const c = (mock.get(clave, []) || []).find(x => String(x.id) === String(id));
      if (!c) return toast('No se encontró la ' + (clave === 'remisiones' ? 'remisión ' : 'cotización ') + id, 'err');
      this.cotizacion = { ...c, _clave: clave };
      if (c.exoneracion_id !== undefined) { this.f.exoneracion_id = c.exoneracion_id; this.exoAuto = false; }   // la de la cotización (null = sin exoneración)
      if (c.cliente_id) this.f.cliente_id = c.cliente_id;
      else if (c.cliente_cedula) {   // cotizaciones de ejemplo o escritas a mano: se busca el cliente por cédula
        const ced = String(c.cliente_cedula).replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        const cl = (store.clientes || []).find(x => String(x.numero_id || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase() === ced);
        if (cl) this.f.cliente_id = cl.id; else toast(`Seleccione el cliente: "${c.cliente_nombre}" no está en Contactos`, 'err');
      }
      // el tipo de cambio de la cotización solo vale en moneda extranjera; con CRC el XML lleva 1 (antes salía el del dólar) (R89)
      // solo un tipo de cambio escrito a mano en la cotización pasa a la factura; el automático de la cotización lleva margen (precios)
      if (c.moneda) { this.f.moneda = c.moneda; this.$nextTick(() => { this.f.tipo_cambio = c.moneda === 'CRC' ? 1 : (c.tipo_cambio_manual && +c.tipo_cambio > 1 ? +c.tipo_cambio : monedas.tc(c.moneda)); }); }
      if (c.vendedor) this.f.vendedor = c.vendedor;
      if (c.notas) this.f.observaciones = c.notas;
      // la validez de la cotización NO es el vencimiento de la factura: este sale de la condición y el plazo
      this.f.lineas = (c.lineas || []).map(l => ({ descuento_pct: l.descuento_pct, producto_id: l.producto_id || null, detalle: l.detalle || '', cabys: l.cabys || '', cantidad: +l.cantidad || 1, precio_unitario: l.precio_unitario ?? null, descuento: +l.descuento || 0, codigo_tarifa: l.codigo_tarifa || '08', tarifa: l.tarifa ?? 13, ...(l.exonerar === false ? { exonerar: false } : {}) }));
      toast(`Datos cargados de la cotización ${c.numero || id}: revise y emita`, 'ok');
    },
    // Al emitir desde una cotización, la cotización queda marcada como facturada con el número del comprobante.
    marcarCotizacionFacturada(consecutivo, docId) {
      if (!this.cotizacion) return;
      const clave = this.cotizacion._clave || 'cotizaciones', rows = mock.get(clave, []) || [];
      const r = rows.find(x => x.id === this.cotizacion.id);
      if (r) { r.estado = 'Facturada'; r.factura = consecutivo; r.factura_id = docId || null; mock.set(clave, rows); }   // factura_id: si Hacienda la rechaza se puede volver a convertir (R329)
    },
  },
  async created() {
    api('/api/marcas').then(l => { this.marcas = (l || []).filter(m => m.activa || m.id === this.f.marca_id); if (!this.f.marca_id && !this.params.id) { const p = this.marcas.find(m => m.id === sesion.marcaSucursal) || this.marcas.find(m => m.predeterminada); if (p) this.f.marca_id = p.id; } }).catch(() => {});   /* 3.45; 3.82: la de la sucursal */
    if (this.params.id) { try { const all = await api('/api/comprobantes'); this.doc = all.find(d => d.id == this.params.id); } catch {} if (!this.doc) this.noEncontrado = true; return; }   // (R335)
    try { this.bodegas = await api('/api/inventario/bodegas'); const bs = sesion.sucursalActual?.bodega_id; this.f.bodega_id = (bs && this.bodegas.find(b => b.id === bs && b.activa !== false)?.id) || (this.bodegas.find(b => b.principal) || this.bodegas[0])?.id || null; } catch (e) { toast(e.message, 'err'); }   /* 3.87: la bodega de la sucursal activa */
    if (this.params.cotizacion) this.cargarCotizacion(this.params.cotizacion);
    if (this.params.remision) this.cargarCotizacion(this.params.remision, 'remisiones');
    if (this.borradorId) {
      try { const b = (await api('/api/borradores')).find(x => x.id === this.borradorId); if (b) await this.cargarBorrador(b); else { this.borradorId = null; toast('Ese borrador ya no existe (se emitió o se eliminó)', 'err'); } } catch (e) { toast(e.message, 'err'); }
    }
    if (this.recurrenteId) {
      try { const r = (await api('/api/recurrentes')).find(x => x.id === this.recurrenteId); if (r) this.cargarDeRecurrente(r); else toast('No se encontró la factura recurrente', 'err'); } catch (e) { toast(e.message, 'err'); }
    }
    if (this.params.copiar && this.modoRecurrente && !this.recurrenteId) {   // Duplicar una factura recurrente (3.43): misma programación, nueva recurrencia
      try { const r = (await api('/api/recurrentes')).find(x => x.id === +this.params.copiar); if (r) { this.cargarDeRecurrente(r); this.rec.nombre = (r.nombre || '') + ' (copia)'; this.duplicadoDe = r.nombre || ('recurrencia #' + r.id); } else toast('No se encontró la factura recurrente a duplicar', 'err'); } catch (e) { toast(e.message, 'err'); }
    }
    if (this.params.duplicar && !this.modoRecurrente) {                       // Duplicar una factura emitida (3.43): nueva factura con las mismas líneas
      try { const d = await api('/api/comprobantes/' + this.params.duplicar); this.cargarDeDocumento(d); } catch (e) { toast('No se pudo cargar el comprobante a duplicar: ' + e.message, 'err'); }
    }
    if (this.params.pendiente) {
      try {
        const p = await api('/api/recurrentes/pendientes/' + this.params.pendiente);
        if (p.estado !== 'pendiente') toast('Esta factura pendiente ya fue ' + p.estado, 'err');
        else { this.pendiente = p; if (p.recurrente) this.cargarDeRecurrente(p.recurrente); this.venceManual = true; this.f.vence = p.fecha_programada >= hoy() ? p.fecha_programada : hoy(); const dv = this.diasVence(); if (dv > 0) { const d = new Date(this.f.vence + 'T00:00:00'); d.setDate(d.getDate() + dv); this.f.vence = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); } }
      } catch (e) { toast(e.message, 'err'); }
    }
  },
  template: `
  <div class="page">
    <div class="card" v-if="noEncontrado"><Empty icon="⚠" title="Comprobante no encontrado" text="El comprobante que busca no existe o pertenece a otra empresa."><a class="btn" href="#/ventas/facturas">Ir a facturas de venta</a></Empty></div>
    <template v-else-if="doc">
      <PageHead :title="CAT.tipoDoc[doc.tipo_documento] + ' ' + doc.consecutivo" :crumbs="[{label:'Facturas de venta',to:'/ventas/facturas'},{label:doc.consecutivo}]">
        <a class="btn sec" :href="'/api/comprobantes/'+doc.id+'/pdf'" target="_blank">Ver PDF</a><a class="btn sec" :href="'/api/comprobantes/'+doc.id+'/xml'" target="_blank">XML</a>
        <a class="btn" v-if="doc.estado==='aceptado' && ['01','04','09'].includes(doc.tipo_documento) && puede('facturar')" :href="'#/ventas/notas-credito/nueva?factura=' + doc.id" title="Anular o corregir este comprobante con una nota de crédito">Nota de crédito</a>
      </PageHead>
      <div class="dash" style="margin-bottom:14px">
        <div class="kpi w3" v-if="doc.marca_id && marcas.length"><div class="t">Marca</div><div class="v" style="font-size:16px">{{(marcas.find(m => m.id === doc.marca_id) || {}).nombre || '—'}}</div></div>
        <div class="kpi w3"><div class="t">Valor total</div><div class="v">{{money(doc.total, doc.moneda)}}</div></div>
        <div class="kpi w3"><div class="t">{{doc.otros_impuestos ? 'IVA' : 'Impuestos'}}</div><div class="v">{{money(doc.impuesto, doc.moneda)}}</div></div>
        <div class="kpi w3" v-if="doc.otros_impuestos"><div class="t">Otros impuestos</div><div class="v">{{money(doc.otros_impuestos, doc.moneda)}}</div></div>
        <div class="kpi w3"><div class="t">Total cobrado</div><div class="v">{{money(doc.pagado || 0, doc.moneda)}}</div></div>
        <div class="kpi w3" v-if="(doc.acreditado||0) > 0.005"><div class="t">Notas de crédito</div><div class="v">{{money(doc.acreditado, doc.moneda)}}</div></div>
        <div class="kpi w3"><div class="t">Por cobrar</div><div class="v" :style="{color: (doc.total - (doc.pagado||0) - (doc.acreditado||0)) > 0.005 ? 'var(--danger)' : 'var(--ok, #059669)'}">{{money(Math.max(0, doc.total - (doc.pagado || 0) - (doc.acreditado || 0)), doc.moneda)}}</div></div>
      </div>
      <div class="card">
        <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:8px"><h2 style="margin:0">Información de emisión D.G.T. <Badge :value="doc.estado"></Badge><span class="small muted" v-if="doc.ambiente==='sandbox'"> · ambiente de pruebas</span></h2></div>
        <div class="grid">
          <div><div class="small muted">Cliente</div><b>{{doc.receptor_nombre||'—'}}</b></div>
          <div><div class="small muted">Fecha de emisión</div><b>{{fechaHora(doc.fecha_emision)}}</b></div>
          <div><div class="small muted">Vencimiento</div><b>{{doc.fecha_vencimiento ? fecha(doc.fecha_vencimiento) : '—'}}</b></div>
          <div><div class="small muted">Versión D.G.T.</div><b>4.4</b></div>
          <div style="grid-column:1/-1"><div class="small muted">Clave de comprobante</div><span class="mono">{{doc.clave}}</span></div>
          <div style="grid-column:1/-1" v-if="doc.mensaje_hacienda"><div class="small muted">Respuesta D.G.T.</div><div style="white-space:pre-wrap">{{doc.mensaje_hacienda}}</div></div>
        </div>
        <div class="row" style="gap:8px;margin-top:10px;flex-wrap:wrap">
          <a class="btn sec sm" :href="'/api/comprobantes/'+doc.id+'/xml'" target="_blank">⎘ XML del comprobante</a>
          <a class="btn sec sm" v-if="doc.respuesta_nombre" :href="'/api/comprobantes/'+doc.id+'/respuesta'" target="_blank">✔ Respuesta de Hacienda</a>
          <a class="btn sec sm" :href="'/api/comprobantes/'+doc.id+'/pdf'" target="_blank">⎙ Abrir PDF</a>
        </div>
      </div>
      <div class="card pad0" style="overflow:hidden"><iframe :src="'/api/comprobantes/'+doc.id+'/pdf#toolbar=0&view=FitH'" title="Vista previa del comprobante" style="width:100%;height:80vh;border:0;background:#fff"></iframe></div>
      <Comments></Comments>
    </template>
    <template v-else>
      <PageHead :title="modoRecurrente ? (recurrenteId ? 'Editar factura recurrente' : 'Nueva factura recurrente') : pendiente ? 'Factura recurrente pendiente de emitir' : (f.tipo_documento==='04' ? 'Nuevo tiquete electrónico' : f.tipo_documento==='09' ? 'Nueva factura de exportación' : 'Nueva factura de venta')" :crumbs="modoRecurrente || pendiente ? [{label:'Facturas recurrentes',to:'/ventas/recurrentes'},{label: modoRecurrente ? (recurrenteId ? 'Editar' : 'Nueva') : 'Emitir'}] : [{label:'Facturas de venta',to:'/ventas/facturas'},{label:'Nueva'}]">
        <span class="badge primary">Versión 4.4</span>
        <button class="btn ghost" @click="ajustes=true">Más ajustes</button>
      </PageHead>
      <div class="alert info" v-if="duplicadoDe" style="margin-bottom:12px">Copia de <b>{{duplicadoDe}}</b>: revise cliente, líneas y precios. Se emite como un comprobante nuevo al pulsar Emitir.</div>
      <div class="alert warn" v-if="!e">Configure primero los datos de la empresa emisora en <a href="#/configuracion/empresa">Configuración › Empresa</a>.</div>
      <div class="alert warn" v-if="clienteSinId">El cliente elegido no tiene identificación y Hacienda la exige en este comprobante. <a href="javascript:void 0" @click="f.tipo_documento = '04'">Emitir tiquete electrónico</a> · <a :href="'#/contactos/' + f.cliente_id">Agregarle la identificación</a></div>
      <div class="alert info" v-if="pendiente">Generada por la recurrencia <b>{{pendiente.recurrente?.nombre || ('#' + pendiente.recurrente_id)}}</b> para el <b>{{fecha(pendiente.fecha_programada)}}</b>. Revise los datos y emítala; si no corresponde, vuelva a <a href="#/ventas/recurrentes">Facturas recurrentes</a> para cambiar la fecha u omitirla.</div>
      <div class="card" v-if="modoRecurrente">
        <h2>Recurrencia</h2>
        <div class="grid">
          <Field label="Nombre" help="Para reconocerla en la lista"><input v-model="rec.nombre" placeholder="Soporte mensual Hotel Playa Serena"></Field>
          <Field label="Periodicidad" req><select v-model="rec.periodicidad" @change="if (rec.periodicidad === 'quincenal') { rec.quincena15 = false; rec.dia_emision = 15; rec.dia_emision2 = 31; }"><option v-for="(n,k) in PERIODOS" :key="k" :value="k">{{n}}</option></select></Field>
          <Field label="Fecha de inicio" req><input type="date" v-model="rec.inicio"></Field>
          <Field label="Fecha de fin" help="Vacío = indefinida"><input type="date" v-model="rec.fin"></Field>
          <Field label="Mes de emisión" help="Mes del año en que se genera" v-if="rec.periodicidad === 'anual'"><select v-model.number="rec.mes_emision"><option v-for="(m, i) in MESES" :key="i" :value="i + 1">{{m}}</option></select></Field>
          <Field label="Mes de la primera emisión" :help="'Luego cada ' + ({bimensual: 2, trimestral: 3, semestral: 6})[rec.periodicidad] + ' meses'" v-if="['bimensual','trimestral','semestral'].includes(rec.periodicidad)"><select v-model.number="rec.mes_emision"><option v-for="(m, i) in MESES" :key="i" :value="i + 1">{{m}}</option></select></Field>
          <Field label="Día de emisión" help="Día del mes (31 = último día del mes)" v-if="!['diaria','semanal','quincenal'].includes(rec.periodicidad)"><input type="number" min="1" max="31" v-model.number="rec.dia_emision"></Field>
          <Field label="Día de la semana" v-if="rec.periodicidad === 'semanal'"><select v-model.number="rec.dia_semana"><option v-for="(d, i) in DIAS_SEMANA" :key="i" :value="i">{{d}}</option></select></Field>
          <Field label="Días del mes" help="31 = último día del mes" v-if="rec.periodicidad === 'quincenal' && !rec.quincena15"><div class="row" style="gap:6px;flex-wrap:nowrap"><input type="number" min="1" max="31" v-model.number="rec.dia_emision" style="width:50%"><span class="muted">y</span><input type="number" min="1" max="31" v-model.number="rec.dia_emision2" style="width:50%"></div></Field>
          <Field label="Quincenal" v-if="rec.periodicidad === 'quincenal' && rec.quincena15" help="Esta recurrencia se genera cada 15 días"><button type="button" class="btn sec sm" @click="rec.quincena15 = false; rec.dia_emision = 15; rec.dia_emision2 = 31">Cambiar a dos días fijos del mes</button></Field>
          <Field label="Estado"><select v-model="rec.activa"><option :value="true">Activa</option><option :value="false">Pausada</option></select></Field>
        </div>
        <div class="alert info" style="margin:10px 0 0" v-if="calendario && calendario.fechas.length">Próximas emisiones: <b>{{calendario.fechas.map(x => fecha(x)).join(' · ')}}</b> · {{diasVence() ? 'cada una vence ' + diasVence() + ' día' + (diasVence() === 1 ? '' : 's') + ' después' : 'vencen el mismo día'}}<span v-if="calendario.atrasadas"> · {{calendario.atrasadas === 1 ? 'la primera ya pasó y se genera' : 'las ' + calendario.atrasadas + ' primeras ya pasaron y se generan'}} al guardar</span></div>
        <div class="alert warn" style="margin:10px 0 0" v-else-if="calendario">Con estas fechas no se genera ninguna factura (la fecha de fin queda antes de la primera emisión).</div>
        <p class="small muted" style="margin:8px 0 0">En cada fecha programada el sistema genera la factura y la deja <b>pendiente de emitir</b>: usted la revisa, la aprueba (se emite a Hacienda) o le cambia la fecha.</p>
      </div>
      <div class="card">
        <div class="row" style="justify-content:space-between;align-items:flex-start;margin-bottom:16px">
          <div><div style="font-size:16px;font-weight:650">{{marcaNombre}}</div><div class="small muted">{{marcaSel ? (e?.nombre || '') + ' · ' : ''}}{{CAT.tipoId[e?.tipo_id]||''}}: {{e?.numero_id}} · Actividad {{e?.actividad}} · {{e?.correo}}<a class="link" v-if="marcas.length" href="javascript:void 0" @click="ajustes=true" style="margin-left:6px">Cambiar marca</a></div></div>
          <div style="text-align:right"><div class="small muted">Numeración</div><select class="inp"><option>{{sucursalEmite}} electrónica</option></select><div class="small muted" style="margin-top:4px">No. <span class="mono">{{numero}}</span> · Sucursal {{codSuc}} · Punto de venta {{String(e?.terminal||1).padStart(5,'0')}}</div></div>
        </div>
        <h2>Ajustes</h2>
        <div class="grid">
          <Field label="Tipo de documento" req><select v-model="f.tipo_documento"><option value="01">Factura electrónica</option><option value="04">Tiquete electrónico</option><option value="09" v-if="!modoRecurrente">Factura de exportación</option></select></Field>
          <Field label="Actividad económica" req :help="actividades.length > 1 ? 'La principal o una secundaria registrada en Hacienda' : ''"><select v-if="actividades.length > 1" v-model="f.actividad_emisor"><option v-for="a in actividades" :key="a" :value="a === e?.actividad ? null : a">{{a}}{{a === e?.actividad ? ' (principal)' : ''}}</option></select><input v-else :value="e?.actividad" disabled></Field>
          <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :value="m.value">{{m.label}}</option></select></Field>
          <Field label="Tipo de cambio" req v-if="f.moneda !== 'CRC'" :help="'Colones por 1 ' + f.moneda + (ayudaTC ? ' · ' + ayudaTC : '')"><input type="number" step="0.01" min="0" v-model.number="f.tipo_cambio" class="mono"></Field>
          <Field label="Bodega" help="De donde se descuentan las existencias"><Buscador v-model="f.bodega_id" :opciones="bodegas" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
        </div>
        <h2 style="margin-top:18px">Información de la factura</h2>
        <div class="grid">
          <Field label="Cliente" :req="f.tipo_documento!=='04'" :help="f.tipo_documento==='09' ? 'Cliente del exterior: identificación tipo Extranjero (05); su dirección se imprime como señas en el extranjero' : ''"><Buscador v-model="f.cliente_id" :opciones="store.clientes.filter(c=>c.activo!==false && c.tipo!=='Proveedor')" detalle="numero_id" :vacio="f.tipo_documento==='04'?'Sin receptor':'Seleccionar'" agregar="cliente"></Buscador></Field>
          <Field label="Fecha de creación" v-if="!modoRecurrente"><input type="date" :value="f.fecha" disabled></Field>
          <Field label="Fecha de creación" v-else help="Cada factura lleva la fecha en que se genera"><input value="La de cada emisión" disabled></Field>
          <Field label="Fecha de vencimiento" v-if="!modoRecurrente" :help="esCredito() && !venceManual ? 'Fecha + plazo de crédito' : ''"><input type="date" v-model="f.vence" @input="venceManual = true"></Field>
          <Field label="Vence a los (días)" v-else-if="esCredito()" help="A crédito vence según el plazo de crédito, contado desde cada emisión"><input :value="(parseInt(f.plazo_credito, 10) || 0) + ' días después de cada emisión'" disabled></Field>
          <Field label="Vence a los (días)" v-else help="Días después de cada emisión (0 = el mismo día)"><input type="number" min="0" max="365" v-model.number="rec.dias_vencimiento"></Field>
          <Field label="Condición" req><select v-model="f.condicion_venta"><option v-for="o in CAT.condicionVentaDe(f.tipo_documento)" :key="o.value" :value="o.value">{{o.label}}</option></select></Field>
          <Field label="¿Cuál condición?" req v-if="f.condicion_venta==='99'" help="Hacienda exige describirla (5 a 100 caracteres)"><input v-model="f.condicion_venta_otros" maxlength="100"></Field>
          <Field label="Plazo de crédito (días)" req v-if="esCredito()" help="Obligatorio en toda venta a crédito (también Estado a crédito e IVA diferido)"><input type="number" min="1" v-model.number="f.plazo_credito"></Field>
          <Field label="Medio de pago" req><select v-model="f.medio_pago"><option v-for="o in opts(CAT.medioPago)" :value="o.value">{{o.label}}</option></select></Field>
          <Field label="¿Cuál medio de pago?" req v-if="f.medio_pago==='99'" help="Hacienda exige describirlo (3 a 100 caracteres)"><input v-model="f.medio_pago_otros" maxlength="100"></Field>
        </div>
      </div>
      <div class="card" v-if="f.cliente_id && f.tipo_documento !== '09' && (exos.length || puede('facturar') || puede('catalogos'))">
        <h2>Exoneración del cliente <small>Se aplica a las líneas gravadas con CABYS autorizado; Hacienda verifica número, fecha y tarifa</small></h2>
        <div class="grid cols-2">
          <p class="small muted" v-if="!exos.length && !exosCargando" style="margin:0;align-self:center">El cliente no tiene exoneraciones vigentes. Si presenta una, cárguela con su PDF o número.</p>
          <Field v-else label="Documento de exoneración"><select v-model="f.exoneracion_id" @change="exoAuto = false"><option :value="null">— No aplicar exoneración —</option><option v-for="x in exos" :key="x.id" :value="x.id">{{exoEtiqueta(x)}}</option></select></Field>
          <div class="small muted" v-if="exoSel" style="align-self:center">{{exoSel.tipo}} · {{exoSel.tipo_nombre}}<br>{{exoSel.institucion_nombre}}<span v-if="exoSel.estado==='por_vencer'"> · <b>vence pronto</b></span><span v-if="exoSel.tiene_pdf"> · <a class="link" style="cursor:pointer" @click="verPdfExo(exoSel)">ver PDF</a></span></div>
        </div>
        <div class="alert info" v-if="exoSinLineas && exoAuto" style="margin:10px 0 0">Esta exoneración no aplica a ninguna de las líneas (CABYS no autorizados o sin IVA): el comprobante se emitirá sin exoneración.</div>
        <div class="alert warn" v-else-if="exoSinLineas" style="margin:10px 0 0">Ninguna línea queda exonerada (sus CABYS no están autorizados o no llevan IVA). Quite la exoneración o revise los ítems: así no se puede emitir.</div>
        <div class="row" style="margin-top:8px" v-if="puede('facturar') || puede('catalogos')"><button class="btn sec sm" @click="exoNueva = true">+ Exoneración (PDF o número)</button></div>
        <ExoneracionRapida v-if="exoNueva" :cliente-id="f.cliente_id" :numero-id="numeroCliente" @close="exoNueva = false" @registrada="exoRegistrada"></ExoneracionRapida>
      </div>
      <div class="card"><h2>Ítems</h2><LineEditor v-model="f.lineas" :productos="store.productos.filter(p=>p.activo!==false&&p.es_venta!==false)" :moneda="f.moneda" :cliente-id="f.cliente_id" :exoneracion="exoSel"></LineEditor>
        <p class="small muted" style="margin:10px 0 0" v-if="disponibles.length">Existencias en la bodega seleccionada:
          <span v-for="(d,i) in disponibles" :key="d.id"><span :style="d.falta?'color:var(--danger);font-weight:600':''">{{d.nombre}}: {{fmt(d.disponible,0)}}</span><span v-if="i<disponibles.length-1"> · </span></span>
        </p>
      </div>
      <div class="card"><div class="grid cols-2">
        <Field label="Notas" help="Visibles en el PDF (campo OtroTexto del XML)"><textarea rows="3" v-model="f.observaciones" placeholder="Agrega comentarios para aclarar datos de la factura"></textarea></Field>
        <Field label="Términos y condiciones"><textarea rows="3" v-model="f.terminos" placeholder="Cuentas bancarias, condiciones de pago…"></textarea></Field>
      </div>
      <p class="small muted" style="margin:12px 0 0">Autorizada mediante resolución MH-DGT-RES-0027-2024 del 13 de noviembre del 2024 (Alcance N°186 a La Gaceta N°217 del 19/11/2024).</p></div>
      <div class="row end" style="margin-bottom:18px" v-if="modoRecurrente">
        <a class="btn ghost" href="#/ventas/recurrentes">Cancelar</a>
        <button class="btn" @click="guardarRecurrente" :disabled="guardando">{{guardando?'Guardando…':'Guardar factura recurrente'}}</button>
      </div>
      <div class="row end" style="margin-bottom:18px" v-else>
        <button class="btn ghost" @click="guardarBorrador" :disabled="guardando" title="Se guarda como borrador: sin número, sin firma y sin enviar a Hacienda">Guardar borrador</button>
        <button class="btn sec" @click="emitir('imprimir')" :disabled="guardando">Emitir e imprimir</button>
        <button class="btn" @click="emitir('emitir')" :disabled="guardando">{{guardando?'Procesando…':'Emitir'}}</button>
      </div>
      <Comments :saved="false"></Comments>
      <Drawer v-if="ajustes" title="Más ajustes" @close="ajustes=false">
        <h2 style="font-size:14px">Parámetros adicionales</h2>
        <div class="grid" style="grid-template-columns:1fr">
          <Field label="Bodega"><Buscador v-model="f.bodega_id" :opciones="bodegas" :detalle="b => b.principal ? 'principal' : ''" agregar="bodega"></Buscador></Field>
          <Field label="Vendedor"><Buscador v-model="f.vendedor" catalogo="vendedores" valor="nombre" placeholder="Sin vendedor" agregar="vendedor"></Buscador></Field>
          <Field label="Moneda"><select v-model="f.moneda"><option v-for="m in monedasOpc" :value="m.value">{{m.label}}</option></select></Field>
          <Field label="Tipo de cambio" req v-if="f.moneda !== 'CRC'" :help="'Colones por 1 ' + f.moneda + (ayudaTC ? ' · ' + ayudaTC : '')"><input type="number" step="0.01" min="0" v-model.number="f.tipo_cambio" class="mono"></Field>
          <Field label="Orden de compra"><input v-model="f.orden_compra" placeholder="Ingrese el número de orden"></Field>
          <Field label="Marca" v-if="marcas.length" help="Logo y nombre comercial con que sale este comprobante; la cédula es siempre la de la empresa"><select v-model.number="f.marca_id"><option :value="null">Empresa ({{e?.nombre_comercial || e?.nombre}})</option><option v-for="m in marcas" :key="m.id" :value="m.id">{{m.nombre}}{{m.predeterminada ? ' · predeterminada' : ''}}</option></select></Field>
        </div>
        <h2 style="font-size:14px;margin-top:18px">Detalles en ventas</h2>
        <div class="row" style="flex-direction:column;align-items:flex-start"><Toggle label="Retenciones" :model-value="false"></Toggle><Toggle label="Otros cargos" :model-value="false"></Toggle></div>
        <h2 style="font-size:14px;margin-top:18px">Plantilla de impresión</h2>
        <select class="inp"><option>Factura de venta estándar</option></select>
        <template #foot><button class="btn ghost" @click="ajustes=false">Cancelar</button><button class="btn" @click="ajustes=false">Guardar</button></template>
      </Drawer>
    </template>
  </div>`,
};
