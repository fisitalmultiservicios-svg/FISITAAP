"""Respaldo automático de data/ (bases SQLite, XML emitidos y recibidos, llaves cifradas, logos, claves del servidor).

- Copia consistente de cada base con la API de respaldo de SQLite (sirve con WAL y con la app en uso).
- ZIP en FE_RESPALDOS_DIR (por defecto <carpeta de la app>/respaldos, fuera de data/ y de public_html); conserva los últimos
  FE_RESPALDOS_CONSERVAR (14). Lo ejecuta la cola una vez al día y el administrador del sistema cuando quiera.
- El ZIP incluye secret.key y, SOLO si existe en disco, data/master.key (con FE_MASTER_KEY en el entorno no hay archivo y la
  restauración necesita esa misma variable). Debe guardarse con el mismo cuidado que la carpeta data (R168).
"""
import os
import sqlite3
import tempfile
import re
import zipfile
from datetime import datetime
from pathlib import Path

from .config import DATA_DIR, ahora_cr

RESPALDOS_DIR = Path(os.environ.get("FE_RESPALDOS_DIR") or (DATA_DIR.parent / "respaldos"))
CONSERVAR = int(os.environ.get("FE_RESPALDOS_CONSERVAR", "14"))
MARCA = DATA_DIR / "respaldo.ultimo"
CARPETAS = ("xml", "recibidos", "certs", "img", "empresas", "exoneraciones")           # empresas: solo archivos que no sean .db (los .db van por backup API)
ARCHIVOS = ("logo.png", "master.key", "secret.key", "tipo_cambio.json", "estado_hacienda.json", "sitio.json")
PATRONES = ("logo_empresa_*",)                                        # logos por empresa (R172)


def _copiar_db(origen: Path, destino: Path) -> None:
    src = sqlite3.connect(f"file:{origen}?mode=ro", uri=True, timeout=30)
    try:
        dst = sqlite3.connect(destino)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def ejecutar() -> Path:
    RESPALDOS_DIR.mkdir(parents=True, exist_ok=True)
    nombre = f"facturacr_{ahora_cr():%Y%m%d_%H%M%S}.zip"
    destino = RESPALDOS_DIR / nombre
    parcial = RESPALDOS_DIR / (nombre + ".parcial")               # se escribe aparte y se renombra al terminar (R166)
    try:
        _escribir(parcial, nombre)
    except BaseException:
        parcial.unlink(missing_ok=True)
        raise
    parcial.replace(destino)
    rotar()
    MARCA.write_text(ahora_cr().isoformat(timespec="seconds"), encoding="utf-8")
    return destino


def _escribir(destino: Path, nombre: str) -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        dbs = [DATA_DIR / "facturacr.db"] + sorted((DATA_DIR / "empresas").glob("*.db"))
        copias = []
        for db in dbs:
            if db.exists():
                rel = db.relative_to(DATA_DIR)
                (tmp / rel).parent.mkdir(parents=True, exist_ok=True)
                _copiar_db(db, tmp / rel); copias.append(rel)
        with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
            for rel in copias:
                z.write(tmp / rel, f"data/{rel.as_posix()}")
            for carpeta in CARPETAS:
                base = DATA_DIR / carpeta
                if base.is_dir():
                    for p in base.rglob("*"):
                        if p.is_file() and not p.name.endswith((".db", ".db-wal", ".db-shm")):
                            z.write(p, f"data/{p.relative_to(DATA_DIR).as_posix()}")
            for a in ARCHIVOS:
                if (DATA_DIR / a).exists():
                    z.write(DATA_DIR / a, f"data/{a}")
            for pat in PATRONES:
                for p in DATA_DIR.glob(pat):
                    if p.is_file():
                        z.write(p, f"data/{p.name}")
            con_master = (DATA_DIR / "master.key").exists()
            z.writestr("LEEME.txt", f"Respaldo FISITAAP by Brillante Agencia {nombre}\n"
                                    "Restaurar: detener la app; VACIAR la carpeta data del servidor (o al menos borrar los archivos *.db-wal, *.db-shm y las\n"
                                    "bases data/empresas/*.db que no estén en este zip); copiar el contenido de data/ de este zip; arrancar (R167).\n"
                                    + ("Incluye data/master.key: guarde este archivo con el mismo cuidado que la carpeta data.\n" if con_master else
                                       "NO incluye master.key (la clave maestra está en la variable FE_MASTER_KEY del servidor): para restaurar en otro\n"
                                       "servidor defina la MISMA variable; sin ella no se pueden leer las contraseñas ni las llaves cifradas (R168).\n"))


def rotar() -> None:
    zips = sorted(p for p in RESPALDOS_DIR.glob("facturacr_*.zip") if not p.name.endswith(".parcial"))   # solo respaldos completos (R166)
    for viejo in zips[:-CONSERVAR] if CONSERVAR > 0 else []:
        try:
            viejo.unlink()
        except OSError:
            pass


def diario() -> Path | None:
    """Un respaldo por día (lo llama la cola en cada pasada; solo actúa si hoy no se ha hecho)."""
    hoy = ahora_cr()
    try:
        # 3.87: la marca sola no basta: si la carpeta de respaldos se borró (p. ej. al reemplazar la aplicación), se rehace
        if MARCA.read_text(encoding="utf-8")[:10] == hoy.strftime("%Y-%m-%d") and any(RESPALDOS_DIR.glob(f"facturacr_{hoy:%Y%m%d}_*.zip")):
            return None
    except FileNotFoundError:
        pass
    return ejecutar()


# ----------------------------------------------------------------------------- respaldos que no mienten (3.87)
MARCA_DESCARGA = DATA_DIR / "respaldo.descargado"      # JSON {fecha, nombre, por}: último respaldo general descargado desde la consola


def _dentro(hijo: Path, padre: Path) -> bool:
    try:
        hijo.resolve().relative_to(padre.resolve())
        return True
    except (ValueError, OSError):
        return False


def ubicacion_segura() -> bool:
    """False si la carpeta de respaldos queda dentro de la carpeta de la aplicación (y fuera de data/): al reemplazar la aplicación en un
    despliegue se perderían. No se cambia el valor por defecto (movería los respaldos existentes): la consola avisa."""
    from .config import BASE_DIR
    return not _dentro(RESPALDOS_DIR, BASE_DIR) or _dentro(RESPALDOS_DIR, DATA_DIR)


def carpeta_sugerida() -> str:
    """Carpeta hermana de la aplicación (en el hosting, /home/<usuario>/respaldos)."""
    from .config import BASE_DIR
    return str(BASE_DIR.resolve().parent / "respaldos").replace("\\", "/")


def marcar_descarga(nombre: str, por: str | None = None) -> None:
    import json
    try:
        MARCA_DESCARGA.write_text(json.dumps({"fecha": ahora_cr().isoformat(timespec="seconds"), "nombre": nombre, "por": por}, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass


def ultima_descarga() -> dict | None:
    import json
    try:
        d = json.loads(MARCA_DESCARGA.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else None
    except (OSError, ValueError):
        return None


def trae_empresas(nombre: str, ids) -> bool:
    """3.87: ¿el respaldo general `nombre` trae la base de alguna de estas empresas? Lee solo el índice del zip (no lo descomprime).
    Si no existe, False (el llamador responde 404); si no se puede leer, True: no se entrega lo que no se puede revisar."""
    ids = {int(x) for x in (ids or ())}
    p = ruta_global(nombre)
    if not ids or p is None:
        return False
    try:
        with zipfile.ZipFile(p) as z:
            dentro = set(z.namelist())
    except (OSError, zipfile.BadZipFile):
        return True
    return any(f"data/empresas/empresa_{i}.db" in dentro for i in ids)


def listar() -> list[dict]:
    out = []
    for p in sorted(RESPALDOS_DIR.glob("facturacr_*.zip"), reverse=True):
        st = p.stat()
        out.append({"nombre": p.name, "bytes": st.st_size, "fecha": datetime.fromtimestamp(st.st_mtime, tz=ahora_cr().tzinfo).isoformat(timespec="seconds")})
    return out


# ----------------------------------------------------------------------------- respaldos por empresa (3.59)
# Cada empresa crea el suyo desde Configuración › Respaldos: su base, sus XML emitidos y recibidos, certificado, logo, exoneraciones
# y adjuntos. Van en RESPALDOS_DIR/empresas/<id>/empresa_<id>_<fecha>.zip; se guardan hasta MAXIMO_EMPRESA por empresa y los
# borra la propia empresa o el administrador del sistema. No incluyen secret.key ni master.key.
MAXIMO_EMPRESA = int(os.environ.get("FE_RESPALDOS_EMPRESA_MAX", "10"))
PATRON_GLOBAL = r"facturacr_\d{8}_\d{6}\.zip"
PATRON_EMPRESA = r"empresa_\d+_\d{8}_\d{6}(_\d+)?\.zip"     # _2, _3… si hay dos en el mismo segundo (3.63)
_SENSIBLE = ("clave", "pass", "token", "secret", "hash", "pin", "smtp_")


def dir_empresa(eid: int) -> Path:
    return RESPALDOS_DIR / "empresas" / str(int(eid))


def listar_empresa(eid: int) -> list[dict]:
    out = []
    for p in sorted(dir_empresa(eid).glob(f"empresa_{int(eid)}_*.zip"), reverse=True):
        st = p.stat()
        out.append({"nombre": p.name, "bytes": st.st_size, "fecha": datetime.fromtimestamp(st.st_mtime, tz=ahora_cr().tzinfo).isoformat(timespec="seconds"),
                    "origen": _origen_de(p, eid)})      # 3.81: número de la empresa en la otra instalación (None = de esta misma)
    return out


def _origen_de(ruta: Path, eid: int):
    try:
        with zipfile.ZipFile(ruta) as z:
            o = _empresa_del_zip(z.namelist())
    except (OSError, zipfile.BadZipFile):
        return None
    return o if o is not None and o != int(eid) else None


def listar_empresas() -> list[dict]:
    """Todos los respaldos creados por las empresas (para el panel del administrador del sistema)."""
    base = RESPALDOS_DIR / "empresas"
    if not base.is_dir():
        return []
    out = []
    for d in sorted(base.iterdir(), key=lambda p: int(p.name) if p.name.isdigit() else 0):
        if d.is_dir() and d.name.isdigit() and any(d.glob("empresa_*.zip")):
            out.append({"empresa_id": int(d.name), "respaldos": listar_empresa(int(d.name))})
    return out


def ruta_empresa(eid: int, nombre: str) -> Path | None:
    """Ruta del zip si el nombre es válido, pertenece a la empresa y existe; si no, None."""
    import re
    if not re.fullmatch(PATRON_EMPRESA, nombre or "") or not nombre.startswith(f"empresa_{int(eid)}_"):
        return None
    p = dir_empresa(eid) / nombre
    return p if p.is_file() else None


def ruta_global(nombre: str) -> Path | None:
    import re
    if not re.fullmatch(PATRON_GLOBAL, nombre or ""):
        return None
    p = RESPALDOS_DIR / nombre
    return p if p.is_file() else None


def eliminar(nombre: str) -> bool:
    p = ruta_global(nombre)
    if p is None:
        return False
    p.unlink()
    return True


def eliminar_empresa(eid: int, nombre: str) -> bool:
    p = ruta_empresa(eid, nombre)
    if p is None:
        return False
    p.unlink()
    return True


def _nombre_libre(carpeta: Path, eid: int) -> str:
    """empresa_<id>_<fecha>.zip; si ya existe uno de este mismo segundo (respaldo de seguridad + restauración), _2, _3…"""
    base = f"empresa_{int(eid)}_{ahora_cr():%Y%m%d_%H%M%S}"
    n, nombre = 1, base + ".zip"
    while (carpeta / nombre).exists() or (carpeta / (nombre + ".parcial")).exists():
        n += 1
        nombre = f"{base}_{n}.zip"
    return nombre


def ejecutar_empresa(empresa, forzar: bool = False) -> Path:
    """forzar: respaldo de seguridad antes de restaurar, aunque se haya llegado al tope."""
    eid = int(empresa.id)
    if not forzar and len(listar_empresa(eid)) >= MAXIMO_EMPRESA:
        raise ValueError(f"Ya tiene {MAXIMO_EMPRESA} respaldos guardados en el servidor; descargue y elimine alguno para crear otro.")
    carpeta = dir_empresa(eid)
    carpeta.mkdir(parents=True, exist_ok=True)
    nombre = _nombre_libre(carpeta, eid)
    destino = carpeta / nombre
    parcial = carpeta / (nombre + ".parcial")
    try:
        _escribir_empresa(parcial, nombre, empresa)
    except BaseException:
        parcial.unlink(missing_ok=True)
        raise
    parcial.replace(destino)
    return destino


def _nombres_xml(db: Path) -> set[str]:
    """Nombres de archivo XML referidos desde cualquier tabla de la base (columnas *xml*nombre*)."""
    nombres: set[str] = set()
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    try:
        tablas = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for t in tablas:
            cols = [r[1] for r in con.execute(f'PRAGMA table_info("{t}")')]
            for c in cols:
                if "xml" in c.lower() and "nombre" in c.lower():
                    for (v,) in con.execute(f'SELECT DISTINCT "{c}" FROM "{t}" WHERE "{c}" IS NOT NULL AND "{c}" != \'\''):
                        if isinstance(v, str) and "/" not in v and "\\" not in v:
                            nombres.add(v)
    finally:
        con.close()
    return nombres


def _escribir_empresa(destino: Path, nombre: str, empresa) -> None:
    import json
    eid = int(empresa.id)
    db = DATA_DIR / "empresas" / f"empresa_{eid}.db"
    with tempfile.TemporaryDirectory() as tmp:
        copia = Path(tmp) / f"empresa_{eid}.db"
        if db.exists():
            _copiar_db(db, copia)
        with zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as z:
            if copia.exists():
                z.write(copia, f"data/empresas/empresa_{eid}.db")
                for n in sorted(_nombres_xml(copia)):
                    for carpeta in ("xml", "recibidos"):
                        p = DATA_DIR / carpeta / n
                        if p.is_file():
                            z.write(p, f"data/{carpeta}/{n}")
            p12 = getattr(empresa, "p12_nombre", None)
            if p12 and (DATA_DIR / "certs" / p12).is_file():
                z.write(DATA_DIR / "certs" / p12, f"data/certs/{p12}")
            for p in DATA_DIR.glob(f"logo_empresa_{eid}.*"):
                if p.is_file():
                    z.write(p, f"data/{p.name}")
            for base in (DATA_DIR / "exoneraciones" / f"empresa_{eid}", DATA_DIR / "empresas" / str(eid)):
                if base.is_dir():
                    for p in base.rglob("*"):
                        if p.is_file():
                            z.write(p, f"data/{p.relative_to(DATA_DIR).as_posix()}")
            datos = {k: v for k, v in empresa.model_dump().items() if not any(s in k.lower() for s in _SENSIBLE)}
            z.writestr("empresa.json", json.dumps(datos, ensure_ascii=False, indent=1, default=str))
            z.writestr("LEEME.txt", f"Respaldo de la empresa {empresa.nombre} ({nombre}) hecho con FISITAAP by Brillante Agencia.\n"
                                    "Contiene la base de datos de la empresa, los comprobantes electrónicos emitidos y recibidos, el certificado,\n"
                                    "el logo, las exoneraciones y los adjuntos. El certificado y las contraseñas guardadas van cifrados y solo\n"
                                    "sirven dentro de FISITAAP by Brillante Agencia: para restaurar, escriba a soporte y se carga en el servidor sin tocar\n"
                                    "a las demás empresas. Guarde este archivo con el mismo cuidado que sus facturas.\n")


# ----------------------------------------------------------------------------- restaurar (3.63)
CABECERA_SQLITE = b"SQLite format 3\x00"


def _empresa_del_zip(nombres: list) -> "int | None":
    """Número de la empresa cuya base trae el zip (un solo data/empresas/empresa_N.db); None si no trae exactamente una."""
    import re
    ids = [int(m.group(1)) for n in nombres if (m := re.fullmatch(r"data/empresas/empresa_(\d+)\.db", n))]
    return ids[0] if len(ids) == 1 else None


def _comparable(v) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", str(v or "")).upper()


def _empresa_json(z, nombres) -> dict:
    import json
    if "empresa.json" not in nombres:
        return {}
    try:
        d = json.loads(z.read("empresa.json").decode("utf-8"))
        return d if isinstance(d, dict) else {}
    except (ValueError, UnicodeDecodeError, KeyError):
        return {}


def _cedula_de(eid: int) -> str:
    from sqlmodel import Session
    from .db import Empresa, engine
    with Session(engine) as sc:
        e = sc.get(Empresa, int(eid))
        return (e.numero_id or "") if e is not None else ""


def validar_zip_empresa(eid: int, ruta: Path, otra_instalacion: bool = True) -> list[str]:
    """Comprueba que el zip sea un respaldo de una empresa y no traiga rutas raras. Devuelve la lista de nombres. Desde 3.81
    acepta el de otra instalación (otro número de empresa): al restaurar se renumera a esta empresa."""
    import re
    try:
        with zipfile.ZipFile(ruta) as z:
            nombres = z.namelist()
            origen = int(eid) if f"data/empresas/empresa_{int(eid)}.db" in nombres else (_empresa_del_zip(nombres) if otra_instalacion else None)
            if origen is None:
                raise ValueError("El archivo no es un respaldo de esta empresa: no trae su base de datos")
            if origen != int(eid):                         # 3.81: de otra instalación, solo si es de la misma cédula
                datos = _empresa_json(z, nombres)
                propia = _cedula_de(eid)
                if not datos:
                    raise ValueError("El archivo no es un respaldo de esta empresa: no dice de qué empresa es")
                if _comparable(datos.get("numero_id")) != _comparable(propia):
                    raise ValueError(f"El archivo no es un respaldo de esta empresa: es de «{datos.get('nombre_comercial') or datos.get('nombre') or 'otra empresa'}» "
                                     f"(cédula {datos.get('numero_id') or 'sin cédula'}) y esta empresa tiene la cédula {propia or 'sin cédula'}")
            for n in nombres:
                partes = n.split("/")
                if n.startswith("/") or ".." in partes or "\\" in n or re.search(r"[\x00-\x1f]", n):
                    raise ValueError("El respaldo trae rutas inválidas")
            with z.open(f"data/empresas/empresa_{origen}.db") as f:
                if f.read(16) != CABECERA_SQLITE:
                    raise ValueError("La base de datos del respaldo está dañada")
            return nombres
    except zipfile.BadZipFile:
        raise ValueError("El archivo no es un zip válido")


def guardar_subido(eid: int, contenido: bytes) -> Path:
    """Deja un zip subido por el usuario en la carpeta de respaldos de la empresa (validado) y devuelve su ruta."""
    carpeta = dir_empresa(eid)
    carpeta.mkdir(parents=True, exist_ok=True)
    nombre = _nombre_libre(carpeta, eid)
    destino = carpeta / nombre
    tmp = carpeta / (nombre + ".parcial")
    tmp.write_bytes(contenido)
    try:
        validar_zip_empresa(eid, tmp)
    except ValueError:
        tmp.unlink(missing_ok=True)
        raise
    tmp.replace(destino)
    return destino


def restaurar_empresa(empresa, ruta: Path) -> dict:
    """Restaura la empresa desde el zip: respaldo de seguridad del estado actual, se suelta el motor, se reemplaza la base
    (archivo nuevo: otros procesos la detectan por el inodo) y se copian XML, certificado, logo, exoneraciones y adjuntos.
    Las contraseñas y llaves siguen cifradas con la clave de la empresa, que vive en la base central y no se toca."""
    import os
    import re
    import shutil
    eid = int(empresa.id)
    nombres = validar_zip_empresa(eid, ruta)
    origen = eid if f"data/empresas/empresa_{eid}.db" in nombres else _empresa_del_zip(nombres)
    ajeno = origen != eid                                  # 3.81: respaldo de otra instalación (otro número de empresa)
    seguridad = ejecutar_empresa(empresa, forzar=True)
    from .db import EMPRESAS_DIR, _engines
    hit = _engines.pop(eid, None)
    if hit is not None:
        hit[0].dispose()
    db_rel = f"data/empresas/empresa_{origen}.db"
    destino_db = EMPRESAS_DIR / f"empresa_{eid}.db"
    copiados = {"base": 0, "xml": 0, "recibidos": 0, "certs": 0, "logo": 0, "exoneraciones": 0, "adjuntos": 0}
    omitidos = {"certs": 0, "existentes": 0}
    logo_nuevo = None
    with zipfile.ZipFile(ruta) as z:
        tmp_db = EMPRESAS_DIR / f"empresa_{eid}.db.restaurando"
        with z.open(db_rel) as src, open(tmp_db, "wb") as dst:
            shutil.copyfileobj(src, dst)
        if ajeno:
            renumerar_base(tmp_db, origen, eid)
        cx = sqlite3.connect(str(tmp_db))                  # 3.87: sin la huella de esquema que traiga (db.huella_esquema): al abrirse se
        try:                                               # revisa y migra entera, aunque el respaldo diga que ya estaba al día
            cx.execute("PRAGMA user_version = 0")
        finally:
            cx.close()
        for suf in ("-wal", "-shm"):
            (EMPRESAS_DIR / f"empresa_{eid}.db{suf}").unlink(missing_ok=True)
        os.replace(tmp_db, destino_db)
        copiados["base"] = 1
        for n in nombres:
            if n.endswith("/") or not n.startswith("data/") or n == db_rel:
                continue
            rel = n[5:]
            if ajeno:                                      # los archivos de la empresa llevan su número: pasan al de esta
                if rel.startswith("certs/"):
                    omitidos["certs"] += 1                 # cifrado con las claves del otro servidor: se vuelve a subir aquí
                    continue
                if rel.startswith(f"exoneraciones/empresa_{origen}/"):
                    rel = f"exoneraciones/empresa_{eid}/" + rel[len(f"exoneraciones/empresa_{origen}/"):]
                elif rel.startswith(f"empresas/{origen}/"):
                    rel = f"empresas/{eid}/" + rel[len(f"empresas/{origen}/"):]
                elif re.fullmatch(rf"logo_empresa_{origen}\.\w+", rel):
                    rel = f"logo_empresa_{eid}" + rel[len(f"logo_empresa_{origen}"):]
                    logo_nuevo = rel
                elif rel.split("/")[0] in ("xml", "recibidos") and (DATA_DIR / rel).exists():
                    omitidos["existentes"] += 1            # no se pisa un comprobante que ya está en este servidor
                    continue
            top = rel.split("/")[0]
            if top in ("xml", "recibidos", "certs"):
                clave = top
            elif rel.startswith(f"exoneraciones/empresa_{eid}/"):
                clave = "exoneraciones"
            elif rel.startswith(f"empresas/{eid}/"):
                clave = "adjuntos"
            elif re.fullmatch(rf"logo_empresa_{eid}\.\w+", rel):
                clave = "logo"
            else:
                continue                                                  # nada fuera de lo que es de esta empresa
            destino = DATA_DIR / rel
            destino.parent.mkdir(parents=True, exist_ok=True)
            with z.open(n) as src, open(destino, "wb") as dst:
                shutil.copyfileobj(src, dst)
            copiados[clave] += 1
    pendiente = []
    if ajeno:
        if logo_nuevo:
            _poner_logo(eid, logo_nuevo)
        pendiente = ["Subir de nuevo la llave criptográfica (.p12) y escribir su PIN en Configuración › Facturación electrónica",
                     "Escribir otra vez el usuario y la contraseña de Hacienda y los del correo de envío",
                     "Revisar cédula, actividad, dirección, sucursal y terminal de la empresa (no viajan en el respaldo)",
                     "Crear los usuarios de la empresa y, si vende en línea, volver a subir las fotos de los productos"]
    return {"seguridad": seguridad.name, "copiados": copiados, "otra_instalacion": ajeno, "empresa_origen": origen, "omitidos": omitidos, "pendiente": pendiente}


def renumerar_base(ruta: Path, viejo: int, nuevo: int) -> int:
    """En la base de una empresa traída de otra instalación, empresa_id = viejo pasa a nuevo en todas las tablas (3.81).
    Devuelve cuántas filas cambiaron."""
    con = sqlite3.connect(str(ruta))
    try:
        total = 0
        clinica = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='clinica_paciente'").fetchone()
        if int(viejo) != int(nuevo) and clinica and con.execute("SELECT 1 FROM clinica_paciente LIMIT 1").fetchone():
            raise ValueError("Un respaldo con expedientes clínicos debe restaurarse en la misma empresa, conservando sus claves; no se puede renumerar")
        tablas = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for t in tablas:
            cols = [r[1] for r in con.execute(f'PRAGMA table_info("{t}")')]
            if "empresa_id" in cols:
                total += con.execute(f'UPDATE "{t}" SET empresa_id = ? WHERE empresa_id = ?', (int(nuevo), int(viejo))).rowcount
        con.commit()
        return total
    finally:
        con.close()


def _poner_logo(eid: int, nombre: str) -> None:
    """El logo restaurado queda como logo de la empresa (vive en la base central)."""
    from sqlmodel import Session
    from .db import Empresa, engine
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
        if e is not None and e.logo_nombre != nombre:
            e.logo_nombre = nombre; sc.add(e); sc.commit()
