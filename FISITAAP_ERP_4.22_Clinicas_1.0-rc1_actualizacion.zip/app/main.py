"""API web del núcleo de facturación electrónica (FastAPI). Multicuenta: toda ruta de negocio depende de
`auth.contexto` (usuario autenticado + empresa activa con su rol) y trabaja sobre la base de datos propia de esa empresa
(`auth.sesion_empresa`). Los secretos (PIN, ATV, SMTP, .p12) se guardan cifrados con la clave de cada empresa."""
import contextlib
import logging
import hmac
import base64
import json
import math
import re
import threading
import types
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Literal, Optional

import httpx
from lxml import etree
from fastapi import Cookie, Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from sqlalchemy import select as sa_select
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import text
from sqlmodel import Session, select
from sqlalchemy.exc import IntegrityError

from . import auth, cabys as cabys_local, correo, demo, exoneraciones, hotel, sitio, exportar, inventario, migracion, modulos, plantillas, recepcion, recordatorios, reportes, respaldo, resumen, rrhh, secretos, sucursales, tipo_cambio, traslados, ubicaciones, version
from . import planes
from .auth import Contexto, auditar, contexto, requiere, sesion_empresa
from .config import CRON_TOKEN, DATA_DIR, PROVEEDOR_SISTEMAS, URL_PUBLICA, ahora_cr, nombre_sistema
from .db import Cliente, Documento, DocumentoLinea, Empresa, Producto, Secuencia, engine, engine_empresa, get_session, init_db
from .fe import firma, hacienda, pdf, rep as fe_rep
from .fe.clave import generar_clave, generar_consecutivo
from .fe.modelos import (OtroCargo, Comprobante, Descuento, Identificacion, Impuesto, Linea, MedioPago, Parte,
                         Referencia, Telefono, Ubicacion)
from .fe.validador import validar
from .fe.xml_builder import a_bytes, construir_xml

import os
import time
PRODUCCION = os.getenv("FE_ENTORNO", "").lower() in ("produccion", "production", "prod")
# En producción no se publica la documentación interactiva de la API
app = FastAPI(title=f"{nombre_sistema()} – Núcleo FE v4.4", docs_url=None if PRODUCCION else "/docs", redoc_url=None if PRODUCCION else "/redoc",
              openapi_url=None if PRODUCCION else "/openapi.json")
# Código de actividad económica: CIIU 4 como lo publica Hacienda desde TRIBU-CR («6201.0») o el formato de 6 dígitos; el XML v4.4
# pide exactamente 6 caracteres (CodigoActividadEmisor / CodigoActividadReceptor) y ambos los cumplen
ACTIVIDAD_RE = r"\d{6}|\d{4}\.\d"
MAX_SUBIDA = 3 * 1024 * 1024          # 3 MB para .p12, logos e imágenes de productos


def _leer_subida(archivo: UploadFile, maximo: int = MAX_SUBIDA) -> bytes:
    datos = archivo.file.read(maximo + 1)
    if len(datos) > maximo:
        raise HTTPException(413, f"El archivo supera el tamaño máximo permitido ({maximo // (1024 * 1024)} MB)")
    return datos
app.include_router(auth.router)
app.include_router(auth.admin)
app.include_router(inventario.router)
from . import clinicas as _clinicas
app.include_router(_clinicas.router)
app.include_router(reportes.router)
app.include_router(sucursales.router)     # sucursales dentro de una empresa (3.66)
app.include_router(traslados.router)      # traslados entre empresas del grupo (3.69)
from . import sinc as _sinc, agente_local as _agente_local   # instalación local (3.12)
app.include_router(_sinc.router)
app.include_router(_agente_local.router)
app.include_router(exoneraciones.router)
from . import suscripcion as _suscripcion  # noqa: E402
app.include_router(_suscripcion.router)   # pago automático del plan con Tilopay (3.36)
from . import publicidad as _publicidad     # noqa: E402
app.include_router(_publicidad.router)    # publicidad por correo desde la consola (3.39)
from . import marcas as _marcas             # noqa: E402
from . import correo_diseno as _dz          # noqa: E402  (3.83: diseño común de los correos)
from . import asistencia as _asistencia     # noqa: E402
from . import pedidos as _pedidos           # noqa: E402
from . import entregas as _entregas         # noqa: E402
from . import promociones as _promociones   # noqa: E402
app.include_router(_promociones.router)   # cupones, puntos, tarjetas de regalo y modificadores (3.49)
app.include_router(_marcas.router)        # marcas: varios logos y nombres comerciales con una misma cédula (3.45)
app.include_router(_asistencia.router)    # marcas de asistencia de empleados con quiosco de código y clave (3.46)
app.include_router(_pedidos.router)       # FISITAAP: catálogo público y pedidos en línea (3.47)
app.include_router(_entregas.router)      # FISITAAP: zonas en el mapa, motorizados y liquidaciones (3.48)
from . import fisitaap as _fisitaap       # noqa: E402  FISITAAP embebido tal cual, en /app/fisitaap/ (3.74)
app.include_router(_fisitaap.router)
from . import compras_inventario as _compras_inv   # noqa: E402  líneas del comprobante recibido → ítems e inventario (3.75)
app.include_router(_compras_inv.router)
app.include_router(sitio.router)          # página pública en «/» y contacto (1.36)
app.include_router(demo.router)           # pruebas gratis de 30 días (1.38)
from . import sistema as _sistema  # noqa: E402
app.include_router(_sistema.router)       # nombre y lema del sistema en un solo lugar (3.51)
from . import tike as _tike  # noqa: E402
app.include_router(_tike.router)          # TiKe: tickets de soporte, portal del cliente y buzón (3.52)
from . import tike_contratos as _tikec  # noqa: E402
app.include_router(_tikec.router)         # TiKe: contratos, equipos, repuestos, facturar desde el ticket y reportes (3.53)
from . import tike_docs as _tiked  # noqa: E402
app.include_router(_tiked.router)         # TiKe: documentación del cliente (3.54)
from . import ia as _ia  # noqa: E402
app.include_router(_ia.router)            # asistente con IA (3.56)
from . import actualizacion_local as _actualizacion_local  # noqa: E402
app.include_router(_actualizacion_local.router)   # programa local Windows publicado en la nube y actualización automática del exe (3.58)
from . import avisos_dueno as _avisos_dueno  # noqa: E402
app.include_router(_avisos_dueno.router)  # 3.87: aviso de rechazos de Hacienda y cierre de caja (Z) por correo al dueño
from . import rrhh_docs as _rrhh_docs  # noqa: E402
app.include_router(_rrhh_docs.router)     # 4.22: documentos del empleado (contrato, identificación, permisos) con sus archivos
STATIC = Path(__file__).parent / "static"
XML_DIR = DATA_DIR / "xml"
CERT_DIR = DATA_DIR / "certs"
IMG_DIR = DATA_DIR / "img"
IMG_DIR.mkdir(exist_ok=True)


def _img_dir(eid: int) -> Path:
    """Carpeta de imágenes de productos de una empresa. Antes todas compartían data/img y producto_<id>.png de la empresa B
    reemplazaba la foto del producto <id> de la empresa A (los ids empiezan en 1 en cada empresa) (R43)."""
    d = IMG_DIR / f"empresa_{eid}"
    d.mkdir(exist_ok=True)
    return d


def migrar_imagenes(eid: int, s) -> int:
    """Fotos guardadas en data/img (compartida) pasan a la carpeta de la empresa que las referencia."""
    import shutil
    n = 0
    for p in s.exec(select(Producto).where(Producto.empresa_id == eid, Producto.imagen_nombre != None)).all():   # noqa: E711
        viejo, nuevo = IMG_DIR / p.imagen_nombre, _img_dir(eid) / p.imagen_nombre
        if viejo.is_file() and not nuevo.exists():
            shutil.copy2(viejo, nuevo); n += 1
    return n


# 4.7: historial de exportables. reportes_exportables lo recibe cualquier usuario con «ver»; antes de la 4.7 también se anotaban ahí las
# descargas de Recursos humanos con datos de un empleado (su ficha con nombre y cédula, su liquidación). Al arrancar, esas entradas pasan a
# rrhh_exportables, que solo se entrega con el permiso rrhh. La regla es la MISMA del navegador (esExportableRRHH en
# static/js/pages/reportes/_montos.js, que hace lo mismo al descargar algo de RRHH): archivo que empieza con «empleado_» o título que
# empieza con «Ficha del empleado» o con «Liquidación » (no la «Liquidación a proveedores» del hotel). Los listados sin nombres en el título
# (Empleados, Planilla PL-…, Aguinaldo…) se quedan, como en el navegador. La marca de hecho es el contenido: si el general ya no tiene
# ninguna, no se escribe nada (una lectura por empresa en cada arranque); así también se limpia lo que traiga un respaldo viejo restaurado
# o una pestaña que siga con la versión anterior.
EXPORTABLE_RRHH_ARCHIVO = re.compile(r"^empleado_")
EXPORTABLE_RRHH_TITULO = re.compile(r"^(Ficha del empleado|Liquidación (?!a proveedores))")
MAX_EXPORTABLES = 30                                    # como el navegador (registrarExportable): las 30 más recientes


def es_exportable_rrhh(x) -> bool:
    """4.7: ¿la entrada del historial de exportables lleva datos de un empleado? (esExportableRRHH de _montos.js)."""
    return isinstance(x, dict) and bool(EXPORTABLE_RRHH_ARCHIVO.match(str(x.get("archivo") or ""))
                                        or EXPORTABLE_RRHH_TITULO.match(str(x.get("reporte") or "")))


def mover_exportables_rrhh(s, eid: int) -> int:
    """4.7: pasa de reportes_exportables a rrhh_exportables las entradas con datos de un empleado (es_exportable_rrhh). Primero se
    escribe el de Recursos humanos (sin repetir, de la más reciente a la más vieja, 30 como máximo) y después se quita del general: si lo
    segundo falla no se pierde nada y el próximo arranque lo completa. Cada escritura va con la versión leída (si alguien guardó entre
    tanto, conflicto y se reintenta en el próximo arranque). Devuelve cuántas movió (0 = ya estaba limpio: no escribe nada)."""
    reg = modulos._registro(s, eid, "reportes_exportables")
    if reg is None:
        return 0
    version = reg.version or 0
    general = modulos.leer(s, eid, "reportes_exportables", None)
    mover = [x for x in general if es_exportable_rrhh(x)] if isinstance(general, list) else []
    if not mover:
        return 0
    reg_rrhh = modulos._registro(s, eid, "rrhh_exportables")
    version_rrhh = (reg_rrhh.version or 0) if reg_rrhh is not None else 0
    previos = modulos.leer(s, eid, "rrhh_exportables", None)
    previos = [x for x in previos if isinstance(x, dict)] if isinstance(previos, list) else []
    juntos, vistos = [], set()
    for x in sorted(mover + previos, key=lambda x: str(x.get("fecha") or ""), reverse=True):
        k = (str(x.get("archivo") or ""), str(x.get("reporte") or ""), str(x.get("fecha") or ""))
        if k not in vistos:
            vistos.add(k); juntos.append(x)
    modulos.reemplazar(s, eid, "rrhh_exportables", juntos[:MAX_EXPORTABLES], version_rrhh)
    modulos.reemplazar(s, eid, "reportes_exportables", [x for x in general if not es_exportable_rrhh(x)], version)
    logging.getLogger(__name__).info("Empresa %s: %s descargas de Recursos humanos pasaron a su propio historial de exportables", eid, len(mover))
    return len(mover)


_arrancado = False


def arranque():
    """Inicialización (idempotente): base central, migraciones y catálogo CABYS. La llama uvicorn al iniciar y
    también `passenger_wsgi.py` en cPanel, donde no se ejecutan los eventos de inicio ASGI."""
    global _arrancado
    if _arrancado:
        return
    _t0_arranque = time.time()
    from . import salud as _salud
    _salud.instalar_registro()           # 3.87: últimas advertencias del servidor en memoria para la consola (Salud del sistema)
    if PRODUCCION and not URL_PUBLICA:
        logging.getLogger(__name__).warning("FE_URL_PUBLICA no está definida: los correos no llevarán el enlace de consulta del comprobante")
    with _lock_arranque():
        init_db()
        migracion.ejecutar(CERT_DIR)
        from .db import engine_empresa as _ee
        try:
            with Session(engine) as sc:
                eids = [e.id for e in sc.exec(select(Empresa)).all()]
        except Exception as ex:  # noqa: BLE001
            eids = []; logging.getLogger(__name__).warning("Arranque: no se pudo listar empresas: %s", ex)
        for eid in eids:                  # cada empresa y cada paso por separado: un fallo no frena a las demás
            for paso in (lambda se: modulos.rellenar_condicion_venta(se, XML_DIR),     # condición de venta (REP)
                         lambda se: modulos.migrar_registros(se),                       # registros por elemento, sin duplicados
                         lambda se: modulos.rellenar_tipo_cambio(se, XML_DIR),          # consolidación CRC/USD del resumen
                         lambda se: modulos.rellenar_referencias(se, XML_DIR),          # notas de crédito → saldo de la factura (después del tipo de cambio)
                         lambda se: recepcion.rellenar_tipo_cambio(se),
                         lambda se: recepcion.rellenar_referencias(se),              # notas de proveedores → su factura
                         lambda se: modulos.corregir_unidades(se, UNIDADES_HACIENDA),   # 'g','m','d' → 'G','M','D' (R30)
                         lambda se: modulos.corregir_tipo_servicio(se),                 # servicios importados con tipo 'Producto' (R40)
                         lambda se: modulos.migrar_secuencias(se, _ambiente_de(eid)),  # secuencias por ambiente (R91)
                         lambda se: modulos.reponer_pendientes(se),                     # 'emitiendo' sin documento → 'pendiente'
                         lambda se: mover_exportables_rrhh(se, eid),                    # 4.7: lo de RRHH sale del historial general de exportables
                         lambda se: migrar_imagenes(eid, se)):                           # fotos de productos por empresa (R43)
                try:
                    with Session(_ee(eid)) as se:
                        paso(se)
                except Exception as ex:  # noqa: BLE001
                    logging.getLogger(__name__).warning("Arranque empresa %s: %s", eid, ex)
        _migraciones_unicas()
        # Catálogo CABYS: la primera vez (20 506 códigos, 20-40 s) o cuando cambió la forma de leer el Excel. En segundo plano para que
        # el primer arranque no supere el tiempo de espera del servidor web; mientras tanto la búsqueda usa la API de Hacienda.
        def _importar_cabys():
            # cerrojo propio (archivo creado en exclusiva): con varios procesos solo uno importa; un cerrojo de más de 20 min se
            # considera abandonado (el proceso murió a medias)
            cerrojo = DATA_DIR / "cabys.lock"
            try:
                if cerrojo.exists() and (datetime.now().timestamp() - cerrojo.stat().st_mtime) < 1200:
                    return
                fd = os.open(str(cerrojo), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
                os.close(fd)
            except FileExistsError:
                return
            except OSError:
                pass
            try:
                cabys_local.importar_si_cambio()
            except Exception as ex:  # noqa: BLE001  el catálogo es opcional: queda la API de Hacienda
                logging.getLogger(__name__).warning("No se pudo importar CABYS: %s", ex)
            finally:
                try:
                    cerrojo.unlink()
                except OSError:
                    pass
        if os.environ.get("FE_CABYS_SINCRONO") == "1":
            _importar_cabys()
        else:
            threading.Thread(target=_importar_cabys, name="cabys-import", daemon=True).start()
    _arrancado = True
    _salud.marcar_arranque(time.time() - _t0_arranque)   # 3.87: la consola muestra cuánto tardó
    from . import cola
    cola.iniciar_hilo()                  # reintentos periódicos mientras la app esté viva (el cron cubre el resto)
    _sinc.cargar_rangos()                # instalación local: rango de ids de cada empresa vinculada (3.13)
    _sinc.iniciar_hilo()                 # solo en la instalación local (FE_MODO_LOCAL=1): sincroniza con la nube (3.12)
    threading.Thread(target=_calentar, name="calentar-arranque", daemon=True).start()   # 3.87: la primera visita no paga lo que tarda en frío


def _migraciones_unicas() -> None:
    """4.15: el ajuste de roles del hotel (3.20) estaba en el evento de inicio, que Passenger no dispara: en cPanel nunca corrió. Corre una sola vez por
    instalación. Si falla se reintenta en el próximo arranque. Se retiraron, sin activarlas, otras dos que corrían en ese mismo evento y hoy dañarían datos reales:
    la de moneda de los ítems (3.25) pondría en dólares, sin convertir el precio, los ítems en colones de una empresa en dólares; y la del rol Avanzado (3.32)
    movería a un rol propio a quienes hoy tienen, desde hace semanas, los permisos del rol base."""
    marca = DATA_DIR / "migraciones_unicas.json"
    try:
        hechas = set(json.loads(marca.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        hechas = set()
    for nombre, paso in (("roles_hotel_3_20", auth.migrar_roles_hotel),):
        if nombre in hechas:
            continue
        try:
            with Session(engine) as sc:
                r = paso(sc)
            logging.getLogger(__name__).info("Migración %s: %s", nombre, r)
            hechas.add(nombre)
            marca.write_text(json.dumps(sorted(hechas)), encoding="utf-8")
        except Exception:  # noqa: BLE001
            logging.getLogger(__name__).exception("No se pudo aplicar la migración %s", nombre)


def _calentar():
    """3.87 (restaurante-r5): lo que la primera visita después de cada arranque pagaba en frío, en un hilo aparte: no retrasa el
    arranque ni cambia ninguna respuesta.
    - FastAPI arma la lista de rutas de cada router incluido en la primera petición que lo recorre (de 0,7 a 3 s en frío, y las
      peticiones que llegan juntas esperan ese mismo cerrojo). Una petición interna a una ruta /api que no existe los recorre todos:
      responde 404, no lee ninguna empresa ni sale a la red. Si llega una petición real mientras tanto, espera lo mismo que antes.
    - El tipo de cambio del día, si aún no se consultó hoy (la primera /api/arranque del día esperaba la respuesta de Hacienda). Usa el
      mismo interruptor que el hilo de la cola: con FE_COLA_HILO=0 (pruebas y QA aislada) no sale nada a la red."""
    import asyncio

    async def _una():
        async def recibir():
            return {"type": "http.request", "body": b"", "more_body": False}

        async def enviar(_m):
            return None
        await app({"type": "http", "asgi": {"version": "3.0"}, "http_version": "1.1", "method": "GET", "scheme": "http", "path": "/api/__calentar__",
                   "raw_path": b"/api/__calentar__", "query_string": b"", "headers": [(b"host", b"127.0.0.1")], "client": ("127.0.0.1", 0),
                   "server": ("127.0.0.1", 80), "root_path": ""}, recibir, enviar)
    try:
        asyncio.run(_una())
    except Exception as ex:  # noqa: BLE001  calentar es opcional
        logging.getLogger(__name__).warning("No se pudieron preparar las rutas al arrancar: %s", ex)
    if os.environ.get("FE_COLA_HILO", "1") != "0":
        try:
            tipo_cambio.obtener()
        except Exception as ex:  # noqa: BLE001
            logging.getLogger(__name__).warning("No se pudo consultar el tipo de cambio al arrancar: %s", ex)


@contextlib.contextmanager
def _lock_arranque():
    """Serializa el arranque entre los procesos de Passenger (todos ejecutan arranque() tras el fork): el segundo
    entra cuando el primero terminó de crear tablas/columnas. La importación CABYS corre después en un hilo con su propio
    cerrojo (data/cabys.lock). En Windows (desarrollo) no bloquea."""
    f = open(DATA_DIR / "arranque.lock", "w")
    try:
        try:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX)
        except ImportError:
            pass
        yield
    finally:
        f.close()


@app.on_event("startup")
def _startup():
    arranque()


# ---------------------------------------------------------------- empresa (perfil de la cuenta)
def _empresa_dict(e: Empresa, tecnicos: bool = True) -> dict:
    """Ficha de la empresa sin secretos: la clave de cifrado nunca sale, y el usuario de Hacienda y los servidores de
    correo solo para quien puede configurar (los demás roles ven '***' si existen) (R286)."""
    d = e.model_dump(exclude={"clave_cifrada"})
    for k in ("password_hacienda", "p12_pin", "smtp_password", "imap_password", "rrhh_smtp_password"):
        d[k] = "***" if getattr(e, k) else None
    if not tecnicos:
        for k in ("usuario_hacienda", "smtp_host", "smtp_usuario", "imap_host", "imap_usuario", "rrhh_smtp_host", "rrhh_smtp_usuario"):
            d[k] = "***" if getattr(e, k, None) else None
    return d


@app.get("/api/empresa")
def get_empresa(ctx: Contexto = Depends(contexto)):
    return {**_empresa_dict(ctx.empresa, ctx.puede("configurar")), "rol": ctx.rol}


def telefono_valido(v) -> bool:
    """Teléfono del emisor o receptor: 8 dígitos o un número especial de 3 dígitos (Anexos 4.4, rev. 22/04/2026: «excepto…
    número telefónico especial, por ejemplo, el 911»)."""
    try:
        n = int(v)
    except (TypeError, ValueError):
        return False
    return 100 <= n <= 999 or 10000000 <= n <= 99999999


class EmpresaIn(BaseModel):
    nombre: str; nombre_comercial: Optional[str] = None; tipo_id: str = "02"; numero_id: str; actividad: str
    provincia: int = 1; canton: int = 1; distrito: int = 1; barrio: Optional[str] = None; otras_senas: str
    telefono: Optional[int] = Field(None, ge=100, le=99999999)   # 8 dígitos sin 506 ni guiones, o especial de 3 (911) (3.41)

    @field_validator("telefono")
    @classmethod
    def _telefono_cr(cls, v):
        if v is not None and not telefono_valido(v):
            raise ValueError("El teléfono debe tener 8 dígitos (o ser un número especial de 3, como 911), sin guiones ni el 506")
        return v
    correo: str
    margen_cambiario: float = Field(5.0, ge=0, le=100)
    sucursal: int = Field(1, ge=1, le=999); terminal: int = Field(1, ge=1, le=99999)   # 3 y 5 dígitos del consecutivo
    proveedor_sistemas: Optional[str] = None; ambiente: Literal["sandbox", "produccion"] = "sandbox"
    usuario_hacienda: Optional[str] = None; password_hacienda: Optional[str] = None
    smtp_host: Optional[str] = None; smtp_puerto: Optional[int] = 465; smtp_usuario: Optional[str] = None
    smtp_password: Optional[str] = None; smtp_remitente: Optional[str] = None
    smtp_seguridad: Literal["ssl", "starttls", "ninguna"] = "ssl"; smtp_nombre: Optional[str] = None; smtp_copia: Optional[str] = None
    correo_automatico: bool = True
    actividad_nombre: Optional[str] = None
    sitio_web: Optional[str] = None
    registro_fiscal_8707: Optional[str] = Field(None, max_length=12)   # bebidas alcohólicas (Ley 8707): va en el Emisor del XML
    factura_electronica: bool = True                                   # 3.61: apagado = comprobantes internos, sin Hacienda
    confirma_sin_fe: bool = False                                      # 4.21: la persona confirmó que como «No contribuyente» queda sin facturación electrónica


@app.put("/api/empresa")
def put_empresa(data: EmpresaIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    # 4.21: los largos mínimos son reglas de Hacienda para el emisor de un comprobante electrónico; sin facturación electrónica (o como
    # «No contribuyente») basta lo que necesita el comprobante interno: una empresa llamada «Soda» no podía guardar sus datos
    if data.tipo_id == "06" and getattr(ctx.empresa, "factura_electronica", True) is not False and not data.confirma_sin_fe:
        # pasar a «No contribuyente» apaga la facturación electrónica: nunca en silencio (un contribuyente que elige mal el tipo, o una pestaña
        # de otra pantalla que manda toda la empresa, dejaría de reportar sus ventas a Hacienda sin saberlo)
        raise HTTPException(409, "Una empresa «No contribuyente» no emite comprobantes electrónicos. Para guardarla así, hágalo desde Configuración › Empresa "
                                 "y confirme que queda sin facturación electrónica (comprobantes internos, sin Hacienda)")
    sin_hacienda = getattr(data, "factura_electronica", True) is False or data.tipo_id == "06"
    _validar_texto_hacienda(data.nombre, "El nombre de la empresa", 3 if sin_hacienda else 5, 100, True)
    _validar_texto_hacienda(data.nombre_comercial, "El nombre comercial", 1 if sin_hacienda else 3, 80)
    _validar_texto_hacienda(data.barrio, "El barrio", 1 if sin_hacienda else 5, 50)
    fe = getattr(data, "factura_electronica", True) is not False      # 3.94: sin facturación electrónica no se exigen los datos de Hacienda
    if data.tipo_id == "06":          # 4.21: un «No contribuyente» no emite comprobantes electrónicos: queda con comprobantes internos y no se
        fe = False                    # le exigen actividad económica ni dirección (antes no podía guardar sus datos: pedía la actividad)
        data.factura_electronica = False
    _validar_texto_hacienda(data.otras_senas, "Las otras señas", 5 if fe else 1, 250, fe)   # 4.21: sin facturación electrónica, lo que la persona escriba
    if (fe or (data.actividad or "").strip()) and not re.fullmatch(ACTIVIDAD_RE, (data.actividad or "").strip()):   # 3.94: opcional sin FE (si se escribe, se valida)
        raise HTTPException(400, "La actividad económica debe ser el código de Hacienda: 4 dígitos, punto y 1 dígito (p. ej. 6201.0) o 6 dígitos")
    data.actividad = (data.actividad or "").strip()
    if data.tipo_id == "06":          # 4.21: la identificación de un «No contribuyente» no tiene formato oficial (el número de sus comprobantes
        n06 = re.sub(r"[^A-Za-z0-9]", "", data.numero_id or "").upper()        # internos usa un relleno propio si no mide de 9 a 12)
        if not 1 <= len(n06) <= 20:
            raise HTTPException(400, "La identificación de la empresa debe tener de 1 a 20 letras o dígitos, sin guiones ni espacios")
        data.numero_id = n06
    else:
        data.numero_id = _normalizar_identificacion(data.tipo_id, data.numero_id)
    if not ubicaciones.existe(data.provincia, data.canton, data.distrito):          # igual que con los clientes (R247)
        raise HTTPException(400, "La ubicación de la empresa (provincia, cantón y distrito) no existe en el catálogo de Hacienda")
    e = s.get(Empresa, ctx.empresa.id)
    antes_fe = getattr(e, "factura_electronica", True) is not False
    apagada_sola = data.tipo_id == "06" and antes_fe     # 4.21: se avisa en pantalla y se audita
    if e.es_demo and fe and ((data.usuario_hacienda or "").strip() or (data.password_hacienda or "").strip() not in ("", "***") or data.ambiente == "produccion"):
        # 4.5: solo con la facturación electrónica encendida; apagarla nunca choca con esta regla (antes una demo en «producción» no se podía apagar)
        raise HTTPException(400, "La empresa demo no se conecta a Hacienda: configure la conexión en su propia empresa")
    secretos.asegurar_clave(e)
    usuario = (data.usuario_hacienda or "").strip().lower() or None
    # El usuario de API de Hacienda lleva el ambiente en el dominio: @stag = pruebas, @prod = producción.
    if usuario and "comprobanteselectronicos.go.cr" in usuario:
        es_prod = usuario.endswith("@prod.comprobanteselectronicos.go.cr")
        if es_prod != (data.ambiente == "produccion"):
            raise HTTPException(400, "El usuario de Hacienda no corresponde al ambiente elegido: los de pruebas terminan en "
                                     "@stag.comprobanteselectronicos.go.cr y los de producción en @prod.comprobanteselectronicos.go.cr")
    cambio_ambiente = data.ambiente != e.ambiente
    for k, v in data.model_dump().items():
        if k == "confirma_sin_fe":          # 4.21: es de la petición, no un dato de la empresa
            continue
        if k in ("password_hacienda", "smtp_password"):
            if v in (None, "", "***"):
                continue
            v = secretos.cifrar(e.clave_cifrada, v.strip("\r\n"))
        if k == "usuario_hacienda":
            v = usuario
        if k == "proveedor_sistemas" and v:
            v = "".join(ch for ch in v if ch.isalnum())
        setattr(e, k, v)
    if cambio_ambiente:
        # La llave criptográfica es distinta en pruebas y producción: se exige cargar la del nuevo ambiente. La numeración
        # continúa desde el último consecutivo YA emitido en ese ambiente (en producción arranca en 1).
        e.p12_nombre, e.p12_pin, e.p12_vence = None, None, None
        _reajustar_secuencias(e.id, data.ambiente)
    s.add(e); s.commit(); s.refresh(e)
    auditar(s, "config_empresa", "Datos de la empresa / Hacienda / SMTP actualizados", ctx.usuario, e.id, ctx.request)
    if cambio_ambiente:
        auditar(s, "cambio_ambiente", f"Ambiente de Hacienda: {data.ambiente}. Debe cargar la llave .p12 de ese ambiente", ctx.usuario, e.id, ctx.request)
    if apagada_sola:
        auditar(s, "config_empresa", "Facturación electrónica apagada: la empresa quedó como «No contribuyente» (comprobantes internos)", ctx.usuario, e.id, ctx.request)
    elif antes_fe != (getattr(e, "factura_electronica", True) is not False):     # 4.21: el interruptor cambió por este guardado (otra pantalla, una integración)
        auditar(s, "config_empresa", "Facturación electrónica " + ("encendida" if getattr(e, "factura_electronica", True) is not False else "apagada: comprobantes internos, sin Hacienda")
                + " (al guardar los datos de la empresa)", ctx.usuario, e.id, ctx.request)
    return {"ok": True, "id": e.id, "cambio_ambiente": cambio_ambiente, "facturacion_apagada": apagada_sola}


def _faltantes_para_facturar(e) -> list:
    """4.21: lo que le falta a la empresa GUARDADA para emitir comprobantes electrónicos (lo mismo que exige put_empresa con la
    facturación electrónica encendida), dicho con el nombre que cada dato tiene en Configuración › Empresa."""
    faltan = []
    nombre = (e.nombre or "").strip()
    if not 5 <= len(nombre) <= 100:
        faltan.append("el nombre o razón social (de 5 a 100 letras)")
    if (e.tipo_id or "") == "06":
        faltan.append("un tipo de identificación de contribuyente (una empresa «No contribuyente» no emite comprobantes electrónicos)")
    else:
        try:
            _normalizar_identificacion(e.tipo_id or "02", e.numero_id or "")
        except HTTPException:
            faltan.append("el número de identificación")
    if not re.fullmatch(ACTIVIDAD_RE, (e.actividad or "").strip()):
        faltan.append("la actividad económica principal")
    if not 5 <= len((e.otras_senas or "").strip()) <= 250:
        faltan.append("la dirección (otras señas)")
    if not ubicaciones.existe(e.provincia, e.canton, e.distrito):
        faltan.append("la provincia, el cantón y el distrito")
    comercial, barrio = (e.nombre_comercial or "").strip(), (e.barrio or "").strip()
    if comercial and not 3 <= len(comercial) <= 80:
        faltan.append("el nombre comercial (de 3 a 80 letras, o vacío)")
    if barrio and not 5 <= len(barrio) <= 50:
        faltan.append("el barrio (de 5 a 50 letras, o vacío)")
    if not (e.correo or "").strip():
        faltan.append("el correo")
    return faltan


class FacturacionElectronicaIn(BaseModel):
    activa: bool


@app.post("/api/empresa/facturacion-electronica")
def cambiar_facturacion_electronica(data: FacturacionElectronicaIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    """4.21: enciende o apaga SOLO el interruptor «Esta empresa emite comprobantes electrónicos». Antes ese cambio viajaba con toda la
    empresa (PUT /api/empresa) y lo tumbaba cualquier otro dato guardado que no pasara la validación: una empresa nace sin número de
    identificación, así que no se podía apagar, y con el interruptor encendido tampoco se podían guardar los datos (pedía la actividad).
    Apagar no valida nada más. Encender exige lo que Hacienda pide del emisor y dice qué falta y dónde se completa."""
    e = s.get(Empresa, ctx.empresa.id)
    antes = getattr(e, "factura_electronica", True) is not False
    if data.activa and not antes:
        if e.es_demo and ((e.usuario_hacienda or "").strip() or e.password_hacienda or e.ambiente == "produccion"):
            raise HTTPException(400, "La empresa demo no se conecta a Hacienda: configure la conexión en su propia empresa")
        faltan = _faltantes_para_facturar(e)
        if faltan:
            raise HTTPException(400, "Para encender la facturación electrónica complete primero en Configuración › Empresa: " + "; ".join(faltan) + ".")
    if bool(data.activa) != antes:
        e.factura_electronica = bool(data.activa)
        s.add(e); s.commit()
        auditar(s, "config_empresa", "Facturación electrónica " + ("encendida" if data.activa else "apagada: comprobantes internos, sin Hacienda"), ctx.usuario, e.id, ctx.request)
    return {"ok": True, "factura_electronica": bool(data.activa)}


def _reajustar_secuencias(eid: int, ambiente: str) -> None:
    """Deja cada secuencia en el mayor consecutivo ya emitido en `ambiente` (0 si no hay), sin repetir números."""
    from .db import engine_empresa
    # Cada ambiente conserva su propia serie (incluida la fijada a mano): solo se sube la del ambiente nuevo si quedó por
    # debajo de lo ya emitido en él (R91)
    with Session(engine_empresa(eid)) as se:
        for seq in se.exec(select(Secuencia).where(Secuencia.empresa_id == eid, Secuencia.ambiente == ambiente)).all():
            docs = se.exec(select(Documento.consecutivo).where(Documento.empresa_id == eid, Documento.ambiente == ambiente,
                                                                  Documento.tipo_documento == seq.tipo_documento)).all()
            seq.ultimo = max(seq.ultimo, max((int(c[-10:]) for c in docs if c and c[-10:].isdigit()), default=0))
            se.add(seq)
        se.commit()


@app.post("/api/empresa/certificado")
def subir_certificado(archivo: UploadFile = File(...), pin: str = Form(...), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    if e.es_demo:
        raise HTTPException(400, "La empresa demo no se conecta a Hacienda: cargue la llave en su propia empresa")
    secretos.asegurar_clave(e)
    contenido = _leer_subida(archivo)
    pin = pin.strip("\r\n")
    try:
        _key, cert = firma.cargar_p12(contenido, pin)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    except Exception as ex:
        raise HTTPException(400, f"No se pudo abrir el .p12 (¿PIN incorrecto?): {ex}")
    # La llave de Hacienda trae la cédula del titular: debe ser la de esta empresa (en SaaS evita cargar la llave de otra)
    cedula_cert = firma.cedula_del_certificado(cert)
    digitos_empresa = "".join(ch for ch in (e.numero_id or "") if ch.isdigit())
    if cedula_cert and digitos_empresa and (e.numero_id or "").isdigit() and not firma.misma_cedula(cedula_cert, digitos_empresa):   # cédulas alfanuméricas: no se compara
        raise HTTPException(400, f"La llave pertenece a la cédula {cedula_cert}, no a la de esta empresa ({e.numero_id})")
    nombre = f"empresa_{e.id}.p12"
    (CERT_DIR / nombre).write_bytes(secretos.cifrar_archivo(e.clave_cifrada, contenido))
    e.p12_nombre, e.p12_pin = nombre, secretos.cifrar(e.clave_cifrada, pin)
    e.p12_vence = cert.not_valid_after_utc.isoformat()
    s.add(e); s.commit()
    auditar(s, "certificado_cargado", f"{cert.subject.rfc4514_string()} | emisor {cert.issuer.rfc4514_string()} | vence {e.p12_vence[:10]}",
            ctx.usuario, e.id, ctx.request)
    return {"ok": True, "sujeto": cert.subject.rfc4514_string(), "emisor": cert.issuer.rfc4514_string(), "vence": e.p12_vence}


@app.post("/api/empresa/logo")
def subir_logo(archivo: UploadFile = File(...), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    ext = (archivo.filename or "logo.png").rsplit(".", 1)[-1].lower()
    if ext not in ("png", "jpg", "jpeg"):
        raise HTTPException(400, "El logo debe ser PNG o JPG")
    nombre = f"logo_empresa_{e.id}.{ext}"
    (DATA_DIR / nombre).write_bytes(_leer_subida(archivo))
    e.logo_nombre = nombre
    s.add(e); s.commit()
    return {"ok": True, "logo": f"/api/empresa/logo?v={int(datetime.now().timestamp())}"}


@app.get("/api/empresa/logo")
def ver_logo(ctx: Contexto = Depends(contexto)):
    p = pdf.logo_empresa(ctx.empresa)
    if not p:
        return Response(status_code=204)          # 3.87: sin logo no es un error (antes 404 y un error en la consola en cada visita)
    return FileResponse(p)


# ---------------------------------------------------------------- configuración de documentos (campos de impresión)
@app.get("/api/config/documentos")
def config_documentos(ctx: Contexto = Depends(contexto)):
    return {"catalogo": plantillas.catalogo(), "tipos": {t: plantillas.obtener(t, ctx.empresa.id) for t in plantillas.TIPOS}}


class ConfigDocIn(BaseModel):
    titulo: Optional[str] = None
    campos: list[str]
    terminos: Optional[str] = None
    notas: Optional[str] = None


@app.put("/api/config/documentos/{tipo}")
def guardar_config_documento(tipo: str, data: ConfigDocIn, ctx: Contexto = Depends(requiere("documentos"))):
    if tipo not in plantillas.TIPOS:
        raise HTTPException(404, "Tipo de documento desconocido")
    return plantillas.guardar(tipo, data.titulo, data.campos, data.terminos, data.notas, ctx.empresa.id)


@app.delete("/api/config/documentos/{tipo}")
def restaurar_config_documento(tipo: str, ctx: Contexto = Depends(requiere("documentos"))):
    return plantillas.restaurar(tipo, ctx.empresa.id)


def _emisor_dict(e: Empresa) -> dict:
    return {"nombre": e.nombre, "nombre_comercial": e.nombre_comercial, "tipo_id": e.tipo_id, "cedula": e.numero_id,
            "direccion": ", ".join(x for x in [ubicaciones.nombre(e.provincia, e.canton, e.distrito), e.barrio, e.otras_senas] if x),
            "telefono": f"+506 {e.telefono}" if e.telefono else "",
            "correo": e.correo, "sitio_web": e.sitio_web or "", "actividad": e.actividad, "actividad_desc": e.actividad_nombre or ""}


def _marca_doc(e: Empresa, d: Documento):
    """Marca con que se emitió el documento (o la predeterminada si no indica ninguna); None = datos de la empresa (3.45)."""
    with Session(engine_empresa(e.id)) as s2:
        return _marcas.marca_de(s2, e.id, getattr(d, "marca_id", None)) or _marcas.predeterminada(s2, e.id)


def _meta_pdf(e: Empresa, d: Documento, m=None) -> dict:
    ct = _marcas.contacto_de(e, m)
    return {"emisor_sitio_web": ct["sitio_web"] or "", "emisor_telefono": f"+506 {ct['telefono']}" if ct["telefono"] else "",
            "emisor_actividad_desc": e.actividad_nombre or "",
            "vendedor": d.vendedor, "fecha_vencimiento": d.fecha_vencimiento, "pagado": (d.pagado or 0) + (d.acreditado or 0),   # cobros y notas de crédito
            "terminos": getattr(d, "terminos", None) or None, "orden_compra": getattr(d, "orden_compra", None) or "",
            "interno": d.estado == "interno"}          # 3.61: comprobante interno: título propio, sin clave, QR ni leyenda de Hacienda


@app.post("/api/pdf/documento")
def pdf_documento(payload: dict, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """PDF de documentos no electrónicos (cotización, remisión, orden de compra, recibo) a partir de JSON."""
    e = ctx.empresa
    payload["emisor"] = _emisor_dict(e)
    m = _marcas.marca_de(s, e.id, payload.get("marca_id")) or _marcas.predeterminada(s, e.id)      # marca del documento (3.45)
    if m is not None:
        ct = _marcas.contacto_de(e, m)
        payload["emisor"].update({"nombre_comercial": m.nombre, "sitio_web": ct["sitio_web"], "correo": ct["correo"], "telefono": f"+506 {ct['telefono']}" if ct["telefono"] else ""})
    tipo = payload.get("tipo", "cotizacion")
    # Imágenes de los productos para la columna "Imagen" (si el producto no tiene, queda en blanco)
    for l in payload.get("lineas", []):
        l.pop("imagen_path", None)                 # solo el servidor decide qué archivo se imprime (R43)
        p = _producto(s, e.id, l["producto_id"]) if l.get("producto_id") else None
        if p is None and l.get("cabys"):
            p = s.exec(select(Producto).where(Producto.empresa_id == e.id, Producto.cabys == l["cabys"],
                                              Producto.nombre == (l.get("detalle") or ""))).first()
        if p and p.imagen_nombre and (_img_dir(e.id) / p.imagen_nombre).exists():
            l["imagen_path"] = str(_img_dir(e.id) / p.imagen_nombre)
    cfg = plantillas.obtener(tipo, e.id)
    if payload.get("vista_previa_campos"):
        cfg = {**cfg, "campos": payload["vista_previa_campos"]}
    try:
        contenido = pdf.generar_pdf_documento(payload, cfg, _marcas.logo_de(e, m))
    except Exception as ex:
        raise HTTPException(400, f"No se pudo generar el PDF: {ex}")
    nombre = f"{tipo}_{payload.get('numero', '')}.pdf"
    return Response(contenido, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{nombre}"'})


# ---------------------------------------------------------------- clientes
def _cliente(s: Session, empresa_id: int, cid: int) -> Cliente | None:
    c = s.get(Cliente, cid)
    return c if c and c.empresa_id == empresa_id else None


def _producto(s: Session, empresa_id: int, pid: int) -> Producto | None:
    p = s.get(Producto, pid)
    return p if p and p.empresa_id == empresa_id else None


def _documento(s: Session, empresa_id: int, did: int) -> Documento:
    d = s.get(Documento, did)
    if not d or d.empresa_id != empresa_id:
        raise HTTPException(404, "Comprobante no encontrado")
    return d


# 3.87: las rutas que abren un comprobante por id aplican las reglas de la lista: el Cajero solo lo reciente y quien está amarrado a
# una sucursal solo lo de ella. Antes revisaban solo la empresa y, como los ids son seguidos, por id se recorría todo el historial
# (clientes, montos, líneas, PDF y XML). Fuera de su alcance se responde lo mismo que a un id que no existe.
HORAS_CAJERO = 6           # la caja que cruza la medianoche sigue reimprimiendo lo de las últimas horas de su turno
# 4.5: lo que la caja necesita de un fiado para abonarlo (GET /api/comprobantes?cliente_id&con_saldo de un usuario de solo caja)
CAMPOS_ABONO_CAJA = ("id", "tipo_documento", "consecutivo", "fecha_emision", "fecha_vencimiento", "total", "pagado", "acreditado", "cliente_id", "condicion_venta", "moneda", "estado")
ARCHIVO_NO_DISPONIBLE = "El archivo de este comprobante no está disponible en el servidor"


def _exigir_ventas(ctx: Contexto, que: str = "las ventas") -> None:
    """3.87: los roles de un solo módulo (Técnico de soporte, solo RRHH, Camarera, Técnico, Seguridad: auth.solo_modulo) no leen
    comprobantes, cobros ni borradores. Antes los recibían completos con solo «ver»."""
    if auth.solo_modulo(ctx.permisos):
        raise HTTPException(403, f"Su rol ({ctx.rol}) no tiene acceso a {que}")


def _exigir_recurrentes(ctx: Contexto) -> None:
    """La caja (solo «pos») y los roles de un solo módulo no leen las facturas recurrentes ni sus pendientes (3.87: las pendientes,
    con cliente, líneas y precios negociados, sí le llegaban al Cajero)."""
    if auth.solo_pos(ctx.permisos) or auth.solo_modulo(ctx.permisos):
        raise HTTPException(403, "Su rol no tiene acceso a las facturas recurrentes")


def _desde_cajero() -> str:
    """Desde cuándo abre comprobantes el Cajero: hoy, como su lista, o de madrugada las últimas HORAS_CAJERO horas (texto
    comparable con fecha_emision, que se guarda como ahora_cr().isoformat(timespec='seconds'))."""
    ahora = ahora_cr()
    return min(ahora.strftime("%Y-%m-%d"), (ahora - timedelta(hours=HORAS_CAJERO)).isoformat(timespec="seconds"))


def _documento_ctx(s: Session, ctx: Contexto, did: int) -> Documento:
    """_documento + las reglas de lectura del rol (3.87): solo módulo, Cajero y sucursal fija."""
    _exigir_ventas(ctx)
    d = _documento(s, ctx.empresa.id, did)
    if auth.solo_pos(ctx.permisos) and str(d.fecha_emision or "") < _desde_cajero():
        raise HTTPException(404, "Comprobante no encontrado")
    suc = getattr(ctx, "sucursal", None)
    if suc is not None and getattr(ctx, "sucursal_fija", False) and not sucursales.pertenece(d, suc):
        raise HTTPException(404, "Comprobante no encontrado")
    return d


def _instante_cr(txt) -> Optional[datetime]:
    """3.87: una fecha u hora guardada por la interfaz (ISO con Z, como la guarda la caja, con desfase o solo la fecha) como instante
    comparable. Sin zona se toma la hora de Costa Rica. None si está vacía o no se entiende."""
    from .config import TZ_CR
    t = str(txt or "").strip()
    try:
        d = datetime.fromisoformat(t[:-1] + "+00:00" if t.endswith("Z") else t) if t else None
    except ValueError:
        return None
    return d if d is None or d.tzinfo else d.replace(tzinfo=TZ_CR)


def _ventana_cajero(s: Session, eid: int) -> dict:
    """3.87: lo que el Cajero (solo «pos») lee de la caja, {clave: función(elemento) -> bool}: las sesiones abiertas y las abiertas o
    cerradas desde _desde_cajero() (su día; de madrugada, también el turno que cruzó la medianoche) y las ventas de esas sesiones o
    hechas desde entonces. Antes recibía en /api/registros/pos_ventas y al entrar las ventas de cualquier día, con cliente, total y
    líneas, como ya no pasa con los comprobantes. Las colecciones se suben por diferencias: lo que no se le envía no se borra."""
    desde = _instante_cr(_desde_cajero())
    reciente = lambda *fechas: any(i is not None and i >= desde for i in map(_instante_cr, fechas))   # noqa: E731
    sesion_ok = lambda c: isinstance(c, dict) and (c.get("estado") == "Abierta" or reciente(c.get("abierta_en"), c.get("cerrada_en")))   # noqa: E731
    sesiones = {str(c["id"]) for c in (modulos.leer(s, eid, "pos_cajas", []) or []) if sesion_ok(c) and c.get("id") is not None}
    venta_ok = lambda v: isinstance(v, dict) and ((v.get("caja_id") is not None and str(v["caja_id"]) in sesiones) or reciente(v.get("hora") or v.get("fecha")))   # noqa: E731
    return {"pos_cajas": sesion_ok, "pos_ventas": venta_ok}


def _datos_registro(ctx: Contexto, s: Session, clave: str, datos):
    """Lo que este rol recibe de un registro (3.87): sin montos para quien no los ve y, al Cajero, de la caja solo lo de su día."""
    datos = auth.recortar_montos(ctx.permisos, clave, datos)
    if clave in ("pos_cajas", "pos_ventas") and isinstance(datos, list) and auth.solo_pos(ctx.permisos):
        ok = _ventana_cajero(s, ctx.empresa.id)[clave]
        datos = [x for x in datos if ok(x)]
    return datos


@app.get("/api/clientes")
def clientes(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    filas = s.exec(select(Cliente).where(Cliente.empresa_id == ctx.empresa.id).order_by(Cliente.nombre)).all()
    if auth.solo_modulo(ctx.permisos):      # 3.87: TiKe trabaja con el cliente del ticket (sin su límite de crédito); los demás roles de un solo módulo, sin contactos
        return [c.model_dump(exclude={"limite_credito"}) for c in filas] if ctx.puede("tike") else []
    return filas


def _json_default(o):
    if hasattr(o, "model_dump"):
        return o.model_dump()
    if hasattr(o, "isoformat"):
        return o.isoformat()
    if isinstance(o, Decimal):
        return float(o)
    return str(o)


def _json_rapido(request: Request, datos=None, texto: str | None = None) -> Response:
    """Respuesta JSON de las listas grandes (3.72): se serializa directo (el codificador genérico de FastAPI recorre cada campo y
    con miles de filas tarda más que la consulta) y va comprimida con gzip cuando el navegador lo acepta. Si el servidor web ya
    comprime, la deja pasar tal cual."""
    if texto is not None:
        cuerpo = texto
    else:
        try:
            cuerpo = json.dumps(datos, ensure_ascii=False, separators=(",", ":"), default=_json_default, allow_nan=False)
        except ValueError:                     # 3.87: un NaN o infinito guardado sale como 0 (antes salía «NaN», que el navegador no lee)
            cuerpo = json.dumps(resumen.finitos(datos), ensure_ascii=False, separators=(",", ":"), default=_json_default)
    if len(cuerpo) > 1024 and "gzip" in (request.headers.get("accept-encoding") or "").lower():
        import gzip as _gzip
        return Response(content=_gzip.compress(cuerpo.encode("utf-8"), 5), media_type="application/json", headers={"Content-Encoding": "gzip", "Vary": "Accept-Encoding"})
    return Response(content=cuerpo, media_type="application/json", headers={"Vary": "Accept-Encoding"})


def _normalizar_identificacion(tipo_id: str, numero: str) -> str:
    """Identificación sin guiones ni espacios, en mayúsculas. Desde la revisión v4.4 de abril 2026 las cédulas jurídicas pueden
    ser alfanuméricas (Registro Nacional); física, DIMEX y NITE siguen siendo numéricas."""
    n = re.sub(r"[^A-Za-z0-9]", "", numero or "").upper()
    reglas = {"01": (r"\d{9}", "9 dígitos"), "02": (r"\d{10}|[A-Z0-9]{9,20}", "10 dígitos, o alfanumérica de 9 a 20 caracteres"),
              "03": (r"\d{11,12}", "11 o 12 dígitos"), "04": (r"\d{10}", "10 dígitos")}
    if tipo_id == "05":                      # pasaporte / identificación extranjera: el XSD solo fija un máximo de 20
        patron, texto = r"[A-Z0-9]{1,20}", "de 1 a 20 letras o dígitos"
    else:
        patron, texto = reglas.get(tipo_id, (r"[A-Z0-9]{9,20}", "9 a 20 letras o dígitos"))
    if not re.fullmatch(patron, n):
        raise HTTPException(400, f"La identificación ({CAT_TIPO_ID.get(tipo_id, tipo_id)}) debe tener {texto}, sin guiones ni espacios")
    return n


CAT_TIPO_ID = {"01": "cédula física", "02": "cédula jurídica", "03": "DIMEX", "04": "NITE", "05": "extranjero", "06": "no contribuyente"}


def _validar_texto_hacienda(valor, nombre: str, minimo: int, maximo: int, obligatorio: bool = False):
    v = (valor or "").strip()
    if not v:
        if obligatorio:
            raise HTTPException(400, f"{nombre} es obligatorio")
        return
    if len(v) < minimo or len(v) > maximo:
        raise HTTPException(400, f"{nombre} debe tener entre {minimo} y {maximo} caracteres (Hacienda no admite otra cosa)")


def _sin_identificacion(c) -> bool:
    """Contacto sin identificación (3.33): solo recibe tiquetes electrónicos."""
    return not (getattr(c, "numero_id", "") or "").strip()


def _normalizar_direcciones(v):
    """4.6: otras direcciones del cliente (casa, trabajo, donde la hermana…) como texto JSON [{nombre, detalle, enlace}]; máximo 20;
    cada una con sus señas (hasta 250) y un enlace de mapa opcional. Vacío = None."""
    if v is None or v == "" or v == "[]":
        return None
    try:
        lista = json.loads(v) if isinstance(v, str) else v
    except ValueError:
        raise HTTPException(400, "Las direcciones no tienen un formato válido")
    if not isinstance(lista, list):
        raise HTTPException(400, "Las direcciones no tienen un formato válido")
    if len(lista) > 20:
        raise HTTPException(400, "Máximo 20 direcciones por contacto")
    out = []
    for d in lista:
        if not isinstance(d, dict):
            raise HTTPException(400, "Las direcciones no tienen un formato válido")
        nombre = str(d.get("nombre") or "").strip()[:40]; detalle = str(d.get("detalle") or "").strip(); enlace = str(d.get("enlace") or "").strip()
        if not detalle:
            raise HTTPException(400, "Cada dirección necesita las señas (por ejemplo «Casa: 200 m sur de la iglesia, portón negro»)")
        if len(detalle) > 250:
            raise HTTPException(400, "Las señas de una dirección llevan hasta 250 caracteres")
        if enlace and not re.match(r"^https?://", enlace):
            raise HTTPException(400, "El enlace del mapa debe empezar con http:// o https://")
        out.append({"nombre": nombre or "Entrega", "detalle": detalle, "enlace": enlace[:300]})
    return json.dumps(out, ensure_ascii=False) if out else None


def _validar_cliente(c: Cliente, sin_fe: bool = False):
    # límites del esquema de Hacienda: evitan un comprobante que no se pueda emitir después. 4.2: sin facturación electrónica solo
    # cuentan los máximos (una dirección corta como «SJ» no detiene nada: el comprobante interno no la exige)
    _validar_texto_hacienda(c.nombre, "El nombre", 1 if sin_fe else 3, 100, True)     # ReceptorType: 3 a 100 (el emisor sí exige 5)
    _validar_texto_hacienda(c.nombre_comercial, "El nombre comercial", 1 if sin_fe else 3, 80)
    _validar_texto_hacienda(c.barrio, "El barrio", 1 if sin_fe else 5, 50)
    _validar_texto_hacienda(c.direccion, "Las otras señas (dirección)", 1 if sin_fe else 5, 250)
    if c.actividad and not re.fullmatch(ACTIVIDAD_RE, str(c.actividad).strip()):
        raise HTTPException(400, "La actividad económica debe ser el código de Hacienda: 4 dígitos, punto y 1 dígito (p. ej. 6201.0) o 6 dígitos")
    if c.actividad:
        c.actividad = str(c.actividad).strip()
    for _campo in ('telefono', 'celular'):
        _v = getattr(c, _campo, None)
        if _v is not None and not telefono_valido(_v):
            raise HTTPException(400, f'El {_campo} debe tener 8 dígitos (o ser un número especial de 3, como 911), sin guiones ni el 506')
    if c.provincia and c.canton and c.distrito and not ubicaciones.existe(c.provincia, c.canton, c.distrito):
        raise HTTPException(400, 'Provincia, cantón o distrito no válidos')
    c.nombre = c.nombre.strip()
    for _campo, _nombre in (("correo_facturas", "Enviar facturas a"), ("correo_cc", "Copia (CC) de las facturas")):   # (3.38)
        _lista = _correos_validos(getattr(c, _campo, None), _nombre)
        if len(_lista) > 50:
            raise HTTPException(400, f"{_nombre}: máximo 50 correos")
        setattr(c, _campo, ", ".join(_lista) or None)
    c.direcciones = _normalizar_direcciones(getattr(c, "direcciones", None))   # 4.6
    if not (c.tipo_id or "").strip():                  # «Sin identificación» (3.33): sin número; solo tiquetes
        if (c.numero_id or "").strip():
            raise HTTPException(400, "Elija el tipo de identificación, o borre el número si el contacto no tiene identificación")
        c.tipo_id, c.numero_id = "", ""
        return
    c.numero_id = _normalizar_identificacion(c.tipo_id, c.numero_id)


@app.post("/api/clientes")
def crear_cliente(c: Cliente, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    # un proveedor lo crea quien lleva gastos (R134; 3.87: solo «Proveedor», un «Ambos» también es cliente); el cajero del punto de venta crea clientes (alta rápida)
    if not (ctx.puede("catalogos") or ((c.tipo or "") == "Proveedor" and ctx.puede("gastos")) or (ctx.puede("pos") and (c.tipo or "Cliente") == "Cliente")):
        raise HTTPException(403, "Su rol no puede crear contactos")
    _validar_cliente(c, _sin_fe(ctx))
    c.id = None; c.empresa_id = ctx.empresa.id
    s.add(c); s.commit(); s.refresh(c)
    return c


@app.get("/api/clientes/{cid}")
def ver_cliente(cid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """4.6: la ficha fresca de un contacto (el formulario la pide antes de editar: otro equipo pudo agregarle direcciones)."""
    c = _cliente(s, ctx.empresa.id, cid)
    if not c:
        raise HTTPException(404)
    if auth.solo_modulo(ctx.permisos) and not ctx.puede("tike"):
        raise HTTPException(403, "Su rol no consulta contactos")
    return c.model_dump(exclude={"limite_credito"}) if auth.solo_modulo(ctx.permisos) else c


@app.put("/api/clientes/{cid}")
def editar_cliente(cid: int, data: Cliente, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    # 3.87: quien lleva gastos (Contador) corrige los proveedores que puede crear (R134); antes los creaba y no podía editarlos
    if not (ctx.puede("catalogos") or ctx.puede("gastos")):
        ctx.exigir("catalogos")
    c = _cliente(s, ctx.empresa.id, cid)
    if not c:
        raise HTTPException(404)
    if not ctx.puede("catalogos") and not ((c.tipo or "") == "Proveedor" and (data.tipo or "") == "Proveedor"):
        raise HTTPException(403, "Su rol solo corrige proveedores: un cliente (o un contacto que es cliente y proveedor) lo cambia quien administra los clientes")
    # 4.6: solo se escriben los campos que vinieron en el cuerpo (más los que la validación normaliza): un cuerpo parcial
    # (otra pantalla, una versión anterior) no borra lo que no conoce, por ejemplo las direcciones que agregó la caja
    enviados = set(data.model_fields_set) | {"nombre", "tipo_id", "numero_id", "actividad", "correo_facturas", "correo_cc"}
    _validar_cliente(data, _sin_fe(ctx))
    for k, v in data.model_dump(exclude={"id", "empresa_id"}).items():
        if k in enviados:
            setattr(c, k, v)
    s.add(c); s.commit(); s.refresh(c)
    return c


class DireccionIn(BaseModel):
    nombre: Optional[str] = None
    detalle: str
    enlace: Optional[str] = None


@app.post("/api/clientes/{cid}/direcciones")
def agregar_direccion_cliente(cid: int, data: DireccionIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """4.6: la caja agrega una dirección de entrega al cliente (casa, trabajo…) sin tocar el resto de la ficha (el cajero no edita contactos)."""
    if not (ctx.puede("catalogos") or ctx.puede("pos")):
        raise HTTPException(403, "Su rol no puede agregar direcciones a los contactos")
    if _sinc.MODO_LOCAL:
        # instalación local: una ficha de la nube (o de otra terminal) no se sube desde aquí y la próxima bajada la pisaría; la
        # dirección se agrega en la nube y la copia local se actualiza con su respuesta
        cfg = _sinc._cfg_local(s, ctx.empresa.id)
        rango = int(cfg.get("terminal") or 0) if cfg.get("vinculado") else 0
        if rango and cfg.get("token") and cfg.get("url") and not modulos.en_rango(cid, rango):
            try:
                token = secretos.descifrar(ctx.empresa.clave_cifrada, cfg["token"])
                r = httpx.post(cfg["url"] + f"/api/clientes/{cid}/direcciones", headers={"Authorization": "Bearer " + token}, json=data.model_dump(), timeout=20)
            except Exception:
                raise HTTPException(503, "Sin conexión con la nube: la dirección de este contacto se agrega cuando vuelva la conexión (o desde Contactos en la nube)")
            if r.status_code != 200:
                try:
                    det = r.json().get("detail")
                except Exception:
                    det = None
                raise HTTPException(r.status_code if 400 <= r.status_code < 500 else 502, det if isinstance(det, str) else "La nube no aceptó la dirección")
            _sinc._upsert(s, Cliente, [r.json()], ctx.empresa.id); s.commit()
            return _cliente(s, ctx.empresa.id, cid)
    nueva = {"nombre": (data.nombre or "").strip(), "detalle": (data.detalle or "").strip(), "enlace": (data.enlace or "").strip()}
    for _intento in range(4):                               # escritura condicional: dos cajeros que agregan a la vez no se pisan
        c = _cliente(s, ctx.empresa.id, cid)
        if not c:
            raise HTTPException(404)
        leido = c.direcciones
        try:
            lista = json.loads(leido) if leido else []
        except ValueError:
            lista = []
        lista = [d for d in lista if isinstance(d, dict)]
        if any(str(d.get("detalle", "")).strip().lower() == nueva["detalle"].lower() for d in lista):
            return c                                        # ya la tenía: no se repite
        nuevo = _normalizar_direcciones(lista + [nueva])
        r = s.execute(text(f"UPDATE {Cliente.__tablename__} SET direcciones = :nuevo WHERE id = :cid AND empresa_id = :eid AND direcciones IS :leido"),
                      {"nuevo": nuevo, "cid": cid, "eid": ctx.empresa.id, "leido": leido})
        if r.rowcount:
            s.commit(); s.expire_all()
            return _cliente(s, ctx.empresa.id, cid)
        s.rollback(); s.expire_all()                        # otro la cambió entre la lectura y la escritura: se vuelve a leer
    raise HTTPException(409, "El contacto se está actualizando desde otro equipo; intente de nuevo")


@app.delete("/api/clientes/{cid}")
def borrar_cliente(cid: int, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    c = _cliente(s, ctx.empresa.id, cid)
    if c:
        def _usado_en_gastos() -> bool:
            for clave, campos in (("compras", ("proveedor_id",)), ("ordenes", ("proveedor_id",)), ("pagos_gastos", ("contacto_id",)),
                                  ("nd_gastos", ("proveedor_id",)), ("recurrentes_gastos", ("contacto_id",))):
                for x in modulos.leer(s, ctx.empresa.id, clave, []) or []:
                    if isinstance(x, dict) and any(str(x.get(k)) == str(cid) for k in campos):
                        return True
            return False
        con_pagos = s.exec(select(modulos.Pago).where(modulos.Pago.cliente_id == cid).limit(1)).first() is not None
        con_recurrentes = s.exec(select(modulos.Recurrente).where(modulos.Recurrente.cliente_id == cid).limit(1)).first() is not None
        if s.exec(select(Documento).where(Documento.cliente_id == cid).limit(1)).first() or con_pagos or con_recurrentes or _usado_en_gastos():   # (R238)
            c.activo = False; s.add(c); s.commit()
            return {"ok": True, "desactivado": True}
        s.delete(c); s.commit()
    return {"ok": True}


# ---------------------------------------------------------------- productos
@app.get("/api/productos")
def productos(venta: Optional[bool] = None, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Todos los ítems; con venta=1 solo los que se venden (los insumos y preparaciones quedan fuera) (3.18)."""
    if auth.solo_pos(ctx.permisos):          # 3.87: la caja vende con el precio; el costo no le llega (tampoco por /api/arranque)
        filas = s.exec(select(Producto).where(Producto.empresa_id == ctx.empresa.id, *((Producto.es_venta == True,) if venta else ())).order_by(Producto.nombre)).all()  # noqa: E712
        return [p.model_dump(exclude={"costo"}) for p in filas]
    q = select(Producto).where(Producto.empresa_id == ctx.empresa.id)
    if venta:
        q = q.where(Producto.es_venta == True)  # noqa: E712
    filas = s.exec(q.order_by(Producto.nombre)).all()
    if not auth.ve_documentos(ctx):                      # 3.87: los roles operativos ven nombre y precio (lavandería, minibar), no el costo
        return [p.model_dump(exclude={"costo"}) for p in filas]
    return filas


UNIDADES_HACIENDA = frozenset(["1", "´", "´´", "°C", "1/m", "A", "A/m", "A/m²", "Acv", "Al", "Alc", "B", "Bq", "C", "C/kg", "C/m²", "C/m³", "Cc", "Cd", "cd/m²", "Cm", "cm", "Cu", "D", "eV", "F", "F/m", "Fa", "G", "Gal", "Gy", "Gy/s", "h", "H", "H/m", "Hz", "I", "J", "J/(kg·K)", "J/(mol·K)", "J/K", "J/kg", "J/m³", "J/mol", "K", "Kat", "kat/m³", "Kg", "kg/m³", "Km", "Kw", "kWh", "L", "Lm", "Ln", "Lx", "M", "m/s", "m/s²", "m²", "m³", "Min", "mL", "Mm", "Mol", "mol/m³", "N", "N/m", "N·m", "Np", "º", "Os", "Otros", "Oz", "Pa", "Pa·s", "Qq", "Rad", "rad/s", "rad/s²", "S", "s", "Sp", "Spe", "Sr", "St", "Sv", "t", "T", "U", "Ua", "Unid", "V", "V/m", "W", "W/(m·K)", "W/(m²·sr)", "W/m²", "W/sr", "Wb", "Ω"])


def _moneda_principal(s: Session, eid: int) -> str:
    """Moneda principal de la empresa según Configuración › Monedas (registro `monedas`); colones si no hay (3.25)."""
    mon = modulos.leer(s, eid, "monedas", []) or []
    return next((str(m.get("codigo")) for m in mon if isinstance(m, dict) and m.get("principal") and m.get("codigo")), "CRC")


def _precio_en_moneda(p: Producto, moneda: str, tipo_cambio) -> float:
    """Precio base del ítem en la moneda del documento (3.25): los ítems pueden estar en dólares. Solo se convierte entre
    colones y dólares con el tipo de cambio del documento; cualquier otro par se deja tal cual."""
    de, a, v = (p.moneda or "CRC"), (moneda or "CRC"), float(p.precio or 0)
    tc = float(tipo_cambio or 0)
    if de == a or tc <= 0:
        return v
    if de == "USD" and a == "CRC":
        return round(v * tc, 5)
    if de == "CRC" and a == "USD":
        return round(v / tc, 5)
    return v


def _normalizar_otro_impuesto(v):
    """Ítem: «otro impuesto» (dict o JSON) validado con las reglas del Anexo → JSON normalizado o None (3.41)."""
    from .fe.modelos import otro_impuesto, otro_impuesto_dict
    try:
        i = otro_impuesto(v)
    except (ValueError, TypeError, ArithmeticError) as ex:
        raise HTTPException(400, f"Otro impuesto del ítem: {_mensaje_pydantic(ex)}")
    return json.dumps(otro_impuesto_dict(i)) if i is not None else None


def _sin_fe(ctx) -> bool:
    """3.93: la empresa con la facturación electrónica apagada (comprobantes internos, p. ej. régimen simplificado) no está obligada
    a los datos de Hacienda del ítem: el CABYS pasa a ser opcional (si se escribe, se valida igual)."""
    return getattr(getattr(ctx, "empresa", None), "factura_electronica", True) is False


def _validar_producto(p: Producto, sin_fe: bool = False):
    if not (p.nombre or "").strip():
        raise HTTPException(400, "El producto requiere nombre")
    p.otro_impuesto = _normalizar_otro_impuesto(getattr(p, "otro_impuesto", None))
    p.moneda = str(p.moneda or "CRC").strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", p.moneda):
        raise HTTPException(400, "La moneda del precio debe ser un código de tres letras (CRC, USD)")
    p.nombre = p.nombre.strip()
    if len(p.nombre) < 3 or len(p.nombre) > 200:
        raise HTTPException(400, "El nombre del producto debe tener entre 3 y 200 caracteres (es el detalle de la línea en la factura)")
    if p.unidad_medida not in UNIDADES_HACIENDA:
        # minúsculas de versiones anteriores ('g', 'm', 'd') → la unidad oficial
        arreglo = {u.lower(): u for u in UNIDADES_HACIENDA}.get(str(p.unidad_medida or "").lower())
        if not arreglo:
            raise HTTPException(400, f"La unidad de medida '{p.unidad_medida}' no existe en el catálogo de Hacienda; elija una de la lista")
        p.unidad_medida = arreglo
    if p.codigo and len(str(p.codigo).strip()) > 20:
        raise HTTPException(400, "El código del producto no puede pasar de 20 caracteres (va en CodigoComercial de la factura)")
    if p.partida_arancelaria:
        pa = re.sub(r"[^0-9]", "", str(p.partida_arancelaria))
        if len(pa) != 12:
            raise HTTPException(400, "La partida arancelaria debe tener exactamente 12 dígitos (p. ej. 847130000000), con o sin puntos")
        p.partida_arancelaria = pa
    insumo = (getattr(p, "es_venta", True) is False or sin_fe) and not (p.cabys or "").strip()   # insumo que no se vende: sin CABYS (3.18); 3.93: tampoco sin facturación electrónica
    if insumo:
        p.cabys = ""
    elif not (p.cabys and len(p.cabys) == 13 and p.cabys.isdigit()):
        raise HTTPException(400, "El código CABYS debe tener 13 dígitos")
    if not insumo and cabys_local.disponible() and not cabys_local.obtener(p.cabys):
        raise HTTPException(400, f"El código CABYS {p.cabys} no existe en el catálogo oficial; búsquelo por descripción")
    if p.es_servicio or p.tipo == "Servicio":
        p.es_servicio, p.inventariable = True, False
        if p.tipo == "Producto":          # importado por CSV sin tipo: al editarlo se facturaba como mercancía
            p.tipo = "Servicio"
    # 3.87: existencia mínima y máxima opcionales (Inventario › Por reponer); un servicio no lleva existencias
    if p.es_servicio:
        p.existencia_minima = p.existencia_maxima = None
    for campo, nombre in (("existencia_minima", "La existencia mínima"), ("existencia_maxima", "La existencia máxima")):
        v = getattr(p, campo, None)
        if v is not None and not 0 <= float(v) <= 1e12:
            raise HTTPException(400, f"{nombre} debe ser un número mayor o igual a cero")
    if getattr(p, "existencia_minima", None) is not None and getattr(p, "existencia_maxima", None) is not None and p.existencia_maxima < p.existencia_minima:
        raise HTTPException(400, "La existencia máxima no puede ser menor que la mínima")


class ProductoIn(BaseModel):
    """Producto + existencia inicial opcional (se registra como movimiento 'inicial' en la bodega indicada)."""
    codigo: Optional[str] = None; nombre: str; cabys: str = ""; precio: float = 0; unidad_medida: str = "Unid"; moneda: Optional[str] = None   # sin moneda = la principal de la empresa (3.25)
    es_servicio: bool = False; codigo_tarifa: str = "08"; tarifa: float = 13.0; tipo: str = "Producto"
    descripcion: Optional[str] = None; categoria: Optional[str] = None; costo: float = 0; inventariable: bool = True
    venta_negativo: bool = False; partida_arancelaria: Optional[str] = None; activo: bool = True; imagen_nombre: Optional[str] = None
    cantidad_inicial: Optional[float] = None
    bodega_id: Optional[int] = None
    es_venta: bool = True                        # 3.18: apagado = insumo (sin CABYS; no se vende)
    otro_impuesto: Optional[Any] = None          # 3.41: Selectivo de Consumo o impuesto específico (dict o JSON; None = ninguno)
    visible_catalogo: bool = False; descripcion_publica: Optional[str] = None; destacado: bool = False; agotado: bool = False   # catálogo público (3.47)
    existencia_minima: Optional[float] = None; existencia_maxima: Optional[float] = None   # 3.87: Inventario › Por reponer (vacío = sin aviso)


@app.post("/api/productos")
def crear_producto(data: ProductoIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    if not data.moneda:
        data.moneda = _moneda_principal(s, ctx.empresa.id)
    p = Producto(**data.model_dump(exclude={"id", "cantidad_inicial", "bodega_id", "imagen_nombre"}), empresa_id=ctx.empresa.id)
    _validar_producto(p, _sin_fe(ctx))
    if data.cantidad_inicial is not None and (data.cantidad_inicial < 0 or data.cantidad_inicial > 1e12):
        raise HTTPException(400, "La existencia inicial debe ser un número mayor o igual a cero")
    bodega_id = None
    if data.cantidad_inicial and p.inventariable and not p.es_servicio:
        bodega_id = data.bodega_id or inventario.bodega_principal(s, ctx.empresa.id).id
        inventario._bodega_activa(s, ctx.empresa.id, bodega_id)                 # se valida ANTES de guardar el producto (R273)
    s.add(p); s.flush()
    if bodega_id:
        inventario.registrar_movimiento(s, producto=p, bodega_id=bodega_id, tipo="inicial", cantidad=float(data.cantidad_inicial),
                                        fecha=ahora_cr().strftime("%Y-%m-%d"), costo_unitario=p.costo or 0, referencia="Inventario inicial")
    s.commit(); s.refresh(p)                                                    # producto y existencia se confirman juntos
    return p


class LoteProductosIn(BaseModel):
    """Acciones en bloque sobre varios ítems (3.25): se envían solo los cambios que aplican."""
    ids: list[int]
    moneda: Optional[str] = None             # etiqueta la moneda del precio SIN tocar el número
    convertir_a: Optional[str] = None        # convierte el precio al tipo de cambio y deja esa moneda
    tipo_cambio: Optional[float] = None      # colones por dólar para convertir_a
    solo_precio_menor_que: Optional[float] = None   # aplica la moneda o la conversión solo a los ítems con precio menor que este valor
    precio_factor: Optional[float] = None    # multiplica el precio (1.10 = +10 %)
    categoria: Optional[str] = None
    codigo_tarifa: Optional[str] = None
    tarifa: Optional[float] = None
    activo: Optional[bool] = None


@app.post("/api/productos/lote/cambios")
def lote_productos(data: LoteProductosIn, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    if not data.ids:
        raise HTTPException(400, "Elija al menos un ítem")
    if len(data.ids) > 5000:
        raise HTTPException(400, "Demasiados ítems en una sola acción")
    if data.convertir_a and not (data.tipo_cambio and data.tipo_cambio > 0):
        raise HTTPException(400, "Para convertir el precio indique el tipo de cambio")
    cambiados, omitidos = 0, 0
    for pid in data.ids:
        p = _producto(s, ctx.empresa.id, int(pid))
        if not p:
            omitidos += 1
            continue
        aplica_moneda = data.solo_precio_menor_que is None or float(p.precio or 0) < float(data.solo_precio_menor_que)
        toco = False
        if data.moneda and aplica_moneda:
            p.moneda = data.moneda.strip().upper(); toco = True
        if data.convertir_a and aplica_moneda:
            a = data.convertir_a.strip().upper()
            if (p.moneda or "CRC") != a:
                p.precio = _precio_en_moneda(p, a, data.tipo_cambio); p.moneda = a; toco = True
        if data.precio_factor is not None and data.precio_factor > 0:
            p.precio = round(float(p.precio or 0) * float(data.precio_factor), 5); toco = True
        if data.categoria is not None:
            p.categoria = data.categoria.strip() or None; toco = True
        if data.codigo_tarifa:
            p.codigo_tarifa = data.codigo_tarifa; p.tarifa = float(data.tarifa if data.tarifa is not None else p.tarifa); toco = True
        if data.activo is not None:
            p.activo = bool(data.activo); toco = True
        if toco:
            # se valida solo lo que cambia (no el CABYS: un ítem viejo con un código fuera del catálogo también debe poder etiquetarse)
            p.moneda = str(p.moneda or "CRC").strip().upper()
            if not re.fullmatch(r"[A-Z]{3}", p.moneda):
                raise HTTPException(400, "La moneda del precio debe ser un código de tres letras (CRC, USD)")
            if float(p.precio or 0) < 0 or float(p.precio or 0) > 1e12:
                raise HTTPException(400, f"{p.nombre}: el precio queda fuera de rango")
            s.add(p); cambiados += 1
        else:
            omitidos += 1
    s.commit()
    _auditar(ctx, "productos_lote", f"{cambiados} ítem(s) cambiados en bloque")
    return {"ok": True, "cambiados": cambiados, "omitidos": omitidos}


# ------------------------------------------------------------------ importar ítems desde Excel o CSV (3.58)
@app.get("/api/productos/plantilla.xlsx")
def plantilla_items(ctx: Contexto = Depends(requiere("catalogos"))):
    from . import importacion_items
    return Response(importacion_items.plantilla_xlsx(), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": 'attachment; filename="plantilla-items.xlsx"'})


@app.post("/api/productos/importar")
def importar_productos(archivo: UploadFile = File(...), modo: str = Form("crear"), simular: str = Form("0"),
                       ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    """Importa (o actualiza) ítems desde un archivo Excel (.xlsx) o CSV con las columnas de la plantilla. Con simular=1 solo
    valida y devuelve el resumen. Las filas con error se saltan y se reportan; las válidas se guardan una a una."""
    from . import importacion_items as imp
    eid = ctx.empresa.id
    if modo not in ("crear", "actualizar"):
        raise HTTPException(400, "El modo debe ser «crear» o «actualizar»")
    solo_simular = str(simular or "0").strip().lower() in ("1", "true", "si", "sí")
    try:
        filas = imp.leer_archivo(archivo.filename or "", _leer_subida(archivo, imp.MAX_BYTES))
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    principal = _moneda_principal(s, eid)
    existentes = s.exec(select(Producto).where(Producto.empresa_id == eid)).all()
    por_codigo = {str(p.codigo).strip().lower(): p for p in existentes if (p.codigo or "").strip()}
    por_nombre = {(p.nombre or "").strip().lower(): p for p in existentes}
    creados = actualizados = omitidos = 0
    errores: list[str] = []; avisos: list[str] = []
    bodega = None
    for f in filas:
        n = f["_fila"]; nombre = imp._texto(f.get("nombre")); codigo = imp._texto(f.get("codigo"))
        cabys = re.sub(r"\s", "", imp._texto(f.get("cabys")))
        etiqueta = nombre or f"fila {n}"
        try:
            precio = imp.numero(f.get("precio")); costo = imp.numero(f.get("costo")); existencia = imp.numero(f.get("existencia"))
            minimo = imp.numero(f.get("minimo")); maximo = imp.numero(f.get("maximo"))          # 3.87: existencia mínima y máxima (opcionales)
        except ValueError:
            errores.append(f"Fila {n} ({etiqueta}): precio, costo, existencia, mínimo o máximo no son números"); omitidos += 1; continue
        if not nombre or precio is None:
            errores.append(f"Fila {n}: faltan el nombre o el precio"); omitidos += 1; continue
        if precio < 0 or precio > 1e12 or (costo is not None and (costo < 0 or costo > 1e12)):
            errores.append(f"Fila {n} ({etiqueta}): precio o costo fuera de rango"); omitidos += 1; continue
        if len(codigo) > 20:
            errores.append(f"Fila {n} ({etiqueta}): el código «{codigo}» pasa de 20 caracteres (límite de Hacienda)"); omitidos += 1; continue
        t = imp.leer_tarifa(f.get("tarifa"))
        if t.get("problema"):
            errores.append(f"Fila {n} ({etiqueta}): {t['problema']}"); omitidos += 1; continue
        tipo_txt = imp._texto(f.get("tipo")); es_serv = "servicio" in tipo_txt.lower()
        unidad = imp._texto(f.get("unidad")) or "Unid"
        moneda = (imp._texto(f.get("moneda")) or principal).upper()
        categoria = imp._texto(f.get("categoria")) or None; descripcion = imp._texto(f.get("descripcion")) or None
        visible = imp._si(f.get("visible"))
        existente = por_codigo.get(codigo.lower()) if codigo else None
        if existente is None and not codigo:
            existente = por_nombre.get(nombre.lower())
        if existente is not None and modo == "crear":
            errores.append(f"Fila {n} ({etiqueta}): ya existe un ítem con ese {'código' if codigo else 'nombre'}; use el modo «actualizar» para cambiarlo"); omitidos += 1; continue
        if existente is not None:
            p = existente
            p.precio = float(precio); p.codigo_tarifa = t["codigo_tarifa"]; p.tarifa = imp.TARIFA_PCT[t["codigo_tarifa"]]; p.unidad_medida = unidad
            if costo is not None:
                p.costo = float(costo)
            if categoria is not None:
                p.categoria = categoria
            if descripcion is not None:
                p.descripcion = descripcion
            if cabys:
                p.cabys = cabys
            if visible is not None:
                p.visible_catalogo = visible
            if moneda:
                p.moneda = moneda
            if minimo is not None:
                p.existencia_minima = minimo
            if maximo is not None:
                p.existencia_maxima = maximo
        else:
            if not cabys and not _sin_fe(ctx):                   # 3.93: sin facturación electrónica el CABYS es opcional
                errores.append(f"Fila {n} ({etiqueta}): falta el código CABYS"); omitidos += 1; continue
            p = Producto(empresa_id=eid, codigo=codigo or None, nombre=nombre, cabys=cabys, precio=float(precio), unidad_medida=unidad, moneda=moneda,
                         es_servicio=es_serv, tipo="Servicio" if es_serv else "Producto", codigo_tarifa=t["codigo_tarifa"], tarifa=imp.TARIFA_PCT[t["codigo_tarifa"]],
                         categoria=categoria, descripcion=descripcion, costo=float(costo or 0), inventariable=not es_serv, visible_catalogo=bool(visible),
                         existencia_minima=minimo, existencia_maxima=maximo)
        try:
            _validar_producto(p, _sin_fe(ctx))
        except HTTPException as ex:
            if existente is not None:
                s.refresh(p)                                   # se descartan los cambios en memoria del ítem existente
            errores.append(f"Fila {n} ({etiqueta}): {ex.detail}"); omitidos += 1; continue
        if t.get("defecto"):
            avisos.append(f"Fila {n} ({etiqueta}): sin tarifa en el archivo, se asignó 13 % (código 08)")
        if existente is not None:
            actualizados += 1
            if existencia is not None:
                avisos.append(f"Fila {n} ({etiqueta}): la existencia solo se aplica al crear; ajústela en Inventario › Ajustes")
            if not solo_simular:
                s.add(p)
            continue
        creados += 1
        if solo_simular:
            if existencia:
                avisos.append(f"Fila {n} ({etiqueta}): entra con {existencia:g} en la bodega principal")
            por_nombre[nombre.lower()] = p
            if codigo:
                por_codigo[codigo.lower()] = p
            continue
        s.add(p); s.flush()
        por_nombre[nombre.lower()] = p
        if codigo:
            por_codigo[codigo.lower()] = p
        if existencia and p.inventariable and not p.es_servicio:
            if existencia < 0 or existencia > 1e12:
                avisos.append(f"Fila {n} ({etiqueta}): existencia fuera de rango, se creó sin inventario inicial"); continue
            bodega = bodega or inventario.bodega_principal(s, eid)
            inventario.registrar_movimiento(s, producto=p, bodega_id=bodega.id, tipo="inicial", cantidad=float(existencia),
                                            fecha=ahora_cr().strftime("%Y-%m-%d"), costo_unitario=p.costo or 0, referencia="Importación de ítems")
    if solo_simular:
        s.rollback()
    else:
        s.commit()
        _auditar(ctx, "productos_importados", f"{creados} ítem(s) creados y {actualizados} actualizados desde {archivo.filename or 'archivo'}")
    return {"simulado": solo_simular, "modo": modo, "filas": len(filas), "creados": creados, "actualizados": actualizados, "omitidos": omitidos, "errores": errores[:300], "avisos": avisos[:300]}


@app.put("/api/productos/{pid}")
def editar_producto(pid: int, cuerpo: dict, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    p = _producto(s, ctx.empresa.id, pid)
    if not p:
        raise HTTPException(404)
    # Solo los campos enviados (edición parcial: precios en bloque, categoría…): se validan sobre el producto completo
    # (antes un cuerpo sin nombre o cabys respondía 422 antes de llegar aquí)
    campos = {k: v for k, v in (cuerpo or {}).items() if k in ProductoIn.model_fields and k not in ("id", "cantidad_inicial", "bodega_id", "imagen_nombre")}
    try:
        data = ProductoIn(**{**{k: getattr(p, k) for k in ProductoIn.model_fields if hasattr(p, k)}, **campos})
    except ValueError as ex:
        raise HTTPException(400, _mensaje_pydantic(ex))
    for k in campos:
        setattr(p, k, getattr(data, k))
    _validar_producto(p, _sin_fe(ctx))
    s.add(p); s.commit(); s.refresh(p)
    return p


@app.post("/api/productos/{pid}/imagen")
def subir_imagen_producto(pid: int, archivo: UploadFile = File(...), ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    p = _producto(s, ctx.empresa.id, pid)
    if not p:
        raise HTTPException(404)
    ext = (archivo.filename or "img.png").rsplit(".", 1)[-1].lower()
    if ext not in ("png", "jpg", "jpeg", "webp"):
        raise HTTPException(400, "La imagen debe ser PNG, JPG o WEBP")
    nombre = f"producto_{pid}.{ext}"
    (_img_dir(ctx.empresa.id) / nombre).write_bytes(_leer_subida(archivo))
    p.imagen_nombre = nombre
    s.add(p); s.commit()
    return {"ok": True, "imagen": f"/api/productos/{pid}/imagen?v={int(datetime.now().timestamp())}"}


@app.get("/api/productos/{pid}/imagen")
def imagen_producto(pid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    p = _producto(s, ctx.empresa.id, pid)
    if not p or not p.imagen_nombre or not re.fullmatch(r"producto_\d+\.(png|jpg|jpeg|webp)", p.imagen_nombre or "") or not (_img_dir(ctx.empresa.id) / p.imagen_nombre).exists():
        raise HTTPException(404, "Sin imagen")
    return FileResponse(_img_dir(ctx.empresa.id) / p.imagen_nombre)


@app.delete("/api/productos/{pid}/imagen")
def quitar_imagen_producto(pid: int, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    p = _producto(s, ctx.empresa.id, pid)
    if p and p.imagen_nombre:
        (_img_dir(ctx.empresa.id) / p.imagen_nombre).unlink(missing_ok=True)
        p.imagen_nombre = None; s.add(p); s.commit()
    return {"ok": True}


@app.delete("/api/productos/{pid}")
def borrar_producto(pid: int, ctx: Contexto = Depends(requiere("catalogos")), s: Session = Depends(sesion_empresa)):
    p = _producto(s, ctx.empresa.id, pid)
    if not p:
        return {"ok": True}
    if s.exec(select(DocumentoLinea).where(DocumentoLinea.producto_id == pid).limit(1)).first() or \
            s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.producto_id == pid).limit(1)).first():
        # Ya fue facturado o tiene movimientos de inventario: se desactiva en lugar de borrarse (conserva la trazabilidad) (R114)
        p.activo = False; s.add(p); s.commit()
        return {"ok": True, "desactivado": True}
    for ex in s.exec(select(inventario.Existencia).where(inventario.Existencia.producto_id == pid)).all():
        s.delete(ex)
    for m in s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.producto_id == pid)).all():
        s.delete(m)
    s.delete(p); s.commit()
    return {"ok": True}


# ---------------------------------------------------------------- Hacienda / CABYS (públicos para usuarios autenticados)
@app.get("/api/hacienda/contribuyente/{identificacion}")
def contribuyente(identificacion: str, ctx: Contexto = Depends(contexto)):   # con sesión y límite por usuario (antes era pública) (R121)
    auth.limitar_ip(ctx.request, "consulta", 60, 300, "Demasiadas consultas a Hacienda en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    try:
        d = hacienda.consultar_contribuyente(identificacion)
    except RuntimeError as ex:
        raise HTTPException(502, str(ex))
    if not d:
        raise HTTPException(404, "No se encontró el contribuyente")
    return d


@app.get("/api/hacienda/cabys")
def cabys(q: str, ctx: Contexto = Depends(contexto)):
    """Busca en el catálogo CABYS oficial cargado localmente; si no está cargado, consulta la API de Hacienda."""
    if cabys_local.disponible():
        return cabys_local.buscar(q)
    auth.limitar_ip(ctx.request, "consulta", 60, 300, "Demasiadas consultas a Hacienda en pocos minutos; espere un momento", f"u{ctx.usuario.id}")
    try:
        return hacienda.buscar_cabys(q)
    except RuntimeError as ex:
        raise HTTPException(502, str(ex))


@app.get("/api/cabys/{codigo}")
def cabys_detalle(codigo: str, ctx: Contexto = Depends(contexto)):
    d = cabys_local.obtener(codigo)
    if not d and not cabys_local.disponible():                      # sin catálogo local: se pregunta a Hacienda (R285)
        try:
            d = next((x for x in hacienda.buscar_cabys(codigo, 5) if str(x.get("codigo")) == codigo), None)
        except RuntimeError as ex:
            raise HTTPException(503, str(ex))
    if not d:
        raise HTTPException(404, "Código CABYS no encontrado en el catálogo oficial")
    return d


@app.post("/api/cabys/importar")
def cabys_importar(a=Depends(auth.superadmin)):      # el catálogo CABYS es de la base central, compartido por todas las empresas (R128)
    return {"importados": cabys_local.importar_excel(reemplazar=True)}


# ---------------------------------------------------------------- comprobantes
class LineaIn(BaseModel):
    producto_id: Optional[int] = None
    cabys: Optional[str] = None
    detalle: Optional[str] = None
    cantidad: Decimal = Decimal(1)
    precio_unitario: Optional[Decimal] = None
    descuento: Decimal = Decimal(0)
    unidad_medida: Optional[str] = None
    es_servicio: Optional[bool] = None
    codigo_tarifa: Optional[str] = None
    tarifa: Optional[Decimal] = None
    exonerar: Optional[bool] = None           # con exoneración en el comprobante: None = según el CABYS autorizado; False = no aplicar
    otro_impuesto: Optional[Any] = None       # 3.41: None = el del ítem; {} = ninguno; dict = este (fe.modelos.otro_impuesto)

    @field_validator("cantidad")
    @classmethod
    def _cantidad_3_decimales(cls, v):
        # el XML escribe la cantidad con 3 decimales: el monto se calcula con la misma cantidad (antes 0,3333 × 1000 daba 333,30 y
        # el XML decía 0.333) (R81)
        if v is None or v <= 0:
            raise ValueError("La cantidad debe ser mayor que cero")
        if v > Decimal("9999999999"):
            raise ValueError("La cantidad es demasiado grande")
        try:
            return v.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP)
        except InvalidOperation:
            raise ValueError("Cantidad fuera de rango")


class ComprobanteIn(BaseModel):
    tipo_documento: str = "01"
    cliente_id: Optional[int] = None
    condicion_venta: str = "01"
    condicion_venta_otros: Optional[str] = None     # descripción obligatoria con la condición 99
    plazo_credito: Optional[int] = None
    medio_pago: str = "01"
    medio_pago_otros: Optional[str] = None          # descripción obligatoria con el medio 99
    moneda: str = "CRC"
    tipo_cambio: Decimal = Decimal("1")
    lineas: list[LineaIn]
    referencia_clave: Optional[str] = None
    referencia_fecha: Optional[str] = None
    referencia_codigo: str = "01"
    referencia_codigo_otro: Optional[str] = None      # descripción obligatoria cuando referencia_codigo == "99"
    referencia_razon: Optional[str] = None
    referencia_tipo_doc: Optional[str] = None         # FEC: tipo del documento del proveedor (14 régimen especial, 99 otro)
    referencia_tipo_doc_otro: Optional[str] = None
    referencia_numero: Optional[str] = None           # FEC: número del documento del proveedor
    observaciones: Optional[str] = None
    vendedor: Optional[str] = None
    fecha_vencimiento: Optional[str] = None
    bodega_id: Optional[int] = None
    pendiente_id: Optional[int] = None        # factura pendiente de una recurrencia que se emite con este comprobante
    borrador_id: Optional[int] = None         # borrador que se emite con este comprobante (se borra al emitir)
    actividad_emisor: Optional[str] = None    # actividad secundaria de la empresa para esta venta (6 dígitos); vacío = la principal (R53)
    terminos: Optional[str] = None            # términos y condiciones impresos en el PDF (R103)
    orden_compra: Optional[str] = None        # número de orden de compra del cliente: va en OtroTexto y en el PDF (R103)
    idempotencia: Optional[str] = None        # clave única del formulario: si llega repetida se devuelve el comprobante ya creado (R93)
    extra: Optional[dict] = None              # datos solo del formulario (términos, orden de compra, cotización): viajan en el borrador
    otros_cargos: list[dict] = Field(default_factory=list, max_length=15)   # [{tipo, detalle, porcentaje?, monto?}]: impuesto de servicio 10 %, timbres… (POS/restaurantes)
    marca_id: Optional[int] = None            # marca (logo y nombre comercial) del documento (3.45); vacío = la predeterminada o la empresa
    exoneracion_id: Optional[int] = None      # exoneración del cliente; en notas, None = la del comprobante de referencia y 0 = ninguna
    pos_terminal_id: Optional[int] = None     # 4.5: caja (pos_config.terminales[].id) desde la que vende el punto de venta
    pos_autorizacion: Optional[str] = None    # 4.5: token de POST /api/pos/autorizar (clave de supervisor) para pasar el descuento máximo de esa caja
    pedido_id: Optional[int] = None           # 4.9: pedido en línea (cuenta en espera de la caja) que se cobra con este comprobante: queda enlazado (Pedido.documento_id)
    pedido_parcial: bool = False              # 4.9: la caja cobra solo una parte del pedido (quedan partes o cuentas «aparte»): se enlaza, pero no pasa a entregado ni se avisa


CAT_TIPO = {"01": "FE", "02": "ND", "03": "NC", "04": "TE", "08": "FEC", "09": "FEE", "10": "REP"}
CONDICIONES_CREDITO = ("02", "08", "10")      # crédito, servicios al Estado a crédito, crédito con IVA hasta 90 días


def _vencimiento(data: "ComprobanteIn", ahora) -> str:
    """Fecha de vencimiento: la indicada; en ventas a crédito, si falta o no pasa de la emisión, emisión + plazo (antes
    quedaba igual a la emisión y desde el día siguiente la factura se contaba como vencida)."""
    hoy = ahora.strftime("%Y-%m-%d")
    venc = (data.fecha_vencimiento or "")[:10]
    if data.condicion_venta in CONDICIONES_CREDITO and (not venc or venc <= hoy):
        from datetime import timedelta as _td
        return (ahora + _td(days=int(data.plazo_credito or 30))).strftime("%Y-%m-%d")
    return venc or hoy
TIPOS_NUMERACION = {"01": "Factura electrónica", "04": "Tiquete electrónico", "03": "Nota de crédito", "02": "Nota de débito", "08": "Factura electrónica de compra", "09": "Factura de exportación", "10": "Recibo electrónico de pago"}


def _max_emitido(s: Session, eid: int, ambiente: str, tipo: str, sucursal: int | None = None) -> int:
    """Mayor número (10 dígitos finales del consecutivo) ya emitido en este ambiente para el tipo dado; 0 si ninguno.
    3.87: con `sucursal`, solo los de esa sucursal (3 primeros dígitos del consecutivo), igual que siembra _siguiente_numero."""
    cons = s.exec(select(Documento.consecutivo).where(Documento.empresa_id == eid, Documento.ambiente == ambiente,
                                                       Documento.tipo_documento == tipo)).all()
    pre = f"{int(sucursal):03d}" if sucursal else None
    return max((int(c[-10:]) for c in cons if c and c[-10:].isdigit() and (pre is None or c[:3] == pre)), default=0)


def _sucursal_numeracion(ctx: Contexto, tipo: str) -> int:
    """3.87: código de sucursal con que sale el tipo: el de la sucursal activa (fija o elegida), como en crear_comprobante; sin
    sucursal, y siempre el recibo de pago (REP), la principal. Antes Numeraciones mostraba y ajustaba siempre la serie de la principal."""
    suc = getattr(ctx, "sucursal", None)
    return int(suc.codigo) if suc is not None and tipo != "10" else int(ctx.empresa.sucursal or 1)


def _numeracion(s: Session, e: Empresa, tipo: str, sucursal: int | None = None) -> dict:
    cod = int(sucursal or e.sucursal or 1)
    seq = s.exec(select(Secuencia).where(Secuencia.empresa_id == e.id, Secuencia.tipo_documento == tipo, Secuencia.ambiente == e.ambiente, Secuencia.sucursal == cod)).first()
    ultimo = seq.ultimo if seq else 0
    minimo = _max_emitido(s, e.id, e.ambiente, tipo, cod)
    emitidos = sum(1 for c in s.exec(select(Documento.consecutivo).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente,
                                                                       Documento.tipo_documento == tipo)).all() if (c or "")[:3] == f"{cod:03d}")
    return {"tipo": tipo, "nombre": TIPOS_NUMERACION[tipo], "ultimo": ultimo, "minimo": minimo, "emitidos": emitidos, "sucursal": cod,
            "proximo": generar_consecutivo(tipo, ultimo + 1, cod, e.terminal)}


@app.get("/api/numeraciones")
def numeraciones(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Consecutivos por tipo de documento en el ambiente activo y la sucursal activa (último usado, mínimo permitido, próximo a emitir)."""
    e = ctx.empresa
    return {"ambiente": e.ambiente, "sucursal": _sucursal_numeracion(ctx, "01"), "terminal": e.terminal,
            "numeraciones": [_numeracion(s, e, t, _sucursal_numeracion(ctx, t)) for t in TIPOS_NUMERACION]}


class NumeracionIn(BaseModel):
    ultimo: int = Field(ge=0, le=9_999_999_998)     # último número usado; el próximo comprobante sale con ultimo + 1 (9.999.999.999 dejaba la serie sin siguiente) (R246)


@app.put("/api/numeraciones/{tipo}")
def poner_numeracion(tipo: str, data: NumeracionIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    """Fija el último consecutivo usado (p. ej. para continuar la numeración de un sistema anterior). Nunca puede quedar
    por debajo de lo ya emitido aquí en el ambiente activo: evitaría duplicados que Hacienda y el índice único rechazarían."""
    e = ctx.empresa
    if tipo not in TIPOS_NUMERACION:
        raise HTTPException(404, "Tipo de documento desconocido")
    cod = _sucursal_numeracion(ctx, tipo)                        # 3.87: la serie de la sucursal activa (antes la principal con el mínimo de todas)
    minimo = _max_emitido(s, e.id, e.ambiente, tipo, cod)
    if data.ultimo < minimo:
        raise HTTPException(400, f"El último número no puede ser menor que {minimo}, el mayor consecutivo ya emitido en esta sucursal y ambiente")
    seq = s.exec(select(Secuencia).where(Secuencia.empresa_id == e.id, Secuencia.tipo_documento == tipo, Secuencia.ambiente == e.ambiente, Secuencia.sucursal == cod)).first()
    anterior = seq.ultimo if seq else 0
    if seq is None:
        seq = Secuencia(empresa_id=e.id, tipo_documento=tipo, ambiente=e.ambiente, sucursal=cod, ultimo=0)
    seq.ultimo = data.ultimo
    s.add(seq); s.commit()
    _auditar(ctx, "numeracion_modificada", f"{TIPOS_NUMERACION[tipo]} ({e.ambiente}, sucursal {cod:03d}): último {anterior} → {data.ultimo}; "
                                            f"próximo {generar_consecutivo(tipo, data.ultimo + 1, cod, e.terminal)}")
    return _numeracion(s, e, tipo, cod)


def _ambiente_de(empresa_id: int) -> str:
    with Session(engine) as sc:
        emp = sc.get(Empresa, empresa_id)
        return (emp.ambiente if emp else "") or "sandbox"


def _sucursal_de(empresa_id: int) -> int:
    with Session(engine) as sc:
        e = sc.get(Empresa, empresa_id)
        return int(getattr(e, "sucursal", 1) or 1) if e else 1


def _siguiente_numero(s: Session, empresa_id: int, tipo: str, ambiente: str | None = None, sucursal: int | None = None) -> int:
    """Incremento atómico en SQL: el UPDATE toma el lock de escritura antes de leer, así dos procesos o hilos que emitan
    a la vez nunca reciben el mismo consecutivo (con leer-sumar-escribir en Python sí ocurría). Si la petición falla
    después (XSD, firma), la transacción se revierte y el número no se consume."""
    sc = int(sucursal or _sucursal_de(empresa_id))
    p = {"e": empresa_id, "t": tipo, "a": ambiente or _ambiente_de(empresa_id), "s": sc, "s3": f"{sc:03d}"}
    # la fila nueva de un ambiente (y sucursal, 3.66) se siembra con el mayor consecutivo ya emitido en él (documentos previos a la 1.14)
    s.execute(text("INSERT INTO secuencia (empresa_id, tipo_documento, ambiente, sucursal, ultimo) SELECT :e, :t, :a, :s, "
                   "COALESCE((SELECT MAX(CAST(substr(consecutivo, -10) AS INTEGER)) FROM documento WHERE empresa_id = :e AND ambiente = :a AND tipo_documento = :t AND substr(consecutivo, 1, 3) = :s3), 0) "
                   "WHERE NOT EXISTS (SELECT 1 FROM secuencia WHERE empresa_id = :e AND tipo_documento = :t AND ambiente = :a AND sucursal = :s)"), p)
    s.execute(text("UPDATE secuencia SET ultimo = ultimo + 1 WHERE empresa_id = :e AND tipo_documento = :t AND ambiente = :a AND sucursal = :s"), p)
    return int(s.execute(text("SELECT ultimo FROM secuencia WHERE empresa_id = :e AND tipo_documento = :t AND ambiente = :a AND sucursal = :s"), p).scalar_one())


def _cedula_para_clave(e) -> str:
    """4.21: la identificación del emisor que va dentro del número de cada comprobante (12 posiciones, de 9 a 12 letras o dígitos). Un
    comprobante interno nunca va a Hacienda: si la empresa SIN facturación electrónica tiene una identificación vacía, corta o larga (un
    «No contribuyente», un pasaporte, una cédula jurídica alfanumérica larga), se usa un relleno propio con el número de la empresa para
    que pueda vender. Con la facturación electrónica encendida no cambia nada: ahí la identificación tiene que servirle a Hacienda."""
    n = re.sub(r"[^A-Za-z0-9]", "", getattr(e, "numero_id", "") or "")
    if getattr(e, "factura_electronica", True) is False and not 9 <= len(n) <= 12:
        return f"{int(e.id or 0):012d}"
    return e.numero_id


def _parte_empresa(e: Empresa) -> Parte:
    # 3.99: sin facturación electrónica (comprobante interno) la actividad y la dirección son opcionales: si faltan, no detienen la emisión
    sin_fe = getattr(e, "factura_electronica", True) is False
    ubic_ok = bool(e.provincia and e.canton and e.distrito and len((e.otras_senas or "").strip()) >= 5)
    return Parte(
        nombre=e.nombre, identificacion=Identificacion(tipo=e.tipo_id, numero=e.numero_id),
        nombre_comercial=e.nombre_comercial, actividad=((e.actividad or "").strip() or None) if sin_fe else e.actividad,
        ubicacion=Ubicacion(provincia=e.provincia, canton=e.canton, distrito=e.distrito, barrio=e.barrio, otras_senas=e.otras_senas) if (ubic_ok or not sin_fe)
        else Ubicacion(provincia=e.provincia or 1, canton=e.canton or 1, distrito=e.distrito or 1, otras_senas=(e.otras_senas or "").strip() if len((e.otras_senas or "").strip()) >= 5 else "Costa Rica"),
        telefono=Telefono(numero=e.telefono) if e.telefono and telefono_valido(e.telefono) else None, correo=e.correo,
        registro_fiscal=(e.registro_fiscal_8707 or "").strip() or None,
    )


def _parte_cliente(c: Cliente) -> Parte:
    ubic = None
    if c.provincia and c.canton and c.distrito and c.direccion and len(c.direccion) >= 5:
        ubic = Ubicacion(provincia=c.provincia, canton=c.canton, distrito=c.distrito, barrio=c.barrio or None, otras_senas=c.direccion)
    ident = None if _sin_identificacion(c) else Identificacion(tipo=c.tipo_id, numero=c.numero_id)
    return Parte(nombre=c.nombre, identificacion=ident, ubicacion=ubic,
                 telefono=Telefono(numero=c.telefono) if c.telefono and telefono_valido(c.telefono) else None, correo=c.correo or None,
                 actividad=c.actividad or None)


def _parte_cliente_laxa(c: Cliente) -> Parte:
    """4.2: sin facturación electrónica (comprobante interno), un contacto con datos que Hacienda no admitiría no detiene la venta:
    va con lo que sí es válido (como mínimo, su nombre)."""
    try:
        return _parte_cliente(c)
    except ValueError:
        pass
    nombre = (c.nombre or "").strip()
    nombre = (nombre if len(nombre) >= 3 else (nombre + " (cliente)").strip())[:100]
    try:
        ident = None if _sin_identificacion(c) else Identificacion(tipo=c.tipo_id, numero=c.numero_id)
    except ValueError:
        ident = None
    return Parte(nombre=nombre, identificacion=ident, correo=c.correo or None)


_CAMPOS_HACIENDA = {"otras_senas": "Dirección exacta (otras señas)", "nombre": "Nombre", "nombre_comercial": "Nombre comercial",
                    "numero": "Número de identificación", "tipo": "Tipo de identificación", "correo": "Correo", "actividad": "Actividad económica",
                    "provincia": "Provincia", "canton": "Cantón", "distrito": "Distrito", "barrio": "Barrio", "telefono": "Teléfono",
                    "registro_fiscal": "Registro fiscal"}


def _explicar_hacienda(ex: Exception) -> str:
    """4.2: qué dato falla y por qué, en palabras (antes: «String should have at least 5 characters», sin decir cuál)."""
    errores = getattr(ex, "errors", None)
    if not callable(errores):
        return str(ex)
    partes = []
    try:
        for er in errores():
            campo = next((p for p in reversed(tuple(er.get("loc") or ())) if isinstance(p, str) and p in _CAMPOS_HACIENDA), None)
            t, c = er.get("type", ""), er.get("ctx") or {}
            if t == "string_too_short":
                msg = f"debe tener al menos {c.get('min_length')} caracteres"
            elif t == "string_too_long":
                msg = f"admite como máximo {c.get('max_length')} caracteres"
            elif t == "missing":
                msg = "es obligatorio"
            elif t.startswith(("int_", "greater_than", "less_than")):
                msg = "falta o no es válido"
            else:
                msg = str(er.get("msg", "")).replace("Value error, ", "")
            partes.append(f"{_CAMPOS_HACIENDA[campo]}: {msg}" if campo else msg)
    except Exception:  # noqa: BLE001
        return _mensaje_pydantic(ex)
    return "; ".join(partes) or _mensaje_pydantic(ex)


def _mensaje_pydantic(ex: Exception) -> str:
    """Primer mensaje legible de un ValidationError (sin el prefijo técnico 'Value error, ')."""
    errores = getattr(ex, "errors", None)
    if callable(errores):
        try:
            return "; ".join(str(e.get("msg", "")).replace("Value error, ", "") for e in errores())
        except Exception:
            pass
    return str(ex)


# ---- borradores: comprobantes guardados sin emitir (sin consecutivo, sin firma, sin inventario; la cola no los ve) ----
_NOMBRE_IMP = {"02": "Impuesto Selectivo de Consumo", "03": "Impuesto único a los combustibles", "04": "Impuesto específico de bebidas alcohólicas",
               "05": "Impuesto específico de bebidas sin alcohol y jabones", "06": "Impuesto a los productos de tabaco", "12": "Impuesto específico al cemento"}


def _total_borrador(data: "ComprobanteIn", exo=None) -> float:
    """Total aproximado para la lista (cantidad × precio − descuento + IVA por línea, menos la exoneración que aplicaría). El total
    real sale al emitir."""
    total = 0.0
    for li in data.lineas:
        try:
            base = float(li.cantidad or 0) * float(li.precio_unitario or 0) - float(li.descuento or 0)
            tarifa = float(li.tarifa if li.tarifa is not None else 0)
            if exo is not None and li.exonerar is not False and (li.codigo_tarifa or "08") != "10" and tarifa > 0 and exoneraciones.cubre(exo, li.cabys or ""):
                tarifa -= min(float(exo.tarifa or 0), tarifa)
            total += base * (1 + tarifa / 100)
        except (TypeError, ValueError):
            continue
    neto = sum((float(li.cantidad or 0) * float(li.precio_unitario or 0) - float(li.descuento or 0)) for li in data.lineas if li.cantidad is not None and li.precio_unitario is not None)
    for oc in data.otros_cargos or []:
        try:
            m = float(oc.get("monto") or 0) if isinstance(oc, dict) else 0
            if not m and isinstance(oc, dict) and oc.get("porcentaje") not in (None, ""):
                m = neto * float(oc.get("porcentaje")) / 100
            if m > 0 and m < 1e13:
                total += m
        except (TypeError, ValueError):
            continue
    return round(total, 2)


def _exo_borrador(s: Session, eid: int, data: "ComprobanteIn", cliente):
    """Exoneración del borrador para su total aproximado (sin validar vigencia: eso se hace al emitir)."""
    if not (data.exoneracion_id and cliente):
        return None
    x = s.get(exoneraciones.ExoneracionCliente, data.exoneracion_id)
    return x if x and x.empresa_id == eid and x.cliente_id == cliente.id else None


def _borrador_dict(b: modulos.Borrador) -> dict:
    return {"id": b.id, "tipo_documento": b.tipo_documento, "cliente_id": b.cliente_id, "receptor_nombre": b.receptor_nombre, "moneda": b.moneda,
            "total": b.total, "usuario": b.usuario, "creado": b.creado, "actualizado": b.actualizado, "estado": "borrador", "datos": json.loads(b.datos or "{}")}


@app.get("/api/borradores", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def listar_borradores(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _exigir_ventas(ctx, "los borradores")                                 # 3.87
    if auth.solo_pos(ctx.permisos):
        raise HTTPException(403, "Su rol no tiene acceso a los borradores")
    return [_borrador_dict(b) for b in s.exec(select(modulos.Borrador).where(modulos.Borrador.empresa_id == ctx.empresa.id).order_by(modulos.Borrador.id.desc())).all()]


@app.post("/api/borradores")
def crear_borrador(data: ComprobanteIn, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    cliente = _cliente(s, ctx.empresa.id, data.cliente_id) if data.cliente_id else None
    b = modulos.Borrador(empresa_id=ctx.empresa.id, tipo_documento=data.tipo_documento, cliente_id=cliente.id if cliente else None,
                         receptor_nombre=cliente.nombre if cliente else None, moneda=data.moneda, total=_total_borrador(data, _exo_borrador(s, ctx.empresa.id, data, cliente)),
                         datos=data.model_dump_json(), usuario=ctx.usuario.correo)
    s.add(b); s.commit(); s.refresh(b)
    return _borrador_dict(b)


@app.put("/api/borradores/{bid}")
def editar_borrador(bid: int, data: ComprobanteIn, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    _clinicas.bloquear_edicion(s, ctx.empresa.id, bid)
    b = s.get(modulos.Borrador, bid)
    if not b or b.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Borrador no encontrado")
    cliente = _cliente(s, ctx.empresa.id, data.cliente_id) if data.cliente_id else None
    b.tipo_documento = data.tipo_documento; b.cliente_id = cliente.id if cliente else None; b.receptor_nombre = cliente.nombre if cliente else None
    b.moneda = data.moneda; b.total = _total_borrador(data, _exo_borrador(s, ctx.empresa.id, data, cliente)); b.datos = data.model_dump_json(); b.actualizado = datetime.now(timezone.utc)
    s.add(b); s.commit(); s.refresh(b)
    return _borrador_dict(b)


@app.delete("/api/borradores/{bid}")
def eliminar_borrador(bid: int, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    b = s.get(modulos.Borrador, bid)
    if not b or b.empresa_id != ctx.empresa.id:
        raise HTTPException(404, "Borrador no encontrado")
    from . import tike_contratos as _tc       # 3.87: si salió de un ticket de TiKe, sus horas y repuestos vuelven a quedar por cobrar
    _tc.liberar_borrador(s, ctx.empresa.id, b, getattr(ctx.usuario, "nombre", "") or "")
    _clinicas.enlazar_borrador(s, ctx.empresa.id, b)
    s.delete(b); s.commit()
    return {"ok": True}


# ---- 4.5: lo que la pantalla de la caja limitaba sola (descuento máximo por línea y clave de supervisor) lo revisa también el
# servidor para un usuario de solo caja (Cajero): por POST /api/comprobantes mandaba cualquier descuento.
AUTORIZACION_POS_SEGUNDOS = 15 * 60       # vigencia del token de la clave de supervisor (la venta en curso, con margen)


def _terminales_pos(s: Session, eid: int) -> list:
    """Cajas de pos_config ({terminales: [...]}); la configuración vieja de una sola caja (1.22) cuenta como la caja 1."""
    cfg = modulos.leer(s, eid, "pos_config", None)
    if not isinstance(cfg, dict) or not cfg:
        return []
    lista = [t for t in cfg.get("terminales") if isinstance(t, dict)] if isinstance(cfg.get("terminales"), list) else []
    return lista or [{**cfg, "id": 1}]


def _descuento_max_pos(t: dict) -> float:
    """descuento_max_pct como lo aplica caja.js (descuentoPct): Math.min(100, +x || 100); vacío o 0 = sin límite."""
    try:
        pct = float(t.get("descuento_max_pct") or 0)
    except (TypeError, ValueError):
        pct = 0.0
    return min(100.0, pct) if pct > 0 else 100.0


def _terminal_pos(terminales: list, terminal_id) -> Optional[dict]:
    """La caja pedida; si no viene o no existe, la más estricta: omitir pos_terminal_id no afloja nada."""
    if not terminales:
        return None
    tid = modulos._id_entero(terminal_id)
    return next((t for t in terminales if tid is not None and modulos._id_entero(t.get("id")) == tid), None) or min(terminales, key=_descuento_max_pos)


def _claves_pos(texto) -> set:
    """Las dos formas en que la caja resume la clave de supervisor (hashClave de pos/_datos.js): SHA-256 y, sin crypto.subtle
    (http sin TLS), djb2. pos_config.terminales[].clave_supervisor guarda una de ellas, nunca la clave en claro."""
    import hashlib
    t = str(texto or "").strip()
    if not t:
        return set()
    h = 5381
    for ch in "fe-pos:" + t:
        h = ((h * 33) ^ ord(ch)) & 0xFFFFFFFF
    return {"sha:" + hashlib.sha256(("fe-pos:" + t).encode("utf-8")).hexdigest(), "djb:" + format(h, "x")}


def _autorizacion_pos_valida(ctx: Contexto, token, terminal: dict) -> bool:
    """Token de /api/pos/autorizar de este usuario, esta empresa y esta caja, sin vencer."""
    d = auth.abrir(str(token)) if token else None
    return bool(d and d.get("tipo") == "pos_aut" and d.get("uid") == ctx.usuario.id and d.get("eid") == ctx.empresa.id
                and modulos._id_entero(d.get("term")) == modulos._id_entero(terminal.get("id")))


def _revisar_descuento_pos(s: Session, ctx: Contexto, data: "ComprobanteIn") -> None:
    """Venta (contado o fiado) de un usuario de solo caja: el descuento de cada línea no pasa del máximo de su caja salvo con la
    autorización de un supervisor (pos_autorizacion). Las promociones, cupones y puntos que la pantalla aplica por encima del
    máximo también la piden (caja.js la solicita antes de cobrar); con el 100 % de TERMINAL_BASE nada cambia."""
    if not auth.solo_pos(ctx.permisos) or data.tipo_documento not in ("01", "04"):
        return
    term = _terminal_pos(_terminales_pos(s, ctx.empresa.id), data.pos_terminal_id)
    if term is None:
        return
    maximo = _descuento_max_pos(term)
    if maximo >= 100:
        return
    for n, li in enumerate(data.lineas or [], start=1):
        precio = li.precio_unitario
        if precio is None and li.producto_id:                 # sin precio en la línea se factura el del ítem
            p = _producto(s, ctx.empresa.id, li.producto_id)
            precio = _precio_en_moneda(p, data.moneda, data.tipo_cambio) if p else None
        try:
            bruto, desc = float(li.cantidad or 0) * float(precio or 0), float(li.descuento or 0)
        except (TypeError, ValueError, ArithmeticError):
            continue
        if desc <= bruto * maximo / 100 + 0.005:
            continue
        if _autorizacion_pos_valida(ctx, data.pos_autorizacion, term):
            return
        raise HTTPException(403, f"Línea {n}: el descuento ({desc:,.2f}) supera el {maximo:g} % permitido en {term.get('nombre') or 'esta caja'}; pida a un "
                                 "supervisor que lo autorice con su clave" + ("" if term.get("clave_supervisor") else
                                                                               " (la caja no tiene clave de supervisor: configúrela en Punto de venta › Configuración o suba el descuento máximo)"))


class AutorizacionPosIn(BaseModel):
    terminal_id: Optional[int] = None
    clave: str = Field(min_length=1, max_length=200)
    accion: Optional[str] = None


@app.post("/api/pos/autorizar")
def autorizar_pos(data: AutorizacionPosIn, ctx: Contexto = Depends(requiere("pos")), s: Session = Depends(sesion_empresa)):
    """4.5: la clave de supervisor se comprueba en el servidor y devuelve un token corto que la caja manda con la venta
    (pos_autorizacion). Antes solo la comparaba la pantalla con el resumen guardado en pos_config, que el Cajero también lee."""
    aviso_lim = "Demasiados intentos con la clave de supervisor; espere unos minutos"
    if ctx.request is not None:
        auth.limitar_ip(ctx.request, "pos_aut", 10, 300, aviso_lim, registrar=False)        # solo revisa el cupo: las claves correctas no cuentan
    term = _terminal_pos(_terminales_pos(s, ctx.empresa.id), data.terminal_id)
    if term is None or not term.get("clave_supervisor"):
        raise HTTPException(400, "Esta caja no tiene clave de supervisor: configúrela en Punto de venta › Configuración")
    if term.get("clave_supervisor") not in _claves_pos(data.clave):
        if ctx.request is not None:
            auth.limitar_ip(ctx.request, "pos_aut", 10, 300, aviso_lim)                      # cuenta el fallo (10 en 5 minutos por conexión)
        raise HTTPException(403, "Clave de supervisor incorrecta")
    tid = modulos._id_entero(term.get("id"))
    _auditar(ctx, "pos_autorizacion", f"{term.get('nombre') or 'Caja'}: {str(data.accion or 'autorización de supervisor')[:120]}")
    return {"token": auth.firmar({"tipo": "pos_aut", "uid": ctx.usuario.id, "eid": ctx.empresa.id, "term": tid}, AUTORIZACION_POS_SEGUNDOS), "terminal_id": tid}


@app.post("/api/comprobantes")
def crear_comprobante(data: ComprobanteIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    # la factura de compra (08) la emite quien lleva gastos (Contador); lo demás, quien factura (R134)
    if data.tipo_documento == "08":
        if not (ctx.puede("gastos") or ctx.puede("facturar")):
            raise HTTPException(403, "Su rol no puede emitir facturas de compra")
    elif ctx.puede("pos") and data.tipo_documento in ("01", "04") and data.condicion_venta == "01":
        pass                                   # cajero del punto de venta: tiquetes y facturas de contado
    elif ctx.puede("pos") and data.tipo_documento in ("01", "04") and data.condicion_venta == "02" and data.cliente_id \
            and not (ctx.puede("facturar") and not ((getattr(_cliente(s, ctx.empresa.id, data.cliente_id), "limite_credito", None) or 0) > 0)):
        # 3.87: quien factura (Administrador, Avanzado, Vendedor) emite a crédito desde Ingresos a un cliente sin límite: va al else, que
        # exige «facturar», como en Facturación y Servicios. El fiado del Cajero (solo «pos») y toda venta a crédito a un cliente CON
        # límite siguen con esta revisión
        # fiado desde la caja (3.23): a crédito solo a un cliente con límite de crédito y sin pasarse de él (lo pendiente + esta venta)
        cli_f = _cliente(s, ctx.empresa.id, data.cliente_id)
        if not cli_f or not (cli_f.limite_credito or 0) > 0:
            raise HTTPException(403, "Desde la caja solo se fía a clientes con límite de crédito definido en Contactos")
        # 4.9: lo que debe, con las reglas del crédito de la revendedora (pedidos.creditos_contactos, el que revisa el pedido a crédito de la
        # página) y de Cuentas por cobrar: del ambiente de Hacienda activo, 01/02/04/09 en condición de crédito (02/08/10), sin rechazados (el
        # «error» se sigue debiendo). Antes contaba todos los ambientes y cualquier condición distinta de 01: la caja rechazaba el fiado de un
        # pedido que la página ya había aceptado. Sin «en pedidos»: la cuenta del pedido que se cobra sigue en la espera y contaría dos veces.
        docs_f = s.exec(select(Documento).where(Documento.empresa_id == ctx.empresa.id, Documento.cliente_id == cli_f.id, Documento.ambiente == ctx.empresa.ambiente,
                                                Documento.tipo_documento.in_(_pedidos.TIPOS_SALDO), Documento.condicion_venta.in_(CONDICIONES_CREDITO),
                                                Documento.estado != "rechazado")).all()
        # 4.9: en la moneda principal, como creditos_contactos (el límite está en ella): antes sumaba cada saldo en la moneda de su documento
        # (₡45.200 contra un límite de $500, o $100 como si fueran ₡100)
        conv_f = _pedidos.conversor(s, ctx.empresa.id)
        debe = sum(max(0.0, conv_f(modulos.saldo_documento(d), d.moneda, d.tipo_cambio)) for d in docs_f)
        nueva = 0.0
        for ln in data.lineas or []:
            try:
                nueva += max(0.0, float(ln.cantidad or 0) * float(ln.precio_unitario or 0) - float(ln.descuento or 0)) * (1 + float(ln.tarifa or 0) / 100)
            except (TypeError, ValueError, AttributeError):
                pass
        nueva = conv_f(nueva, data.moneda, data.tipo_cambio)
        # 4.9: lo ya pagado con tarjeta de regalo del pedido a crédito no se fía: la caja lo aplica sin cuenta al emitir (hallazgo 14) y la
        # página ya lo descontó (pedidos_en_credito y el checkout). Sin esto, la caja recibía un 403 por un fiado que sí cabía
        try:
            ped_f = s.get(_pedidos.Pedido, int(data.pedido_id)) if data.pedido_id else None
        except (TypeError, ValueError):
            ped_f = None
        if ped_f is not None and ped_f.empresa_id == ctx.empresa.id and ped_f.a_credito and ped_f.contacto_id == cli_f.id:
            pre_f = _pedidos.prepago_pendiente(s, ctx.empresa.id, ped_f)   # los montos del pedido están en colones
            if pre_f > 0:
                nueva = max(0.0, nueva - conv_f(pre_f, "CRC", data.tipo_cambio))
        # 4.9: el reenvío de un fiado ya emitido (respuesta perdida, R93) no se revisa otra vez: docs_f ya cuenta su propio saldo y respondía 403
        # («No se emitió» con el tiquete emitido); la idempotencia de abajo devuelve lo ya creado
        ya_f = s.exec(select(Documento.id).where(Documento.empresa_id == ctx.empresa.id, Documento.idempotencia == data.idempotencia)).first() if data.idempotencia else None
        if ya_f is None and debe + nueva > float(cli_f.limite_credito) + 0.005:
            raise HTTPException(403, f"{cli_f.nombre} debe {debe:,.2f} y con esta venta ({nueva:,.2f}) pasa su límite de {float(cli_f.limite_credito):,.2f}: no se puede fiar")
    else:
        ctx.exigir("facturar")
    e = ctx.empresa
    # Reenvío del mismo formulario (corte de red justo después de emitir): se devuelve lo ya creado, sin otro consecutivo (R93)
    if data.idempotencia:
        ya = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.idempotencia == data.idempotencia)).first()
        if ya:
            return ya
    _clinicas.validar_emision(s, ctx.empresa.id, data)
    _revisar_descuento_pos(s, ctx, data)       # 4.5: el descuento máximo de la caja (y la clave de supervisor) también en el servidor; va después de la idempotencia: el reenvío de una venta ya emitida devuelve lo creado sin volver a pedir el token (vence a los 15 min)
    planes.verificar_emision(s, e)                 # límite de documentos del plan (3.16)
    cliente = _cliente(s, e.id, data.cliente_id) if data.cliente_id else None
    # Nota de crédito/débito de un tiquete sin receptor: tampoco lleva receptor (el XSD lo permite) (R76)
    nota_de_tiquete = data.tipo_documento in ("02", "03") and (data.referencia_clave or "")[29:31] == "04"
    if data.tipo_documento != "04" and not cliente and not nota_de_tiquete:
        raise HTTPException(400, "Este tipo de documento requiere un cliente (receptor)")
    if cliente and _sin_identificacion(cliente) and data.tipo_documento != "04" and not nota_de_tiquete:
        raise HTTPException(400, f"{cliente.nombre} no tiene identificación y Hacienda la exige en este comprobante. "
                                 "Agréguela en Contactos o emita un tiquete electrónico")

    # Exoneración del cliente (Anexos v4.4): se valida (vigencia, beneficiario, tipo permitido; Hacienda si la verificación tiene
    # más de 24 h) y se aplica a las líneas gravadas con CABYS autorizado. Las notas heredan la del comprobante que corrigen.
    exo, exo_aviso, exo_id = None, None, data.exoneracion_id
    heredada = False
    if data.tipo_documento in ("02", "03") and data.referencia_clave:
        ref_exo = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.clave == data.referencia_clave)).first()
        if ref_exo is not None and ref_exo.exoneracion_id:
            if exo_id is None or exo_id == ref_exo.exoneracion_id:
                exo_id, heredada = ref_exo.exoneracion_id, True
    if exo_id:
        exo, exo_aviso = exoneraciones.para_documento(s, e.id, exo_id, cliente, data.tipo_documento, heredada=heredada)
    exo_ref: dict[str, Decimal] = {}          # nota heredada: CABYS exonerados en la factura y la tarifa exonerada que llevaron
    if heredada:
        for rl in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == ref_exo.id)).all():
            if (rl.iva_exonerado or 0) > 0 and rl.tarifa_exonerada:
                exo_ref.setdefault(rl.cabys, Decimal(str(rl.tarifa_exonerada)))

    lineas = []
    for n_linea, li in enumerate(data.lineas, start=1):
        p = _producto(s, e.id, li.producto_id) if li.producto_id else None
        if p is not None and getattr(p, "es_venta", True) is False:
            raise HTTPException(400, f"«{p.nombre}» es un insumo y no se vende: véndalo a través de una receta o encienda «Se vende» en el ítem")
        # línea escrita a mano: el CABYS dice si es servicio (capítulos 5 a 9) y la unidad acompaña (R79)
        if li.es_servicio is None and p is None and (li.cabys or "")[:1] in "56789":
            li.es_servicio = True
            if not li.unidad_medida:
                li.unidad_medida = "Sp"
        if not p and not ((li.cabys or _sin_fe(ctx)) and li.detalle and li.precio_unitario is not None):   # 3.93: sin FE, la línea a mano no pide CABYS
            raise HTTPException(400, "Cada línea requiere producto o bien CABYS, detalle y precio" if not _sin_fe(ctx) else "Cada línea requiere producto o bien detalle y precio")
        tarifa_cod = li.codigo_tarifa or (p.codigo_tarifa if p else "08")
        tarifa = li.tarifa if li.tarifa is not None else Decimal(str(p.tarifa)) if p else Decimal(13)
        if data.tipo_documento == "09":           # exportación: sin IVA (antes cada línea tomaba el 13 % del producto) (R77)
            tarifa_cod, tarifa = "01", Decimal(0)
        exo_linea = None
        cabys_linea = li.cabys or (p.cabys if p else "")
        if exo is not None and li.exonerar is not False and tarifa_cod not in ("10",) and Decimal(tarifa or 0) > 0:
            if heredada and cabys_linea not in exo_ref:
                if li.exonerar:
                    raise HTTPException(400, f"Línea {n_linea}: el CABYS {cabys_linea} no llevó exoneración en el comprobante que se corrige")
            elif heredada or exoneraciones.cubre(exo, cabys_linea):
                try:
                    exo_linea = exoneraciones.modelo_fe(exo, Decimal(tarifa), exo_ref.get(cabys_linea) if heredada else None)
                except ValueError as ex:
                    raise HTTPException(400, f"Exoneración {exo.numero}: {_mensaje_pydantic(ex)}. Corrija sus datos en la ficha del cliente")
            elif li.exonerar:
                raise HTTPException(400, f"Línea {n_linea}: el CABYS {cabys_linea} no está autorizado en la exoneración {exo.numero}")
        elif exo is None and li.exonerar:
            raise HTTPException(400, f"Línea {n_linea}: marcada como exonerada pero el comprobante no tiene exoneración")
        # 3.41: Selectivo de Consumo o impuesto específico (el de la línea o, si no viene, el del ítem); la exportación no los lleva
        from .fe.modelos import otro_impuesto as _otro_imp, ESPECIFICOS as _ESPEC
        try:
            otro = _otro_imp(li.otro_impuesto if li.otro_impuesto is not None else (getattr(p, "otro_impuesto", None) if p else None))
        except (ValueError, TypeError, ArithmeticError) as ex:
            raise HTTPException(400, f"Línea {n_linea}: otro impuesto: {_mensaje_pydantic(ex)}")
        if data.tipo_documento == "09":
            otro = None
        elif otro is not None and (data.moneda or "CRC") != "CRC" and Decimal(str(data.tipo_cambio or 0)) > 0:
            # los montos fijos que fija Hacienda son en colones: en un comprobante en otra moneda van al tipo de cambio del documento
            _tc = Decimal(str(data.tipo_cambio))
            if otro.monto_unidad is not None:
                otro = otro.model_copy(update={"monto_unidad": (otro.monto_unidad / _tc).quantize(Decimal("0.00001"))})
            if otro.especifico is not None:
                otro = otro.model_copy(update={"especifico": otro.especifico.model_copy(update={"impuesto_unidad": (otro.especifico.impuesto_unidad / _tc).quantize(Decimal("0.00001"))})})
        if otro is not None and otro.codigo in _ESPEC and data.tipo_documento == "08":
            raise HTTPException(400, f"Línea {n_linea}: la factura de compra no admite impuestos específicos (combustibles, bebidas, tabaco)")
        cabys_l = li.cabys or (p.cabys if p else "") or ""
        if not cabys_l and not _sin_fe(ctx):             # 3.93: con facturación electrónica el CABYS es obligatorio en cada línea
            raise HTTPException(400, f"Línea {n_linea}: «{str(li.detalle or (p.nombre if p else ''))[:40]}» no tiene código CABYS; agréguelo en la ficha del ítem")
        try:
            lineas.append(Linea(
                cabys=cabys_l, detalle=li.detalle or p.nombre, cantidad=li.cantidad,
                unidad_medida=li.unidad_medida or (p.unidad_medida if p else "Unid"),
                precio_unitario=li.precio_unitario if li.precio_unitario is not None else Decimal(str(_precio_en_moneda(p, data.moneda, data.tipo_cambio))),
                es_servicio=li.es_servicio if li.es_servicio is not None else (p.es_servicio if p else False),
                codigo_comercial=p.codigo if p and p.codigo else None,
                partida_arancelaria=(p.partida_arancelaria or None) if p else None,
                descuentos=[Descuento(monto=li.descuento, codigo="07", naturaleza="Descuento comercial")] if li.descuento else [],
                impuestos=[Impuesto(codigo_tarifa=tarifa_cod, tarifa=tarifa, exoneracion=exo_linea)] + ([otro] if otro is not None else []),
            ))
        except ValueError as ex:                   # ValidationError: antes terminaba en error 500 y el usuario veía 'null'
            raise HTTPException(400, f"Línea {n_linea}: {_mensaje_pydantic(ex)}")

    if exo is not None and not heredada and not any(l.impuestos[0].exoneracion is not None for l in lineas):
        # se eligió una exoneración que no aplica a ninguna línea: mejor avisar antes de consumir el consecutivo
        raise HTTPException(400, f"La exoneración {exo.numero} no aplica a ninguna línea (los CABYS no están autorizados o las líneas no llevan IVA). "
                                 "Quítela del comprobante o revise los ítems")
    # Otros cargos (sin IVA, suman al total): con porcentaje y sin monto, el monto sale de la venta neta de las líneas
    otros_cargos = []
    if data.otros_cargos:
        if data.tipo_documento == "09":
            raise HTTPException(400, "La factura de exportación no admite otros cargos en este sistema")
        from .fe.calculo import calcular_linea as _calc_linea
        venta_neta = sum((_calc_linea(l).subtotal for l in lineas), Decimal(0))
        from decimal import DecimalException

        def _num(valor, nombre, n):
            try:
                d = Decimal(str(valor))
            except (DecimalException, ValueError, TypeError):
                raise HTTPException(400, f"Otro cargo {n}: el {nombre} '{str(valor)[:30]}' no es un número")
            if not d.is_finite() or abs(d) >= Decimal("1e13"):
                raise HTTPException(400, f"Otro cargo {n}: el {nombre} está fuera de rango")
            return d
        for n_oc, oc in enumerate(data.otros_cargos, start=1):
            if not isinstance(oc, dict):
                raise HTTPException(400, f"Otro cargo {n_oc}: formato inválido")
            try:
                pct = _num(oc.get("porcentaje"), "porcentaje", n_oc) if oc.get("porcentaje") not in (None, "") else None
                if pct is not None and not (0 <= pct <= 100):
                    raise HTTPException(400, f"Otro cargo {n_oc}: el porcentaje debe estar entre 0 y 100")
                monto = _num(oc.get("monto"), "monto", n_oc) if oc.get("monto") not in (None, "", 0, "0") else None
                if monto is None and pct is not None:
                    monto = (venta_neta * pct / 100)
                if monto is None:
                    continue
                monto = monto.quantize(Decimal("0.00001"), rounding=ROUND_HALF_UP)
                if monto <= 0:
                    continue
                otros_cargos.append(OtroCargo(tipo=str(oc.get("tipo") or "06"), tipo_otro=(oc.get("tipo_otro") or None), detalle=str(oc.get("detalle") or "Otros cargos")[:160],
                                              porcentaje=pct, monto=monto))
            except ValueError as ex:
                raise HTTPException(400, f"Otro cargo {n_oc}: {_mensaje_pydantic(ex)}")
            except DecimalException:
                raise HTTPException(400, f"Otro cargo {n_oc}: monto o porcentaje fuera de rango")

    referencias = []
    if data.tipo_documento in ("02", "03"):
        if not (data.referencia_clave and data.referencia_fecha and data.referencia_razon):
            raise HTTPException(400, "Las notas requieren clave, fecha y razón del documento de referencia")
        if len(data.referencia_clave) != 50 or not re.fullmatch(r"[A-Za-z0-9]{50}", data.referencia_clave):
            raise HTTPException(400, "La clave del documento de referencia debe tener 50 caracteres")
        try:
            referencias.append(Referencia(tipo_doc=_tipo_doc_referencia(data.referencia_clave[29:31], data.tipo_documento), numero=data.referencia_clave,
                                          fecha_emision=data.referencia_fecha, codigo=data.referencia_codigo,
                                          codigo_otro=data.referencia_codigo_otro, razon=data.referencia_razon))
        except ValueError as ex:
            raise HTTPException(400, _mensaje_pydantic(ex))
    if data.tipo_documento == "08":
        # Factura electrónica de compra: la emite la empresa por cuenta de un proveedor que no factura electrónicamente.
        # Referencia obligatoria al documento del proveedor (tipo 14 "comprobante aportado por contribuyente de régimen especial" u otro).
        if not cliente or (cliente.tipo or "") not in ("Proveedor", "Ambos"):
            raise HTTPException(400, "La factura de compra requiere un contacto de tipo Proveedor (o Ambos)")
        try:
            referencias.append(Referencia(tipo_doc=data.referencia_tipo_doc or "14", tipo_doc_otro=data.referencia_tipo_doc_otro,
                                          numero=(data.referencia_clave or data.referencia_numero or "S/N")[:50],
                                          fecha_emision=data.referencia_fecha or ahora_cr().isoformat(timespec="seconds"),
                                          codigo=data.referencia_codigo or "04", codigo_otro=data.referencia_codigo_otro,
                                          razon=data.referencia_razon or "Factura de compra por bienes o servicios adquiridos a proveedor sin factura electrónica"))
        except ValueError as ex:
            raise HTTPException(400, _mensaje_pydantic(ex))

    # Hacienda exige TipoCambio en colones por unidad de la moneda del comprobante (CRC = 1). Con el dólar como moneda
    # principal el formulario mandaba 1 y los montos en colones quedaban mal.
    if data.moneda != "CRC" and (float(data.tipo_cambio or 1) <= 0 or float(data.tipo_cambio or 1) == 1):
        raise HTTPException(400, f"Indique el tipo de cambio en colones por 1 {data.moneda} (Hacienda lo exige; con 1 los montos en colones quedan mal)")
    ahora = ahora_cr()                      # hora de Costa Rica aunque el servidor esté en UTC
    suc = getattr(ctx, "sucursal", None)                                        # 3.66: sucursal activa (vacío = la principal)
    if suc is not None and not suc.activa:      # 3.87: amarrado a una sucursal desactivada: consulta lo suyo, no emite (antes salía con la principal)
        raise HTTPException(403, f"La sucursal «{suc.nombre}» está desactivada: puede consultar sus documentos, pero para emitir pida al administrador "
                                 "que la active o que lo asigne a otra sucursal")
    bodega_id = data.bodega_id or (suc.bodega_id if suc and suc.bodega_id else None) or inventario.bodega_principal(s, e.id).id      # (puede hacer commit al crear la bodega: va ANTES del reclamo)
    if data.bodega_id:
        inventario._bodega_activa(s, e.id, data.bodega_id)                      # existe, es de la empresa y está activa
    # Factura pendiente de una recurrencia: se toma ANTES de consumir consecutivo, en la misma transacción; una segunda
    # pestaña recibe 409. Si la emisión falla, el rollback la deja 'pendiente' (R92)
    if data.pendiente_id:
        if not ctx.puede("facturar"):           # 3.87: la caja (solo «pos») sacaba de la cola una factura recurrente con su tiquete
            raise HTTPException(403, "Emitir una factura recurrente pendiente requiere permiso para facturar")
        tomada = s.execute(text("UPDATE facturapendiente SET estado = 'emitiendo' WHERE id = :id AND empresa_id = :e AND estado = 'pendiente'"),
                           {"id": data.pendiente_id, "e": e.id}).rowcount
        if not tomada:
            raise HTTPException(409, "Esta factura pendiente ya se emitió (o la está emitiendo otro usuario). Revise la lista de facturas antes de repetirla")
    # Verifica existencias antes de consumir consecutivo (facturas/tiquetes descuentan; notas de crédito devuelven)
    if data.tipo_documento in ("01", "04", "09"):
        requerido: dict[int, float] = {}                                   # líneas repetidas del mismo producto se suman (R271)
        for li in data.lineas:
            if li.producto_id:
                requerido[li.producto_id] = requerido.get(li.producto_id, 0.0) + float(li.cantidad)
        for pid, cant in requerido.items():
            p = _producto(s, e.id, pid)
            if p and p.inventariable and not p.es_servicio and not p.venta_negativo:
                ex = inventario.existencia(s, p.id, bodega_id)
                if ex.cantidad + 1e-9 < cant:
                    raise HTTPException(400, f"Existencias insuficientes de '{p.nombre}': hay {ex.cantidad:g}, se facturan {cant:g} en total")
    if e.ambiente == "produccion" and getattr(e, "factura_electronica", True) and not (e.p12_nombre and e.p12_pin):   # 4.21: el comprobante interno no se firma
        raise HTTPException(400, "Cargue la llave criptográfica (.p12) de producción antes de emitir: un comprobante sin firma "
                                 "consumiría un consecutivo que nunca podrá enviarse a Hacienda")
    codigo_suc = int(suc.codigo) if suc else int(e.sucursal or 1)
    numero = _siguiente_numero(s, e.id, data.tipo_documento, e.ambiente, codigo_suc)
    marca = _marcas.validar_marca(s, e.id, data.marca_id) or ((sucursales.marca_de(s, e.id, suc) or _marcas.predeterminada(s, e.id)) if data.tipo_documento != "08" else None)   # (3.45; 3.82: la de la sucursal)
    try:
        consecutivo = generar_consecutivo(data.tipo_documento, numero, codigo_suc, e.terminal)
        clave = generar_clave(_cedula_para_clave(e), consecutivo, ahora, situacion=_sinc.situacion_emision())   # etapa 1: 1 salvo que se active la situación 3
    except (ValueError, AssertionError) as ex:
        raise HTTPException(400, f"No se pudo generar el consecutivo o la clave: {ex}")
    # 4.2: el mensaje dice si falla la empresa o el contacto y qué dato (antes: «Datos del emisor o del receptor no válidos para Hacienda:
    # String should have at least 5 characters»); sin facturación electrónica el contacto nunca detiene el comprobante interno
    try:
        parte_empresa = _parte_empresa(e)
    except ValueError as ex:
        if _sin_fe(ctx):              # 4.21: a quien ya la tiene apagada no se le aconseja apagarla
            raise HTTPException(400, "Faltan datos de la empresa para emitir el comprobante. " + _explicar_hacienda(ex) + ". Complételos en Configuración › Empresa")
        raise HTTPException(400, "Faltan datos de la empresa para la factura electrónica. " + _explicar_hacienda(ex)
                                 + ". Complételos en Configuración › Empresa (o apague allí la facturación electrónica si este negocio no la usa)")
    try:
        parte_contacto = (_parte_cliente_laxa(cliente) if _sin_fe(ctx) else _parte_cliente(cliente)) if cliente else None
    except ValueError as ex:
        raise HTTPException(400, f"Hacienda no acepta los datos del contacto «{getattr(cliente, 'nombre', '')}». " + _explicar_hacienda(ex)
                                 + ". Corríjalos en Contactos" + (" o emita el tiquete sin cliente" if data.tipo_documento == "04" else ""))
    if data.tipo_documento == "08":           # la empresa es el receptor; el proveedor figura como emisor
        emisor_doc, receptor_doc = parte_contacto, parte_empresa
    else:
        emisor_doc, receptor_doc = parte_empresa, parte_contacto
        if data.actividad_emisor and re.fullmatch(ACTIVIDAD_RE, data.actividad_emisor.strip()):     # actividad secundaria (R53)
            emisor_doc = emisor_doc.model_copy(update={"actividad": data.actividad_emisor.strip()})
        if marca is not None:                                                                        # marca: solo el nombre comercial (3.45)
            emisor_doc = emisor_doc.model_copy(update={"nombre_comercial": marca.nombre})
    # «Otros» (99): la descripción solo viaja con ese código; con otro código (o vacía) va como None, no como '' (min_length)
    cond_otros = ((data.condicion_venta_otros or "").strip() or None) if data.condicion_venta == "99" else None
    medio_otros = ((data.medio_pago_otros or "").strip() or None) if data.medio_pago == "99" else None
    try:
        comp = Comprobante(
            tipo_documento=data.tipo_documento, clave=clave, consecutivo=consecutivo,
            fecha_emision=ahora.isoformat(timespec="seconds"),     # YYYY-MM-DDTHH:MM:SS-06:00
            proveedor_sistemas=e.proveedor_sistemas or PROVEEDOR_SISTEMAS,
            emisor=emisor_doc, receptor=receptor_doc,
            condicion_venta=data.condicion_venta, plazo_credito=data.plazo_credito, condicion_venta_otros=cond_otros,
            moneda=data.moneda, tipo_cambio=data.tipo_cambio, lineas=lineas,
            medios_pago=[MedioPago(tipo=data.medio_pago, otros=medio_otros)], referencias=referencias, otros_cargos=otros_cargos,
            otro_texto=((f"Orden de compra: {data.orden_compra.strip()}. " if (data.orden_compra or "").strip() else "") + (data.observaciones or "")).strip() or None,
        )
    except ValueError as ex:
        raise HTTPException(400, _mensaje_pydantic(ex))
    try:
        root = construir_xml(comp)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    errores = validar(root, comp.tipo_documento)
    if errores and _sin_fe(ctx):                     # 3.93/3.99: el comprobante interno no va a Hacienda: los datos de Hacienda que falten no lo detienen
        logging.getLogger(__name__).info("Comprobante interno con datos incompletos para Hacienda (no se envía): %s", "; ".join(str(x) for x in errores)[:300])
        errores = []
    if errores:
        raise HTTPException(400, {"mensaje": "El XML no cumple el esquema v4.4", "errores": errores})

    estado = "generado"
    if not getattr(e, "factura_electronica", True):           # 3.61: comprobante interno, sin firma ni envío a Hacienda
        estado = "interno"
    elif e.p12_nombre and e.p12_pin:
        try:
            root = firma.firmar(root, secretos.descifrar_archivo(e.clave_cifrada, (CERT_DIR / e.p12_nombre).read_bytes()),
                                secretos.descifrar(e.clave_cifrada, e.p12_pin))
            estado = "firmado"
        except Exception as ex:
            raise HTTPException(400, f"Error al firmar: {ex}")

    from .fe.calculo import calcular
    r = calcular(comp)
    nombre_xml = f"{clave}.xml"
    (XML_DIR / nombre_xml).write_bytes(a_bytes(root))
    doc = Documento(
        empresa_id=e.id, tipo_documento=comp.tipo_documento, clave=clave, consecutivo=consecutivo,
        fecha_emision=comp.fecha_emision, cliente_id=cliente.id if cliente else None,
        receptor_nombre=cliente.nombre if cliente else None, moneda=comp.moneda, tipo_cambio=float(comp.tipo_cambio or 1), idempotencia=data.idempotencia or None,
        terminos=(data.terminos or "").strip()[:2000] or None, orden_compra=(data.orden_compra or "").strip()[:60] or None,
        total=float(r.total_comprobante), impuesto=float(r.total_iva), otros_impuestos=float(r.total_otros_impuestos), estado=estado, xml_nombre=nombre_xml,
        marca_id=marca.id if marca is not None else None,
        vendedor=data.vendedor or None, fecha_vencimiento=_vencimiento(data, ahora),
        ambiente=e.ambiente, condicion_venta=data.condicion_venta, sucursal_id=suc.id if suc else None,
        referencia_clave=(data.referencia_clave or None) if comp.tipo_documento in ("02", "03") else None,
        referencia_codigo=(data.referencia_codigo or None) if comp.tipo_documento in ("02", "03") else None,   # (R330)
        otros_cargos=json.dumps([{"tipo": oc.tipo, "tipo_otro": oc.tipo_otro, "detalle": oc.detalle, "porcentaje": float(oc.porcentaje) if oc.porcentaje is not None else None, "monto": float(oc.monto)} for oc in otros_cargos]) if otros_cargos else None,
        exoneracion_id=exo.id if exo is not None and r.total_iva_exonerado > 0 else None,
        exoneracion_numero=exo.numero if exo is not None and r.total_iva_exonerado > 0 else None,
        iva_exonerado=float(r.total_iva_exonerado),
    )
    if comp.tipo_documento in ("02", "03") and data.referencia_clave:                    # (R240)
        ref = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.clave == data.referencia_clave)).first()
        if ref is not None:                                   # una clave de otro sistema no se puede verificar: se acepta
            if (ref.estado or "") not in ("aceptado", "interno"):
                raise HTTPException(400, f"El comprobante de referencia {ref.consecutivo} no está aceptado por Hacienda (estado: {ref.estado})")
            if comp.tipo_documento == "03" and ref.tipo_documento in ("01", "04", "09", "08"):
                otras = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.tipo_documento == "03",
                                                       Documento.referencia_clave == ref.clave)).all()
                acumulado = sum(float(x.total or 0) for x in otras if (x.estado or "") not in ("rechazado", "error"))
                if acumulado + float(r.total_comprobante) > float(ref.total or 0) + 0.01:
                    raise HTTPException(400, f"Las notas de crédito sobre {ref.consecutivo} sumarían {acumulado + float(r.total_comprobante):,.2f}, "
                                             f"más que el total del comprobante ({float(ref.total or 0):,.2f})")
    # Un solo commit al final: documento, consecutivo, líneas e inventario se confirman juntos o se revierten juntos
    s.add(doc); s.flush()
    if data.borrador_id:                    # emitido desde un borrador: el borrador se va con el mismo commit
        bor = s.get(modulos.Borrador, data.borrador_id)
        if bor and bor.empresa_id == e.id:
            _clinicas.enlazar_borrador(s, e.id, bor, doc.id)
            _tikec.ligar_documento(s, e.id, bor, doc.id)       # 4.5: si salió de un ticket de TiKe, lo cobrado queda ligado al comprobante (anularlo lo devuelve)
            s.delete(bor)
    if data.pendiente_id:                   # la pendiente queda emitida y enlazada en el mismo commit
        s.execute(text("UPDATE facturapendiente SET estado = 'emitida', documento_id = :d WHERE id = :id AND estado = 'emitiendo'"), {"d": doc.id, "id": data.pendiente_id})
    # 4.9: cobro de un pedido en línea en la caja: el pedido queda con su comprobante (y entregado) en el mismo commit; así su total deja de
    # contar en «en pedidos» del crédito de la revendedora (antes se contaba también en el saldo del fiado)
    # 4.9: pedido_parcial (cobro de una parte): queda enlazado, pero sigue sin entregar y no se avisa al cliente hasta el cobro que lo cierra
    ped_avisar = _pedidos.vincular_documento(s, e, data.pedido_id, doc, parcial=bool(data.pedido_parcial)) if data.pedido_id and data.tipo_documento in ("01", "04") else None
    for n, lc in enumerate(r.lineas, start=1):
        li = data.lineas[n - 1]
        s.add(DocumentoLinea(
            documento_id=doc.id, numero=n, producto_id=li.producto_id, cabys=lc.linea.cabys, detalle=lc.linea.detalle,
            cantidad=float(lc.linea.cantidad), unidad_medida=lc.linea.unidad_medida,
            precio_unitario=float(lc.linea.precio_unitario), descuento=float(lc.total_descuento),
            codigo_tarifa=lc.linea.impuestos[0].codigo_tarifa, tarifa=float(lc.linea.impuestos[0].tarifa),
            impuesto=float(lc.iva_neto), otros_impuestos=float(lc.otros_neto), total=float(lc.monto_total_linea),
            impuestos_detalle=json.dumps([{"codigo": i.codigo, "nombre": _NOMBRE_IMP.get(i.codigo, i.codigo), "tarifa": float(i.tarifa) if i.tarifa is not None else None,
                                           "monto": float(i.monto)} for i in lc.impuestos if i.codigo != "01"]) if lc.otros_neto else None,
            iva_exonerado=float(sum((i.monto_exonerado for i in lc.impuestos), Decimal(0))),
            tarifa_exonerada=float(min(lc.impuestos[0].exoneracion.tarifa, lc.impuestos[0].tarifa)) if lc.impuestos and lc.impuestos[0].exoneracion is not None else None,
        ))
    # Movimientos de inventario: venta (01/04/09) descuenta; la nota de crédito devuelve mercadería SOLO si es anulación o
    # devolución (códigos 01, 06, 13; R109); la factura de compra (08) entra como compra con costo (R110). En el ambiente de
    # pruebas no se mueve el inventario real (R111).
    # Sin facturación electrónica (3.61) el ambiente de Hacienda no aplica: el inventario real se mueve siempre (3.69).
    mueve = (e.ambiente == "produccion" or not getattr(e, "factura_electronica", True)) and (data.tipo_documento in ("01", "04", "09", "08") or
                                             (data.tipo_documento == "03" and (data.referencia_codigo or "01") in ("01", "06", "13")))
    if mueve:
        if data.tipo_documento == "03" and data.referencia_clave:      # misma bodega de la que salió la venta original
            orig = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.clave == data.referencia_clave)).first()
            mov0 = s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.documento_id == orig.id)).first() if orig else None
            if mov0:
                bodega_id = mov0.bodega_id
        if data.tipo_documento == "08":
            inventario.ingresar_por_compra(
                s, e.id, doc.id, f"{CAT_TIPO.get('08', 'FEC')} {consecutivo}", bodega_id,
                [{"producto_id": li.producto_id, "cantidad": li.cantidad, "costo": lc.subtotal / li.cantidad if li.cantidad else 0} for li, lc in zip(data.lineas, r.lineas)],
                ahora.strftime("%Y-%m-%d"), float(comp.tipo_cambio or 1) if comp.moneda != "CRC" else 1.0)
        else:
            inventario.descontar_por_venta(
                s, e.id, doc.id, f"{CAT_TIPO.get(data.tipo_documento, 'DOC')} {consecutivo}", bodega_id,
                [{"producto_id": li.producto_id, "cantidad": li.cantidad} for li in data.lineas],
                ahora.strftime("%Y-%m-%d"), devolucion=(data.tipo_documento == "03"))
    s.commit(); s.refresh(doc)
    if ped_avisar:                          # 4.9: el pedido pasó a entregado al cobrarlo: aviso al cliente (si dejó correo y hay correo saliente)
        _pedidos.avisar_cliente_id(e.id, ped_avisar, "entregado")
    if doc.tipo_documento == "03" and doc.estado == "interno" and doc.referencia_clave:   # 3.87: la nota de crédito interna no espera a Hacienda: rebaja ya el saldo de la factura
        modulos.recalcular_acreditado(s, e.id, doc.referencia_clave); s.refresh(doc)
        _clinicas.liberar_si_acreditada(s, e.id, doc.referencia_clave)
        _tikec.liberar_si_acreditada(s, e.id, doc.referencia_clave, getattr(ctx.usuario, "nombre", "") or "")   # 4.5: si la nota cubre la factura completa, las horas y repuestos del ticket vuelven a quedar por cobrar
    _auditar(ctx, "emitir", f"{CAT_TIPO.get(doc.tipo_documento, doc.tipo_documento)} {doc.consecutivo} ({doc.estado}) total {doc.total:,.2f} {doc.moneda}"
             + (f" · exoneración {doc.exoneracion_numero}: IVA exonerado {doc.iva_exonerado:,.2f}" if doc.exoneracion_numero else "")
             + (f" · {exo_aviso}" if exo_aviso and doc.exoneracion_numero else ""))
    return doc


@app.get("/api/comprobantes", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def listar_comprobantes(request: Request, cliente_id: Optional[int] = None, con_saldo: int = 0, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    # Solo los comprobantes del ambiente activo: los emitidos en pruebas no se mezclan con los reales.
    # 3.72: columnas directas (sin objetos ORM) y respuesta JSON directa: con miles de comprobantes tardaba 3 veces más.
    _exigir_ventas(ctx)                                                    # 3.87: no para los roles de un solo módulo
    t = Documento.__table__
    q = sa_select(t).where(t.c.empresa_id == ctx.empresa.id, t.c.ambiente == ctx.empresa.ambiente)
    # 4.5: abonos de fiados desde la caja: un usuario de solo caja recibe de ese cliente las facturas y tiquetes a crédito con saldo, de
    # cualquier fecha (antes solo las de hoy: un fiado de ayer no se podía abonar), y solo las columnas del abono (CAMPOS_ABONO_CAJA)
    abono_caja = auth.solo_pos(ctx.permisos) and cliente_id is not None and bool(con_saldo)
    if abono_caja:
        q = q.where(t.c.tipo_documento.in_(("01", "04")), t.c.estado != "rechazado")
    elif auth.solo_pos(ctx.permisos):                                      # el cajero solo ve lo de hoy
        q = q.where(t.c.fecha_emision >= ahora_cr().strftime("%Y-%m-%d"))
    if cliente_id is not None:                                             # 3.87: saldo del fiado en la caja: solo ese cliente (antes bajaba todos)
        q = q.where(t.c.cliente_id == cliente_id)
    nombres = [c.name for c in t.columns]
    suc = getattr(ctx, "sucursal", None)                                   # 3.66
    out = []
    for fila in s.execute(q.order_by(t.c.id.desc())).all():
        d = dict(zip(nombres, fila))
        if suc and not sucursales.pertenece(d, suc):
            continue
        if con_saldo and (d["total"] or 0) - (d["pagado"] or 0) - (d["acreditado"] or 0) <= 0.004:   # 3.87: con saldo por cobrar
            continue
        if abono_caja:
            if (d.get("condicion_venta") or "01") not in CONDICIONES_CREDITO:   # 4.5: de contado no es fiado. 4.9: como creditos_contactos y docs_f (02/08/10): un «99 Otros» o «04 Apartado» ya no cuenta como deuda en la caja
                continue
            out.append({k: d.get(k) for k in CAMPOS_ABONO_CAJA}); continue
        d["total_otros_cargos"] = resumen.otros_cargos_de(d)              # impuesto de servicio, timbres… (dentro del total; se muestran aparte)
        out.append(d)
    return _json_rapido(request, out)


@app.get("/api/comprobantes/{did}", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def detalle_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    d = _documento_ctx(s, ctx, did)                                        # 3.87: reglas del Cajero y de la sucursal fija
    lineas = s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == did).order_by(DocumentoLinea.numero)).all()
    try:
        oc = json.loads(d.otros_cargos) if d.otros_cargos else []
    except ValueError:
        oc = []
    return {**d.model_dump(), "lineas": [l.model_dump() for l in lineas], "otros_cargos": oc, "total_otros_cargos": resumen.otros_cargos_de(d)}


@app.get("/api/comprobantes/{did}/enlace")
def enlace_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Enlace público de consulta del comprobante (para WhatsApp, correo o mensajes): quien lo tenga ve el documento y
    descarga el PDF y el XML sin iniciar sesión. Variables de las plantillas de WhatsApp listas para usar."""
    if auth.solo_pos(ctx.permisos) or not (ctx.puede("facturar") or ctx.puede("cobros")):
        raise HTTPException(403, "Compartir comprobantes requiere permiso para facturar o cobrar")
    d = _documento_ctx(s, ctx, did)
    e = ctx.empresa
    cliente = _cliente(s, e.id, d.cliente_id) if d.cliente_id else None
    url = enlace_publico(e, d.id, str(ctx.request.base_url))
    total = pdf.fmt(d.total, d.moneda)
    return {"url": url, "telefono_cliente": str(cliente.telefono) if cliente and cliente.telefono else "",
            "variables": recordatorios.variables_doc(d, e, d.receptor_nombre or (cliente.nombre if cliente else "") or "estimado cliente", total, url, ahora_cr().date())}


def _doc_publico(token: str, request):
    """(empresa, documento) de un enlace público válido; 404 si el token no sirve."""
    auth.limitar_ip(request, "publico", 120, 300, "Demasiadas consultas desde su conexión; espere unos minutos")
    datos = auth.abrir(token or "")
    if not datos or datos.get("tipo") != "pub":
        raise HTTPException(404, "El enlace no es válido o ya venció")
    with Session(engine) as sc:
        e = sc.get(Empresa, int(datos.get("eid") or 0))
    if not e or e.bloqueada or int(datos.get("v") or 0) != int(getattr(e, "enlaces_version", 1) or 1):
        raise HTTPException(404, "El enlace no es válido o ya venció")
    with Session(engine_empresa(e.id)) as s:
        d = s.get(Documento, int(datos.get("did") or 0))
        if not d or d.empresa_id != e.id:
            raise HTTPException(404, "El enlace no es válido o ya venció")
        s.expunge(d)
    return e, d


_HTML_PUBLICO = """<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{titulo} {numero} · {empresa}</title>
<style>body{{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f3f4f6;margin:0;color:#1d2433}}.c{{max-width:560px;margin:32px auto;background:#fff;border-radius:12px;
padding:28px 28px 22px;box-shadow:0 2px 12px rgba(0,0,0,.06)}}h1{{font-size:20px;margin:0 0 4px}}.m{{color:#6b7280;font-size:13px}}dl{{display:grid;grid-template-columns:150px 1fr;gap:6px 12px;margin:18px 0}}
dt{{color:#6b7280;font-size:13px}}dd{{margin:0;font-weight:600}}.b{{display:inline-block;margin:6px 8px 0 0;padding:10px 16px;border-radius:8px;background:#0f766e;color:#fff;text-decoration:none;font-weight:600}}
.b.s{{background:#e5e7eb;color:#1d2433}}.ok{{color:#047857}}.no{{color:#b91c1c}}.k{{font-family:ui-monospace,Consolas,monospace;font-size:11px;word-break:break-all;color:#6b7280}}</style></head>
<body><div class="c"><h1>{empresa}</h1><div class="m">Cédula {cedula}</div>
<dl><dt>Documento</dt><dd>{titulo} {numero}</dd><dt>Fecha</dt><dd>{fecha}</dd><dt>Cliente</dt><dd>{cliente}</dd><dt>Total</dt><dd>{total}</dd>
<dt>Estado en Hacienda</dt><dd class="{clase}">{estado}</dd></dl>
<a class="b" href="/p/{token}/pdf">Descargar PDF</a><a class="b s" href="/p/{token}/xml">XML</a>{resp}
<p class="k">Clave: {clave}</p><p class="m">Enlace de consulta emitido por {empresa}. Si no esperaba este documento, ignore este mensaje.</p></div></body></html>"""


@app.get("/p/{token}")
def consulta_publica(token: str, request: Request):
    """Página pública (sin sesión) con los datos básicos del comprobante y la descarga del PDF y el XML."""
    from html import escape
    e, d = _doc_publico(token, request)
    titulo = resumen.TIPOS.get(d.tipo_documento, "Comprobante")
    estado = {"aceptado": "Aceptado", "rechazado": "Rechazado", "enviado": "En proceso", "firmado": "Pendiente de envío"}.get(d.estado or "", d.estado or "")
    clase = "ok" if d.estado == "aceptado" else ("no" if d.estado == "rechazado" else "")
    resp = f'<a class="b s" href="/p/{escape(token, quote=True)}/respuesta">Respuesta de Hacienda</a>' if d.respuesta_nombre else ""
    html = _HTML_PUBLICO.format(titulo=escape(titulo), numero=escape(d.consecutivo or ""), empresa=escape(_marcas.nombre_de(e, _marca_doc(e, d))),
                                cedula=escape(e.numero_id or ""), fecha=escape("/".join(reversed(str(d.fecha_emision or "")[:10].split("-")))),
                                cliente=escape(d.receptor_nombre or "Consumidor final"), total=escape(pdf.fmt(d.total, d.moneda)), estado=escape(estado), clase=clase,
                                token=escape(token, quote=True), resp=resp, clave=escape(d.clave or ""))
    return Response(html, media_type="text/html; charset=utf-8", headers={"X-Robots-Tag": "noindex"})


@app.get("/p/{token}/pdf")
def consulta_publica_pdf(token: str, request: Request):
    e, d = _doc_publico(token, request)
    try:
        return Response(_pdf_de(d, e), media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{d.consecutivo}.pdf"'})
    except FileNotFoundError:
        raise HTTPException(404, "El archivo del comprobante no está disponible")


@app.get("/p/{token}/xml")
def consulta_publica_xml(token: str, request: Request):
    e, d = _doc_publico(token, request)
    if not d.xml_nombre or not (XML_DIR / d.xml_nombre).exists():
        raise HTTPException(404, "El archivo del comprobante no está disponible")
    return FileResponse(XML_DIR / d.xml_nombre, media_type="application/xml", filename=d.xml_nombre)


@app.get("/p/{token}/respuesta")
def consulta_publica_respuesta(token: str, request: Request):
    e, d = _doc_publico(token, request)
    if not d.respuesta_nombre or not (XML_DIR / d.respuesta_nombre).exists():
        raise HTTPException(404, "Aún no hay respuesta de Hacienda")
    return FileResponse(XML_DIR / d.respuesta_nombre, media_type="application/xml", filename=d.respuesta_nombre)


@app.get("/api/comprobantes/{did}/xml", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def xml_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    d = _documento_ctx(s, ctx, did)
    _sinc.traer_archivos(ctx.empresa.id, d)                              # etapa 2a: el XML viejo se baja la primera vez
    if not d.xml_nombre or not (XML_DIR / d.xml_nombre).exists():         # 3.87: 404 claro, como el enlace público (antes 500)
        raise HTTPException(404, ARCHIVO_NO_DISPONIBLE)
    return FileResponse(XML_DIR / d.xml_nombre, media_type="application/xml", filename=d.xml_nombre)


@app.get("/api/comprobantes/{did}/respuesta", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def respuesta_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    d = _documento_ctx(s, ctx, did)
    if not d.respuesta_nombre:
        raise HTTPException(404, "Aún no hay respuesta de Hacienda")
    _sinc.traer_archivos(ctx.empresa.id, d)                              # etapa 2a
    if not (XML_DIR / d.respuesta_nombre).exists():                      # 3.87 (antes 500)
        raise HTTPException(404, "El archivo de la respuesta de Hacienda no está disponible en el servidor")
    return FileResponse(XML_DIR / d.respuesta_nombre, media_type="application/xml", filename=d.respuesta_nombre)


def _pdf_de(d: Documento, e: Empresa) -> bytes:
    _sinc.traer_archivos(e.id, d)                                        # etapa 2a
    xml = (XML_DIR / d.xml_nombre).read_bytes()
    resp = (XML_DIR / d.respuesta_nombre).read_bytes() if d.respuesta_nombre else None
    m = _marca_doc(e, d)
    return pdf.generar_pdf(xml, resp, _meta_pdf(e, d, m), cfg=plantillas.obtener(pdf.datos_desde_xml(xml)["tipo"], e.id),
                           logo_path=_marcas.logo_de(e, m))


@app.get("/api/comprobantes/{did}/pdf", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def pdf_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    d = _documento_ctx(s, ctx, did)
    try:
        if not d.xml_nombre:
            raise FileNotFoundError(did)
        contenido = _pdf_de(d, ctx.empresa)
    except FileNotFoundError:                   # 3.87: el XML ya no está en disco: mensaje claro, como el enlace público (antes 500)
        raise HTTPException(404, ARCHIVO_NO_DISPONIBLE)
    return Response(contenido, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{d.consecutivo}.pdf"'})


@app.get("/api/comprobantes/{did}/tiquete", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def tiquete_comprobante(did: int, ancho: int = 80, recibido: Optional[float] = None, vuelto: Optional[float] = None, cajero: Optional[str] = None,
                        ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Tiquete para impresora térmica (58 u 80 mm) del comprobante: para el punto de venta. recibido/vuelto se imprimen al pie."""
    d = _documento_ctx(s, ctx, did)
    e = ctx.empresa
    try:
        if not d.xml_nombre:
            raise FileNotFoundError(did)
        _sinc.traer_archivos(e.id, d)                                    # etapa 2a
        xml = (XML_DIR / d.xml_nombre).read_bytes()
        resp = (XML_DIR / d.respuesta_nombre).read_bytes() if d.respuesta_nombre else None
    except FileNotFoundError:                   # 3.87 (antes 500 al reimprimir en la caja)
        raise HTTPException(404, ARCHIVO_NO_DISPONIBLE)
    import math
    extra = {"cajero": (cajero or "")[:60] or None}
    if recibido is not None and math.isfinite(recibido) and 0 <= recibido < 1e12:
        extra["recibido"] = round(recibido, 2)
        extra["vuelto"] = round(vuelto, 2) if (vuelto is not None and math.isfinite(vuelto) and 0 <= vuelto < 1e12) else round(max(0.0, recibido - float(d.total or 0)), 2)
    m = _marca_doc(e, d)
    contenido = pdf.generar_tiquete(xml, resp, _meta_pdf(e, d, m), ancho_mm=ancho, logo_path=_marcas.logo_de(e, m), extra=extra)
    return Response(contenido, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="tiquete_{d.consecutivo}.pdf"'})


class CorreoIn(BaseModel):
    para: Optional[str] = None
    cc: Optional[str] = None          # None = las personas del contacto con «Recibe copia»; "" = sin copia (3.38)
    mensaje: Optional[str] = Field(None, max_length=1500)


def _cfg_smtp(e: Empresa, clave_smtp: str | None = None) -> correo.ConfigSMTP:
    if clave_smtp is None:
        try:
            clave_smtp = secretos.descifrar(e.clave_cifrada, e.smtp_password)
        except ValueError as ex:
            raise HTTPException(400, f"No se pudo leer la contraseña SMTP guardada; vuelva a guardarla en Configuración. {ex}")
    return correo.ConfigSMTP(e.smtp_host, e.smtp_puerto or (465 if (e.smtp_seguridad or "ssl") == "ssl" else 587), e.smtp_usuario,
                             clave_smtp, e.smtp_remitente, seguridad=e.smtp_seguridad or "ssl", nombre=e.smtp_nombre or None,
                             copia=(e.smtp_copia or "").strip() or None)


@app.get("/api/tipo-cambio/historico")
def tipo_cambio_historico(anio: Optional[int] = None, ctx: Contexto = Depends(contexto)):
    """4.18: registro propio del tipo de cambio de referencia del BCCR, por año."""
    return tipo_cambio.historico(anio)


@app.get("/api/tipo-cambio/mapa")
def tipo_cambio_mapa(ctx: Contexto = Depends(contexto)):
    return tipo_cambio.mapa()


@app.get("/api/tipo-cambio/dia")
def tipo_cambio_dia(fecha: str, ctx: Contexto = Depends(contexto)):
    return tipo_cambio.dia(fecha) or {}


@app.get("/api/tipo-cambio")
def get_tipo_cambio(forzar: int = 0, ctx: Contexto = Depends(contexto)):
    """Venta/compra BCCR del día (vía Hacienda) y el tipo de cambio aplicado por la empresa (venta + margen de protección)."""
    t = tipo_cambio.obtener(forzar=bool(forzar))
    margen = ctx.empresa.margen_cambiario if ctx.empresa.margen_cambiario is not None else 5.0
    return {**t, "margen": margen, "aplicado": tipo_cambio.aplicado(t.get("venta"), margen)}


class MargenIn(BaseModel):
    margen: float = Field(ge=0, le=100)


@app.put("/api/empresa/margen-cambiario")
def put_margen_cambiario(data: MargenIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    e.margen_cambiario = data.margen
    s.add(e); s.commit()
    _auditar(ctx, "empresa_actualizada", f"Margen cambiario: {data.margen} %")
    return get_tipo_cambio(0, ctx)


@app.post("/api/empresa/smtp/probar")
def probar_smtp(data: CorreoIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    """Envía un correo de prueba con la configuración SMTP GUARDADA de la empresa (guarde primero)."""
    e = s.get(Empresa, ctx.empresa.id)
    if not (e.smtp_host and e.smtp_remitente):
        raise HTTPException(400, "Guarde primero el servidor SMTP y el remitente")
    para = _correos_de(data.para or ctx.usuario.correo)
    if not para:
        raise HTTPException(400, "Indique un correo de destino válido")
    try:
        correo.probar(_cfg_smtp(e), para[0], e.nombre_comercial or e.nombre, rem=_dz.de_empresa(e))
    except correo.ErrorCorreo as ex:
        auditar(s, "correo_prueba", f"FALLÓ a {para[0]}: {ex}"[:500], ctx.usuario, e.id, ctx.request)
        raise HTTPException(502, str(ex))
    except Exception as ex:  # noqa: BLE001
        auditar(s, "correo_prueba", f"FALLÓ a {para[0]}: {ex}"[:500], ctx.usuario, e.id, ctx.request)
        raise HTTPException(502, f"No se pudo enviar el correo de prueba: {ex}")
    auditar(s, "correo_prueba", f"Correo de prueba enviado a {para[0]} ({e.smtp_host}:{e.smtp_puerto}, {e.smtp_seguridad})", ctx.usuario, e.id, ctx.request)
    return {"ok": True, "para": para[0], "detalle": f"Enviado desde {e.smtp_remitente} por {e.smtp_host}:{e.smtp_puerto} ({e.smtp_seguridad})"}


def _correos_de(texto: str | None) -> list[str]:
    return [x for x in re.split(r"[,;\s]+", texto or "") if x and "@" in x]


_RE_CORREO = re.compile(r"[^@\s,;<>]+@[^@\s,;<>]+\.[A-Za-z]{2,}")


def _correos_validos(texto: str | None, campo: str) -> list[str]:
    """Correos separados por coma, punto y coma o espacio; sin repetidos. Un correo mal escrito se rechaza con su nombre (3.38)."""
    out, malos = [], []
    for x in re.split(r"[,;\s]+", texto or ""):
        x = x.strip().strip("<>").lower()
        if not x:
            continue
        (out if _RE_CORREO.fullmatch(x) else malos).append(x)
    if malos:
        raise HTTPException(400, f"{campo}: correo no válido: {', '.join(malos[:3])}")
    return list(dict.fromkeys(out))


def _para_cliente(cliente) -> list[str]:
    """«Enviar facturas a» del contacto; si está vacío, su correo principal (3.38)."""
    if not cliente:
        return []
    return _correos_de(getattr(cliente, "correo_facturas", None)) or _correos_de(cliente.correo)


def _cc_cliente(s: Session, eid: int, cliente) -> list[str]:
    """Copia por defecto: «Copia (CC) de las facturas» del contacto + personas asociadas con «Recibe copia» (3.38)."""
    if not cliente:
        return []
    fijo = _correos_de(getattr(cliente, "correo_cc", None))
    return list(dict.fromkeys(fijo + [p["correo"] for p in _personas_copia(s, eid, cliente.id)]))


def _personas_copia(s: Session, eid: int, cliente_id: int | None, solo_marcadas: bool = True) -> list[dict]:
    """Personas asociadas del contacto (Contactos › Personas asociadas) con correo; con solo_marcadas, las que tienen «Recibe copia»."""
    if not cliente_id:
        return []
    extra = modulos.leer(s, eid, "contactos_extra", {}) or {}
    dato = extra.get(str(cliente_id)) or extra.get(cliente_id) or {} if isinstance(extra, dict) else {}
    out = []
    for p in (dato.get("personas") or []) if isinstance(dato, dict) else []:
        c = str((p or {}).get("correo") or "").strip().lower()
        if c and _RE_CORREO.fullmatch(c) and (not solo_marcadas or p.get("notificar")):
            out.append({"nombre": str(p.get("nombre") or "")[:80], "correo": c, "notificar": bool(p.get("notificar"))})
    return out


@app.get("/api/comprobantes/{did}/destinatarios")
def destinatarios_correo(did: int, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """Para la ventana «Enviar por correo»: correo del cliente, sus personas asociadas y el último envío (3.38)."""
    d = _documento_ctx(s, ctx, did)
    cliente = _cliente(s, ctx.empresa.id, d.cliente_id) if d.cliente_id else None
    return {"para": _para_cliente(cliente), "cc_fijo": _correos_de(getattr(cliente, "correo_cc", None)) if cliente else [],
            "cliente": cliente.nombre if cliente else (d.receptor_nombre or None),
            "personas": _personas_copia(s, ctx.empresa.id, d.cliente_id, solo_marcadas=False), "correo_enviado": d.correo_enviado,
            "estado": d.estado, "consecutivo": d.consecutivo, "con_respuesta": bool(d.respuesta_nombre)}


@app.post("/api/comprobantes/{did}/correo")
def enviar_correo(did: int, data: CorreoIn, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa
    d = _documento_ctx(s, ctx, did)
    cliente = _cliente(s, e.id, d.cliente_id) if d.cliente_id else None
    para = _correos_validos(data.para, "Para") if (data.para or "").strip() else _para_cliente(cliente)
    cc = _correos_validos(data.cc, "Copia") if data.cc is not None else _cc_cliente(s, e.id, cliente)
    cc = [x for x in cc if x not in para]
    if len(para) + len(cc) > 60:                         # más que eso muchos servidores de correo rechazan el mensaje
        raise HTTPException(400, "Máximo 60 destinatarios por envío")
    base = str(ctx.request.base_url) if getattr(ctx, "request", None) is not None else None
    _correo_comprobante(s, e, d, para, base, cc=cc, mensaje=(data.mensaje or "").strip() or None)
    _auditar(ctx, "correo_enviado", f"{d.consecutivo} a {', '.join(para)}" + (f" (copia: {', '.join(cc)})" if cc else ""))
    return {"ok": True, "para": para, "cc": cc, "documento": d}


def _programar_correo_automatico(e: Empresa, d: Documento, usuario, sincrono: bool = False) -> None:
    """En cuanto Hacienda ACEPTA un comprobante, lo envía al cliente en segundo plano (si la empresa tiene activado el envío
    automático, SMTP configurado y el cliente tiene correo). Un fallo no afecta la operación: queda en la auditoría como
    'correo_fallido' y el botón ✉ sigue disponible para reintentar a mano. `sincrono=True` (cola/cron) lo envía en el acto.
    Etapa 1: en una instalación vinculada no se envía desde la computadora: lo manda la nube, una sola vez, al recibir el comprobante aceptado."""
    if _sinc.MODO_LOCAL and _sinc.correo_en_nube(e.id):
        return
    if not getattr(e, "correo_automatico", True) or not (e.smtp_host and e.smtp_remitente) or (d.correo_enviado and not str(d.correo_enviado).startswith("enviando")) or not d.cliente_id:
        return
    eid, did = e.id, d.id
    quien = types.SimpleNamespace(id=getattr(usuario, "id", None), correo=getattr(usuario, "correo", None))

    def _tarea():
        from .db import engine_empresa
        consecutivo, para = str(did), []
        try:
            with Session(engine) as sc:
                emp = sc.get(Empresa, eid)
            with Session(engine_empresa(eid)) as se:
                # se reclama el envío con un UPDATE condicionado: dos pasadas de la cola no mandan dos correos (R94)
                marca, limite = "enviando:" + ahora_cr().isoformat(timespec="seconds"), "enviando:" + (ahora_cr() - timedelta(minutes=15)).isoformat(timespec="seconds")
                tomado = se.execute(text("UPDATE documento SET correo_enviado = :m WHERE id = :id AND estado = 'aceptado' AND (correo_enviado IS NULL OR "
                                         "(correo_enviado LIKE 'enviando:%' AND correo_enviado < :lim))"), {"id": did, "m": marca, "lim": limite}).rowcount   # un reclamo de más de 15 min caducó (proceso muerto)
                se.commit()
                if not tomado:
                    return
                doc = se.get(Documento, did)
                consecutivo = doc.consecutivo
                cli = se.get(Cliente, doc.cliente_id) if doc.cliente_id else None
                para = _para_cliente(cli)
                if not para:
                    return
                cc = [x for x in _cc_cliente(se, eid, cli) if x not in para]
                _correo_comprobante(se, emp, doc, para, cc=cc)
                if cc:
                    para = para + [f"copia: {', '.join(cc)}"]
            with Session(engine) as sc:
                auditar(sc, "correo_enviado", f"{consecutivo} a {', '.join(para)} (automático al aceptar Hacienda)", None, eid, None, quien.correo)
        except Exception as ex:  # noqa: BLE001
            detalle = getattr(ex, "detail", None) or str(ex)
            try:
                with Session(engine_empresa(eid)) as se:    # libera el reclamo: el botón ✉ y la siguiente pasada pueden reintentar
                    se.execute(text("UPDATE documento SET correo_enviado = NULL WHERE id = :id AND correo_enviado LIKE 'enviando:%'"), {"id": did}); se.commit()
            except Exception:  # noqa: BLE001
                pass
            with Session(engine) as sc:
                auditar(sc, "correo_fallido", f"{consecutivo}: {detalle}"[:500], None, eid, None, quien.correo)

    if sincrono:
        _tarea()
    else:
        threading.Thread(target=_tarea, daemon=True).start()


# ---- consulta pública del comprobante (enlace sin sesión): token firmado {tipo: pub, eid, did}, válido 5 años
_PLANTILLA_CORREO_TIPO = {"01": "factura", "04": "factura", "09": "factura", "08": "factura", "02": "nota_debito", "03": "nota_credito", "10": "pago_recibido"}


def token_publico(e: Empresa, did: int) -> str:
    """Enlace de consulta válido 2 años; lleva la versión de enlaces de la empresa (Configuración › Integraciones › Invalidar)."""
    return auth.firmar({"tipo": "pub", "eid": int(e.id), "did": int(did), "v": int(getattr(e, "enlaces_version", 1) or 1)}, 2 * 365 * 86400)


def enlace_publico(e: Empresa, did: int, base: str | None = None) -> str | None:
    """Raíz: FE_URL_PUBLICA; sin ella, solo fuera de producción se toma la de la petición (en producción la cabecera Host no es
    de fiar para un enlace que sale en un correo con remitente real)."""
    if _sinc.MODO_LOCAL:                                        # etapa 1: un enlace a 127.0.0.1 no le abre al cliente; el correo lleva el PDF y el XML
        return None
    raiz = (URL_PUBLICA or ("" if PRODUCCION else (base or ""))).rstrip("/")
    return f"{raiz}/p/{token_publico(e, did)}" if raiz else None


class _SinCuerpo(BaseModel):
    pass


@app.post("/api/empresa/enlaces/invalidar")
def invalidar_enlaces(ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    """Invalida todos los enlaces públicos de consulta emitidos hasta ahora (los correos ya enviados dejan de abrir)."""
    e = s.get(Empresa, ctx.empresa.id)
    e.enlaces_version = int(e.enlaces_version or 1) + 1
    s.add(e); s.commit()
    _auditar(ctx, "enlaces_invalidados", f"versión {e.enlaces_version}")
    return {"ok": True, "version": e.enlaces_version}


def _correo_comprobante(s: Session, e: Empresa, d: Documento, para: list[str], base_url: str | None = None,
                        cc: list[str] | None = None, mensaje: str | None = None) -> None:
    """Envía PDF + XML (+ respuesta de Hacienda) a `para` y marca `correo_enviado`. Solo comprobantes aceptados. El texto sale de
    Configuración › Plantillas de correo (variables {{numero}} {{fecha}} {{total}} {{cliente}} {{enlace}}…) o del texto base."""
    if d.estado not in ("aceptado", "interno"):
        raise HTTPException(400, f"Solo se envían por correo comprobantes aceptados por Hacienda (estado actual: {d.estado}). "
                                 "Use Consultar para actualizar el estado")
    if not (e.smtp_host and e.smtp_remitente):
        raise HTTPException(400, "Configure el servidor SMTP en la empresa (host, remitente, usuario y contraseña)")
    if not para:
        raise HTTPException(400, "Indique el correo del destinatario (el cliente no tiene correo registrado)")
    _sinc.traer_archivos(e.id, d)                                        # etapa 2a
    try:
        xml = (XML_DIR / d.xml_nombre).read_bytes()
        datos = pdf.datos_desde_xml(xml)
        adjuntos = [(f"{d.consecutivo}.pdf", _pdf_de(d, e), "application", "pdf")]
        if d.estado != "interno":                                   # el comprobante interno va solo en PDF (3.61)
            adjuntos.append((d.xml_nombre, xml, "application", "xml"))
        if d.respuesta_nombre:
            adjuntos.append((d.respuesta_nombre, (XML_DIR / d.respuesta_nombre).read_bytes(), "application", "xml"))
        clave_smtp = secretos.descifrar(e.clave_cifrada, e.smtp_password)
    except FileNotFoundError as ex:
        raise HTTPException(404, f"Falta el archivo del comprobante en el servidor: {Path(ex.filename).name}")
    except ValueError as ex:
        raise HTTPException(400, f"No se pudo leer la contraseña SMTP guardada; vuelva a guardarla en Configuración. {ex}")
    total = pdf.fmt(datos["totales"]["total"], datos["moneda"])
    marca_doc = _marca_doc(e, d)
    nombre_marca = _marcas.nombre_de(e, marca_doc)                                      # (3.45)
    rem = _dz.de_empresa(e, marca_doc)                                                  # 3.83: logo y color de la marca o de la empresa
    fecha_doc = (d.fecha_emision or "")[:10]
    fecha_doc = f"{fecha_doc[8:10]}/{fecha_doc[5:7]}/{fecha_doc[:4]}" if len(fecha_doc) == 10 else ""
    enlace = enlace_publico(e, d.id, base_url)
    plantillas_correo = modulos.leer(s, e.id, "plantillas_correo", {}) or {}
    pl = (plantillas_correo.get("correo") or {}).get(_PLANTILLA_CORREO_TIPO.get(d.tipo_documento, "factura")) if isinstance(plantillas_correo, dict) else None
    variables = recordatorios.variables_doc(d, e.model_copy(update={"nombre_comercial": nombre_marca}), d.receptor_nombre or "", total, enlace, ahora_cr().date())
    if isinstance(pl, dict) and str(pl.get("cuerpo") or "").strip():
        texto = recordatorios.rellenar(pl.get("cuerpo"), variables)
        asunto = recordatorios.rellenar(pl.get("asunto"), variables).strip() or f"{datos['titulo']} {d.consecutivo} — {nombre_marca}"
        html = _dz.armar(rem, titulo=f"Le enviamos su {datos['titulo'].lower()}", antetitulo=datos["titulo"], asunto=asunto,
                         preencabezado=f"{datos['titulo']} {d.consecutivo} por {total}.", mensaje=mensaje or "", texto_libre=texto,
                         datos=[("Número", d.consecutivo), ("Fecha", fecha_doc), ("Total", total)],
                         boton_=("Ver el comprobante en línea", enlace) if enlace else None, nota=f"Clave numérica: {d.clave}" if d.clave else "")
        if enlace:
            texto += f"\n\nConsulte el comprobante en línea: {enlace}\n"
    else:
        html, texto = correo.plantilla_comprobante(nombre_marca, datos["titulo"], d.consecutivo, total, d.clave,
                                                   con_respuesta=bool(d.respuesta_nombre), enlace=enlace, rem=rem,
                                                   cliente=d.receptor_nombre or "", fecha=fecha_doc, mensaje=mensaje or "")
        asunto = f"{datos['titulo']} {d.consecutivo} — {nombre_marca}"
    if mensaje:                                          # nota de quien envía, arriba del texto de la plantilla (3.38; en el HTML va como cita, 3.83)
        texto = mensaje + "\n\n" + texto
    cfg = _cfg_smtp(e, clave_smtp)
    if nombre_marca and nombre_marca != (e.nombre_comercial or e.nombre):            # el correo sale a nombre de la marca (3.45)
        cfg.nombre = nombre_marca
    try:
        correo.enviar(cfg, para, asunto[:200], html, texto, adjuntos, cc=cc or None)
    except correo.ErrorCorreo as ex:
        raise HTTPException(502, str(ex))
    except Exception as ex:
        raise HTTPException(502, f"No se pudo enviar el correo: {ex}")
    d.correo_enviado = ahora_cr().isoformat(timespec="seconds")
    s.add(d); s.commit(); s.refresh(d)


def recordatorios_cobro_empresa(e: Empresa, hoy=None) -> dict:
    """Manda por correo los recordatorios de cobro que tocan hoy (Configuración › Notificaciones de cobro). Una pasada por día
    y por empresa; cada factura recibe cada tipo de recordatorio una sola vez."""
    hoy = hoy or ahora_cr().date()
    if not (e.smtp_host and e.smtp_remitente):
        return {"empresa_id": e.id, "enviados": 0, "motivo": "sin SMTP"}
    with Session(engine_empresa(e.id)) as s:
        cfg = modulos.leer(s, e.id, "notificaciones", None)
        if not isinstance(cfg, dict) or not any(isinstance(cfg.get(t), dict) and cfg[t].get("activo") for t in recordatorios.TIPOS):
            return {"empresa_id": e.id, "enviados": 0, "motivo": "desactivado"}
        marca = modulos.leer(s, e.id, "recordatorios_enviados", None)
        marca = marca if isinstance(marca, dict) else {}
        if marca.get("fecha") == hoy.isoformat():
            return {"empresa_id": e.id, "enviados": 0, "motivo": "ya revisado hoy"}
        enviados = [x for x in (marca.get("enviados") or []) if isinstance(x, str)]
        docs = s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente, Documento.tipo_documento.in_(("01", "02", "09")))).all()
        pendientes = recordatorios.seleccionar(cfg, docs, hoy, enviados)
        n = 0; errores = 0
        try:
            clave_smtp = secretos.descifrar(e.clave_cifrada, e.smtp_password)
        except ValueError:
            return {"empresa_id": e.id, "enviados": 0, "motivo": "clave SMTP ilegible"}
        cfg_smtp = _cfg_smtp(e, clave_smtp)
        mensajes, claves = [], []
        remitentes: dict = {}                                    # 3.83: un remitente (logo y color) por marca
        titulos = {"proximas": "Su factura vence pronto", "vencimiento": "Su factura vence hoy", "vencidas": "Tiene una factura vencida"}
        for d, tipo in pendientes:
            cliente = _cliente(s, e.id, d.cliente_id) if d.cliente_id else None
            para = _correos_de(cliente.correo if cliente else "")
            if not para:
                enviados.append(f"{d.id}|{tipo}"); continue         # sin correo: no se insiste
            c = cfg[tipo]
            saldo = pdf.fmt(recordatorios.saldo_doc(d), d.moneda)
            variables = recordatorios.variables_doc(d, e, d.receptor_nombre or (cliente.nombre if cliente else "") or "estimado cliente", saldo, enlace_publico(e, d.id), hoy)
            asunto = recordatorios.rellenar(c.get("asunto"), variables).strip() or f"Recordatorio de pago · {d.consecutivo}"
            texto = recordatorios.rellenar(c.get("cuerpo"), variables)
            if d.marca_id not in remitentes:
                remitentes[d.marca_id] = _dz.de_empresa(e, _marcas.marca_de(s, e.id, d.marca_id) or _marcas.predeterminada(s, e.id))
            vence_doc = (d.fecha_vencimiento or "")[:10]
            html = _dz.armar(remitentes[d.marca_id], titulo=titulos.get(tipo, "Recordatorio de pago"), asunto=asunto, preencabezado=f"Saldo pendiente: {saldo}.",
                             texto_libre=texto, datos=[("Factura", d.consecutivo), ("Saldo pendiente", saldo),
                                                       ("Vence", f"{vence_doc[8:10]}/{vence_doc[5:7]}/{vence_doc[:4]}" if len(vence_doc) == 10 else "")],
                             boton_=("Ver la factura en línea", variables.get("enlace")) if variables.get("enlace") else None,
                             nota="Si ya pagó, gracias, y por favor ignore este recordatorio.")
            mensajes.append((para, asunto[:200], html, texto + (f"\n\n{variables['enlace']}" if variables.get("enlace") else "")))
            claves.append((d, tipo, para))
        # una sola conexión SMTP para todos; si el servidor no responde, se corta y se reintenta otro día (la selección es por ventana)
        resultados = correo.enviar_varios(cfg_smtp, mensajes) if mensajes else []
        for (d, tipo, para), err in zip(claves, resultados):
            if err is None:
                enviados.append(f"{d.id}|{tipo}"); n += 1
                _auditar_u(None, e.id, None, "recordatorio_enviado", f"{tipo}: {d.consecutivo} a {', '.join(para)}")
            else:
                errores += 1
                _auditar_u(None, e.id, None, "recordatorio_fallido", f"{tipo}: {d.consecutivo}: {str(err)[:200]}")
        try:
            v = modulos.versiones(s, e.id).get("recordatorios_enviados", 0)
            modulos.reemplazar(s, e.id, "recordatorios_enviados", {"fecha": hoy.isoformat(), "enviados": enviados[-5000:]}, version=v)
            s.commit()
        except Exception as ex:  # noqa: BLE001
            s.rollback()
            _auditar_u(None, e.id, None, "recordatorio_fallido", f"no se pudo guardar la marca de recordatorios: {str(ex)[:150]}")
    return {"empresa_id": e.id, "enviados": n, "errores": errores}


def recordatorios_cobro_todas() -> list[dict]:
    """Pasada diaria de recordatorios de cobro de todas las empresas (la llama la cola de Hacienda)."""
    out = []
    with Session(engine) as sc:
        empresas = sc.exec(select(Empresa).where(Empresa.bloqueada == False)).all()  # noqa: E712
    for e in empresas:
        try:
            out.append(recordatorios_cobro_empresa(e))
        except Exception as ex:  # noqa: BLE001
            out.append({"empresa_id": e.id, "error": str(ex)[:200]})
    return out


def _auditar(ctx: Contexto, accion: str, detalle: str):
    """Registra en la auditoría central (la sesión `s` de las rutas es la de la empresa). Lo hecho con un token de API queda
    marcado con el nombre del token."""
    t = getattr(ctx, "token_api", None)
    _auditar_u(ctx.usuario, ctx.empresa.id, ctx.request, accion, (f"[API: {t.nombre} ({t.prefijo}…)] " if t is not None else "") + str(detalle or ""))


def _auditar_u(usuario, eid: int, request, accion: str, detalle: str):
    """Auditoría central desde una ruta (usuario + request) o desde la cola de Hacienda (sin usuario)."""
    try:
        with Session(engine) as sc:
            auditar(sc, accion, detalle, usuario, eid, request, None if usuario else "sistema (cola Hacienda)")
    except Exception:  # noqa: BLE001  la auditoría nunca convierte una operación exitosa en error
        import logging; logging.getLogger(__name__).exception("No se pudo auditar %s", accion)


def _cliente_hacienda(e: Empresa) -> hacienda.ClienteHacienda:
    if not (e.usuario_hacienda and e.password_hacienda):
        raise HTTPException(400, "Configure usuario y contraseña de Hacienda en Configuración › Facturación electrónica")
    try:
        clave = secretos.descifrar(e.clave_cifrada, e.password_hacienda)
    except ValueError as ex:
        raise HTTPException(500, str(ex))
    return hacienda.ClienteHacienda(hacienda.Credenciales(e.ambiente, e.usuario_hacienda, clave))


def _verificar_ambiente(d: Documento, e: Empresa) -> None:
    if (d.ambiente or "sandbox") != e.ambiente:
        raise HTTPException(409, f"Este comprobante se emitió en el ambiente '{d.ambiente}' y la empresa está en '{e.ambiente}': "
                                 "no se puede enviar ni consultar en otro ambiente")


def _guardar_respuesta(d: Documento, res: dict) -> None:
    if res.get("respuesta_xml"):
        d.respuesta_nombre = f"{d.clave}_respuesta.xml"
        (XML_DIR / d.respuesta_nombre).write_bytes(res["respuesta_xml"])


def _aplicar_estado_hacienda(s: Session, e: Empresa, d: Documento, res: dict) -> bool:
    """Aplica el resultado de una consulta: aceptado/rechazado/error son terminales; recibido/procesando no cambian nada.
    Si Hacienda RECHAZA, el movimiento de inventario del comprobante se revierte (la venta no existió).
    Devuelve True si el comprobante acaba de pasar a 'aceptado' (para disparar el correo automático tras el commit)."""
    nuevo = res.get("estado")
    recien_aceptado = nuevo == "aceptado" and d.estado != "aceptado"
    revertir = nuevo == "rechazado" and d.estado != "rechazado" and d.tipo_documento in ("01", "04", "09", "03", "08")
    ya_rechazado = nuevo == "rechazado" and d.estado == "rechazado"     # 4.15: consultarlo otra vez no borra la nota del cobro revertido
    if nuevo in ("aceptado", "rechazado", "error"):
        d.estado = nuevo
    if not ya_rechazado:
        d.mensaje_hacienda = res.get("detalle") or res.get("error") or f"Estado Hacienda: {nuevo}"
    if revertir:
        # El estado ya cambió: la reversión del inventario se hace permitiendo existencias negativas (la mercadería de una
        # nota de crédito rechazada pudo venderse mientras tanto). Antes la reversión iba primero y, si fallaba por existencias,
        # el comprobante seguía 'enviado' y la cola repetía la reversión parcial en cada reintento.
        # 4.9 (R4): se revierte cada movimiento del comprobante, no sus líneas: un ítem con receta mueve sus ingredientes y no a sí mismo,
        # así que buscar las líneas por los ítems movidos no encontraba nada y los ingredientes nunca volvían. Cada uno vuelve a su bodega.
        movs = s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.documento_id == d.id)).all()
        ya = {m.producto_id for m in movs if (m.referencia or "").startswith("REV ")}   # ítems ya revertidos: no se repite la reversión
        metodo = inventario.metodo_costeo(s, e.id) if movs else None
        for m in movs:
            if (m.referencia or "").startswith("REV ") or m.producto_id in ya:
                continue
            p = s.get(Producto, m.producto_id)
            if p and not p.es_servicio and p.inventariable:
                inventario.registrar_movimiento(s, producto=p, bodega_id=m.bodega_id, tipo="devolucion" if float(m.cantidad or 0) < 0 else "venta",
                                                cantidad=-float(m.cantidad or 0), fecha=ahora_cr().strftime("%Y-%m-%d"), referencia=f"REV {d.consecutivo}",
                                                documento_id=d.id, observaciones=m.observaciones, permitir_negativo=True, metodo=metodo)
    _guardar_respuesta(d, res)
    if revertir and d.tipo_documento in ("01", "04"):
        # 4.5: emitido desde un ticket de TiKe: sus horas y repuestos vuelven a quedar por cobrar (anulación directa o rechazo de Hacienda); confirma quien llama
        _tikec.liberar_documento(s, e.id, d, "", "anulado" if str(res.get("detalle") or "").startswith("Anulado") else "rechazado por Hacienda")
        _clinicas.liberar_documento(s, e.id, d)
    if (recien_aceptado or revertir) and d.tipo_documento == "03" and d.referencia_clave:
        # nota de crédito aceptada: rebaja el saldo de la factura que corrige (deja de estar por cobrar si la anula)
        # 3.87: y al anularla o rechazarla se recalcula (la interna ya contaba: el saldo vuelve a la factura)
        s.add(d); s.flush()
        modulos.recalcular_acreditado(s, e.id, d.referencia_clave)
        if recien_aceptado:
            _clinicas.liberar_si_acreditada(s, e.id, d.referencia_clave)
            _tikec.liberar_si_acreditada(s, e.id, d.referencia_clave)   # 4.5: la nota aceptada cubre la factura completa: lo cobrado de sus tickets vuelve a quedar por cobrar
    return recien_aceptado


def enviar_documento(s: Session, e: Empresa, d: Documento, usuario=None, request=None, sincrono: bool = False) -> Documento:
    """Envía a Hacienda un comprobante firmado. Lo usan el botón/endpoint y la cola de reintentos.
    Lanza HTTPException con mensaje claro (400 configuración, 409 ya enviado, 502/504 Hacienda no disponible)."""
    if d.estado == "interno":
        raise HTTPException(400, "Este comprobante es interno (la empresa no usa facturación electrónica): no se envía a Hacienda")
    if d.estado == "generado":
        raise HTTPException(400, "El comprobante no está firmado: cargue el certificado .p12 y vuelva a generarlo")
    if d.estado in ("enviado", "aceptado", "rechazado"):
        raise HTTPException(409, f"Este comprobante ya fue enviado a Hacienda (estado: {d.estado}). Use Consultar")
    _verificar_ambiente(d, e)
    antes = d.estado                                                # 3.87: aviso al dueño solo si RECIÉN pasa a rechazado o error
    cliente = _cliente(s, e.id, d.cliente_id) if d.cliente_id else None
    cli = _cliente_hacienda(e)
    try:
        xml_firmado = (XML_DIR / d.xml_nombre).read_bytes()
        emisor_json, receptor_json = {"tipo": e.tipo_id, "numero": e.numero_id}, ({"tipo": cliente.tipo_id, "numero": cliente.numero_id} if cliente and not _sin_identificacion(cliente) else None)
        if d.tipo_documento == "08" and cliente:
            emisor_json, receptor_json = receptor_json, emisor_json
        try:                                                        # lo que se declara a Hacienda es lo que está firmado en el XML (R241)
            raiz = etree.fromstring(xml_firmado)
            def _ident(nombre):
                nodo = raiz.find(f".//{{*}}{nombre}/{{*}}Identificacion")
                if nodo is None:
                    return None
                tipo, numero = nodo.findtext("{*}Tipo"), nodo.findtext("{*}Numero")
                return {"tipo": tipo, "numero": numero} if tipo and numero else None
            emisor_json = _ident("Emisor") or emisor_json
            receptor_json = _ident("Receptor") or receptor_json
        except etree.XMLSyntaxError:
            pass
        res = cli.enviar(
            d.clave, d.fecha_emision, emisor_json, receptor_json,
            xml_firmado,
        )
        if not res["ok"] and 400 <= res["status"] < 500:
            # Hacienda rechazó la petición: puede ser que la clave YA estaba recibida (reintento tras un timeout).
            est = cli.consultar(d.clave)
            if est["estado"] not in ("no_encontrado", "http_error"):
                d.estado = "enviado"
                recien = _aplicar_estado_hacienda(s, e, d, est)
                s.add(d); s.commit(); s.refresh(d)
                revertir_cobros_rechazado(s, e.id, d, antes)             # 4.15
                _auditar_u(usuario, e.id, request, "enviar_hacienda", f"{d.consecutivo}: ya estaba en Hacienda ({d.estado})")
                if recien:
                    _programar_correo_automatico(e, d, usuario, sincrono)
                if d.estado != antes:
                    _avisos_dueno.programar_rechazo(e, d, sincrono)
                return d
    except hacienda.CredencialesInvalidas as ex:
        raise HTTPException(400, str(ex))
    except RuntimeError as ex:
        raise HTTPException(502, str(ex))
    except httpx.HTTPError as ex:
        raise HTTPException(504, f"Hacienda no respondió ({type(ex).__name__}). El comprobante queda en cola y se reintentará "
                                 "automáticamente; no lo vuelva a emitir")
    if not res["ok"] and (res["status"] >= 500 or res["status"] in (408, 429)):
        # Hacienda no está disponible (error temporal, común a fin de mes): el comprobante sigue 'firmado' y la cola lo
        # reintenta con espera creciente (antes quedaba en 'error' y nadie lo volvía a enviar)
        d.mensaje_hacienda = f"Hacienda no disponible (HTTP {res['status']}); se reintentará automáticamente"
        s.add(d); s.commit(); s.refresh(d)
        raise HTTPException(502, f"Hacienda no está disponible en este momento (HTTP {res['status']}). El comprobante queda en cola y se "
                                 "reintentará automáticamente; no lo vuelva a emitir")
    d.estado = "enviado" if res["ok"] else "error"
    if res["ok"]:
        d.fecha_envio = ahora_cr().isoformat(timespec="seconds")
    d.mensaje_hacienda = res["error"] or ("Ya había sido recibido por Hacienda" if res.get("duplicado") else f"Recibido por Hacienda (HTTP {res['status']})")
    s.add(d); s.commit(); s.refresh(d)
    _auditar_u(usuario, e.id, request, "enviar_hacienda", f"{d.consecutivo}: {d.estado}")
    if d.estado != antes:
        _avisos_dueno.programar_rechazo(e, d, sincrono)               # 3.87: después del commit; solo actúa si quedó en error
    return d


def consultar_documento(s: Session, e: Empresa, d: Documento, usuario=None, request=None, sincrono: bool = False) -> Documento:
    """Consulta el estado en Hacienda y lo aplica (aceptado → correo automático; rechazado → revierte inventario)."""
    _verificar_ambiente(d, e)
    antes = d.estado                                                # 3.87: aviso al dueño solo si RECIÉN pasa a rechazado o error
    try:
        res = _cliente_hacienda(e).consultar(d.clave)
    except hacienda.CredencialesInvalidas as ex:
        raise HTTPException(400, str(ex))
    except RuntimeError as ex:
        raise HTTPException(502, str(ex))
    except httpx.HTTPError as ex:
        raise HTTPException(504, f"Hacienda no respondió la consulta ({type(ex).__name__}); se reintentará automáticamente")
    if res["estado"] == "http_error":
        raise HTTPException(502, f"Hacienda no pudo atender la consulta (HTTP {res['status']}): {res.get('error')}")
    recien = False
    if res["estado"] == "no_encontrado":
        if d.estado == "error":
            d.mensaje_hacienda = "Hacienda no tiene este comprobante: puede enviarlo de nuevo"
        elif d.estado == "enviado" and (ahora_cr() - datetime.fromisoformat(d.fecha_envio or d.fecha_emision)).total_seconds() > 86400:
            # más de 24 h 'enviado' y Hacienda no lo registra: pasa a 'error' para poder reenviarlo (antes quedaba atascado) (R96)
            d.estado = "error"; d.mensaje_hacienda = "Hacienda no registra este comprobante después de 24 horas: envíelo de nuevo"
        else:
            d.mensaje_hacienda = "Hacienda aún no registra este comprobante; vuelva a consultar en unos minutos"
    else:
        recien = _aplicar_estado_hacienda(s, e, d, res)
    s.add(d); s.commit(); s.refresh(d)
    revertir_cobros_rechazado(s, e.id, d, antes)                       # 4.15
    if recien:
        _programar_correo_automatico(e, d, usuario, sincrono)
    if d.estado != antes:
        _avisos_dueno.programar_rechazo(e, d, sincrono)               # 3.87: después del commit; solo actúa en rechazado o error
    return d


@app.post("/api/comprobantes/procesar-pendientes")
def procesar_pendientes(ctx: Contexto = Depends(requiere("facturar"))):
    """Envía lo firmado pendiente y consulta lo enviado de la empresa activa (si Hacienda responde). Lo llama la lista."""
    from . import cola
    try:
        with Session(engine_empresa(ctx.empresa.id)) as s:
            modulos.procesar_recurrentes(s, ctx.empresa.id, ahora_cr().date())   # facturas recurrentes cuya fecha llegó
    except Exception:  # noqa: BLE001
        pass
    f = cola._bloquear()                        # misma exclusión que el cron: dos pasadas a la vez repetían reversiones y correos (R94)
    if f is None:
        return {"omitido": "otra pasada de la cola está en curso", "enviados": 0, "aceptados": 0, "rechazados": 0}
    try:
        return cola.procesar_empresa(ctx.empresa.id, limite=20, usuario=ctx.usuario, sincrono=False)
    finally:
        try:
            f.close()
        except Exception:  # noqa: BLE001
            pass


@app.get("/api/hacienda/estado")
def estado_hacienda(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Última verificación de disponibilidad de Hacienda (por ambiente) y comprobantes pendientes de la empresa."""
    from . import cola
    return cola.estado(ctx.empresa, s)


@app.post("/api/cola/procesar")
def cola_procesar(x_cron_token: Optional[str] = Header(None)):
    """Para un cron externo (cPanel › Cron Jobs con curl): procesa la cola de TODAS las empresas.
    Protegido con el token FE_CRON_TOKEN (variable de entorno de la app)."""
    from . import cola
    if not CRON_TOKEN:
        raise HTTPException(503, "Defina FE_CRON_TOKEN en las variables de entorno de la aplicación para habilitar este endpoint")
    if not hmac.compare_digest((x_cron_token or "").strip().encode("utf-8", "replace"), str(CRON_TOKEN).encode()):
        raise HTTPException(403, "Token de cron inválido")
    return cola.procesar_todas(origen="cron")             # 3.87: la consola sabe si el cron existe y cuándo llamó


@app.get("/api/ping")
def ping():
    """3.87: respuesta mínima para un cron de calentamiento (mantiene vivo el proceso). No toca la base ni dice la versión."""
    return {"ok": True}


def _permiso_hacienda(ctx: Contexto, d: Documento) -> None:
    """Enviar/consultar: 'facturar'; el REP (tipo 10) también con 'cobros', que es quien lo registra (R100)."""
    if d.tipo_documento == "10" and ctx.puede("cobros"):
        return
    if d.tipo_documento == "08" and ctx.puede("gastos"):
        return
    if ctx.puede("pos") and d.tipo_documento in ("01", "04"):
        return
    ctx.exigir("facturar")


@app.post("/api/comprobantes/{did}/enviar")
def enviar_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    d = _documento_ctx(s, ctx, did)
    _permiso_hacienda(ctx, d)
    if _sinc.MODO_LOCAL and d.origen_sinc == _sinc.ORIGEN_NUBE:          # 4.16: un solo emisor
        raise HTTPException(409, "Este comprobante se emitió en la página web y lo envía ella a Hacienda")
    return enviar_documento(s, ctx.empresa, d, ctx.usuario, ctx.request)


@app.post("/api/comprobantes/{did}/consultar")
def consultar_comprobante(did: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    d = _documento_ctx(s, ctx, did)
    _permiso_hacienda(ctx, d)
    return consultar_documento(s, ctx.empresa, d, ctx.usuario, ctx.request)


@app.post("/api/comprobantes/{did}/anular")
def anular_comprobante(did: int, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    """Comprobante que nunca llegó a Hacienda ('generado' sin firma o 'error' al enviar): se anula y se devuelve el inventario
    que descontó (antes quedaba descontado para siempre y otra factura por la misma venta lo descontaba de nuevo) (R98)."""
    d = _documento_ctx(s, ctx, did)
    if d.estado not in ("generado", "error", "interno"):
        raise HTTPException(409, f"Solo se anulan comprobantes en estado 'generado', 'interno' o 'error' (este está '{d.estado}'); los aceptados se anulan con nota de crédito")
    if d.estado == "error" and d.xml_nombre and ctx.empresa.usuario_hacienda and ctx.empresa.password_hacienda:
        try:                                # por si Hacienda sí lo tiene (un 'error' por 'no registra' que llegó tarde)
            consultar_documento(s, ctx.empresa, d, ctx.usuario, ctx.request)
        except HTTPException:
            pass
        if d.estado != "error":
            raise HTTPException(409, f"Hacienda sí registra este comprobante (estado {d.estado}); no se puede anular")
    if d.tipo_documento in ("01", "04"):         # 4.5: emitido desde un ticket de TiKe: sus horas y repuestos vuelven a quedar por cobrar (la bitácora dice quién anuló)
        _tikec.liberar_documento(s, ctx.empresa.id, d, getattr(ctx.usuario, "nombre", "") or "", "anulado")
        _clinicas.liberar_documento(s, ctx.empresa.id, d)
    if d.tipo_documento == "03" and d.estado == "interno" and d.referencia_clave:
        # 4.5: la nota interna que dejó la factura acreditada por completo ya devolvió horas y repuestos al ticket de TiKe (no se puede
        # rehacer): anularla dejaría la factura con saldo y el ticket por cobrar otra vez (doble cobro)
        from .tike import TicketEntrada
        ref = s.exec(select(Documento).where(Documento.empresa_id == ctx.empresa.id, Documento.clave == d.referencia_clave)).first()
        if (ref is not None and ref.tipo_documento in ("01", "04") and float(ref.total or 0) - float(ref.acreditado or 0) <= 0.004
                and s.exec(select(TicketEntrada).where(TicketEntrada.empresa_id == ctx.empresa.id, TicketEntrada.tipo == "sistema",
                                                       TicketEntrada.texto.like(f"Comprobante {ref.consecutivo} acreditado por completo con nota de crédito:%"))).first() is not None):
            raise HTTPException(409, f"Esta nota de crédito devolvió horas o repuestos a un ticket de TiKe al dejar {ref.consecutivo} acreditada por completo; no se puede anular")
    _aplicar_estado_hacienda(s, ctx.empresa, d, {"estado": "rechazado", "detalle": "Anulado por el usuario: no fue aceptado por Hacienda"})
    s.add(d); s.commit(); s.refresh(d)
    _auditar(ctx, "anular", f"{CAT_TIPO.get(d.tipo_documento, d.tipo_documento)} {d.consecutivo} anulado (no aceptado por Hacienda)")
    return d


# ============================================================================= módulos comerciales (modulos.py)
# ---- registros: listas JSON por clave y empresa (cotizaciones, compras, bancos, contabilidad, tareas, configuración…)


def _clave_valida(clave: str):
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,80}", clave):
        raise HTTPException(400, "Clave de registro inválida")


def _puede_leer_registro(ctx: Contexto, clave: str) -> bool:
    """Cada rol recibe solo los registros que puede ver (salarios, bancos y contabilidad no llegan a un Vendedor)."""
    if not planes.permite_registro(ctx.empresa, clave):                  # módulo no incluido en el plan (3.16)
        return False
    if clave.startswith("hotel_") and auth.tipo_negocio_de(ctx.empresa) != "hospitalidad":   # las claves del hotel solo existen en hospitalidad (3.20)
        return False
    return ctx.usuario.es_superadmin or auth.puede_leer_registro(ctx.permisos, clave)


@app.get("/api/bancos/cuentas")
def bancos_cuentas(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Cuentas de Bancos para elegir dónde entra un cobro o sale un pago: nombre, tipo, moneda y si es la principal (sin saldos)."""
    if not (ctx.puede("cobros") or ctx.puede("gastos") or ctx.puede("ver_todo") or ctx.puede("rrhh") or ctx.puede("pos")):
        raise HTTPException(403, "Su rol no tiene acceso a las cuentas bancarias")
    out = []
    for b in modulos.leer(s, ctx.empresa.id, "bancos", []) or []:
        if isinstance(b, dict) and b.get("nombre"):
            out.append({"id": b.get("id"), "nombre": b["nombre"], "tipo": b.get("tipo") or "Banco", "moneda": b.get("moneda") or "CRC", "principal": bool(b.get("principal"))})
    return out


class MovimientoBancoIn(BaseModel):
    cuenta: str
    monto: float
    fecha: str
    descripcion: str = ""
    ref: str
    reemplazar: bool = False
    moneda: Optional[str] = None            # del documento (pago, planilla): el servidor lo pasa a la moneda de la cuenta
    tipo_cambio: Optional[float] = None


def _permiso_movimiento(ctx: Contexto, refs):
    """Gastos mueve cualquier cuenta; RRHH solo lo de planillas y liquidaciones (sin acceso al resto de Bancos).
    Se revisa CADA ref: una lista que empiece por una de planilla no habilita a quitar las demás."""
    if ctx.puede("gastos"):
        return
    refs = [refs] if isinstance(refs, str) else list(refs)
    if ctx.puede("rrhh") and refs and all(isinstance(r, str) and r.startswith(("planilla:", "liquidacion:", "aguinaldo:")) for r in refs):
        return
    # recepción del hotel: adelantos y pagos de la cuenta del huésped entran a Bancos sin tener acceso al resto (2.2);
    # la caja: dólares recibidos (cambio) y retiros depositados al banco (3.20)
    if (ctx.puede("cobros") or ctx.puede("pos")) and refs and all(isinstance(r, str) and r.startswith(("hotel:", "pos:")) for r in refs):
        return
    raise HTTPException(403, "Su rol no puede registrar movimientos bancarios")


# 4.7.1: la salida en Bancos de una planilla, liquidación o aguinaldo PAGADO tampoco se quita ni se reemplaza, para nadie (también con
# «gastos»): una pestaña abierta con la versión anterior que borraba algo pagado quitaba primero su movimiento y devolvía los préstamos,
# y después el servidor rechazaba el borrado. El movimiento se liga al documento por su ref_mov ('planilla:…', 'liquidacion:…',
# 'aguinaldo:…'); las planillas de versiones anteriores, por 'planilla:<id>'. Registrarlo al pagar y quitar el de algo sin pagar, sí.
# 4.22: y la del pago de las cargas del mes ('cargas:AAAA-MM:tipo'), que registra el servidor al guardar ese pago. Recursos humanos no
# puede mover esas refs por su cuenta (_permiso_movimiento no las incluye): el monto lo calcula el servidor, no el navegador.
_REFS_RRHH = {"planilla:": "planillas", "liquidacion:": "liquidaciones", "aguinaldo:": "rrhh_aguinaldos", "cargas:": "rrhh_pagos_cargas"}


def _items_que_mencionan(s: Session, eid: int, clave: str, textos, ids=()) -> list:
    """Elementos guardados de la colección cuyo texto trae alguno de `textos` (o con esos ids), sin leer ni convertir la lista completa
    (planillas y movimientos pueden ser miles). La búsqueda solo acota: quien llama compara exacto. Con muchos textos, o si la clave no
    es una colección, se lee la lista completa."""
    from sqlalchemy import or_
    textos = sorted({t for t in textos if isinstance(t, str) and t})
    ids = sorted({i for i in ids if i is not None and abs(i) <= modulos.ID_MAXIMO})   # un id enorme no es de nadie (y no cabe en la consulta)
    reg = modulos._registro(s, eid, clave) if (textos or ids) else None
    if reg is None:
        return []
    if not reg.coleccion or len(textos) + len(ids) > 100 or any(len(t) > 200 for t in textos):
        v = modulos.leer(s, eid, clave, [])
        return v if isinstance(v, list) else []
    RI = modulos.RegistroItem
    # el texto se guarda como JSON: se busca la ref tal como queda escrita ahí (comillas o barras escapadas)
    conds = [RI.datos.contains(json.dumps(t, ensure_ascii=False)[1:-1], autoescape=True) for t in textos]
    if ids:
        conds.append(RI.item_id.in_(ids))
    out = []
    for f in s.exec(select(RI).where(RI.empresa_id == eid, RI.clave == clave, or_(*conds))).all():
        try:
            out.append(json.loads(f.datos))
        except ValueError:
            continue
    return out


def _refs_rrhh_pagadas(s: Session, eid: int, refs) -> dict:
    """{ref: mensaje} de las refs que son la salida en Bancos de una planilla, liquidación o aguinaldo pagado (_rrhh_pagado). Solo mira
    la lista de RRHH de las refs que vienen: un pago a proveedores, o un borrado masivo de pagos, no lee nada de RRHH."""
    out = {}
    for prefijo, clave in _REFS_RRHH.items():
        mias = {r for r in refs if isinstance(r, str) and r.startswith(prefijo)}
        if not mias:
            continue
        viejas = [modulos._id_entero(r[len(prefijo):]) for r in mias] if clave == "planillas" else []   # 'planilla:<id>'
        art, pag, corregir = _RRHH_NOMBRE[clave]
        for x in _items_que_mencionan(s, eid, clave, mias, viejas):
            if not _rrhh_pagado(clave, x):
                continue
            propias = {x["ref_mov"]} if isinstance(x.get("ref_mov"), str) else set()
            if clave == "planillas" and modulos._id_entero(x.get("id")) is not None:
                propias.add(f"planilla:{modulos._id_entero(x.get('id'))}")
            nombre = _nombre_pago_cargas(x) if clave == "rrhh_pagos_cargas" else (x.get('numero') or x.get('anio') or x.get('id'))
            for r in propias & mias:
                out[r] = (f"{art} {nombre} ya está {pag}: su movimiento en Bancos no se quita ni "
                          f"se reemplaza. {corregir}")
    return out


def _sin_tocar_lo_pagado(s: Session, eid: int, refs) -> None:
    """403 si alguna ref es la salida en Bancos de una planilla, liquidación o aguinaldo pagado (no se quita nada del lote)."""
    pagadas = _refs_rrhh_pagadas(s, eid, refs)
    if pagadas:
        raise HTTPException(403, next(iter(pagadas.values())))


@app.post("/api/bancos/movimientos")
def registrar_movimiento(data: MovimientoBancoIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Registra (o con reemplazar, sustituye) el movimiento de un pago, planilla o liquidación en la cuenta de Bancos."""
    _permiso_movimiento(ctx, data.ref)
    if data.reemplazar:
        # 4.7.1: el de un documento de RRHH pagado no se reemplaza. Registrarlo al pagar sí: la pantalla lo manda con reemplazar, a
        # veces después del guardado que lo marca pagado, pero esa ref todavía no tiene movimiento
        pagadas = _refs_rrhh_pagadas(s, ctx.empresa.id, [data.ref])
        if pagadas and any(isinstance(m, dict) and m.get("ref") == data.ref
                           for m in _items_que_mencionan(s, ctx.empresa.id, "movimientos", [data.ref])):
            raise HTTPException(403, pagadas[data.ref])
    try:
        ok = modulos.registrar_movimiento_banco(s, ctx.empresa.id, data.cuenta, data.monto, data.fecha, data.descripcion, data.ref, data.reemplazar,
                                                data.moneda, data.tipo_cambio)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    return {"ok": ok}


@app.delete("/api/bancos/movimientos")
def quitar_movimiento(ref: str, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    refs = [r for r in ref.split(",") if r]
    _permiso_movimiento(ctx, refs)
    _sin_tocar_lo_pagado(s, ctx.empresa.id, refs)            # 4.7.1: la salida de una planilla, liquidación o aguinaldo pagado se queda
    return {"ok": True, "quitados": modulos.quitar_movimientos_banco(s, ctx.empresa.id, refs)}


class QuitarMovimientosIn(BaseModel):
    refs: list[str]


@app.post("/api/bancos/movimientos/quitar")
def quitar_movimientos(data: QuitarMovimientosIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Quita los movimientos de varias refs (borrado masivo de pagos o planillas): van en el cuerpo, no en la dirección."""
    refs = [r for r in data.refs if r]
    if len(refs) > 5000:
        raise HTTPException(400, "Demasiados movimientos en una sola solicitud")
    _permiso_movimiento(ctx, refs)
    _sin_tocar_lo_pagado(s, ctx.empresa.id, refs)            # 4.7.1: la pestaña vieja que borraba algo pagado se detiene aquí
    return {"ok": True, "quitados": modulos.quitar_movimientos_banco(s, ctx.empresa.id, refs)}


@app.get("/api/plan")
def plan_empresa(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Plan de la empresa activa con el uso de documentos del periodo (Inicio y avisos) (3.16)."""
    return planes.info(ctx.empresa, s)


def _ventanas_registros() -> dict:
    """Colecciones que al entrar viajan recortadas (3.73): las ventas de caja de los últimos FE_VENTANA_POS_DIAS días (90; 0 = todas).
    Las pantallas que necesitan el historial completo (reportes de caja, cierres) lo piden aparte."""
    from datetime import timedelta as _td
    try:
        dias = int(os.getenv("FE_VENTANA_POS_DIAS", "90") or 0)
    except ValueError:
        dias = 90
    if dias <= 0:
        return {}
    return {"pos_ventas": (ahora_cr().date() - _td(days=dias)).isoformat()}


def _sin_montos_texto(ctx: Contexto, texto: str) -> str:
    """3.87: el objeto {clave: datos} sin los campos con dinero para quien no los ve (Camarera, Técnico, Seguridad). Solo esos roles
    pagan el volver a leer el texto; a los demás les llega tal cual."""
    if not auth.sin_montos(ctx.permisos) or not any(f'"{k}":' in texto for k in auth.CAMPOS_MONTOS):
        return texto
    d = json.loads(texto)
    for k in auth.CAMPOS_MONTOS:
        if k in d:
            d[k] = auth.recortar_montos(ctx.permisos, k, d[k])
    return json.dumps(d, ensure_ascii=False, separators=(",", ":"))


def _registros_texto(ctx: Contexto, s: Session, con_ventana: bool) -> str:
    """{datos, versiones, topes, rango, parciales} de la empresa activa como texto JSON (3.72/3.73)."""
    ventanas = _ventanas_registros() if con_ventana else {}
    if auth.solo_pos(ctx.permisos):                                                       # 3.87: el Cajero, solo lo de su día en la caja
        ventanas = {**ventanas, **_ventana_cajero(s, ctx.empresa.id)}
    texto, vers, parciales = modulos.leer_todo_texto(s, ctx.empresa.id, lambda k: _puede_leer_registro(ctx, k), ventanas or None)
    texto = _sin_montos_texto(ctx, texto)                                                  # 3.87
    extra = {"versiones": vers, "topes": {k: n for k, n in modulos.topes(s, ctx.empresa.id).items() if k in vers},
             "rango": modulos.rango_propio(ctx.empresa.id), "parciales": parciales}     # instalación local: sus ids nuevos salen de su rango (3.13)
    return '{"datos":' + texto + "," + json.dumps(extra, ensure_ascii=False, separators=(",", ":"))[1:]


@app.get("/api/arranque")
def arranque_sesion(request: Request, response: Response, authorization: Optional[str] = Header(default=None), facturacr_token: Optional[str] = Cookie(default=None),
                    s: Session = Depends(get_session)):
    """Todo lo que la aplicación necesita al entrar, en una sola ida (3.73): sesión, empresa, clientes, ítems, registros y tipo de
    cambio. Antes eran cinco llamadas encadenadas y en internet cada una cuesta su ida y vuelta. Si la empresa no está lista (sin
    empresa elegida, contraseña por cambiar, términos pendientes, prueba vencida) solo viene la sesión y la aplicación sigue su
    camino de siempre."""
    u, datos = auth._autenticar(request, authorization, facturacr_token, s)
    yo = auth._respuesta(s, u, datos.get("eid"), request, response, sid=datos["sid"])
    dumps = lambda x: json.dumps(x, ensure_ascii=False, separators=(",", ":"), default=_json_default)  # noqa: E731
    partes = ['"yo":' + dumps(yo)]
    ctx = None
    if yo.get("empresa_id") and not getattr(u, "debe_cambiar_password", False):
        try:
            ctx = auth.contexto(request=request, authorization=authorization, facturacr_token=facturacr_token, s=s)
        except HTTPException:
            ctx = None                               # prueba vencida, términos pendientes, sin acceso…: la aplicación lo resuelve como siempre
    if ctx is not None:
        with ctx.sesion() as se:
            partes.append('"empresa":' + dumps(get_empresa(ctx)))
            partes.append('"clientes":' + dumps(clientes(ctx, se)))
            partes.append('"productos":' + dumps(productos(None, ctx, se)))
            partes.append('"registros":' + _registros_texto(ctx, se, True))
        try:
            partes.append('"tipo_cambio":' + dumps(get_tipo_cambio(0, ctx)))
        except Exception:  # noqa: BLE001  el tipo de cambio es un extra: si el BCCR no responde, la aplicación lo pide después
            pass
    resp = _json_rapido(request, texto="{" + ",".join(partes) + "}")
    for k, v in response.headers.items():                # la cookie de descargas que pone la sesión
        if k.lower() == "set-cookie":
            resp.headers.append("set-cookie", v)
    return resp


@app.get("/api/registros")
def get_registros(request: Request, v: int = 0, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Registros de la empresa activa. v=2: {datos: {clave: valor}, versiones: {clave: n}}; sin v: {clave: valor} (versión anterior).
    3.72: los elementos guardados ya son JSON y se envían tal cual (antes se parseaban, se volvían a serializar y pasaban por el
    codificador genérico: con miles de ventas de caja tardaba 10 veces más); va comprimido si el navegador acepta gzip."""
    if v >= 2:
        return _json_rapido(request, texto=_registros_texto(ctx, s, True))
    texto, _vers, _parc = modulos.leer_todo_texto(s, ctx.empresa.id, lambda k: _puede_leer_registro(ctx, k),   # versión anterior: todo, sin ventana
                                                  _ventana_cajero(s, ctx.empresa.id) if auth.solo_pos(ctx.permisos) else None)   # 3.87: menos al Cajero
    return _json_rapido(request, texto=_sin_montos_texto(ctx, texto))


@app.get("/api/registros/versiones")
def get_registros_versiones(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    return {k: n for k, n in modulos.versiones(s, ctx.empresa.id).items() if _puede_leer_registro(ctx, k)}


@app.get("/api/registros/{clave}")
def get_registro(clave: str, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _clave_valida(clave)
    if not _puede_leer_registro(ctx, clave):
        raise HTTPException(403, "Su rol no tiene acceso a estos datos")
    r = modulos._registro(s, ctx.empresa.id, clave)
    return {"clave": clave, "datos": _datos_registro(ctx, s, clave, modulos.leer(s, ctx.empresa.id, clave)),   # 3.87: sin montos para quien no los ve; el Cajero, su día
            "version": (r.version or 0) if r else 0, "coleccion": bool(r and r.coleccion),
            "ultimo_id": (r.ultimo_id or 0) if r else 0}


class RegistroIn(BaseModel):
    datos: Any
    version: Optional[int] = None          # versión leída; si otro la cambió desde entonces → 409 con la actual


def _ids_de_empleados(s: Session, eid: int) -> set:
    """4.22: los ids de las fichas de empleado guardadas."""
    v = modulos.leer(s, eid, "empleados", None)
    return {i for i in (modulos._id_entero(x.get("id")) for x in v if isinstance(x, dict)) if i is not None} if isinstance(v, list) else set()


def _limpiar_fichas_eliminadas(ctx: Contexto, s: Session, ids) -> bool:
    """4.22: lo que cuelga de la ficha de un empleado y solo escribe el servidor se va con ella: sus documentos (datos y archivos,
    app/rrhh_docs.py) y sus acciones de personal (que por el guardado genérico no se eliminan: _revisar_acciones). `ids`: los
    empleados que el guardado pudo quitar (aquí se descartan los que siguen guardados); None = todos (la lista completa).
    En /cambios y en el PUT completo se llama DESPUÉS de un guardado que tuvo éxito y nunca lo convierte en un error: lo que falle
    queda en el registro del servidor. El borrado de la lista completa (delete_registro) lo llama ANTES de borrar y mira lo que
    devuelve: True si todo se pudo quitar, False si algo falló (y entonces no borra la lista: los ids de empleado vuelven a
    empezar en 1 y un empleado nuevo heredaría los documentos y las acciones que quedaron). En el historial de operaciones deja
    cuántos se fueron y de qué fichas (sus ids).
    Las acciones de personal no se borran: cada una queda como una marca SIN ningún dato personal ({id, numero, estado
    «Eliminada», eliminada_en}: ni nombre, ni empleado, ni motivo, ni detalle, ni salarios, ni quién la registró), para que su
    número AP- siga ocupado y no se le dé nunca a otra acción (dos documentos firmados distintos con el mismo número). Las
    pantallas no las muestran ni las exportan; para el usuario, las acciones se fueron con la ficha."""
    eid, registro = ctx.empresa.id, logging.getLogger(__name__)
    if ids is not None:
        try:
            ids = {i for i in ids if i is not None} - _ids_de_empleados(s, eid)
        except Exception:  # noqa: BLE001  sin saber quién sigue guardado no se borra nada
            s.rollback()
            registro.exception("Empresa %s: no se pudo revisar qué fichas de empleado se eliminaron", eid)
            return False
        if not ids:
            return True
        orden = sorted(ids)
        de = "con la ficha " + ", ".join(f"#{i}" for i in orden[:20]) + (f" y {len(orden) - 20} más" if len(orden) > 20 else "")
    else:
        de = "al borrar la lista completa de empleados"
    docs = acciones = 0
    todo = True
    try:
        docs = _rrhh_docs.borrar_todos(s, eid) if ids is None else _rrhh_docs.borrar_de_empleados(s, eid, ids)
    except Exception:  # noqa: BLE001  la baja del empleado ya quedó guardada: esto no la deshace
        s.rollback()
        todo = False
        registro.exception("Empresa %s: no se pudieron quitar los documentos de las fichas eliminadas (%s)", eid, de)
    try:
        # al borrar la lista completa, si ya falló lo de los documentos la lista no se va a borrar: las acciones no se tocan
        guardadas = [] if ids is None and not todo else [a for a in (modulos.leer(s, eid, "rrhh_acciones", []) or []) if isinstance(a, dict)]
        ahora = ahora_cr().isoformat(timespec="seconds")
        marcas = [{"id": modulos._id_entero(a.get("id")), "numero": a.get("numero") if isinstance(a.get("numero"), str) else "", "estado": ESTADO_ACCION_ELIMINADA, "eliminada_en": ahora}
                  for a in guardadas if not _accion_eliminada(a) and modulos._id_entero(a.get("id")) is not None
                  and (ids is None or modulos._id_entero(a.get("empleado_id")) in ids)]
        if marcas:                                         # escribe el servidor directo: por el guardado genérico una acción no se cambia
            modulos.aplicar_cambios(s, eid, "rrhh_acciones", marcas, [], [])
        acciones = len(marcas)
    except Exception:  # noqa: BLE001
        s.rollback()
        todo = False
        registro.exception("Empresa %s: no se pudieron quitar las acciones de personal de las fichas eliminadas (%s)", eid, de)
    if docs:
        _auditar(ctx, "rrhh_documento_eliminado", f"{docs} {'documento eliminado' if docs == 1 else 'documentos eliminados'} {de}"[:500])
    if acciones:
        _auditar(ctx, "rrhh_accion_eliminada", f"{acciones} {'acción de personal eliminada' if acciones == 1 else 'acciones de personal eliminadas'} {de}"[:500])
    return todo


@app.put("/api/registros/{clave}")
def put_registro(clave: str, data: RegistroIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _clave_valida(clave)
    modo = _exigir_registro(ctx, clave)               # cada módulo exige su permiso (contabilidad, gastos, facturar, configurar…)
    data.datos, _aud = _revisar_escritura(ctx, s, clave, modo, datos=data.datos, version=data.version)   # 3.87: y lo que se reemplaza, por contenido
    if clave in planes.CLAVES_LIMITADAS:                 # habitaciones y cajas contratadas (3.16)
        planes.verificar_registro(ctx.empresa, clave, planes.total_registro(clave, data.datos))
    if clave == "hotel_reservas" and isinstance(data.datos, list):      # dos reservas en la misma habitación y noche (2.2)
        _sin_cruces_hotel([], data.datos, [])
    fichas_antes = _ids_de_empleados(s, ctx.empresa.id) if clave == "empleados" else set()   # 4.22: para saber a quién quitó este guardado
    from sqlalchemy.exc import IntegrityError
    try:
        nueva = modulos.reemplazar(s, ctx.empresa.id, clave, data.datos, data.version)
    except IntegrityError:
        s.rollback()
        raise HTTPException(409, {"mensaje": "Otro usuario guardó estos datos al mismo tiempo", "datos": _datos_registro(ctx, s, clave, modulos.leer(s, ctx.empresa.id, clave)), "version": (modulos._registro(s, ctx.empresa.id, clave).version or 0) if modulos._registro(s, ctx.empresa.id, clave) else 0})
    except modulos.RecargarPagina as rp:
        s.rollback()
        if rp.descartadas:
            raise HTTPException(409, "El sistema se actualizó: recargue la página (Ctrl+F5) y revise lo último que registró en esta "
                                     "pestaña; lo que falte, vuelva a hacerlo. Si ya emitió un comprobante, no lo emita de nuevo: búsquelo en la lista.")
        if rp.guardadas:
            raise HTTPException(409, "El sistema se actualizó. Lo nuevo que registró en esta pestaña sí quedó guardado: no lo repita. "
                                     "Recargue la página (Ctrl+F5) antes de seguir.")
        raise HTTPException(409, "El sistema se actualizó: recargue la página (Ctrl+F5) y vuelva a hacer el cambio. "
                                 "Si ya emitió un comprobante, no lo emita de nuevo: búsquelo en la lista.")
    except modulos.ConflictoRegistro as c:
        raise HTTPException(409, {"mensaje": "Otro usuario cambió estos datos", "datos": _datos_registro(ctx, s, clave, c.datos), "version": c.version})
    except ValueError as ex:
        raise HTTPException(413 if "tamaño" in str(ex) else 400, str(ex))
    for accion, detalle in _aud:                         # 4.21: el PUT completo también deja su auditoría (antes se perdía); solo si se guardó
        _auditar(ctx, accion, detalle)
    if fichas_antes:                                     # 4.22: las fichas que este guardado quitó se llevan sus documentos y sus acciones de personal
        _limpiar_fichas_eliminadas(ctx, s, fichas_antes)
    return {"ok": True, "clave": clave, "version": nueva}


class CambiosIn(BaseModel):
    upserts: list[dict] = []
    deletes: list[Any] = []
    nuevos: list[Any] = []


@app.post("/api/registros/{clave}/cambios")
def cambios_registro(clave: str, data: CambiosIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Altas, cambios y bajas por id en una colección: dos usuarios que agregan o cambian elementos distintos no se pisan."""
    _clave_valida(clave)
    _, auditoria = _revisar_escritura(ctx, s, clave, _exigir_registro(ctx, clave), data)   # 3.87: permiso de la clave y reglas por contenido
    if clave in planes.CLAVES_LIMITADAS and data.nuevos:                 # habitaciones contratadas (3.16)
        actuales = modulos.leer(s, ctx.empresa.id, clave, []) or []
        planes.verificar_registro(ctx.empresa, clave, len(actuales) + len(data.nuevos) - len(data.deletes))
    if clave == "hotel_reservas" and data.upserts:                      # la habitación no puede quedar con dos ocupantes (2.2)
        _sin_cruces_hotel(modulos.leer(s, ctx.empresa.id, clave, []) or [], data.upserts, data.deletes)
    from sqlalchemy.exc import IntegrityError
    from sqlalchemy.orm.exc import StaleDataError
    for intento in range(3):                         # dos procesos que dan el mismo id nuevo a la vez: se reintenta
        try:
            version, remap = modulos.aplicar_cambios(s, ctx.empresa.id, clave, data.upserts, data.deletes, data.nuevos)
            r = modulos._registro(s, ctx.empresa.id, clave)
            for accion, detalle in auditoria:            # 3.87: un cierre de caja cambiado o borrado queda con su antes y después
                if remap and accion == "rrhh_ficha_creada":   # 4.21: la ficha nueva cuyo id ya estaba ocupado se anota con el id que recibió
                    detalle = re.sub(r"^#(\d+) ", lambda m: f"#{remap.get(m.group(1), m.group(1))} ", detalle)
                _auditar(ctx, accion, detalle)
            respuesta = {"ok": True, "clave": clave, "version": version, "remap": remap, "ultimo_id": (r.ultimo_id or 0) if r else 0}
            if clave == "empleados" and data.deletes:    # 4.22: las fichas que este envío quitó se llevan sus documentos y sus acciones de personal
                _limpiar_fichas_eliminadas(ctx, s, {modulos._id_entero(d) for d in data.deletes})
            return respuesta
        except (IntegrityError, StaleDataError):     # StaleDataError: otro borró a la vez un elemento que aquí se cambiaba
            s.rollback()
            if intento == 2:
                raise HTTPException(409, "No se pudo guardar por cambios simultáneos; intente de nuevo")
        except ValueError as ex:
            s.rollback()
            raise HTTPException(413 if "tamaño" in str(ex) else 400, str(ex))


def _sin_cruces_hotel(existentes, upserts, deletes):
    errores = hotel.conflictos(existentes, upserts, deletes)
    if errores:
        raise HTTPException(409, errores[0])


class CorreoHotelIn(BaseModel):
    para: str
    asunto: str
    texto: str = Field(min_length=1, max_length=6000)


@app.post("/api/hotel/correo")
def hotel_correo(data: CorreoHotelIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Confirmación de reserva (o cualquier aviso del hotel) al huésped con el SMTP de la empresa (2.2)."""
    if not (ctx.puede("escribir") or ctx.puede("pos")):
        raise HTTPException(403, "Su rol no puede enviar correos del hotel")
    e = ctx.empresa
    if not (e.smtp_host and e.smtp_remitente):
        raise HTTPException(400, "Configure primero el correo saliente en Configuración › Empresa › Correo")
    para = _correos_de(data.para)
    if not para:
        raise HTTPException(400, "El huésped no tiene un correo válido")
    html = _dz.armar(_dz.de_empresa(e), titulo=data.asunto, asunto=data.asunto, texto_libre=data.texto, preencabezado=data.texto[:120])   # 3.83
    try:
        correo.enviar(_cfg_smtp(e), para, data.asunto, html, data.texto, [])
    except correo.ErrorCorreo as ex:
        auditar(s, "hotel_correo", f"FALLÓ a {para[0]}: {ex}"[:500], ctx.usuario, e.id, ctx.request)
        raise HTTPException(502, str(ex))
    _auditar(ctx, "hotel_correo", f"{data.asunto[:80]} a {', '.join(para)}")
    return {"ok": True, "para": para}


# ---- hotel 2.3: iCal, tareas diarias ----
def _exigir_registro(ctx: Contexto, clave: str) -> Optional[str]:
    """Permiso para escribir un registro: el del módulo; los del hotel (seguridad, limpieza, mantenimiento) también con 'escribir' (recepción) (3.3).
    3.87: quien entra sin el permiso completo de la clave sale con el modo que limita lo que escribe (_revisar_escritura):
    'estado_hab', 'tipos_problema', 'bloqueos' o 'caja'. None = permiso completo."""
    if not planes.permite_registro(ctx.empresa, clave):
        planes.exigir_modulo(ctx.empresa, planes.modulo_de_registro(clave))
    p = auth.permiso_registro(clave)
    if p in ("seguridad", "limpieza", "mantenimiento") and ctx.puede("escribir"):
        return None
    if clave == "hotel_folios" and (ctx.puede("cobros") or ctx.puede("escribir")):   # adelantos y pagos desde Reservaciones (QA 19/10/2026)
        return None
    # ama de llaves y mantenimiento sin «guardar registros» (3.20): estado de las habitaciones, tipos de problema y, para
    # mantenimiento, los bloqueos de habitaciones fuera de servicio (viven en hotel_reservas). 3.87: solo eso (antes la clave
    # completa: el Técnico cambiaba montos y borraba reservas, la Camarera borraba habitaciones y ambos vaciaban las listas)
    if clave in ("hotel_habitaciones", "hotel_tipos_problema") and (ctx.puede("limpieza") or ctx.puede("mantenimiento")) and not ctx.puede(p):
        return "estado_hab" if clave == "hotel_habitaciones" else "tipos_problema"
    if clave == "hotel_reservas" and ctx.puede("mantenimiento") and not ctx.puede(p):
        return "bloqueos"
    ctx.exigir(p)
    return "caja" if clave == "hotel_folios" else None       # 3.87: con solo «pos»: el cargo a habitación desde la caja


# 3.87: lo que se escribe se revisa por CONTENIDO, no solo por la clave
CAMPOS_ESTADO_HAB = ("estado", "estado_hora", "estado_usuario", "camarera", "notas")   # lo que cambian ama de llaves y mantenimiento
_NO_PUEDE = {
    "estado_hab": "Su rol solo cambia el estado de las habitaciones; agregarlas, quitarlas o cambiar sus datos lo hace quien configura el hotel",
    "tipos_problema": "Su rol agrega tipos de problema y cambia o quita los de su módulo, pero no vacía ni reemplaza la lista",
    "bloqueos": "Su rol solo crea, cambia o quita bloqueos de mantenimiento; las reservas de los huéspedes las maneja Recepción",
    "caja": "Desde la caja solo se agregan cargos a la cuenta de un huésped en casa; quitar o cambiar cargos y pagos se hace en Recepción",
    "pos_cajas": "Un cierre de caja ya hecho solo lo reabre o corrige quien registra cobros o administra la empresa",
    "pos_ventas": "Una venta ya emitida o de un cierre de caja ya hecho solo la corrige o elimina quien registra cobros o administra la empresa",
}
CAMPOS_ANULA_VENTA = ("anulada", "anulada_hora", "anulada_por", "motivo_anulacion", "nc_id", "nc_consecutivo")   # anular desde la caja (caja.js)
CAMPOS_EMITE_VENTA = ("doc_id", "consecutivo", "pendiente_id")   # la venta hecha sin red recibe su comprobante al volver la conexión
# 3.87: lo que pedidos.a_caja escribe en la cuenta de un pedido en línea (pos_espera): lo pagado y el enlace con el pedido. La caja
# no los cambia; el servidor los conserva aunque una caja guarde la cuenta sin ellos o con una copia vieja (SINPE rechazado después)
CAMPOS_PEDIDO_EN_LINEA = ("canal", "pedido_id", "pedido_numero", "prepago", "cupon", "puntos_canjeados", "credito")


def _no_negativos(d) -> bool:
    """Los valores numéricos del diccionario (otro impuesto de una línea) no son negativos."""
    for v in (d.values() if isinstance(d, dict) else ()):
        try:
            if not isinstance(v, bool) and float(v) < 0:
                return False
        except (TypeError, ValueError):
            continue
    return True


def _es_bloqueo_propio(r) -> bool:
    """Bloqueo de fechas hecho en el sistema (mantenimiento); los de iCal los pone la sincronización con Booking o Airbnb."""
    return isinstance(r, dict) and r.get("tipo") == "bloqueo" and r.get("origen") != "ical"


def _periodo_cerrado(s: Session, eid: int, fecha, cache: dict) -> Optional[str]:
    """«Octubre 2026» si la fecha cae en un periodo contable cerrado (periodos_<año>, Configuración › Periodos contables)."""
    f = str(fecha or "")[:10]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", f):
        return None
    if f[:4] not in cache:
        cache[f[:4]] = modulos.leer(s, eid, "periodos_" + f[:4], None) or []
    per = next((x for x in cache[f[:4]] if isinstance(x, dict) and modulos._id_entero(x.get("n")) == int(f[5:7])), None)
    return f"{per.get('mes') or f[5:7]} {f[:4]}" if per and per.get("estado") == "Cerrado" else None


def _items_guardados(s: Session, eid: int, clave: str, ids) -> dict:
    """{id: elemento} guardado de esos ids, sin leer la colección completa (los asientos pueden ser miles)."""
    ids = sorted({i for i in ids if i is not None})
    r = modulos._registro(s, eid, clave) if ids else None
    if r is None:
        return {}
    if not r.coleccion:
        v = modulos.leer(s, eid, clave, None)
        return {modulos._id_entero(x.get("id")): x for x in v if isinstance(x, dict) and modulos._id_entero(x.get("id")) in ids} if isinstance(v, list) else {}
    out, RI = {}, modulos.RegistroItem
    for i in range(0, len(ids), 500):
        for f in s.exec(select(RI).where(RI.empresa_id == eid, RI.clave == clave, RI.item_id.in_(ids[i:i + 500]))).all():
            try:
                out[f.item_id] = json.loads(f.datos)
            except ValueError:
                continue
    return out


# 4.7: planillas, aguinaldos y liquidaciones PAGADOS quedan cerrados: no se borran ni se cambian sus montos, empleados (filas),
# fechas ni su estado; lo pagado se corrige con un ajuste en la siguiente planilla o con una planilla complementaria. Los demás campos
# (marcas que el sistema agregue después de pagar, como un correo enviado) sí cambian. Lo que no está pagado se edita y borra como antes.
CAMPOS_RRHH_PAGADO = {
    "planillas": ("numero", "periodo", "desde", "hasta", "fecha", "empleados", "filas", "totales", "estado", "cuenta", "pagada_en", "ref_mov",
                  "complementaria", "referencia_id", "referencia_numero",
                  "generada_por", "generada_en", "aprobada_por", "aprobada_en"),   # 4.21: quién la generó y quién la aprobó (SELLOS_PLANILLA)
    "rrhh_aguinaldos": ("anio", "desde", "hasta", "fecha", "filas", "total", "estado", "cuenta", "ref_mov", "adicional", "referencia_id"),
    "liquidaciones": ("numero", "empleado_id", "nombre", "fecha", "fecha_salida", "motivo", "rubros", "total", "ccss_obrera", "ccss_patronal",
                      "antiguedad", "salario_mensual", "salario_diario", "estado", "cuenta", "pagada_en", "ref_mov",
                      "renta", "adicional", "referencia_id", "referencia_numero"),   # 4.7: la renta y el enlace de la liquidación adicional
}
_RRHH_NOMBRE = {"planillas": ("La planilla", "pagada", "Se corrige con un ajuste en la siguiente planilla o con una planilla complementaria."),
                "liquidaciones": ("La liquidación", "pagada", "Una diferencia se paga aparte."),
                "rrhh_aguinaldos": ("El aguinaldo", "pagado", "Una diferencia se paga aparte."),
                # 4.22: el pago de las cargas del mes (no pasa por _revisar_rrhh_pagado: su clave la escribe solo el servidor)
                "rrhh_pagos_cargas": ("El pago de las cargas de", "registrado", "Una diferencia se registra con un asiento manual.")}
# 4.21: reglas de contenido de Recursos humanos que no son «lo pagado» (eso sigue en _revisar_rrhh_pagado). Las claves de esta tupla
# pasan por _revisar_reglas_rrhh en /cambios y en el PUT completo: para sumar una regla, la clave va aquí y su caso en esa función.
CLAVES_RRHH_REGLAS = ("empleados", "rrhh_conceptos", "rrhh_parametros", "rrhh_horas_extra", "rrhh_ausencias", "rrhh_acciones")
# 4.22: registros que escribe SOLO el servidor, por sus propias rutas: los documentos del empleado (app/rrhh_docs.py: cada uno tiene
# su archivo) y los pagos de las cargas del mes (POST /api/rrhh/pago-cargas: el monto lo calcula el servidor). El guardado genérico
# (PUT de la clave y /cambios) responde 403 con este texto, y el borrado de la clave completa también mientras tenga algo.
CLAVES_SOLO_SERVIDOR = {"rrhh_documentos": "Los documentos se suben desde la ficha del empleado",
                        "rrhh_pagos_cargas": "El pago de las cargas del mes se registra en Recursos humanos › Reportes"}
# 4.21: acciones de personal (rrhh_acciones). Una acción guardada no se edita ni se elimina: se anula con su motivo. Quién y cuándo la
# registró, la anuló o la aplicó a la ficha lo pone el servidor (SELLOS_ACCION: lo que mande el navegador en ellos no cuenta). Solo
# las de TIPOS_ACCION_A_FICHA cambian la ficha (puesto, departamento, categoría o salario) y pueden marcarse aplicadas después
TIPOS_ACCION_PERSONAL = {"ingreso": "Ingreso", "aumento": "Aumento", "traslado": "Traslado", "cambio_puesto": "Cambio de puesto",
                         "amonestacion": "Amonestación", "suspension": "Suspensión", "salida": "Salida"}
TIPOS_ACCION_A_FICHA = ("aumento", "traslado", "cambio_puesto")
SELLOS_ACCION = ("registrada_por", "registrada_en", "anulada_por", "anulada_en", "aplicada_por", "aplicada_en")
# 4.22: lo que queda de una acción cuando se elimina la ficha de su empleado (_limpiar_fichas_eliminadas): una marca {id, numero,
# estado, eliminada_en} sin ningún dato personal. Solo guarda el número, para que no se vuelva a dar; no se cambia ni se anula
ESTADO_ACCION_ELIMINADA = "Eliminada"
# 4.21: campos de la ficha del empleado cuyo cambio queda en el historial de operaciones (QUÉ cambió, nunca el valor)
CAMPOS_FICHA_SENSIBLE = ("modo_salario", "salario_hora", "salario_mensual", "cuenta_iban", "forma_pago", "hijos", "conyuge", "aplica_renta", "ins_riesgos")
# 4.21: aprobación de la planilla. Los cuatro sellos los pone el servidor con el usuario de la sesión y la fecha de hoy (lo que mande
# el navegador en ellos no cuenta); «contenido» es lo que, al cambiar, deja la planilla como recién generada por quien la cambió
SELLOS_PLANILLA = ("generada_por", "generada_en", "aprobada_por", "aprobada_en")
CONTENIDO_PLANILLA = ("periodo", "desde", "hasta", "filas", "totales")
PARAMETROS_APROBACION = (("exigir_aprobacion_planilla", "Aprobación de la planilla antes de pagarla"),
                         ("aprobacion_otro_usuario", "Aprobación por un usuario distinto del que generó la planilla"))


def _rrhh_pagado(clave: str, x) -> bool:
    """4.7: ¿ya se pagó? Planillas y liquidaciones al marcarlas pagadas; el aguinaldo se registra pagado (los de antes, sin estado).
    4.7.1: una sola regla para /cambios, el PUT completo, el borrado de la lista completa y los movimientos de Bancos de lo pagado:
    estado Pagada/Pagado sin importar mayúsculas ni espacios, o con fecha de pago (el borrado de la lista usaba otra y dejaba pasar
    los aguinaldos sin estado)."""
    if not isinstance(x, dict):
        return False
    estado = str(x.get("estado") or "").strip().lower()
    return estado in ("pagada", "pagado") or bool(x.get("pagada_en")) or (clave == "rrhh_aguinaldos" and not estado)


def _planillas_se_cruzan(a: dict, b: dict) -> bool:
    """4.7: las dos planillas cubren algún día en común y comparten al menos un empleado."""
    fechas = [str(x.get(k) or "")[:10] for x in (a, b) for k in ("desde", "hasta")]
    if not all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", f) for f in fechas) or not (fechas[0] <= fechas[3] and fechas[1] >= fechas[2]):
        return False

    def emp(p):
        filas = p.get("filas") if isinstance(p.get("filas"), list) else []
        return {modulos._id_entero(f.get("empleado_id")) for f in filas if isinstance(f, dict)} - {None}
    return bool(emp(a) & emp(b))


def _misma_planilla(a, x: dict, p: dict) -> bool:
    """4.7.1: ¿la planilla pagada guardada `p` es el mismo elemento que el que se revisa? El que se cambia (`a`, por su id) o, en un alta,
    su reintento idéntico (respuesta perdida: aplicar_cambios no lo duplica). Un alta con el id de OTRA planilla recibe un id nuevo al
    guardarse, así que esa planilla sí se compara (antes se descartaba por tener el mismo id y se colaba una repetida)."""
    if isinstance(a, dict):
        return modulos._id_entero(p.get("id")) == modulos._id_entero(a.get("id"))
    try:
        return modulos._id_entero(p.get("id")) == modulos._id_entero(x.get("id")) and modulos._json(p) == modulos._json(x)
    except (TypeError, ValueError):
        return False


def _planilla_aprobada(p) -> bool:
    """4.21: ¿la planilla está aprobada y sin pagar? El estado, sin importar mayúsculas ni espacios (como _rrhh_pagado)."""
    return isinstance(p, dict) and str(p.get("estado") or "").strip().lower() == "aprobada" and not _rrhh_pagado("planillas", p)


def _aprobacion_planillas(ctx: Contexto, s: Session, eid: int, cambios: list) -> list:
    """4.21: quién generó y quién aprobó cada planilla, y la aprobación antes de pagarla si la empresa la exige (Recursos humanos ›
    Parámetros: exigir_aprobacion_planilla y aprobacion_otro_usuario, apagadas por omisión; la segunda solo cuenta con la primera).
    `cambios`: [(guardado | None, nuevo)], los de _revisar_rrhh_pagado; completa el elemento nuevo en sitio y devuelve la auditoría.
    - Los sellos (SELLOS_PLANILLA) son del servidor: en una planilla sin pagar valen los guardados, diga lo que diga el navegador; en
      una pagada se reponen los que no vengan (una pestaña que no los recibió) y un valor distinto lo rechaza la regla de lo pagado.
    - Alta, o cambio del contenido (CONTENIDO_PLANILLA): queda generada por la sesión, hoy. Si estaba aprobada y no vuelve a
      «Generada» en el mismo guardado, 403: primero se le quita la aprobación.
    - Pasa a «Aprobada»: queda aprobada por la sesión, hoy. Con aprobacion_otro_usuario no la aprueba quien la generó (403); una
      planilla de antes, sin ese dato, se deja aprobar y la auditoría lo dice.
    - De «Aprobada» a otro estado sin pagar: se le quitan los sellos de la aprobación.
    - Con exigir_aprobacion_planilla solo se paga la que estaba «Aprobada»; un alta que ya viene pagada tampoco entra (403).
    Con las dos opciones apagadas nada se rechaza por la aprobación: solo se anotan los sellos. El detalle de la auditoría lleva el
    número de la planilla y los correos de los usuarios, nunca montos."""
    correo, hoy = str(getattr(ctx.usuario, "correo", None) or ""), ahora_cr().strftime("%Y-%m-%d")
    p = _rrhh_parametros(s, eid)
    exigir = p.get("exigir_aprobacion_planilla") is True
    otro = exigir and p.get("aprobacion_otro_usuario") is True
    nombre = lambda x: f"La planilla {x.get('numero') or x.get('id')}"            # noqa: E731
    sin_sellos = lambda d: {k: v for k, v in d.items() if k not in SELLOS_PLANILLA}   # noqa: E731
    guardadas, auditoria = None, []
    for a, x in cambios:
        if not isinstance(x, dict):
            continue
        if isinstance(a, dict):
            if _rrhh_pagado("planillas", a):
                for k in SELLOS_PLANILLA:
                    if x.get(k) in (None, "") and a.get(k) not in (None, ""):
                        x[k] = a[k]
                continue
            for k in SELLOS_PLANILLA:
                if k in a:
                    x[k] = a[k]
                else:
                    x.pop(k, None)
            if a == x:
                continue
        else:
            # un alta idéntica (sin contar los sellos) a lo guardado con su id es un reintento (respuesta perdida): queda igual a lo
            # guardado, sellos incluidos, para que aplicar_cambios no la tome por otra planilla y la duplique con un id nuevo
            if guardadas is None:
                guardadas = {modulos._id_entero(g.get("id")): g for g in (modulos.leer(s, eid, "planillas", []) or []) if isinstance(g, dict)}
            g = guardadas.get(modulos._id_entero(x.get("id")))
            if g is not None and sin_sellos(g) == sin_sellos(x):
                x.clear(); x.update(g)
                continue
            for k in ("aprobada_por", "aprobada_en"):      # un alta no trae un aprobador propio; quién la generó se pone abajo, en su
                x.pop(k, None)                             # sitio (así lo guardado queda igual, letra por letra, a lo que mandó la pantalla)
        contenido = not isinstance(a, dict) or any(a.get(k) != x.get(k) for k in CONTENIDO_PLANILLA)
        era, queda, pagada = _planilla_aprobada(a), _planilla_aprobada(x), _rrhh_pagado("planillas", x)
        if contenido:
            if era and (queda or pagada):
                raise HTTPException(403, f"{nombre(a)} está aprobada. Quite la aprobación antes de corregirla")
            x["generada_por"], x["generada_en"] = correo, hoy
        if exigir and pagada and not era:
            raise HTTPException(403, "Esta empresa exige aprobar la planilla antes de pagarla (Recursos humanos › Parámetros)")
        if queda and not era:
            genero = str(x.get("generada_por") or "").strip()
            if otro and genero and genero.lower() == correo.strip().lower():
                raise HTTPException(403, "Debe aprobarla un usuario distinto del que la generó o la corrigió (Recursos humanos › Parámetros)")
            x["aprobada_por"], x["aprobada_en"] = correo, hoy
            auditoria.append(("rrhh_planilla_aprobada", f"{nombre(x)} aprobada por {correo or 'la sesión'}"
                              + (f" (la generó {genero})" if genero else " (no consta quién la generó: es anterior a la aprobación de planillas)")))
        elif era and not queda and not pagada:
            x["aprobada_por"], x["aprobada_en"] = None, None
            auditoria.append(("rrhh_aprobacion_quitada", f"{nombre(x)}: se quitó la aprobación"
                              + (f" de {a.get('aprobada_por')}" if a.get("aprobada_por") else "") + (" para corregirla" if contenido else "")))
    return auditoria


def _revisar_rrhh_pagado(s: Session, eid: int, clave: str, cambios: list, borrados: list, ctx: Optional[Contexto] = None) -> list:
    """4.7: lo pagado de RRHH, para /cambios y para el PUT completo. `cambios`: [(guardado, nuevo)] (guardado None = alta); `borrados`:
    lo guardado que se quita. Rechaza con 403, como los periodos contables cerrados y para todos (también el administrador del
    sistema), y devuelve la auditoría: lo eliminado (sin pagar) y lo que pasa a pagado.
    4.21: con `ctx` (la sesión; lo pasan /cambios y el PUT), en planillas además sella quién la generó y quién la aprobó y aplica la
    aprobación antes de pagar (_aprobacion_planillas); sin `ctx` no se pone ni se revisa nada de eso."""
    campos, (art, pag, corregir) = CAMPOS_RRHH_PAGADO[clave], _RRHH_NOMBRE[clave]
    nombre = lambda x: f"{art} {x.get('numero') or x.get('anio') or x.get('id')}"   # noqa: E731
    for b in borrados:
        if _rrhh_pagado(clave, b):
            raise HTTPException(403, f"{nombre(b)} ya está {pag}: no se elimina. {corregir}")
    # 4.21: antes de comparar lo pagado, porque repone los sellos que una pestaña no recibió
    aprobacion = _aprobacion_planillas(ctx, s, eid, cambios) if clave == "planillas" and ctx is not None else []
    for a, x in cambios:
        if isinstance(a, dict) and a != x and _rrhh_pagado(clave, a) and any(a.get(k) != x.get(k) for k in campos):
            raise HTTPException(403, f"{nombre(a)} ya está {pag}: no se cambian sus montos, empleados, fechas ni su estado. {corregir}")
    if clave == "planillas":
        # la que repite empleados y fechas de una planilla ya pagada solo entra como complementaria (pagos adicionales del período).
        # Se compara con las originales: cruzarse solo con una complementaria pagada (un bono) no es pagar dos veces el salario.
        # 4.7.1: se revisa al guardarla (alta o cambio de periodo, fechas, filas o complementaria) y también al PAGARLA: dos planillas
        # iguales guardadas antes (o desde dos pestañas a la vez) no se pagan las dos, ni dos del mismo envío que quedan pagadas.
        original = lambda p: isinstance(p, dict) and p.get("complementaria") is not True and _rrhh_pagado(clave, p)   # noqa: E731
        paga = lambda a, x: isinstance(a, dict) and not _rrhh_pagado(clave, a) and _rrhh_pagado(clave, x)           # noqa: E731
        revisar = [(a, x) for a, x in cambios if x.get("complementaria") is not True
                   and (not isinstance(a, dict) or paga(a, x)
                        or any(a.get(k) != x.get(k) for k in ("periodo", "desde", "hasta", "filas", "complementaria")))]
        pagadas = [p for p in (modulos.leer(s, eid, "planillas", []) or []) if original(p)] if revisar else []
        del_envio = [x for _, x in revisar if original(x)]
        for a, x in revisar:
            otra = (next((p for p in pagadas if not _misma_planilla(a, x, p) and _planillas_se_cruzan(x, p)), None)
                    or next((p for p in del_envio if p is not x and _planillas_se_cruzan(x, p)), None))
            if otra:
                raise HTTPException(403, f"{nombre(x)} repite empleados y fechas de la planilla pagada {otra.get('numero') or otra.get('id')}: "
                                         + ("no se paga dos veces el mismo período; corríjala y guárdela " if paga(a, x) else "guárdela ")
                                         + "como planilla complementaria (pagos adicionales del mismo período) o cambie las fechas o los empleados")
    auditoria = [("rrhh_eliminado", f"{nombre(b)} eliminad{pag[-1]} (estado: {b.get('estado') or 'sin estado'})") for b in borrados]
    auditoria += [("rrhh_pagado", f"{nombre(x)} registrad{pag[-1]} como {pag}" + (f" desde {x.get('cuenta')}" if x.get("cuenta") else ""))
                  for a, x in cambios if not _rrhh_pagado(clave, a) and _rrhh_pagado(clave, x)]
    return auditoria + aprobacion


def _num_rrhh(v) -> Optional[float]:
    """4.21: número finito de un campo guardado (2500, 2500.0 y «2500» son el mismo); None si está vacío o no es un número."""
    if v is None or isinstance(v, bool) or (isinstance(v, str) and not v.strip()):
        return None
    try:
        n = float(v)
    except (TypeError, ValueError):
        return None
    return n if math.isfinite(n) else None


def _revisar_conceptos_rrhh(ctx: Contexto, cambios: list) -> None:
    """4.21: deducciones e ingresos fijos (rrhh_conceptos). Solo se rechaza lo imposible: en un préstamo o adelanto, un saldo que no
    es un número o es negativo; y unos «ajustes» (correcciones manuales del saldo) que no sean una lista de hasta 100 elementos con
    «antes» y «despues» numéricos. El saldo NO se compara con el total: eliminar una planilla lo devuelve y la pantalla deja
    corregirlos a mano. Los ajustes que no estaban guardados quedan con el usuario de la sesión y la fecha de hoy (no los que diga
    el navegador); los ya guardados conservan los suyos. Lo que no cambia no se revisa (ni el concepto igual a lo guardado, ni un
    saldo que ya estaba así): un dato viejo no bloquea el resto de la lista ni impide pausar o editar ese concepto."""
    correo, hoy = str(getattr(ctx.usuario, "correo", None) or ""), ahora_cr().strftime("%Y-%m-%d")
    for a, x in cambios:
        if isinstance(a, dict) and a == x:
            continue
        nombre = str(x.get("concepto") or x.get("id") or "")[:80]
        saldo = x.get("saldo")
        if x.get("categoria") in ("prestamo", "adelanto") and saldo is not None and saldo != "" and not (isinstance(a, dict) and a.get("saldo") == saldo):
            n = _num_rrhh(saldo)
            if n is None or n < 0:
                raise HTTPException(400, f"El saldo de «{nombre}» debe ser un número igual o mayor que cero")
        ajustes = x.get("ajustes")
        if ajustes is None:
            continue
        if not isinstance(ajustes, list) or len(ajustes) > 100 or any(
                not isinstance(j, dict) or _num_rrhh(j.get("antes")) is None or _num_rrhh(j.get("despues")) is None for j in ajustes):
            raise HTTPException(400, f"Las correcciones del saldo de «{nombre}» no son válidas (hasta 100, cada una con el saldo de antes y el de "
                                     "después): recargue la página (Ctrl+F5) e intente de nuevo")
        # Los ya guardados se reconocen por sus montos y en su orden (la pantalla suelta los más viejos al pasar de 100) y conservan
        # el usuario y la fecha con que se guardaron, diga lo que diga el navegador; los demás son nuevos y los sella esta sesión.
        guardados = [g for g in a.get("ajustes") if isinstance(g, dict)] if isinstance(a, dict) and isinstance(a.get("ajustes"), list) else []
        montos = lambda j: (_num_rrhh(j.get("antes")), _num_rrhh(j.get("despues")))   # noqa: E731
        sellados, k = [], 0
        for j in ajustes:
            i = next((p for p in range(k, len(guardados)) if montos(guardados[p]) == montos(j)), None)
            sello = {"usuario": correo, "fecha": hoy} if i is None else {c: guardados[i][c] for c in ("usuario", "fecha") if c in guardados[i]}
            k = k if i is None else i + 1
            sellados.append({**{c: v for c, v in j.items() if c not in ("usuario", "fecha")}, **sello})
        x["ajustes"] = sellados


def _ficha_comparable(e: dict) -> dict:
    """4.21: los campos sensibles de una ficha listos para comparar: «2500» y 2500.0 son el mismo salario, y un campo vacío o que
    falta vale lo que la ficha toma por omisión (así, volver a guardar una ficha vieja no se anota como un cambio)."""
    return {"modo_salario": str(e.get("modo_salario") or "hora"),
            "salario_hora": _num_rrhh(e.get("salario_hora")) or 0.0, "salario_mensual": _num_rrhh(e.get("salario_mensual")) or 0.0,
            "cuenta_iban": re.sub(r"\s+", "", str(e.get("cuenta_iban") or "")).upper(), "forma_pago": str(e.get("forma_pago") or "transferencia"),
            "hijos": _num_rrhh(e.get("hijos")) or 0.0, "conyuge": bool(e.get("conyuge")), "aplica_renta": e.get("aplica_renta") is not False,
            "ins_riesgos": _num_rrhh(e.get("ins_riesgos"))}


def _bitacora_empleados(pares: list, borrados: list) -> list:
    """4.21: bitácora de la ficha del empleado para el historial de operaciones. `pares`: [(guardado | None, nuevo)] (None = alta);
    `borrados`: fichas guardadas que se quitan. Devuelve [(acción, detalle)], una fila por empleado: «#<id> <Nombre>: <qué cambió>».
    Nunca lleva valores (montos, cuenta, hijos, porcentajes) ni la identificación: la tabla de auditoría es central y también la ve
    el administrador del sistema. Los montos de antes y después están en el «Historial de salario» de la ficha."""
    modo = lambda v: {"hora": "por hora", "mensual": "mensual"}.get(v["modo_salario"], "otro")   # noqa: E731

    def quien(e):
        i = modulos._id_entero(e.get("id"))
        nombre = " ".join(str(e.get(k) or "").strip() for k in ("nombre", "apellidos"))
        return f"#{'?' if i is None else i} " + re.sub(r"[:\s]+", " ", nombre).strip()[:80]    # sin «:»: el detalle se lee «#id Nombre: cambios»

    cambios, altas = [], []
    for a, x in pares:
        if not isinstance(x, dict):
            continue
        if not isinstance(a, dict):
            altas.append(("rrhh_ficha_creada", quien(x)))
            continue
        va, vx = _ficha_comparable(a), _ficha_comparable(x)
        dif = {k for k in CAMPOS_FICHA_SENSIBLE if va[k] != vx[k]}
        partes = []
        if dif & {"modo_salario", "salario_hora", "salario_mensual"}:
            partes.append("salario" + (f" ({modo(va)} → {modo(vx)})" if "modo_salario" in dif else ""))
        if "cuenta_iban" in dif:
            partes.append("cuenta IBAN")
        if "forma_pago" in dif:
            partes.append("forma de pago")
        if dif & {"hijos", "conyuge", "aplica_renta"}:
            partes.append("datos de renta")
        if "ins_riesgos" in dif:
            partes.append("% riesgos")
        if partes:
            cambios.append(("rrhh_ficha_cambiada", (quien(x) + ": " + ", ".join(partes))[:500]))
    bajas = [("rrhh_ficha_eliminada", quien(b)) for b in borrados if isinstance(b, dict)]
    if len(altas) > 20:                                    # una importación o una carga masiva: una sola fila, no cientos
        altas = [("rrhh_ficha_creada", f"{len(altas)} fichas de empleado creadas en un solo envío")]
    if len(bajas) > 20:
        bajas = [("rrhh_ficha_eliminada", f"{len(bajas)} fichas de empleado eliminadas en un solo envío")]
    return cambios + altas + bajas


def _bitacora_parametros_rrhh(cambios: list) -> list:
    """4.21: encender o apagar la aprobación de la planilla (Recursos humanos › Parámetros) queda en el historial de operaciones.
    `cambios`: [(lo guardado, lo que se guarda)] de 'rrhh_parametros', que es un solo valor. Se comparan ya normalizados, como los
    usa la planilla (rrhh.parametros_efectivos: lo que falta vale apagado)."""
    claves = [k for k, _ in PARAMETROS_APROBACION]
    efectivo = lambda d: rrhh.parametros_efectivos({k: d.get(k) for k in claves} if isinstance(d, dict) else None)   # noqa: E731
    out = []
    for a, x in cambios:
        antes, ahora = efectivo(a), efectivo(x)
        out += [("rrhh_parametro_aprobacion", f"{texto}: {'encendida' if ahora[k] else 'apagada'}") for k, texto in PARAMETROS_APROBACION if antes[k] != ahora[k]]
    return out


def _fecha_iso_rrhh(v) -> Optional[str]:
    """4.21: la fecha de un campo guardado si viene como AAAA-MM-DD y existe en el calendario; None si no."""
    if not isinstance(v, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        return None
    try:
        date.fromisoformat(v)
    except ValueError:
        return None
    return v


def _revisar_desde_asistencia(s: Session, eid: int, clave: str, cambios: list, borrados: list) -> None:
    """4.21: horas extra y ausencias que nacen de «Traer de asistencia»: SOLO las altas con origen 'asistencia'. Lo que Recursos
    humanos registra a mano sigue como antes (la pantalla avisa un traslape y deja guardarlo; aquí no se revisa).
    - rrhh_horas_extra: horas mayores que 0 y hasta 16, fecha AAAA-MM-DD y 409 si ese empleado ya tiene horas registradas ese día.
    - rrhh_ausencias: tipo de rrhh.TIPOS_AUSENCIA, «desde» y «hasta» AAAA-MM-DD con desde ≤ hasta y 409 si se traslapa con otra
      ausencia del mismo empleado.
    Se compara con lo guardado (sin lo que este mismo envío quita) y con las altas anteriores del mismo envío."""
    altas = [x for a, x in cambios if a is None and x.get("origen") == "asistencia"]
    if not altas:
        return
    quitados = {modulos._id_entero(b.get("id")) for b in borrados if isinstance(b, dict)}
    otros = [g for g in (modulos.leer(s, eid, clave, []) or []) if isinstance(g, dict) and modulos._id_entero(g.get("id")) not in quitados]
    emp = lambda d: modulos._id_entero(d.get("empleado_id"))                      # noqa: E731
    dia = lambda v: str(v or "")[:10]                                             # noqa: E731
    for x in altas:
        if emp(x) is None:
            raise HTTPException(400, "Lo traído de asistencia no dice de qué empleado es: recargue la página (Ctrl+F5) e intente de nuevo")
        if clave == "rrhh_horas_extra":
            horas, fecha = _num_rrhh(x.get("horas")), _fecha_iso_rrhh(x.get("fecha"))
            if horas is None or not 0 < horas <= 16:
                raise HTTPException(400, "Las horas traídas de asistencia deben ser más de 0 y no pasar de 16 por día")
            if fecha is None:
                raise HTTPException(400, "La fecha de las horas traídas de asistencia no es válida")
            if any(emp(g) == emp(x) and dia(g.get("fecha")) == fecha for g in otros):
                raise HTTPException(409, "Ya hay horas registradas para ese empleado ese día")
        else:
            tipo, desde, hasta = x.get("tipo"), _fecha_iso_rrhh(x.get("desde")), _fecha_iso_rrhh(x.get("hasta"))
            if not isinstance(tipo, str) or tipo not in rrhh.TIPOS_AUSENCIA:
                raise HTTPException(400, "Elija el tipo de cada ausencia traída de asistencia")
            if desde is None or hasta is None or desde > hasta:
                raise HTTPException(400, "Las fechas de la ausencia traída de asistencia no son válidas («Desde» no puede ser posterior a «Hasta»)")
            if any(emp(g) == emp(x) and dia(g.get("desde")) and dia(g.get("desde")) <= hasta and (dia(g.get("hasta")) or dia(g.get("desde"))) >= desde for g in otros):
                raise HTTPException(409, "Ya hay una ausencia registrada para ese empleado que se traslapa con esas fechas")
        otros.append(x)


def _candado_registro(s: Session, eid: int, clave: str) -> None:
    """4.21: toma el candado de escritura de la base de la empresa ANTES de leer lo guardado de `clave`, para que «revisar contra
    lo guardado» y «guardar» sean un solo paso: otra petición que escriba a la vez espera a que esta termine (o se rechace) y ya ve
    su resultado. Es el mismo candado de modulos._bloquear en aplicar_cambios, tomado antes; se suelta al confirmar el guardado o al
    cerrarse la sesión de la petición. Es una escritura que no cambia nada, y sirve también cuando la clave todavía no existe."""
    from sqlalchemy import update as sa_update
    s.execute(sa_update(modulos.Registro).where(modulos.Registro.empresa_id == eid, modulos.Registro.clave == clave).values(version=modulos.Registro.version),
              execution_options={"synchronize_session": False})


def _foto_puesto_valida(d) -> bool:
    """4.21: la «foto» del puesto que guarda una acción de personal (antes o después): un diccionario pequeño de textos y números
    (puesto, departamento, categoría, modo y salario), con el salario finito y no negativo. Sin foto (None) también vale."""
    if d is None:
        return True
    if not isinstance(d, dict) or len(d) > 12:
        return False
    for k, v in d.items():
        if not isinstance(k, str) or len(k) > 40:
            return False
        if v is None or isinstance(v, bool) or (isinstance(v, str) and len(v) <= 200):
            continue
        if not isinstance(v, (int, float)) or not math.isfinite(v):
            return False
    for k in ("salario", "salario_mensual"):
        if d.get(k) not in (None, ""):
            n = _num_rrhh(d.get(k))
            if n is None or n < 0:
                return False
    return True


def _accion_eliminada(d) -> bool:
    """4.22: ¿es la marca que queda de una acción de personal cuando se elimina la ficha de su empleado?"""
    return isinstance(d, dict) and str(d.get("estado") or "").strip().lower() == ESTADO_ACCION_ELIMINADA.lower()


def _valor_numero_accion(d):
    """4.22: el número de una acción de personal por su VALOR: «AP-0012» y «AP-00012» son el mismo. Lo que no sea AP-número (datos
    viejos) se compara como texto, en mayúsculas y sin espacios."""
    n = str((d.get("numero") if isinstance(d, dict) else d) or "").strip().upper()
    m = re.fullmatch(r"AP-(\d{1,18})", n)
    return int(m.group(1)) if m else n


def _revisar_acciones(ctx: Contexto, s: Session, cambios: list, borrados: list) -> list:
    """4.21: acciones de personal (rrhh_acciones), para /cambios y para el PUT completo. `cambios`: [(guardada | None, nueva)].
    - Alta: tipo de TIPOS_ACCION_PERSONAL, número «AP-0001» que no tenga otra acción (409), empleado, fecha y «rige» AAAA-MM-DD,
      «hasta» (si viene) no anterior a «rige», motivo de hasta 500 letras, detalle de hasta 2000 y las fotos del puesto de antes y
      de después con el salario finito y no negativo (400). Nace «Registrada»; quién y cuándo la registró lo pone el servidor. Lo
      demás se guarda tal como llegó (la pantalla conserva su copia: si aquí se cambiara, su próximo guardado parecería una edición).
      4.22: el número lleva dígitos 0-9 y «ya usado» se compara por su valor (AP-0012 y AP-00012 son el mismo), contando las
      marcas de las acciones eliminadas con su ficha: un número no se repite jamás. Y el empleado tiene que existir (409): se
      comprueba con el candado de escritura ya tomado, así que no queda una acción a nombre de una ficha que se acaba de eliminar.
    - Una acción guardada no se cambia (403). Solo pasa de «Registrada» a «Anulada», con motivo_anulacion; o, en un aumento,
      traslado o cambio de puesto que quedó pendiente, se marca aplicada a la ficha. El servidor sella quién y cuándo.
    - No se elimina (403). La marca «Eliminada» que deja el servidor al eliminar la ficha del empleado no se cambia ni se anula (403).
    - Un alta igual (sin contar los sellos) a lo guardado con su id es un reintento (respuesta perdida): queda igual a lo guardado
      para que aplicar_cambios no la duplique con otro id.
    Devuelve la auditoría: número, tipo y empleado; nunca el salario de antes ni el de después."""
    if borrados:
        raise HTTPException(403, "Una acción de personal no se elimina: anúlela")
    correo, ahora = str(getattr(ctx.usuario, "correo", None) or ""), ahora_cr().isoformat(timespec="seconds")
    ids = [modulos._id_entero(x.get("id")) for _, x in cambios]
    if len(ids) != len(set(ids)):
        raise HTTPException(400, "La lista trae la misma acción de personal dos veces (id repetido): recargue la página (Ctrl+F5) e intente de nuevo")
    anulada = lambda d: str(d.get("estado") or "").strip().lower() == "anulada"   # noqa: E731
    numero = lambda d: str(d.get("numero") or "").strip().upper()                 # noqa: E731

    def quien(d):
        i = modulos._id_entero(d.get("empleado_id"))
        nombre = re.sub(r"\s+", " ", str(d.get("nombre") or "")).strip()[:80]
        return f"{numero(d) or 'Sin número'} · {TIPOS_ACCION_PERSONAL.get(d.get('tipo') if isinstance(d.get('tipo'), str) else '', 'Acción')} · #{'?' if i is None else i} {nombre}".strip()[:500]

    guardadas, usados, fichas, auditoria = None, set(), set(), []
    for a, x in cambios:
        if isinstance(a, dict):
            for k in SELLOS_ACCION:                        # los sellos son del servidor: valen los guardados
                if k in a:
                    x[k] = a[k]
                else:
                    x.pop(k, None)
            if a == x:
                continue
            if _accion_eliminada(a):                       # 4.22: lo que quedó de una acción al eliminar la ficha de su empleado
                raise HTTPException(403, f"La acción de personal {numero(a)} se eliminó con la ficha de su empleado: ya no se cambia")
            if anulada(a):
                raise HTTPException(403, f"La acción de personal {numero(a)} está anulada: ya no se cambia")
            dif = {k for k in set(a) | set(x) if a.get(k) != x.get(k)}
            if dif <= {"estado", "motivo_anulacion"} and anulada(x):
                motivo = x.get("motivo_anulacion")
                if not isinstance(motivo, str) or not motivo.strip():
                    raise HTTPException(403, "Para anular una acción de personal indique el motivo de la anulación")
                if len(motivo) > 500:
                    raise HTTPException(400, "El motivo de la anulación admite hasta 500 letras")
                x["estado"], x["anulada_por"], x["anulada_en"] = "Anulada", correo, ahora
                auditoria.append(("rrhh_accion_anulada", quien(x)))
            elif dif == {"aplicada_a_ficha"} and x.get("aplicada_a_ficha") is True and a.get("tipo") in TIPOS_ACCION_A_FICHA:
                x["aplicada_por"], x["aplicada_en"] = correo, ahora
                auditoria.append(("rrhh_accion_aplicada", quien(x)))
            else:
                raise HTTPException(403, "Una acción de personal no se cambia: anúlela y registre otra")
            continue
        tipo = x.get("tipo")
        if not isinstance(tipo, str) or tipo not in TIPOS_ACCION_PERSONAL:
            raise HTTPException(400, "El tipo de la acción de personal no es válido")
        if not isinstance(x.get("numero"), str) or not re.fullmatch(r"AP-[0-9]{4,9}", x["numero"]):   # 4.22: dígitos 0-9 (\d acepta los de otros alfabetos)
            raise HTTPException(400, "El número de la acción de personal no es válido (debe ser como AP-0001)")
        if modulos._id_entero(x.get("empleado_id")) is None:
            raise HTTPException(400, "La acción de personal no dice de qué empleado es")
        rige = _fecha_iso_rrhh(x.get("rige"))
        if _fecha_iso_rrhh(x.get("fecha")) is None or rige is None:
            raise HTTPException(400, "La fecha de la acción de personal y la fecha desde la que rige deben ser fechas válidas")
        if x.get("hasta") not in (None, "") and (_fecha_iso_rrhh(x.get("hasta")) is None or x["hasta"] < rige):
            raise HTTPException(400, "«Hasta» debe ser una fecha igual o posterior a la fecha desde la que rige")
        for campo, tope, texto in (("motivo", 500, "El motivo"), ("detalle", 2000, "El detalle"), ("nombre", 200, "El nombre del empleado")):
            v = x.get(campo)
            if v is not None and (not isinstance(v, str) or len(v) > tope):
                raise HTTPException(400, f"{texto} de la acción de personal admite hasta {tope} letras")
        if not _foto_puesto_valida(x.get("antes")) or not _foto_puesto_valida(x.get("despues")):
            raise HTTPException(400, "Los datos del puesto de antes y de después no son válidos (el salario debe ser un número igual o mayor que cero)")
        if x.get("aplicada_a_ficha") not in (None, True, False):
            raise HTTPException(400, "«Aplicada a la ficha» debe ser sí o no")
        if x.get("estado") not in (None, "", "Registrada") or x.get("motivo_anulacion") not in (None, ""):
            raise HTTPException(400, "Una acción de personal nace registrada: se anula después, con su motivo")
        x["estado"] = "Registrada"
        for k in SELLOS_ACCION:
            x.pop(k, None)
        if guardadas is None:
            # con el candado de escritura tomado ANTES de leer los números ya usados: dos altas que llegan a la vez se ordenan y la
            # segunda ya ve el número de la primera (sin él, de doce altas simultáneas con el mismo número entraban hasta ocho)
            _candado_registro(s, ctx.empresa.id, "rrhh_acciones")
            guardadas = [g for g in (modulos.leer(s, ctx.empresa.id, "rrhh_acciones", []) or []) if isinstance(g, dict)]
            # 4.22: por su valor, y con las marcas de las eliminadas (siguen en lo guardado): su número sigue ocupado
            usados = {_valor_numero_accion(g) for g in guardadas}
            # 4.22: los empleados de las altas, leídos con el candado ya tomado (con SQLite es de toda la base: el borrado de una
            # ficha queda antes o después de esta alta, nunca en medio)
            fichas = set(_items_guardados(s, ctx.empresa.id, "empleados", [modulos._id_entero(y.get("empleado_id")) for b, y in cambios if not isinstance(b, dict)]))
        g = next((g for g in guardadas if modulos._id_entero(g.get("id")) == modulos._id_entero(x.get("id"))), None)
        if g is not None and {k: v for k, v in g.items() if k not in SELLOS_ACCION} == x:
            x.clear(); x.update(g)                         # reintento de un alta ya guardada: queda con los sellos de la primera vez
            continue
        if modulos._id_entero(x.get("empleado_id")) not in fichas:
            raise HTTPException(409, "El empleado de esta acción ya no existe: recargue la página")
        if _valor_numero_accion(x) in usados:
            raise HTTPException(409, f"Ya existe la acción de personal {numero(x)}: actualice la pantalla e intente de nuevo")
        usados.add(_valor_numero_accion(x))
        x["registrada_por"], x["registrada_en"] = correo, ahora
        auditoria.append(("rrhh_accion", quien(x)))
    return auditoria


def _revisar_reglas_rrhh(ctx: Contexto, s: Session, clave: str, cambios: list, borrados: list) -> list:
    """4.21: reglas de Recursos humanos por contenido para las claves de CLAVES_RRHH_REGLAS, en /cambios y en el PUT completo.
    `cambios`: [(guardado | None, nuevo)] (None = alta); `borrados`: lo guardado que se quita. Rechaza con 400 lo imposible, puede
    completar el elemento nuevo en sitio (lo que el servidor sella) y devuelve la auditoría [(acción, detalle)], que quien llama
    escribe solo si el guardado tuvo éxito. Lo pagado (planillas, aguinaldos, liquidaciones) sigue en _revisar_rrhh_pagado."""
    cambios = [(a, x) for a, x in cambios if isinstance(x, dict)]
    if clave == "rrhh_conceptos":
        _revisar_conceptos_rrhh(ctx, cambios)
    elif clave == "empleados":
        return _bitacora_empleados(cambios, borrados)
    elif clave == "rrhh_parametros":
        return _bitacora_parametros_rrhh(cambios)
    elif clave in ("rrhh_horas_extra", "rrhh_ausencias"):
        _revisar_desde_asistencia(s, ctx.empresa.id, clave, cambios, borrados)
    elif clave == "rrhh_acciones":
        return _revisar_acciones(ctx, s, cambios, borrados)
    return []


def _revisar_escritura(ctx: Contexto, s: Session, clave: str, modo: Optional[str], data: Optional["CambiosIn"] = None, datos: Any = None,
                       version: Optional[int] = None):
    """3.87: reglas de contenido de lo que se guarda. Con `data` es un lote de /cambios (puede ajustar data.upserts); sin él, el PUT
    que reemplaza la clave completa con `datos`. Devuelve (datos para el PUT, [(acción, detalle) para la auditoría]).
    - El Técnico: solo sus bloqueos de fechas. La Camarera y el Técnico: solo el estado de las habitaciones (lo demás se toma de lo
      guardado). Desde la caja: solo cargos nuevos de la caja, a huéspedes en casa; nunca se tocan pagos.
    - El Cajero (caja sin cobros ni configurar) abre, usa y cierra su sesión, pero no cambia, reabre ni borra un cierre hecho, ni
      cambia o borra las ventas con que se calcula (pos_ventas): solo las anula en su caja abierta y completa las que vendió sin red.
    - Ningún asiento entra, cambia ni sale de un periodo contable cerrado (antes solo lo vigilaba la pantalla).
    - Un rol sin montos no cambia los montos de lo guardado (no se le enviaron: lo que mande en ellos es de su copia recortada).
    - 4.7: planillas, aguinaldos y liquidaciones pagados no se borran ni cambian montos, filas, fechas o estado (_revisar_rrhh_pagado).
    - 4.21: las demás reglas de Recursos humanos (CLAVES_RRHH_REGLAS: saldo y ajustes de préstamos, bitácora de la ficha, el cambio
      de la aprobación de planillas en Parámetros, las horas extra y ausencias traídas de asistencia y las acciones de personal,
      que no se editan ni se eliminan: se anulan) van en _revisar_reglas_rrhh;
      y el PUT completo ya devuelve su auditoría (antes devolvía una lista vacía y se perdía). En planillas, _revisar_rrhh_pagado
      recibe la sesión para sellar quién la generó y quién la aprobó (_aprobacion_planillas).
    - 4.22: los documentos del empleado y los pagos de las cargas del mes (CLAVES_SOLO_SERVIDOR) no se escriben por aquí: 403."""
    if clave in CLAVES_SOLO_SERVIDOR:
        raise HTTPException(403, CLAVES_SOLO_SERVIDOR[clave])
    eid = ctx.empresa.id
    cajero = clave in ("pos_cajas", "pos_ventas") and not (ctx.puede("cobros") or ctx.puede("configurar"))
    sin_montos = auth.oculta_montos(ctx.permisos, clave)       # quien configura el hotel sí ve (y guarda) sus tarifas
    if not (modo or sin_montos or cajero or clave in ("pos_cajas", "asientos", "pos_espera") or clave in CAMPOS_RRHH_PAGADO or clave in CLAVES_RRHH_REGLAS):   # 4.7: y lo pagado de RRHH
        return datos, []
    cerrados: dict = {}
    def _periodo(fecha):
        p = _periodo_cerrado(s, eid, fecha, cerrados)
        if p:
            raise HTTPException(403, f"El periodo {p} está cerrado: reábralo en Configuración › Periodos contables o cambie la fecha")
    if data is None:                                       # PUT de la clave completa
        guardado = modulos.leer(s, eid, clave, None)
        previos = {modulos._id_entero(x.get("id")): x for x in guardado if isinstance(x, dict)} if isinstance(guardado, list) else {}
        # una lista vacía con versión 0 es «la pestaña no tenía la clave»: si ya existe, reemplazar() responde 409 y no pisa nada
        if (modo or cajero) and (datos or (guardado and version != 0)):
            raise HTTPException(403, _NO_PUEDE.get(modo) or ("Su rol no puede reemplazar las sesiones de caja" if clave == "pos_cajas"
                                                             else "Su rol no puede reemplazar las ventas de caja"))
        if clave == "asientos" and isinstance(datos, list):
            nuevos_put = {modulos._id_entero(x.get("id")): x for x in datos if isinstance(x, dict)}
            for iid in set(previos) | set(nuevos_put):
                antes, ahora = previos.get(iid), nuevos_put.get(iid)
                if antes != ahora:
                    _periodo((antes or {}).get("fecha")); _periodo((ahora or {}).get("fecha"))
        if clave == "pos_espera" and isinstance(datos, list):
            # 4.5: el PUT completo conserva lo del pedido en línea (CAMPOS_PEDIDO_EN_LINEA) como ya hacía /cambios: una caja que
            # reemplaza la clave con una copia sin canal, pedido ni prepago no borra lo pagado en línea (se cobraría otra vez)
            def _con_pedido(x):
                a = previos.get(modulos._id_entero(x.get("id"))) if isinstance(x, dict) else None
                if not (isinstance(a, dict) and a.get("canal") == "online"):
                    return x
                return {**{k: v for k, v in x.items() if k not in CAMPOS_PEDIDO_EN_LINEA}, **{k: a[k] for k in CAMPOS_PEDIDO_EN_LINEA if k in a}}
            datos = [_con_pedido(x) for x in datos]
        aud = []                                           # 4.21: la auditoría del PUT completo (put_registro la escribe si se guardó)
        if clave in CAMPOS_RRHH_PAGADO:                    # 4.7: reemplazando la lista tampoco se borra ni se cambia lo pagado
            lista = [x for x in datos if isinstance(x, dict)] if isinstance(datos, list) else []
            ids = [i for i in (modulos._id_entero(x.get("id")) for x in lista) if i is not None]
            if len(ids) != len(set(ids)):
                # 4.7.1: el mismo id dos veces. Se revisaba una copia y se guardaba la otra (la primera conserva el id y la siguiente
                # recibe uno nuevo): así cambiaba una planilla pagada sin que el servidor lo notara. La pantalla nunca los manda.
                raise HTTPException(400, "La lista trae el mismo elemento dos veces (id repetido): recargue la página (Ctrl+F5) e intente de nuevo")
            reg = modulos._registro(s, eid, clave)
            if reg is None or (reg.version or 0) == (version or 0):   # con otra versión reemplazar() responde 409 sin pisar nada
                quedan = set(ids)                          # 4.7.1: cada elemento (también la lista que crea la clave por primera vez)
                aud += _revisar_rrhh_pagado(s, eid, clave, [(previos.get(modulos._id_entero(x.get("id"))), x) for x in lista],
                                            [g for i, g in previos.items() if i not in quedan], ctx)
            elif version is None and lista:
                # 4.7.1: pestaña de una versión muy anterior (guarda sin versión): reemplazar() le pide recargar, pero antes guarda sus altas
                # (ids por encima del tope de la clave); esas también pasan por la regla de cruces
                tope = max([i for i in previos if i is not None] + [reg.ultimo_id or 0, 0])
                aud += _revisar_rrhh_pagado(s, eid, clave, [(None, x) for x in lista if (modulos._id_entero(x.get("id")) or 0) > tope], [], ctx)
        if clave == "rrhh_acciones" and not modulos.es_lista_ids(datos):
            # 4.21: las acciones de personal son siempre una lista de elementos con id: otra cosa guardada en su lugar (un texto, un
            # objeto) se saltaría las reglas de abajo y dejaría la clave sin poder recibir más acciones
            raise HTTPException(400, "Las acciones de personal se guardan como una lista: recargue la página (Ctrl+F5) e intente de nuevo")
        if clave == "rrhh_parametros":                     # 4.21: un valor, no una lista: se compara lo guardado con lo que llega
            aud += _revisar_reglas_rrhh(ctx, s, clave, [(guardado, datos)], [])
        elif clave in CLAVES_RRHH_REGLAS and isinstance(datos, list):   # 4.21: las mismas reglas de RRHH que en /cambios
            reg = modulos._registro(s, eid, clave)
            lista = [x for x in datos if isinstance(x, dict)]
            if reg is None or (reg.version or 0) == (version or 0):   # con otra versión reemplazar() responde 409 sin pisar nada
                quedan = {modulos._id_entero(x.get("id")) for x in lista}
                _previo = lambda x: previos.get(modulos._id_entero(x.get("id"))) if modulos._id_entero(x.get("id")) is not None else None   # noqa: E731
                aud += _revisar_reglas_rrhh(ctx, s, clave, [(_previo(x), x) for x in lista], [g for i, g in previos.items() if i not in quedan])
            elif version is None and lista:
                # pestaña de una versión muy anterior (guarda sin versión): reemplazar() le pide recargar, pero antes guarda sus altas (ids
                # por encima del tope de la clave). Esas también se revisan y se sellan; responde 409, así que no dejan fila de auditoría
                tope = max([i for i in previos if i is not None] + [reg.ultimo_id or 0, 0])
                _revisar_reglas_rrhh(ctx, s, clave, [(None, x) for x in lista if (modulos._id_entero(x.get("id")) or 0) > tope], [])
        if sin_montos:
            datos = ([auth.reponer_montos(clave, previos.get(modulos._id_entero(x.get("id"))), x) if isinstance(x, dict) else x for x in datos]
                     if isinstance(datos, list) else auth.reponer_montos(clave, guardado, datos))
        return datos, aud
    if clave == "rrhh_acciones":
        # 4.22: el candado de escritura ANTES de leer lo guardado contra lo que se revisa (antes solo lo tomaban las altas, dentro de
        # _revisar_acciones). Anular y «aplicar a la ficha» a la vez sobre la misma acción ya no se pisan: gana la primera y la
        # segunda se revisa contra lo que esa dejó guardado. Tampoco se cuela un cambio sin revisar sobre un id que otra petición
        # crea en ese instante
        _candado_registro(s, eid, clave)
    nuevos = {modulos._id_entero(i) for i in data.nuevos}
    previos = _items_guardados(s, eid, clave, [modulos._id_entero(x.get("id")) for x in data.upserts if isinstance(x, dict)]
                               + [modulos._id_entero(d) for d in data.deletes])
    def _antes(x):                                         # lo guardado que este upsert cambia (None si es un alta)
        iid = modulos._id_entero(x.get("id")) if isinstance(x, dict) else None
        return None if iid in nuevos else previos.get(iid)     # un alta con id ocupado recibe otro (aplicar_cambios): no pisa nada
    borrados = [previos[i] for i in (modulos._id_entero(d) for d in data.deletes) if i in previos]
    auditoria = []
    if modo == "estado_hab":
        if data.deletes or data.nuevos:
            raise HTTPException(403, _NO_PUEDE[modo])
        data.upserts = [{**_antes(x), **{k: x[k] for k in CAMPOS_ESTADO_HAB if k in x}} for x in data.upserts if _antes(x) is not None]
    elif modo == "tipos_problema":                         # agregan los que falten; cambian y quitan los de su módulo, sin vaciar la lista
        mios = {m for m in ("limpieza", "mantenimiento") if ctx.puede(m)}
        if any(_antes(x) is not None and _antes(x) != x and not ({_antes(x).get("modulo"), x.get("modulo")} <= mios) for x in data.upserts) \
                or any(b.get("modulo") not in mios for b in borrados) \
                or (borrados and len(borrados) >= len(modulos.leer(s, eid, clave, []) or []) + len(data.nuevos)):
            raise HTTPException(403, _NO_PUEDE[modo])
    elif modo == "bloqueos":
        if any(not _es_bloqueo_propio(x) or (_antes(x) is not None and not _es_bloqueo_propio(_antes(x))) for x in data.upserts) \
                or any(not _es_bloqueo_propio(b) for b in borrados):
            raise HTTPException(403, _NO_PUEDE[modo])
    elif modo == "caja":
        if auth.solo_pos(ctx.permisos):                    # el Cajero: cargos nuevos de la caja a una cuenta abierta, nada más
            en_casa = {i for i, r in _items_guardados(s, eid, "hotel_reservas", [modulos._id_entero(x.get("reserva_id")) for x in data.upserts
                                                                                  if isinstance(x, dict)]).items() if r.get("estado") == "en_casa"}
            def _cargo_ok(x):
                try:
                    # nada que rebaje la cuenta: ni precio, ni IVA (0 a 13 %), ni monto en colones, ni otro impuesto negativos
                    oi = x.get("otro_impuesto")
                    return (x.get("tipo") == "cargo" and x.get("origen") == "pos" and modulos._id_entero(x.get("reserva_id")) in en_casa
                            and float(x.get("cantidad") or 0) > 0 and float(x.get("precio") or 0) >= 0 and 0 <= float(x.get("tarifa") or 0) <= 13
                            and float(x.get("monto_crc") or 0) >= 0 and (not oi or (isinstance(oi, dict) and _no_negativos(oi))))
                except (TypeError, ValueError):
                    return False
            if data.deletes or any(not isinstance(x, dict) or modulos._id_entero(x.get("id")) not in nuevos or not _cargo_ok(x) for x in data.upserts):
                raise HTTPException(403, _NO_PUEDE[modo])
        elif any(not isinstance(x, dict) or x.get("tipo") != "cargo" or (_antes(x) is not None and _antes(x).get("tipo") != "cargo") for x in data.upserts) \
                or any(b.get("tipo") != "cargo" for b in borrados):      # rol propio con caja (sin cobros): cargos sí, pagos nunca
            raise HTTPException(403, _NO_PUEDE[modo])
    if clave == "pos_cajas":
        _sin_marcas = lambda d: {k: v for k, v in d.items() if k not in ("correo_z", "correo_z_pendiente")}   # 3.87: el aviso del correo del Z no corrige el cierre
        cambiados = [(_antes(x), x) for x in data.upserts if isinstance(x, dict) and _antes(x) is not None and _sin_marcas(_antes(x)) != _sin_marcas(x)]
        cerrados_tocados = [(a, x) for a, x in cambiados if a.get("estado") == "Cerrada"] + [(b, None) for b in borrados if b.get("estado") == "Cerrada"]
        if cajero:
            if cerrados_tocados:
                raise HTTPException(403, _NO_PUEDE["pos_cajas"])
            ids_borrar = {modulos._id_entero(b.get("id")) for b in borrados}
            if any(b.get("ventas") for b in borrados) or (ids_borrar and any(
                    isinstance(v, dict) and modulos._id_entero(v.get("caja_id")) in ids_borrar for v in (modulos.leer(s, eid, "pos_ventas", []) or []))):
                raise HTTPException(403, "Una sesión de caja con ventas no se elimina: ciérrela")
        for a, x in cerrados_tocados:                      # quien sí puede: queda en el historial de operaciones con el antes y el después
            auditoria.append(("pos_cierre_cambiado", f"Sesión {a.get('id')} ({a.get('caja') or 'caja'}, {a.get('usuario') or '—'}): "
                              + (f"{a.get('estado')} → {x.get('estado')}, conteo {a.get('conteo')} → {x.get('conteo')}, diferencia {a.get('diferencia')} → {x.get('diferencia')}"
                                 if x is not None else f"eliminada (conteo {a.get('conteo')}, diferencia {a.get('diferencia')})")))
    if clave == "pos_ventas" and cajero:                   # las ventas con que se calcula el cierre (resumen, PDF y reporte Z)
        sesiones = _items_guardados(s, eid, "pos_cajas", [modulos._id_entero(v.get("caja_id")) for v in previos.values() if isinstance(v, dict)])
        abierta = lambda v: (sesiones.get(modulos._id_entero(v.get("caja_id"))) or {}).get("estado") == "Abierta"   # noqa: E731
        pendiente = lambda v: bool(v.get("pendiente_id")) and not v.get("doc_id")                                   # noqa: E731
        for x in data.upserts:
            a = _antes(x)
            if a is None or a == x:                        # altas: la venta hecha sin red puede llegar después del cierre
                continue
            cambio = {k for k in set(a) | set(x) if a.get(k) != x.get(k)}
            if not ((pendiente(a) and cambio <= set(CAMPOS_EMITE_VENTA))
                    or (abierta(a) and x.get("anulada") is True and cambio <= set(CAMPOS_ANULA_VENTA))):
                raise HTTPException(403, _NO_PUEDE["pos_ventas"])
        if any(not (pendiente(b) and abierta(b)) for b in borrados):   # solo descarta una venta sin comprobante de su caja abierta
            raise HTTPException(403, _NO_PUEDE["pos_ventas"])
    if clave == "pos_espera":                             # 3.87: la cuenta de un pedido en línea conserva lo pagado (no se cobra dos veces)
        data.upserts = [{**{k: v for k, v in x.items() if k not in CAMPOS_PEDIDO_EN_LINEA}, **{k: _antes(x)[k] for k in CAMPOS_PEDIDO_EN_LINEA if k in _antes(x)}}
                        if isinstance(x, dict) and isinstance(_antes(x), dict) and _antes(x).get("canal") == "online" else x for x in data.upserts]
    if clave == "asientos":
        for x in data.upserts:
            a = _antes(x)
            if a is None or a != x:
                if a is not None:
                    _periodo(a.get("fecha"))
                _periodo(x.get("fecha") if isinstance(x, dict) else None)
        for b in borrados:
            _periodo(b.get("fecha"))
    if clave in CAMPOS_RRHH_PAGADO:                        # 4.7: planillas, aguinaldos y liquidaciones pagados quedan cerrados
        auditoria += _revisar_rrhh_pagado(s, eid, clave, [(_antes(x), x) for x in data.upserts if isinstance(x, dict)], borrados, ctx)
    if clave in CLAVES_RRHH_REGLAS and clave != "rrhh_parametros":   # 4.21: saldo y ajustes de préstamos; bitácora de la ficha; lo traído de asistencia (los parámetros son un valor: solo PUT)
        def _par(x):                                       # un alta idéntica a lo guardado con su id es un reintento (aplicar_cambios no la duplica): no es un cambio
            g = previos.get(modulos._id_entero(x.get("id")))
            return (g if g == x else _antes(x), x)
        # el cambio de un elemento que ya no existe (otro lo borró) no se guarda (aplicar_cambios: gana el borrado): ni se revisa ni se anota
        _se_guarda = lambda x: modulos._id_entero(x.get("id")) in nuevos or modulos._id_entero(x.get("id")) in previos   # noqa: E731
        auditoria += _revisar_reglas_rrhh(ctx, s, clave, [_par(x) for x in data.upserts if isinstance(x, dict) and _se_guarda(x)], borrados)
    if sin_montos:
        data.upserts = [auth.reponer_montos(clave, _antes(x), x) for x in data.upserts]
    return None, auditoria


def _agregar_registros(s: Session, eid: int, clave: str, items: list[dict]) -> list[int]:
    """Agrega elementos nuevos a una colección desde el servidor (ids por encima del tope de la clave)."""
    if not items:
        return []
    r = modulos._registro(s, eid, clave)
    actuales = modulos.leer(s, eid, clave, []) or []
    tope = max([(r.ultimo_id or 0) if r else 0] + [int(x.get("id") or 0) for x in actuales if isinstance(x, dict) and isinstance(x.get("id"), int)])
    con_id = []
    for i, x in enumerate(items, start=1):
        con_id.append({**x, "id": tope + i})
    modulos.aplicar_cambios(s, eid, clave, con_id, [], [x["id"] for x in con_id])
    return [x["id"] for x in con_id]


def _hotel_importar_ical(s: Session, eid: int, cfg: dict, habitaciones: list, hoy: str) -> dict:
    """Lee los calendarios iCal configurados en cada habitación (Booking, Airbnb…) y deja sus fechas como bloqueos."""
    out = {"creados": 0, "actualizados": 0, "quitados": 0, "avisos": [], "fuentes": 0}
    for h in habitaciones:
        if not isinstance(h, dict) or h.get("activa") is False:
            continue
        for src in h.get("ical_urls") or []:
            url, nombre = str((src or {}).get("url") or "").strip(), str((src or {}).get("nombre") or "iCal").strip()[:30]
            if not url.lower().startswith(("http://", "https://")):
                continue
            out["fuentes"] += 1
            try:
                resp = httpx.get(url, timeout=20, follow_redirects=True, headers={"User-Agent": "GrupoFactura-Hotel/2.3"})
                resp.raise_for_status()
                eventos = hotel.parsear_ical(resp.text)
            except Exception as ex:  # noqa: BLE001
                out["avisos"].append(f"Hab. {h.get('numero')} · {nombre}: no se pudo leer el calendario ({str(ex)[:80]})")
                continue
            reservas = modulos.leer(s, eid, "hotel_reservas", []) or []
            upserts, deletes, avisos = hotel.sincronizar_ical(reservas, h.get("id"), nombre, eventos, hoy, str(h.get("numero") or ""))
            out["avisos"] += avisos
            nuevos = [u for u in upserts if not u.get("id")]
            cambios = [u for u in upserts if u.get("id")]
            if cambios or deletes:
                modulos.aplicar_cambios(s, eid, "hotel_reservas", cambios, deletes, [])
            if nuevos:
                _agregar_registros(s, eid, "hotel_reservas", nuevos)
            out["creados"] += len(nuevos); out["actualizados"] += len(cambios); out["quitados"] += len(deletes)
    return out


def hotel_diario_empresa(e: Empresa, hoy=None, forzar: bool = False) -> dict:
    """Pasada diaria del hotel: importa los iCal, manda recordatorios de adelanto y de llegada, marca no presentados y carga las
    salidas tardías (según Hotel › Habitaciones y tarifas › Automático). Una vez por día y por empresa (o a pedido con forzar)."""
    hoy = hoy or ahora_cr().date()
    with Session(engine_empresa(e.id)) as s:
        cfg = modulos.leer(s, e.id, "hotel_config", None)
        if not isinstance(cfg, dict) or not cfg.get("activo"):
            return {"empresa_id": e.id, "motivo": "hotel inactivo"}
        if cfg.get("fecha_hotel"):                                   # 3.62: fecha del hotel (avanza al cerrar el día), nunca por delante del calendario
            reg = modulos.leer(s, e.id, "hotel_fecha", None) or {}
            try:
                hoy = min(date.fromisoformat(str(reg.get("fecha"))[:10]), hoy)
            except (TypeError, ValueError):
                pass
        marca = modulos.leer(s, e.id, "hotel_diario", None)
        marca = marca if isinstance(marca, dict) else {}
        if marca.get("fecha") == hoy.isoformat() and not forzar:
            return {"empresa_id": e.id, "motivo": "ya revisado hoy"}
        habitaciones = modulos.leer(s, e.id, "hotel_habitaciones", []) or []
        ical = _hotel_importar_ical(s, e.id, cfg, habitaciones, hoy.isoformat()) if cfg.get("ical_auto", True) else {"fuentes": 0, "creados": 0, "actualizados": 0, "quitados": 0, "avisos": []}
        reservas = modulos.leer(s, e.id, "hotel_reservas", []) or []
        huespedes = modulos.leer(s, e.id, "hotel_huespedes", []) or []
        categorias = modulos.leer(s, e.id, "hotel_categorias", []) or []
        ahora_iso = ahora_cr().isoformat(timespec="seconds")
        t = hotel.tareas_diarias(reservas, huespedes, habitaciones, cfg, hoy.isoformat(), ahora_iso)
        correos_ok, correos_err = 0, []
        if t["correos"]:
            if e.smtp_host and e.smtp_remitente:
                try:
                    cfg_smtp = _cfg_smtp(e)
                except Exception as ex:  # noqa: BLE001
                    cfg_smtp = None; correos_err.append(str(ex)[:120])
            else:
                cfg_smtp = None; correos_err.append("sin correo saliente configurado")
            for c in t["correos"]:
                r, hu, tipo = c["reserva"], c["huesped"], c["tipo"]
                plantilla = (cfg.get("mensaje_recordatorio_adelanto") or hotel.MENSAJE_ADELANTO) if tipo == "adelanto" else (cfg.get("mensaje_recordatorio_llegada") or hotel.MENSAJE_LLEGADA)
                texto = hotel.texto_plantilla(plantilla, r, hu, cfg, categorias, habitaciones, e.nombre_comercial or e.nombre)
                asunto = ("Adelanto pendiente · reserva " if tipo == "adelanto" else "Le esperamos · reserva ") + str(r.get("numero") or "") + " · " + (cfg.get("nombre") or e.nombre_comercial or e.nombre)
                ok = False
                if cfg_smtp is not None:
                    try:
                        html = _dz.armar(_dz.de_empresa(e, nombre=cfg.get("nombre") or None), asunto=asunto, texto_libre=texto, preencabezado=texto[:120],
                                         titulo="Su adelanto está pendiente" if tipo == "adelanto" else "Le esperamos pronto",
                                         antetitulo=f"Reserva {r.get('numero') or ''}".strip())   # 3.83
                        correo.enviar(cfg_smtp, [str(hu["correo"]).strip()], asunto, html, texto, [])
                        ok = True; correos_ok += 1
                    except Exception as ex:  # noqa: BLE001
                        correos_err.append(f"{r.get('numero')}: {str(ex)[:100]}")
                if not ok:                      # no se marca: se reintenta en la próxima pasada
                    for u in t["upserts"]:
                        if u.get("id") == r.get("id"):
                            u["recordatorios"] = {k: v for k, v in (u.get("recordatorios") or {}).items() if k != tipo}
                            u["historial"] = [x for x in u.get("historial") or [] if not str(x.get("texto", "")).startswith("Recordatorio de " + tipo)]
        if t["upserts"]:
            modulos.aplicar_cambios(s, e.id, "hotel_reservas", t["upserts"], [], [])
        if t["cargos"]:
            _agregar_registros(s, e.id, "hotel_folios", t["cargos"])
        resumen = {**t["resumen"], "correos": correos_ok, "ical_creados": ical["creados"], "ical_actualizados": ical["actualizados"], "ical_quitados": ical["quitados"], "ical_fuentes": ical["fuentes"]}
        # la marca del dia se reescribe con su version actual: sin ella, reemplazar() entiende que escribe una pestaña vieja y
        # pide recargar la pagina (RecargarPagina), con lo que la pasada fallaba desde el segundo dia (QA 19/10/2026)
        marca_reg = modulos._registro(s, e.id, "hotel_diario")
        modulos.reemplazar(s, e.id, "hotel_diario", {"fecha": hoy.isoformat(), "hora": ahora_iso, "resumen": resumen, "avisos": (ical["avisos"] + correos_err)[:40]},
                           version=(marca_reg.version or 0) if marca_reg else 0)
    detalle = ", ".join(f"{k} {v}" for k, v in resumen.items() if v)
    if detalle or ical["avisos"] or correos_err:
        _auditar_u(None, e.id, None, "hotel_diario", (detalle or "sin novedades") + (" · avisos: " + "; ".join((ical["avisos"] + correos_err)[:5]) if (ical["avisos"] or correos_err) else ""))
    return {"empresa_id": e.id, "resumen": resumen, "avisos": ical["avisos"] + correos_err}


def hotel_diario_todas() -> list[dict]:
    out = []
    with Session(engine) as sc:
        empresas = sc.exec(select(Empresa).where(Empresa.bloqueada == False)).all()  # noqa: E712
    for e in empresas:
        try:
            out.append(hotel_diario_empresa(e))
        except Exception as ex:  # noqa: BLE001
            out.append({"empresa_id": e.id, "error": str(ex)[:200]})
    return out


class CierreCorreoIn(BaseModel):
    fecha: str
    resumen: dict = Field(default_factory=dict)
    pendientes: list = Field(default_factory=list)
    notas: str = ""
    usuario: str = ""


def _texto_cierre_hotel(cfg: dict, e: Empresa, data: CierreCorreoIn, ctx: Contexto) -> str:
    """Resumen del cierre del día en texto (correo a la gerencia y portada del paquete PDF, 3.60)."""
    r = data.resumen or {}
    mon = cfg.get("moneda") or "USD"
    sim = "₡" if mon == "CRC" else "$"
    def m(v):
        try:
            return f"{sim}{float(v or 0):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        except (TypeError, ValueError):
            return str(v)
    lineas = [f"Cierre del día {data.fecha[8:10]}/{data.fecha[5:7]}/{data.fecha[:4]} · {cfg.get('nombre') or e.nombre_comercial or e.nombre}",
              f"Cerrado por {data.usuario or ctx.usuario.correo}" + ("" if (data.usuario or ctx.usuario.correo) in (ctx.usuario.correo, ctx.usuario.nombre)
                                                                    else f" · generado por {ctx.usuario.correo}"), "",   # 3.87: quien lo envía, si no es quien cerró
              f"Ocupación: {r.get('ocupadas', 0)} de {r.get('total', 0)} habitaciones ({r.get('pct', 0)} %)",
              f"Llegadas {r.get('llegadas', 0)} · salidas {r.get('salidas', 0)} · en casa {r.get('en_casa', 0)} · no presentados {r.get('no_show', 0)} · reservas creadas {r.get('creadas', 0)}", ""]
    nombres = {"hospedaje": "Hospedaje", "auto": "Cargos automáticos", "pos": "Restaurante y bar", "manual": "Otros cargos", "servicios": "Servicios", "eventos": "Eventos", "no_show": "No presentados", "minibar": "Minibar"}
    for k, v in (r.get("porC") or {}).items():
        lineas.append(f"  {nombres.get(k, k)}: {m(v)}")
    lineas += [f"Cargos del día: {m(r.get('cargos'))}", ""]
    for k, v in (r.get("porM") or {}).items():
        lineas.append(f"  Pagos · {k}: {m(v)}")
    lineas += [f"Pagos del día: {m(r.get('pagos'))}", f"ADR {m(r.get('adr'))} · RevPAR {m(r.get('revpar'))}", ""]
    if data.pendientes:
        lineas.append("Pendientes al cerrar: " + " · ".join(f"{p.get('n')} {str(p.get('t') or '').lower()}" for p in data.pendientes if isinstance(p, dict)))
    if data.notas:
        lineas.append("Nota: " + data.notas)
    return "\n".join(lineas)


def _enviar_cierre_hotel(cfg: dict, e: Empresa, data: CierreCorreoIn, texto: str, adjuntos: list) -> str:
    para = str(cfg.get("correo_cierre") or "").strip()
    if "@" not in para:
        raise HTTPException(400, "Indique el correo del cierre del día en Habitaciones y tarifas")
    if not (e.smtp_host and e.smtp_remitente):
        raise HTTPException(400, "Configure el correo saliente de la empresa")
    try:
        lineas = [x for x in texto.split("\n")[1:] if x.strip()]                  # 3.83: la primera línea es el título
        filas = [tuple(p.strip() for p in x.split(": ", 1)) for x in lineas if ": " in x]
        otras = [x.strip() for x in lineas if ": " not in x]
        html = _dz.armar(_dz.de_empresa(e, nombre=cfg.get("nombre") or None), titulo=f"Cierre del día {data.fecha[8:10]}/{data.fecha[5:7]}/{data.fecha[:4]}",
                         asunto="Cierre del día", parrafos_txt=["\n".join(otras)] if otras else [], datos=filas,
                         nota="El detalle completo va en el PDF adjunto." if adjuntos else "")
        correo.enviar(_cfg_smtp(e), [para], f"Cierre del día {data.fecha[8:10]}/{data.fecha[5:7]} · {cfg.get('nombre') or e.nombre_comercial or e.nombre}",
                      html, texto, adjuntos)
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(502, f"No se pudo enviar el correo: {str(ex)[:160]}")
    return para


@app.post("/api/hotel/cierre-correo")
def hotel_cierre_correo(data: CierreCorreoIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Informe del cierre del día por correo a la gerencia (3.22): el resumen que dejó la auditoría nocturna, al correo de
    Habitaciones y tarifas › Correo del cierre del día, con el correo saliente de la empresa."""
    if not ctx.puede(auth.permiso_registro("hotel_cierres")):     # 3.87: el permiso de guardar el cierre (antes también la caja)
        raise HTTPException(403, "Su rol no puede cerrar el día")
    e = ctx.empresa
    cfg = modulos.leer(s, e.id, "hotel_config", None) or {}
    para = _enviar_cierre_hotel(cfg, e, data, _texto_cierre_hotel(cfg, e, data, ctx), [])
    _auditar(ctx, "hotel_cierre_correo", f"Cierre del {data.fecha} enviado a {para}")
    return {"ok": True, "para": para}


# ---- paquete de reportes del cierre del día (3.60): un PDF con los reportes elegidos, guardado junto al cierre
class CierrePaqueteIn(CierreCorreoIn):
    kpis: list = Field(default_factory=list)
    secciones: list = Field(default_factory=list)


def _carpeta_cierres_hotel(eid: int) -> Path:
    return DATA_DIR / "empresas" / str(eid) / "hotel_cierres"


def _puede_ver_cierres(ctx: Contexto) -> bool:
    return ctx.usuario.es_superadmin or auth.puede_leer_registro(ctx.permisos, "hotel_cierres")   # 3.87: la regla del registro (el cajero ya no los recibe)


@app.post("/api/hotel/cierre-paquete")
def hotel_cierre_paquete(data: CierrePaqueteIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Genera el PDF del cierre (resumen + reportes que manda la pantalla, ya formateados), lo guarda en la carpeta de la
    empresa y, si hay correo del cierre, lo envía adjunto. El correo que falla no impide guardar el PDF."""
    if not ctx.puede(auth.permiso_registro("hotel_cierres")):     # 3.87: quien guarda el cierre (antes también la caja, que lo reescribía)
        raise HTTPException(403, "Su rol no puede cerrar el día")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", data.fecha or ""):
        raise HTTPException(400, "Fecha inválida")
    e = ctx.empresa
    cfg = modulos.leer(s, e.id, "hotel_config", None) or {}
    hotel = cfg.get("nombre") or e.nombre_comercial or e.nombre
    fecha_es = f"{data.fecha[8:10]}/{data.fecha[5:7]}/{data.fecha[:4]}"
    texto = _texto_cierre_hotel(cfg, e, data, ctx)
    filas_res = []
    for ln in texto.split("\n")[2:]:                      # el resumen del día como primera tabla (concepto · valor)
        ln = ln.strip()
        if ln:
            k, _, v = ln.partition(": ")
            filas_res.append({"concepto": k, "valor": v})
    sec_resumen = reportes.SeccionIn(titulo="Resumen del día", columnas=[reportes.ColumnaIn(key="concepto", label="Concepto"), reportes.ColumnaIn(key="valor", label="Valor")], filas=filas_res)
    try:
        autor = data.usuario or ctx.usuario.correo
        generado = "" if autor in (ctx.usuario.correo, ctx.usuario.nombre) else f" · generado por {ctx.usuario.correo}"   # 3.87
        rep = reportes.ReporteIn(titulo=f"Cierre del día {fecha_es} · {hotel}"[:120], subtitulo=("Cerrado por " + autor + generado + (" · " + data.notas if data.notas else ""))[:300],
                                 periodo=fecha_es, kpis=data.kpis[:8], secciones=[sec_resumen, *data.secciones[:11]], archivo=f"cierre_{data.fecha}",
                                 nota=("Pendientes al cerrar: " + " · ".join(f"{p.get('n')} {str(p.get('t') or '').lower()}" for p in data.pendientes if isinstance(p, dict)))[:300] if data.pendientes else None)
        reportes._validar(rep)
    except (ValueError, HTTPException) as ex:
        raise HTTPException(400, f"Paquete inválido: {getattr(ex, 'detail', ex)}")
    if sum(len(x.filas) * len(x.columnas) for x in rep.secciones) > 30000:
        raise HTTPException(400, "El paquete es muy grande (más de 30.000 celdas): quite reportes en Habitaciones y tarifas")
    contenido = reportes._pdf(rep, e, pdf.logo_empresa(e))
    carpeta = _carpeta_cierres_hotel(e.id)
    carpeta.mkdir(parents=True, exist_ok=True)
    ruta = carpeta / f"cierre_{data.fecha}.pdf"
    ruta.write_bytes(contenido)
    correo_a = correo_error = None
    if "@" in str(cfg.get("correo_cierre") or ""):
        try:
            correo_a = _enviar_cierre_hotel(cfg, e, data, texto, [(ruta.name, contenido, "application", "pdf")])
        except HTTPException as ex:
            correo_error = str(ex.detail)
    _auditar(ctx, "hotel_cierre", f"Cierre del {data.fecha}: paquete PDF de {len(contenido) // 1024} KB" + (f", enviado a {correo_a}" if correo_a else "") + (f" (correo falló: {correo_error})" if correo_error else ""))
    return {"ok": True, "archivo": ruta.name, "bytes": len(contenido), "correo": correo_a, "correo_error": correo_error}


@app.get("/api/hotel/cierre-paquete")
def hotel_cierre_paquetes(ctx: Contexto = Depends(contexto)):
    if not _puede_ver_cierres(ctx):
        raise HTTPException(403, "Su rol no ve los cierres del hotel")
    carpeta = _carpeta_cierres_hotel(ctx.empresa.id)
    fechas = sorted((p.name[7:17] for p in carpeta.glob("cierre_????-??-??.pdf")), reverse=True) if carpeta.is_dir() else []
    return {"fechas": fechas}


@app.get("/api/hotel/cierre-paquete/{fecha}")
def hotel_cierre_paquete_pdf(fecha: str, ctx: Contexto = Depends(contexto)):
    if not _puede_ver_cierres(ctx):
        raise HTTPException(403, "Su rol no ve los cierres del hotel")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fecha):
        raise HTTPException(404, "Paquete no encontrado")
    p = _carpeta_cierres_hotel(ctx.empresa.id) / f"cierre_{fecha}.pdf"
    if not p.is_file():
        raise HTTPException(404, "Paquete no encontrado")
    return FileResponse(p, media_type="application/pdf", filename=p.name)


@app.delete("/api/hotel/cierre-paquete/{fecha}")
def hotel_cierre_reabrir(fecha: str, motivo: str = "", ctx: Contexto = Depends(requiere("configurar"))):
    """3.61: reabrir el día. Borra el paquete PDF del cierre (el registro del cierre lo quita la pantalla, que es quien lo guarda)
    y deja el motivo en el historial de operaciones. Solo el Administrador."""
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fecha):
        raise HTTPException(404, "Cierre no encontrado")
    motivo = (motivo or "").strip()
    if len(motivo) < 5:
        raise HTTPException(400, "Indique el motivo de la reapertura")
    p = _carpeta_cierres_hotel(ctx.empresa.id) / f"cierre_{fecha}.pdf"
    borrado = p.is_file()
    if borrado:
        p.unlink()
    _auditar(ctx, "hotel_cierre_reabierto", f"Día {fecha} reabierto: {motivo[:200]}" + ("" if borrado else " (no tenía paquete PDF)"))
    return {"ok": True, "pdf_borrado": borrado}


class ArchivoHuespedIn(BaseModel):
    tipo: str          # firma | documento
    datos: str         # data URL (image/png, image/jpeg o image/webp)


_PERMISOS_HUESPED = ("escribir", "pos", "facturar", "cobros")


def _archivo_huesped(eid: int, hid: int, tipo: str) -> Path | None:
    for ext in ("png", "jpg", "webp"):
        p = _img_dir(eid) / f"huesped_{hid}_{tipo}.{ext}"
        if p.exists():
            return p
    return None


@app.post("/api/hotel/huespedes/{hid}/archivo")
def subir_archivo_huesped(hid: int, data: ArchivoHuespedIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Firma digital de la tarjeta de registro y foto del documento del huésped (3.22): llegan como data URL desde el check-in
    y se guardan en la carpeta de imágenes de la empresa (huesped_<id>_<tipo>.<ext>)."""
    if not any(ctx.puede(p) for p in _PERMISOS_HUESPED):
        raise HTTPException(403, "Su rol no puede registrar huéspedes")
    if data.tipo not in ("firma", "documento"):
        raise HTTPException(400, "Tipo de archivo inválido")
    m = re.match(r"data:image/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=\s]+)$", data.datos or "")
    if not m:
        raise HTTPException(400, "La imagen debe ser PNG, JPG o WEBP")
    try:
        raw = base64.b64decode(m.group(2), validate=False)
    except (ValueError, TypeError):
        raise HTTPException(400, "Imagen ilegible")
    if len(raw) > 4 * 1024 * 1024:
        raise HTTPException(413, "La imagen pesa más de 4 MB")
    huespedes = modulos.leer(s, ctx.empresa.id, "hotel_huespedes", []) or []
    if not any(isinstance(h, dict) and h.get("id") == hid for h in huespedes):
        raise HTTPException(404, "Huésped no encontrado")
    ext = {"jpeg": "jpg"}.get(m.group(1), m.group(1))
    for viejo in ("png", "jpg", "webp"):
        (_img_dir(ctx.empresa.id) / f"huesped_{hid}_{data.tipo}.{viejo}").unlink(missing_ok=True)
    (_img_dir(ctx.empresa.id) / f"huesped_{hid}_{data.tipo}.{ext}").write_bytes(raw)
    _auditar(ctx, "hotel_huesped_archivo", f"{data.tipo} del huésped {hid}")
    return {"ok": True}


@app.get("/api/hotel/huespedes/{hid}/archivo/{tipo}")
def archivo_huesped(hid: int, tipo: str, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not (any(ctx.puede(p) for p in _PERMISOS_HUESPED) or ctx.puede("ver_todo")):
        raise HTTPException(403, "Su rol no puede ver los archivos del huésped")
    if tipo not in ("firma", "documento"):
        raise HTTPException(400, "Tipo de archivo inválido")
    p = _archivo_huesped(ctx.empresa.id, hid, tipo)
    if not p:
        raise HTTPException(404, "Sin archivo")
    return FileResponse(p)


class MinibarIn(BaseModel):
    reserva_id: int
    items: list[dict] = Field(default_factory=list)
    nota: str = ""


@app.get("/api/hotel/minibar")
def hotel_minibar_items(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Ítems de la categoría del minibar (Habitaciones y tarifas) para cargarlos desde el celular de la camarera (3.22)."""
    if not any(ctx.puede(p) for p in ("limpieza", "escribir", "pos", "cobros")):
        raise HTTPException(403, "Su rol no puede cargar el minibar")
    cfg = modulos.leer(s, ctx.empresa.id, "hotel_config", None) or {}
    cat = str(cfg.get("minibar_categoria") or "").strip()
    if not cat:
        return {"categoria": "", "items": []}
    items = []
    for p in s.exec(select(Producto).where(Producto.empresa_id == ctx.empresa.id)).all():
        if p.activo is False or (p.categoria or "").strip().lower() != cat.lower() or getattr(p, "es_venta", True) is False:
            continue
        items.append({"id": p.id, "nombre": p.nombre, "precio": float(p.precio or 0), "precio_con_iva": round(float(p.precio or 0) * (1 + float(p.tarifa or 0) / 100), 2), "tarifa": float(p.tarifa or 0)})
    items.sort(key=lambda x: x["nombre"].lower())
    return {"categoria": cat, "items": items}


@app.post("/api/hotel/minibar")
def hotel_minibar_cargar(data: MinibarIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Carga el consumo del minibar a la cuenta de la reserva en casa (3.22): cargos origen «minibar» con el precio de venta
    (sin IVA, en la moneda de la cuenta); la camarera puede hacerlo aunque su rol no guarde cuentas."""
    if not any(ctx.puede(p) for p in ("limpieza", "escribir", "pos", "cobros")):
        raise HTTPException(403, "Su rol no puede cargar el minibar")
    eid = ctx.empresa.id
    r = next((x for x in (modulos.leer(s, eid, "hotel_reservas", []) or []) if isinstance(x, dict) and x.get("id") == data.reserva_id), None)
    if not r:
        raise HTTPException(404, "Reserva no encontrada")
    if r.get("estado") != "en_casa":
        raise HTTPException(409, "El huésped no está en casa: el minibar se carga a cuentas abiertas")
    cfg = modulos.leer(s, eid, "hotel_config", None) or {}
    moneda = r.get("moneda") or cfg.get("moneda") or "USD"
    tc = 0.0
    try:
        t = tipo_cambio.obtener()
        margen = ctx.empresa.margen_cambiario if ctx.empresa.margen_cambiario is not None else 5.0
        tc = float(tipo_cambio.aplicado(t.get("venta"), margen) or 0)
    except Exception:  # noqa: BLE001
        tc = 0.0
    hoy = ahora_cr().date().isoformat()
    cargos, total = [], 0.0
    for it in data.items:
        try:
            pid, cant = int(it.get("producto_id") or 0), float(it.get("cantidad") or 0)
        except (TypeError, ValueError):
            continue
        p = s.get(Producto, pid)
        if not p or p.empresa_id != eid or cant <= 0:
            continue
        if (p.moneda or "CRC") != moneda and tc <= 0:
            raise HTTPException(400, "Sin tipo de cambio del día: cargue el minibar desde Recepción")
        neto = _precio_en_moneda(p, moneda, tc)
        cargos.append({"reserva_id": r["id"], "tipo": "cargo", "origen": "minibar", "fecha": hoy,
                       "detalle": f"{p.nombre} · minibar" + (f" · {data.nota.strip()[:80]}" if data.nota.strip() else ""),
                       "cantidad": cant, "precio": neto, "tarifa": float(p.tarifa or 0), "codigo_tarifa": p.codigo_tarifa or "08", "cabys": p.cabys,
                       "producto_id": p.id, "moneda": moneda, "creado": datetime.now(timezone.utc).isoformat(), "usuario": ctx.usuario.correo})
        total += cant * neto * (1 + float(p.tarifa or 0) / 100)
    if not cargos:
        raise HTTPException(400, "Marque al menos un producto")
    ids = _agregar_registros(s, eid, "hotel_folios", cargos)
    _auditar(ctx, "hotel_minibar", f"Reserva {r.get('numero')}: {len(cargos)} cargo(s) de minibar")
    return {"ok": True, "ids": ids, "total": round(total, 2), "moneda": moneda}


@app.post("/api/hotel/diario")
def hotel_diario_ahora(ctx: Contexto = Depends(contexto)):
    """Corre ahora las tareas automáticas del hotel (iCal, recordatorios, no presentados, salidas tardías)."""
    if not (ctx.puede("escribir") or ctx.puede("pos")):
        raise HTTPException(403, "Su rol no puede ejecutar las tareas del hotel")
    return hotel_diario_empresa(ctx.empresa, forzar=True)


@app.post("/api/hotel/ical/importar")
def hotel_ical_importar(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Lee ahora los calendarios iCal de las habitaciones (Booking, Airbnb…) y actualiza los bloqueos."""
    if not (ctx.puede("escribir") or ctx.puede("pos")):
        raise HTTPException(403, "Su rol no puede importar calendarios")
    planes.exigir_modulo(ctx.empresa, "canales")
    cfg = modulos.leer(s, ctx.empresa.id, "hotel_config", None) or {}
    habitaciones = modulos.leer(s, ctx.empresa.id, "hotel_habitaciones", []) or []
    r = _hotel_importar_ical(s, ctx.empresa.id, cfg, habitaciones, ahora_cr().strftime("%Y-%m-%d"))
    _auditar(ctx, "hotel_ical", f"{r['fuentes']} calendario(s): {r['creados']} nuevos, {r['actualizados']} cambiados, {r['quitados']} quitados" + (f"; avisos: {len(r['avisos'])}" if r["avisos"] else ""))
    return r


def _base_publica(request: Request) -> str:
    return (URL_PUBLICA or str(request.base_url).rstrip("/"))


@app.get("/api/hotel/ical/enlaces")
def hotel_ical_enlaces(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Enlace público del calendario de cada habitación, para pegarlo en Booking o Airbnb (exportar)."""
    planes.exigir_modulo(ctx.empresa, "canales")
    if not ctx.puede("configurar"):   # 3.87: solo quien configura los canales (como la pantalla); el enlace sirve sin sesión y no caduca
        raise HTTPException(403, "Los enlaces del calendario de las habitaciones solo los ve quien configura el hotel")
    habitaciones = modulos.leer(s, ctx.empresa.id, "hotel_habitaciones", []) or []
    base = _base_publica(ctx.request)
    return [{"id": h.get("id"), "numero": h.get("numero"), "url": f"{base}/p/hotel/ical/{ctx.empresa.id}/{h.get('id')}/{hotel.token_ical(auth.SECRET, ctx.empresa.id, int(h.get('id')))}.ics"}
            for h in habitaciones if isinstance(h, dict) and h.get("activa") is not False and isinstance(h.get("id"), int)]


@app.get("/p/hotel/ical/{eid}/{hab_id}/{token}.ics")
def hotel_ical_publico(eid: int, hab_id: int, token: str, request: Request):
    """Calendario iCal de una habitación (lo leen Booking y Airbnb). Sin sesión: el enlace lleva un token propio."""
    from fastapi.responses import Response
    if not hmac.compare_digest(token, hotel.token_ical(auth.SECRET, eid, hab_id)):
        raise HTTPException(404, "Calendario no encontrado")
    auth.limitar_ip(request, "ical", 120, 300, "Demasiadas lecturas del calendario; espere un momento", f"i{eid}")
    with Session(engine) as sc:
        e_ = sc.get(Empresa, eid)
    if e_ is None or "canales" not in planes.modulos_de(e_):          # integración de canales no contratada (3.16)
        raise HTTPException(404, "Calendario no encontrado")
    with Session(engine) as sc:
        e = sc.get(Empresa, eid)
    if e is None or e.bloqueada:
        raise HTTPException(404, "Calendario no encontrado")
    with Session(engine_empresa(eid)) as s:
        cfg = modulos.leer(s, eid, "hotel_config", None) or {}
        habs = modulos.leer(s, eid, "hotel_habitaciones", []) or []
        reservas = modulos.leer(s, eid, "hotel_reservas", []) or []
    h = next((x for x in habs if isinstance(x, dict) and x.get("id") == hab_id), None)
    if h is None or not cfg.get("activo"):
        raise HTTPException(404, "Calendario no encontrado")
    texto = hotel.exportar_ical(reservas, hab_id, cfg.get("nombre") or e.nombre_comercial or e.nombre, str(h.get("numero") or ""))
    return Response(content=texto, media_type="text/calendar; charset=utf-8", headers={"Content-Disposition": f'inline; filename="habitacion-{h.get("numero")}.ics"', "Cache-Control": "no-cache"})


# ---- administración: lista de IP permitidas (2.3)
class SeguridadIn(BaseModel):
    activa: bool = False
    ips: list[str] = Field(default_factory=list, max_length=100)


@app.get("/api/admin/seguridad")
def admin_seguridad(request: Request, a=Depends(auth.superadmin)):
    cfg = auth.seguridad_leer()
    return {**cfg, "ip_actual": auth._ip(request)}


@app.put("/api/admin/seguridad")
def admin_seguridad_guardar(data: SeguridadIn, request: Request, s: Session = Depends(get_session), a=Depends(auth.superadmin)):
    if not auth.es_admin_principal(s, a):       # 3.87: la lista también limita al super administrador; antes cualquier administrador la cambiaba
        raise HTTPException(403, "Solo el super administrador cambia la lista de direcciones IP permitidas")
    ips = []
    for x in data.ips:
        x = str(x).strip()
        if not x:
            continue
        if not auth.ip_valida(x):
            raise HTTPException(400, f"«{x}» no es una dirección IP ni un rango válido (ejemplos: 190.10.20.30 o 200.1.0.0/24)")
        if x not in ips:
            ips.append(x)
    actual = auth._ip(request)
    aviso = None
    if data.activa and not ips:
        raise HTTPException(400, "Para activar la lista indique al menos una dirección")
    if data.activa and actual and actual not in ("127.0.0.1", "::1") and not auth.ip_en_lista(actual, ips):
        ips.append(actual); aviso = f"Se agregó su dirección actual ({actual}) para que no quede fuera"
    cfg = {"ip_admin": {"activa": data.activa, "ips": ips}}
    auth.seguridad_guardar(cfg)
    auditar(s, "seguridad_ip_admin", ("Lista de IP ACTIVA: " if data.activa else "Lista de IP desactivada: ") + ", ".join(ips), a, None, request)
    s.commit()
    return {**cfg, "ip_actual": actual, "aviso": aviso}


@app.delete("/api/registros/{clave}")
def delete_registro(clave: str, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    _clave_valida(clave)
    # 4.7: además de «configurar», el permiso propio de la clave: sin Recursos humanos nadie borra empleados, planillas ni liquidaciones
    # (antes un rol propio con configuración, o un Administrador con RRHH apagado, borraba la lista completa)
    ctx.exigir(auth.permiso_registro(clave))
    if clave in CAMPOS_RRHH_PAGADO:                        # 4.7: lo ya pagado (reportado a la CCSS y a Hacienda) no sale de una vez por aquí
        for x in modulos.leer(s, ctx.empresa.id, clave, []) or []:
            if _rrhh_pagado(clave, x):                     # 4.7.1: la misma regla que /cambios y el PUT (también el aguinaldo sin estado)
                ref = x.get("numero") or ("Aguinaldo " + str(x.get("anio") or "")).strip()
                raise HTTPException(403, f"La lista tiene documentos ya pagados ({ref}): lo pagado no se borra; se corrige con un ajuste")
    if clave == "rrhh_acciones" and (modulos.leer(s, ctx.empresa.id, clave, []) or []):   # 4.21: las acciones de personal no se eliminan: se anulan
        raise HTTPException(403, "Las acciones de personal no se eliminan: se anulan una por una, con su motivo")
    if clave in CLAVES_SOLO_SERVIDOR and (modulos.leer(s, ctx.empresa.id, clave, []) or []):   # 4.22: tampoco de una vez lo que solo escribe el servidor
        raise HTTPException(403, "Los documentos de los empleados se eliminan desde la ficha de cada empleado (o al eliminar al empleado)" if clave == "rrhh_documentos"
                            else "Los pagos de cargas registrados no se borran: una diferencia se registra con un asiento manual")
    if clave == "asientos":                              # 3.87: tampoco por aquí sale un asiento de un periodo contable cerrado
        cerrados: dict = {}
        for a in modulos.leer(s, ctx.empresa.id, clave, []) or []:
            p = _periodo_cerrado(s, ctx.empresa.id, a.get("fecha") if isinstance(a, dict) else None, cerrados)
            if p:
                raise HTTPException(403, f"El periodo {p} está cerrado: reábralo en Configuración › Periodos contables antes de borrar los asientos")
    if clave == "empleados":
        # 4.22: con la lista completa se van los documentos y las acciones de personal de todos, y se van ANTES de borrarla. Al borrar
        # la lista los ids de empleado vuelven a empezar en 1: si esa limpieza fallara después (antes solo quedaba en el registro
        # del servidor), el empleado nuevo n.º 1 heredaría los documentos y las acciones del anterior. Si falla, la lista se queda
        if not _limpiar_fichas_eliminadas(ctx, s, None):
            raise HTTPException(409, "No se pudieron quitar los documentos y las acciones de personal de los empleados: intente de nuevo")
    for r in s.exec(select(modulos.Registro).where(modulos.Registro.empresa_id == ctx.empresa.id, modulos.Registro.clave == clave)).all():
        s.delete(r)
    for f in s.exec(select(modulos.RegistroItem).where(modulos.RegistroItem.empresa_id == ctx.empresa.id, modulos.RegistroItem.clave == clave)).all():
        s.delete(f)
    s.commit()
    _auditar(ctx, "registro_borrado", f"Registro «{clave}» borrado completo")   # 3.87: p. ej. periodos_<año> (reabre todos los meses)
    return {"ok": True}


# ---- pagos recibidos
class PagoIn(BaseModel):
    tipo: Literal["caja", "rep"] = "caja"
    cliente_id: Optional[int] = None
    detalles: str = ""
    fecha: str
    cuenta: str = ""
    condicion_venta: str = "01"
    medio_pago: str = "04"
    medio_pago_otros: Optional[str] = None  # descripción obligatoria cuando el medio es 99 «Otros» (va al REP)
    moneda: str = "CRC"
    tipo_cambio: float = 1
    monto: float = Field(gt=0)
    notas: str = ""
    facturas: list[dict] = []              # [{id, monto}]
    idempotencia: Optional[str] = Field(default=None, max_length=120)   # 4.8: el mismo cobro reenviado devuelve el ya registrado


def _pagos_visibles(ctx: Contexto, s: Session, filas: list) -> list:
    """3.87 (extras:6, lista de cobros): quien está amarrado a una sucursal ve solo los cobros de los comprobantes de ella (contra el
    Documento, como _documento_ctx) y, de los que no llevan factura (anticipos), los que registró él. Antes /api/pagos le traía los
    de todas (cliente, cédula, monto y consecutivo). El Administrador, el vendedor libre y quien solo eligió una sucursal en la
    barra siguen viendo todos."""
    suc = getattr(ctx, "sucursal", None)
    if suc is None or not getattr(ctx, "sucursal_fija", False):
        return filas
    fac = {p.id: [int(f["id"]) for f in json.loads(p.facturas or "[]") if isinstance(f, dict) and str(f.get("id") or "").isdigit()] for p in filas}
    ids = {i for x in fac.values() for i in x}
    suyos = {d.id for d in _filas(s, Documento, ("id", "sucursal_id", "consecutivo"), Documento.empresa_id == ctx.empresa.id)
             if d.id in ids and sucursales.pertenece(d, suc)} if ids else set()
    return [p for p in filas if (all(i in suyos for i in fac[p.id]) if fac[p.id] else p.usuario == ctx.usuario.correo)]


@app.get("/api/pagos", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def get_pagos(request: Request, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    filas = s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == ctx.empresa.id)).all()
    _exigir_ventas(ctx, "los cobros")                                     # 3.87: no para los roles de un solo módulo
    if auth.solo_pos(ctx.permisos):                                        # el cajero solo ve sus cobros de hoy
        hoy_cr = ahora_cr().strftime("%Y-%m-%d"); filas = [p for p in filas if (p.fecha or "")[:10] == hoy_cr and p.usuario == ctx.usuario.correo]
    filas = _pagos_visibles(ctx, s, filas)                                 # 3.87: el amarrado a una sucursal, solo los de ella
    out = [modulos.pago_dict(p) for p in sorted(filas, key=lambda p: p.numero, reverse=True)]
    # estado ACTUAL de cada REP (Pago.documentos guarda una copia al registrar el pago; la cola lo envía y Hacienda responde después) (R100)
    ids = [d["id"] for p in out for d in p.get("documentos", []) if d.get("id")]
    if ids:
        estados = {d.id: (d.estado, d.mensaje_hacienda) for d in s.exec(select(Documento).where(Documento.id.in_(ids))).all()}
        for p in out:
            for d in p.get("documentos", []):
                if d.get("id") in estados:
                    d["estado"], d["mensaje"] = estados[d["id"]]
    return _json_rapido(request, out)           # 3.87: el mismo JSON, serializado directo y con gzip (1,4 MB → 65 KB con miles de cobros)


@app.post("/api/pagos")
def crear_pago(data: PagoIn, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not (ctx.puede("cobros") or (ctx.puede("pos") and data.tipo == "caja")):   # el cajero registra los cobros de la caja
        raise HTTPException(403, "Su rol no puede registrar cobros")
    e = ctx.empresa
    idem = (data.idempotencia or "").strip() or None
    if idem:                                # 4.8: la caja reenvía un cobro cuya respuesta se perdió: no se cobra dos veces
        ya = _pago_por_idempotencia(s, e.id, idem)
        if ya:
            return ya
    if not ctx.puede("cobros"):                                                    # solo con 'pos': ventas de contado de hoy, siempre contra facturas
        hoy_cr = ahora_cr().strftime("%Y-%m-%d")
        if not data.facturas:
            raise HTTPException(403, "En la caja el cobro siempre se aplica a un comprobante")
        for f in data.facturas:
            d0 = _documento(s, e.id, int(f.get("id", 0)))
            fiado_pos = d0.tipo_documento in ("01", "04") and (d0.condicion_venta or "") == "02"   # abonos a ventas a crédito (fiados) desde la caja (3.23)
            if not fiado_pos and (d0.tipo_documento not in ("01", "04") or (d0.condicion_venta or "01") != "01" or (d0.fecha_emision or "")[:10] != hoy_cr):
                raise HTTPException(403, f"{d0.consecutivo}: desde la caja solo se cobran tiquetes y facturas de contado emitidos hoy, y abonos a fiados de la caja")
    cliente = _cliente(s, e.id, data.cliente_id) if data.cliente_id else None
    aplicadas = []
    vistos: set = set()
    for f in data.facturas:
        d = _documento(s, e.id, int(f.get("id", 0)))
        if d.id in vistos:                                                   # (R195)
            raise HTTPException(400, f"{d.consecutivo} está repetida en el cobro")
        vistos.add(d.id)
        if d.tipo_documento not in ("01", "04", "09", "02"):
            raise HTTPException(400, f"{d.consecutivo} no es un documento cobrable")
        if d.estado == "rechazado":
            raise HTTPException(400, f"{d.consecutivo} fue rechazada por Hacienda; no se cobra")
        if (d.moneda or "CRC") != data.moneda:
            raise HTTPException(400, f"{d.consecutivo} está en {d.moneda}; registre el cobro en esa moneda")
        if data.tipo == "rep" and cliente and d.cliente_id != cliente.id:
            raise HTTPException(400, f"{d.consecutivo} no es del cliente indicado")
        if data.tipo == "caja" and d.tipo_documento != "04" and (d.condicion_venta or "") in ("10", "08") and d.estado not in ("aceptado", "interno"):
            raise HTTPException(400, f"{d.consecutivo}: es una venta a crédito con IVA diferido o al Estado; se cobra con recibo electrónico de pago cuando Hacienda la acepte (estado {d.estado})")
        monto = round(float(f.get("monto") or 0), 2)
        if monto <= 0:
            continue
        saldo = modulos.saldo_documento(d)
        if monto > saldo + 0.005:
            raise HTTPException(400, f"El monto aplicado a {d.consecutivo} ({monto:,.2f}) supera su saldo ({saldo:,.2f})")
        aplicadas.append({"id": d.id, "consecutivo": d.consecutivo, "monto": monto})
    if data.tipo == "rep" and not data.notas.strip():
        raise HTTPException(400, "La razón es obligatoria en el recibo electrónico de pago")
    if data.tipo == "rep" and not aplicadas:
        raise HTTPException(400, "El recibo electrónico de pago debe aplicarse a una factura")
    if aplicadas and abs(sum(a["monto"] for a in aplicadas) - round(data.monto, 2)) > 0.01:     # (R177)
        raise HTTPException(400, f"El monto del cobro ({data.monto:,.2f}) no coincide con lo aplicado a las facturas ({sum(a['monto'] for a in aplicadas):,.2f})")
    numero = (max((p.numero for p in s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == e.id)).all()), default=0) or 0) + 1
    try:                                    # antes de emitir nada: la cuenta debe poder recibir el dinero en su moneda
        modulos.validar_cuenta_moneda(s, e.id, data.cuenta, data.moneda, data.tipo_cambio)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    docs_rep = []
    if data.tipo == "rep":
        if not cliente:
            raise HTTPException(400, "El recibo electrónico de pago requiere el cliente")
        if e.ambiente == "produccion" and not (e.p12_nombre and e.p12_pin):
            raise HTTPException(400, "Cargue la llave criptográfica (.p12) antes de emitir recibos electrónicos de pago")
        for f in aplicadas:
            docs_rep.append(_emitir_rep(s, e, cliente, _documento(s, e.id, f["id"]), Decimal(str(f["monto"])), data))
    p = modulos.Pago(empresa_id=e.id, numero=numero, tipo=data.tipo, consecutivo=docs_rep[0].consecutivo if docs_rep else None,
                     cliente_id=cliente.id if cliente else None,
                     cliente_nombre=cliente.nombre if cliente else None, cliente_cedula=cliente.numero_id if cliente else None,
                     detalles=data.detalles, fecha=data.fecha, cuenta=data.cuenta, condicion_venta=data.condicion_venta,
                     medio_pago=data.medio_pago, moneda=data.moneda, tipo_cambio=data.tipo_cambio, monto=round(data.monto, 2),
                     notas=data.notas, facturas=json.dumps(aplicadas), usuario=ctx.usuario.correo, idempotencia=idem,
                     documentos=json.dumps([{"id": d.id, "consecutivo": d.consecutivo, "clave": d.clave, "estado": d.estado} for d in docs_rep]))
    modulos.aplicar_pago(s, e.id, aplicadas, +1)
    s.add(p)
    try:
        s.commit()
    except IntegrityError:                  # 4.8: dos envíos simultáneos del mismo cobro: el segundo devuelve el primero (índice ux_pago_idem)
        s.rollback()
        ya = _pago_por_idempotencia(s, e.id, idem) if idem else None
        if ya:
            return ya
        raise
    s.refresh(p)
    # El dinero entra en la cuenta de Bancos elegida (lo hace el servidor: también funciona para quien no tiene acceso a Bancos)
    try:
        cliente_nombre = cliente.nombre if cliente else ""
        modulos.registrar_movimiento_banco(s, e.id, data.cuenta, float(p.monto), data.fecha,
                                           f"{'Recibo electrónico de pago' if data.tipo == 'rep' else 'Recibo de caja'} #{numero}"
                                           + (f" · {cliente_nombre}" if cliente_nombre else "") + (f" · {data.detalles}" if data.detalles else ""), _ref_pago(p), moneda=data.moneda, tipo_cambio=data.tipo_cambio)
    except Exception as ex:  # noqa: BLE001  el cobro queda registrado aunque el movimiento falle
        import logging; logging.getLogger(__name__).warning("Movimiento bancario del pago %s: %s", p.id, ex)
        s.rollback()
    s.refresh(p)                                   # el commit del movimiento vence el objeto: se recarga para responder completo
    _auditar(ctx, "pago_registrado", f"Pago #{numero} {data.moneda} {data.monto:,.2f} ({data.detalles or 'otros ingresos'})"
             + (f"; REP {', '.join(d.consecutivo for d in docs_rep)}" if docs_rep else ""))
    # Envío a Hacienda de los REP (si Hacienda no responde quedan firmados y la cola los reintenta)
    estados = []
    for d in docs_rep:
        try:
            d = enviar_documento(s, e, d, ctx.usuario, ctx.request)
        except HTTPException as ex:
            d.mensaje_hacienda = f"Pendiente de envío: {ex.detail}"
        estados.append({"id": d.id, "consecutivo": d.consecutivo, "clave": d.clave, "estado": d.estado, "mensaje": d.mensaje_hacienda})
    if docs_rep:
        p.documentos = json.dumps([{k: x[k] for k in ("id", "consecutivo", "clave", "estado")} for x in estados]); s.add(p); s.commit(); s.refresh(p)
    out = modulos.pago_dict(p); out["rep"] = estados
    return out


def _pago_por_idempotencia(s: Session, eid: int, idem: str):
    """4.8: el cobro ya registrado con esa clave, en la forma corta que necesita la caja (número y monto): la clave no sirve para
    leer los datos de un cobro ajeno."""
    p = s.exec(select(modulos.Pago).where(modulos.Pago.empresa_id == eid, modulos.Pago.idempotencia == idem)).first()
    if not p:
        return None
    return {"id": p.id, "numero": p.numero, "monto": p.monto, "medio_pago": p.medio_pago, "repetido": True, "rep": []}


def _condicion_de(d: Documento) -> str:
    """Condición de venta del comprobante (columna nueva; en comprobantes viejos se lee del XML)."""
    if d.condicion_venta:
        return d.condicion_venta
    try:
        root = etree.fromstring((XML_DIR / d.xml_nombre).read_bytes())
        return root.findtext("{*}CondicionVenta") or ""
    except Exception:  # noqa: BLE001
        return ""


def _emitir_rep(s: Session, e: Empresa, cliente: Cliente, factura: Documento, monto: Decimal, data: "PagoIn") -> Documento:
    """Crea, valida y firma un Recibo Electrónico de Pago por el monto cobrado de `factura` (una por factura)."""
    planes.verificar_emision(s, e)
    if factura.tipo_documento not in ("01", "09"):               # sobre una FEC la empresa es la compradora: no cobra (R243)
        raise HTTPException(400, f"{factura.consecutivo}: el REP solo aplica a facturas electrónicas")
    if factura.estado != "aceptado":
        raise HTTPException(400, f"{factura.consecutivo}: la factura debe estar aceptada por Hacienda para emitir el REP (estado {factura.estado})")
    if factura.ambiente != e.ambiente:
        raise HTTPException(400, f"{factura.consecutivo}: la factura es del ambiente {factura.ambiente} y la empresa está en {e.ambiente}")
    cond = _condicion_de(factura)
    cond_rep = fe_rep.CONDICION_FACTURA_A_REP.get(cond)
    if not cond_rep:
        raise HTTPException(400, f"{factura.consecutivo}: el recibo electrónico de pago solo aplica a facturas emitidas a crédito con IVA "
                                 f"diferido (condición 10) o de servicios al Estado (08); esta es condición {cond or '?'}. Registre un recibo de caja")
    if data.moneda != factura.moneda:
        raise HTTPException(400, f"{factura.consecutivo}: el pago debe registrarse en la moneda de la factura ({factura.moneda})")
    lineas = [l.model_dump() for l in s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id == factura.id)).all()]
    if not lineas:
        raise HTTPException(400, f"{factura.consecutivo}: la factura no tiene líneas registradas")
    ahora = ahora_cr()
    numero = _siguiente_numero(s, e.id, "10", e.ambiente)
    try:
        consecutivo = generar_consecutivo("10", numero, e.sucursal, e.terminal)
        clave = generar_clave(_cedula_para_clave(e), consecutivo, ahora, situacion=_sinc.situacion_emision())   # etapa 1: 1 salvo que se active la situación 3
        recibo = fe_rep.ReciboPago(
            clave=clave, consecutivo=consecutivo, fecha_emision=ahora.isoformat(timespec="seconds"),
            proveedor_sistemas=e.proveedor_sistemas or PROVEEDOR_SISTEMAS,
            emisor=_parte_empresa(e), receptor=_parte_cliente(cliente), condicion_venta=cond_rep,
            moneda=factura.moneda, tipo_cambio=Decimal(str(data.tipo_cambio if (data.tipo_cambio or 0) > 1 or factura.moneda == "CRC" else (factura.tipo_cambio or 1))),
            lineas=fe_rep.lineas_pago(lineas, Decimal(str(factura.total)), monto, factura.consecutivo), medio_pago=data.medio_pago,
            medio_pago_otros=((data.medio_pago_otros or "").strip() or None) if data.medio_pago == "99" else None,
            referencias=[Referencia(tipo_doc=_tipo_doc_referencia(factura.tipo_documento, "10"), numero=factura.clave, fecha_emision=factura.fecha_emision,
                                    codigo="17", razon=(data.notas or f"Pago de la factura {factura.consecutivo}")[:180])])
        root = fe_rep.construir_xml_rep(recibo)
    except (ValueError, AssertionError) as ex:
        raise HTTPException(400, f"No se pudo generar el REP: {_mensaje_pydantic(ex)}")
    errores = validar(root, "10")
    if errores:
        raise HTTPException(400, {"mensaje": "El REP no cumple el esquema v4.4", "errores": errores})
    estado = "generado"
    if not getattr(e, "factura_electronica", True):           # 3.61: comprobante interno, sin firma ni envío a Hacienda
        estado = "interno"
    elif e.p12_nombre and e.p12_pin:
        try:
            root = firma.firmar(root, secretos.descifrar_archivo(e.clave_cifrada, (CERT_DIR / e.p12_nombre).read_bytes()),
                                secretos.descifrar(e.clave_cifrada, e.p12_pin))
            estado = "firmado"
        except Exception as ex:
            raise HTTPException(400, f"Error al firmar el REP: {ex}")
    nombre_xml = f"{clave}.xml"
    (XML_DIR / nombre_xml).write_bytes(a_bytes(root))
    iva = sum((l.impuesto for l in recibo.lineas), Decimal(0))
    doc = Documento(empresa_id=e.id, tipo_documento="10", clave=clave, consecutivo=consecutivo, fecha_emision=recibo.fecha_emision,
                    cliente_id=cliente.id, receptor_nombre=cliente.nombre, moneda=factura.moneda, total=float(monto), impuesto=float(iva),
                    estado=estado, xml_nombre=nombre_xml, ambiente=e.ambiente, condicion_venta=cond_rep, fecha_vencimiento=data.fecha)
    s.add(doc); s.flush()
    return doc


class PagoEstadoIn(BaseModel):
    estado: Literal["Conciliado", "No conciliado"]


@app.put("/api/pagos/{pid}/estado")
def estado_pago(pid: int, data: PagoEstadoIn, ctx: Contexto = Depends(requiere("cobros")), s: Session = Depends(sesion_empresa)):
    p = s.get(modulos.Pago, pid)
    if not p or p.empresa_id != ctx.empresa.id or not _pagos_visibles(ctx, s, [p]):   # 3.87: el de otra sucursal, como si no existiera
        raise HTTPException(404, "Pago no encontrado")
    p.estado = data.estado; s.add(p); s.commit()
    return modulos.pago_dict(p)


def _ref_pago(p) -> str:
    """Referencia del movimiento bancario de un cobro. Lleva la hora de creación porque SQLite reutiliza el id de un pago borrado."""
    return f"pago:{p.id}:{int(p.creado.replace(tzinfo=p.creado.tzinfo or timezone.utc).timestamp())}" if p.creado else f"pago:{p.id}"


def revertir_cobros_rechazado(s: Session, eid: int, d: Documento, antes: Optional[str]) -> int:
    with _sinc.diario.aplicando(-1):                                   # 4.16: cada lado revierte su copia: esta baja no sube como si la hubiera hecho un usuario
        return _revertir_cobros_rechazado(s, eid, d, antes)


def _revertir_cobros_rechazado(s: Session, eid: int, d: Documento, antes: Optional[str]) -> int:
    """4.15: un comprobante que Hacienda RECHAZA no existió, así que junto con el inventario se revierte lo cobrado: sale el movimiento de Bancos y se
    quita el cobro; si el cobro cubría más facturas solo se le rebaja esta parte. Se emite de nuevo y se registra el cobro otra vez.
    Va después del commit del rechazo porque los movimientos de Bancos confirman su propia transacción. No aplica a la anulación por el usuario (la
    caja devuelve el dinero por su cuenta). Un cobro conciliado no se toca: alguien confirmó ese dinero en el banco, y el comprobante lo deja dicho.
    Nunca lanza: el rechazo ya quedó guardado. Devuelve cuántos cobros revirtió."""
    if d.estado != "rechazado" or antes == "rechazado" or d.tipo_documento not in ("01", "02", "04", "09") or str(d.mensaje_hacienda or "").startswith("Anulado"):
        return 0
    did, consecutivo, n, notas = d.id, d.consecutivo, 0, []
    try:
        pids = s.exec(select(modulos.Pago.id).where(modulos.Pago.empresa_id == eid, modulos.Pago.facturas.like(f"%{did}%"))).all()
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).exception("No se pudieron leer los cobros del comprobante %s", consecutivo)
        return 0
    for pid in pids:
        try:                                                            # un cobro que falle no corta los demás ni borra las notas de los ya revertidos
            p = s.get(modulos.Pago, pid)
            fs = json.loads(p.facturas or "[]")
            mias = [f for f in fs if modulos._id_entero(f.get("id")) == did]
            if not mias:
                continue
            numero, moneda = p.numero, p.moneda
            refs = {_ref_pago(p), f"pago:{p.id}"}
            movs = [m for m in (modulos.leer(s, eid, "movimientos", []) or []) if isinstance(m, dict) and m.get("ref") in refs]
            if p.estado == "Conciliado" or any(m.get("conciliado") for m in movs):
                notas.append(f"El cobro #{numero} ya está conciliado y no se tocó: revíselo")
                _auditar_u(None, eid, None, "cobro_conciliado_rechazado", f"Hacienda rechazó {consecutivo} y su cobro #{numero} está conciliado: no se tocó")
                continue
            parte, total = round(sum(float(f.get("monto") or 0) for f in mias), 2), round(float(p.monto or 0), 2)
            resto = [f for f in fs if modulos._id_entero(f.get("id")) != did]
            queda = round(total - parte, 2) if resto else 0.0
            if queda > 0:
                if movs:
                    modulos.registrar_movimiento_banco(s, eid, p.cuenta, queda, p.fecha, f"Recibo de caja #{numero}" + (f" · {p.cliente_nombre}" if p.cliente_nombre else "")
                                                       + f" · sin {consecutivo}, rechazado por Hacienda", movs[0]["ref"], reemplazar=True, moneda=p.moneda, tipo_cambio=p.tipo_cambio)
                p = s.get(modulos.Pago, pid)
                modulos.aplicar_pago(s, eid, mias, -1)
                p.monto = queda; p.facturas = json.dumps(resto); s.add(p); s.commit()
            else:
                if movs:
                    modulos.aplicar_cambios(s, eid, "movimientos", [], [m.get("id") for m in movs], [])
                p = s.get(modulos.Pago, pid)
                modulos.aplicar_pago(s, eid, mias, -1)
                s.delete(p); s.commit()
            n += 1
            notas.append(f"Se revirtió el cobro #{numero} ({moneda} {parte:,.2f}): regístrelo de nuevo al emitir el comprobante corregido")
            _auditar_u(None, eid, None, "cobro_revertido", f"Cobro #{numero} {moneda} {parte:,.2f} revertido: Hacienda rechazó {consecutivo}")
        except Exception as ex:  # noqa: BLE001
            s.rollback()
            logging.getLogger(__name__).exception("No se pudo revertir un cobro del comprobante %s", consecutivo)
            notas.append("Un cobro de este comprobante no se pudo revertir: revíselo en Cobros y en Bancos")
            _auditar_u(None, eid, None, "cobro_no_revertido", f"{consecutivo} fue rechazado y un cobro no se pudo revertir: {ex}"[:300])
    if notas:
        try:
            d = s.get(Documento, did)
            d.mensaje_hacienda = " · ".join(notas + [d.mensaje_hacienda or ""]).strip(" ·")     # la nota primero: el correo al dueño recorta el final
            s.add(d); s.commit()
        except Exception:  # noqa: BLE001
            s.rollback()
            logging.getLogger(__name__).exception("No se pudo anotar la reversión en el comprobante %s", consecutivo)
    return n


@app.delete("/api/pagos/{pid}")
def eliminar_pago(pid: int, ctx: Contexto = Depends(requiere("cobros")), s: Session = Depends(sesion_empresa)):
    p = s.get(modulos.Pago, pid)
    if not p or p.empresa_id != ctx.empresa.id or not _pagos_visibles(ctx, s, [p]):   # 3.87: el de otra sucursal, como si no existiera
        raise HTTPException(404, "Pago no encontrado")
    if _sinc.MODO_LOCAL and p.origen_sinc and not p.origen_sinc.startswith("0:"):    # 4.16: aquí solo está la copia: esa baja no llegaría a su dueña
        raise HTTPException(409, "Este cobro lo registró otra computadora: elimínelo allá o en la página web")
    for dd in json.loads(p.documentos or "[]"):
        doc = s.get(Documento, dd["id"])
        if doc and doc.estado in ("enviado", "aceptado"):
            raise HTTPException(409, f"El recibo electrónico de pago {doc.consecutivo} ya fue enviado a Hacienda y no se puede eliminar")
        # uno de pruebas que quedó atrás al pasar a producción ya no sale nunca; uno de producción sí (al volver a producción)
        if doc and doc.estado == "firmado" and doc.ambiente == "produccion" and ctx.empresa.ambiente != "produccion":
            raise HTTPException(409, f"El recibo electrónico de pago {doc.consecutivo} es de producción y está pendiente de envío. "
                                     "Vuelva la empresa al ambiente de producción para enviarlo o consultarlo antes de eliminar el cobro.")
        if doc and doc.estado == "firmado" and doc.ambiente == ctx.empresa.ambiente:
            # pendiente de envío: la cola lo mandaría a Hacienda aunque el cobro ya no exista (o ya llegó y no hubo respuesta)
            raise HTTPException(409, f"El recibo electrónico de pago {doc.consecutivo} está pendiente de envío a Hacienda. "
                                     "Espere la respuesta (o consúltelo en Comprobantes) antes de eliminar el cobro.")
    ref_pago = _ref_pago(p)
    # Primero el movimiento bancario: si no se puede quitar, el cobro se queda y se puede intentar de nuevo (antes se borraba
    # el cobro y, si esto fallaba, el movimiento quedaba en Bancos sin forma de quitarlo)
    try:
        modulos.quitar_movimientos_banco(s, ctx.empresa.id, [ref_pago, f"pago:{pid}"])      # también la ref de versiones anteriores
    except Exception as ex:  # noqa: BLE001
        s.rollback()
        import logging; logging.getLogger(__name__).warning("Quitar movimiento del pago %s: %s", pid, ex)
        raise HTTPException(503, "No se pudo quitar el movimiento en Bancos; el cobro no se eliminó. Intente de nuevo.")
    p = s.get(modulos.Pago, pid)
    if not p or p.empresa_id != ctx.empresa.id:                     # otra pestaña lo eliminó mientras tanto
        raise HTTPException(404, "Pago no encontrado")
    modulos.aplicar_pago(s, ctx.empresa.id, json.loads(p.facturas or "[]"), -1)
    s.delete(p); s.commit()
    _auditar(ctx, "pago_eliminado", f"Pago #{p.numero} {p.moneda} {p.monto:,.2f}")
    return {"ok": True}


# ---- facturas recurrentes
class RecurrenteIn(BaseModel):
    nombre: str = ""
    cliente_id: Optional[int] = None
    tipo_documento: Literal["01", "04"] = "01"
    condicion_venta: str = "01"
    condicion_venta_otros: Optional[str] = None
    plazo_credito: Optional[int] = None
    medio_pago: str = "01"
    medio_pago_otros: Optional[str] = None
    moneda: str = "CRC"
    periodicidad: Literal["diaria", "semanal", "quincenal", "mensual", "bimensual", "trimestral", "semestral", "anual"] = "mensual"
    dia_emision: int = Field(1, ge=1, le=31)
    mes_emision: Optional[int] = Field(None, ge=1, le=12)        # 3.30
    dia_semana: Optional[int] = Field(None, ge=0, le=6)
    dia_emision2: Optional[int] = Field(None, ge=1, le=31)
    actividad_emisor: Optional[str] = None
    dias_vencimiento: Optional[int] = Field(None, ge=0, le=365)   # 3.31
    inicio: str
    fin: Optional[str] = None
    lineas: list[dict] = []
    observaciones: Optional[str] = None
    terminos: Optional[str] = None
    vendedor: Optional[str] = None
    activa: bool = True
    exoneracion_id: Optional[int] = Field(None, ge=0)   # 0 = no aplicar; vacío = la vigente del cliente al emitir


def _recurrente(s: Session, eid: int, rid: int) -> modulos.Recurrente:
    r = s.get(modulos.Recurrente, rid)
    if not r or r.empresa_id != eid:
        raise HTTPException(404, "Factura recurrente no encontrada")
    return r


def _validar_recurrente(s: Session, e: Empresa, data: RecurrenteIn):
    if data.tipo_documento != "04" and not data.cliente_id:
        raise HTTPException(400, "Seleccione el cliente")
    if data.cliente_id and not _cliente(s, e.id, data.cliente_id):
        raise HTTPException(400, "Cliente no encontrado")
    if not data.lineas or not any(l.get("detalle") or l.get("producto_id") for l in data.lineas):
        raise HTTPException(400, "Agregue al menos una línea")
    try:
        date.fromisoformat(data.inicio)
        if data.fin:
            date.fromisoformat(data.fin)
    except ValueError:
        raise HTTPException(400, "Fecha de inicio o fin inválida")
    if data.fin and data.fin < data.inicio:
        raise HTTPException(400, "La fecha de fin debe ser posterior a la de inicio")
    if data.condicion_venta in ("02", "08", "10") and data.plazo_credito:
        data.dias_vencimiento = data.plazo_credito          # a crédito, el vencimiento es el plazo de crédito (3.31)
    if data.periodicidad == "quincenal" and data.dia_emision2 and data.dia_emision2 == data.dia_emision:
        raise HTTPException(400, "En la quincenal, los dos días de emisión deben ser distintos")
    if data.actividad_emisor:
        data.actividad_emisor = data.actividad_emisor.strip()
        if data.actividad_emisor == (e.actividad or "").strip():
            data.actividad_emisor = None
        elif not re.fullmatch(ACTIVIDAD_RE, data.actividad_emisor):
            raise HTTPException(400, "La actividad económica debe ser el código de Hacienda (p. ej. 6201.0)")
    if data.exoneracion_id:                  # la exoneración elegida debe ser de este cliente (su vigencia se revisa al emitir)
        x = s.get(exoneraciones.ExoneracionCliente, data.exoneracion_id)
        if not x or x.empresa_id != e.id or x.cliente_id != data.cliente_id:
            raise HTTPException(400, "La exoneración elegida no pertenece al cliente de la factura recurrente")
        if x.tipo in exoneraciones.SOLO_NOTAS:
            raise HTTPException(400, f"Una exoneración tipo {x.tipo} solo se usa en notas de crédito o débito")


@app.get("/api/recurrentes", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def get_recurrentes(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _exigir_recurrentes(ctx)
    modulos.procesar_recurrentes(s, ctx.empresa.id, ahora_cr().date())
    filas = s.exec(select(modulos.Recurrente).where(modulos.Recurrente.empresa_id == ctx.empresa.id)).all()
    return [modulos.recurrente_dict(r) for r in sorted(filas, key=lambda r: r.id, reverse=True)]


@app.post("/api/recurrentes")
def crear_recurrente(data: RecurrenteIn, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa
    _validar_recurrente(s, e, data)
    cliente = _cliente(s, e.id, data.cliente_id) if data.cliente_id else None
    r = modulos.Recurrente(empresa_id=e.id, cliente_nombre=cliente.nombre if cliente else None, lineas=json.dumps(data.lineas),
                           **data.model_dump(exclude={"lineas"}))
    r.proxima = modulos.primera_de(r).isoformat()
    s.add(r); s.commit(); s.refresh(r)
    modulos.procesar_recurrentes(s, e.id, ahora_cr().date())
    _auditar(ctx, "recurrente_creada", f"Factura recurrente #{r.id} {r.periodicidad} para {r.cliente_nombre or 'sin receptor'}")
    return modulos.recurrente_dict(r)


@app.put("/api/recurrentes/{rid}")
def editar_recurrente(rid: int, data: RecurrenteIn, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa
    r = _recurrente(s, e.id, rid)
    _validar_recurrente(s, e, data)
    cliente = _cliente(s, e.id, data.cliente_id) if data.cliente_id else None
    cambia_calendario = (r.inicio, r.periodicidad, r.dia_emision, r.mes_emision, r.dia_semana, r.dia_emision2) != \
        (data.inicio, data.periodicidad, data.dia_emision, data.mes_emision, data.dia_semana, data.dia_emision2)
    reactivada = data.activa and not r.activa
    for k, v in data.model_dump(exclude={"lineas"}).items():
        setattr(r, k, v)
    r.lineas = json.dumps(data.lineas); r.cliente_nombre = cliente.nombre if cliente else None
    if cambia_calendario or not r.proxima or reactivada:
        # nunca hacia atrás: al cambiar el calendario o reactivar, la próxima es la primera fecha programada igual o posterior a hoy
        # (antes se regeneraban todos los períodos desde el inicio o los meses en pausa) (R189, R190)
        r.proxima = modulos.primera_de(r, desde=ahora_cr().date()).isoformat()
    s.add(r); s.commit(); s.refresh(r)
    modulos.procesar_recurrentes(s, e.id, ahora_cr().date())
    _auditar(ctx, "recurrente_editada", f"Factura recurrente #{r.id}")
    return modulos.recurrente_dict(r)


@app.delete("/api/recurrentes/{rid}")
def eliminar_recurrente(rid: int, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    r = _recurrente(s, ctx.empresa.id, rid)
    for p in s.exec(select(modulos.FacturaPendiente).where(modulos.FacturaPendiente.recurrente_id == rid,
                                                          modulos.FacturaPendiente.estado == "pendiente")).all():
        s.delete(p)
    s.delete(r); s.commit()
    _auditar(ctx, "recurrente_eliminada", f"Factura recurrente #{rid}")
    return {"ok": True}


def _pendiente_dict(s: Session, p: modulos.FacturaPendiente) -> dict:
    r = s.get(modulos.Recurrente, p.recurrente_id)
    d = p.model_dump()
    d["recurrente"] = modulos.recurrente_dict(r) if r else None
    return d


class CalendarioIn(BaseModel):
    periodicidad: Literal["diaria", "semanal", "quincenal", "mensual", "bimensual", "trimestral", "semestral", "anual"] = "mensual"
    dia_emision: int = Field(1, ge=1, le=31)
    mes_emision: Optional[int] = Field(None, ge=1, le=12)
    dia_semana: Optional[int] = Field(None, ge=0, le=6)
    dia_emision2: Optional[int] = Field(None, ge=1, le=31)
    inicio: str
    fin: Optional[str] = None
    editando: bool = False


@app.post("/api/recurrentes/calendario")
def calendario_recurrente(data: CalendarioIn, ctx: Contexto = Depends(contexto)):
    """Vista previa: las próximas fechas en que se generará la factura con esta configuración (3.30)."""
    try:
        date.fromisoformat(data.inicio)
        if data.fin:
            date.fromisoformat(data.fin)
    except ValueError:
        raise HTTPException(400, "Fecha inválida")
    r = modulos.Recurrente(empresa_id=ctx.empresa.id, **data.model_dump(exclude={"editando"}))
    hoy_cr = ahora_cr().date()
    if data.editando:                        # al guardar un cambio de calendario nunca se va hacia atrás
        r.inicio = max(date.fromisoformat(r.inicio), hoy_cr).isoformat()
    fechas = modulos.proximas_fechas(r, 4)
    return {"fechas": [f.isoformat() for f in fechas], "atrasadas": sum(1 for f in fechas if f < hoy_cr)}


@app.get("/api/recurrentes/pendientes", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def get_pendientes(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Facturas generadas por las recurrencias que esperan aprobación (se generan aquí mismo si su fecha ya llegó)."""
    _exigir_recurrentes(ctx)                    # 3.87: antes el Cajero recibía cliente, líneas y precios (y con el id la sacaba de la cola)
    modulos.procesar_recurrentes(s, ctx.empresa.id, ahora_cr().date())
    filas = s.exec(select(modulos.FacturaPendiente).where(modulos.FacturaPendiente.empresa_id == ctx.empresa.id,
                                                         modulos.FacturaPendiente.estado == "pendiente")).all()
    return [_pendiente_dict(s, p) for p in sorted(filas, key=lambda p: p.fecha_programada)]


def _pendiente(s: Session, eid: int, pid: int) -> modulos.FacturaPendiente:
    p = s.get(modulos.FacturaPendiente, pid)
    if not p or p.empresa_id != eid:
        raise HTTPException(404, "Factura pendiente no encontrada")
    return p


@app.get("/api/recurrentes/pendientes/{pid}", dependencies=[Depends(auth.con_documentos)])   # 3.87: no para los roles operativos
def get_pendiente(pid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    _exigir_recurrentes(ctx)
    return _pendiente_dict(s, _pendiente(s, ctx.empresa.id, pid))


class PendienteFechaIn(BaseModel):
    fecha_programada: str


@app.put("/api/recurrentes/pendientes/{pid}")
def posponer_pendiente(pid: int, data: PendienteFechaIn, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    p = _pendiente(s, ctx.empresa.id, pid)
    try:
        date.fromisoformat(data.fecha_programada)
    except ValueError:
        raise HTTPException(400, "Fecha inválida")
    if not p.periodo:
        p.periodo = p.fecha_programada              # el período original se conserva: posponer no deja el período sin facturar (R191)
    p.fecha_programada = data.fecha_programada; s.add(p); s.commit()
    return _pendiente_dict(s, p)


@app.delete("/api/recurrentes/pendientes/{pid}")
def omitir_pendiente(pid: int, ctx: Contexto = Depends(requiere("facturar")), s: Session = Depends(sesion_empresa)):
    p = _pendiente(s, ctx.empresa.id, pid)
    p.estado = "omitida"; s.add(p); s.commit()
    return {"ok": True}


def procesar_recurrentes_todas() -> int:
    """Genera las facturas pendientes de todas las empresas (lo llama la cola / el cron una vez al día)."""
    from .db import engine_empresa
    total = 0
    with Session(engine) as sc:
        ids = [e.id for e in sc.exec(select(Empresa).where(Empresa.bloqueada == False)).all()]  # noqa: E712
    for eid in ids:
        try:
            with Session(engine_empresa(eid)) as s:
                total += modulos.procesar_recurrentes(s, eid, ahora_cr().date())
        except Exception:  # noqa: BLE001
            import logging; logging.getLogger(__name__).exception("Recurrentes: fallo en la empresa %s", eid)
    return total


# ---- recepción de comprobantes (los que emiten los proveedores a la empresa) — app/recepcion.py
class RespuestaRecepcionIn(BaseModel):
    mensaje: Literal["05", "06", "07"]
    condicion_impuesto: Optional[Literal["01", "02", "03", "04", "05"]] = None
    detalle: Optional[str] = None
    monto_impuesto_acreditar: Optional[float] = None
    monto_gasto_aplicable: Optional[float] = None
    clasificacion: Optional[Literal["compra", "gasto"]] = None       # 4.3: compra (costo de lo que se vende) o gasto
    cuenta_contable: Optional[str] = Field(None, max_length=160)


class ClasificacionRecepcionIn(BaseModel):
    clasificacion: Literal["compra", "gasto"]
    cuenta_contable: Optional[str] = Field(None, max_length=160)


@app.put("/api/recepcion/{rid}/clasificacion")
def clasificar_recepcion(rid: int, data: ClasificacionRecepcionIn, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    """4.3: cambia la clasificación (compra o gasto) y la cuenta contable de un comprobante recibido; el asiento automático se rehace solo."""
    r = _recibido(s, ctx.empresa.id, rid)
    if data.clasificacion != (r.clasificacion or "gasto") and (data.cuenta_contable or "").strip() == (r.cuenta_contable or ""):
        data.cuenta_contable = None                      # la cuenta era de la clasificación anterior
    r.clasificacion = data.clasificacion
    r.cuenta_contable = (data.cuenta_contable or "").strip() or None
    s.add(r); s.commit(); s.refresh(r)
    _auditar(ctx, "recepcion_clasificacion", f"{r.consecutivo}: {data.clasificacion}" + (f" · {r.cuenta_contable}" if r.cuenta_contable else ""))
    return recepcion.recibido_dict(r)


class BuzonIn(BaseModel):
    imap_host: Optional[str] = None
    imap_puerto: int = Field(993, ge=1, le=65535)
    imap_seguridad: Literal["ssl", "starttls", "ninguna"] = "ssl"
    imap_usuario: Optional[str] = None
    imap_password: Optional[str] = None
    imap_carpeta: str = "INBOX"
    imap_dias: int = Field(60, ge=1, le=365)


def _recibido(s: Session, eid: int, rid: int) -> recepcion.Recibido:
    r = s.get(recepcion.Recibido, rid)
    if not r or r.empresa_id != eid:
        raise HTTPException(404, "Comprobante recibido no encontrado")
    return r


@app.get("/api/recepcion")
def get_recepcion(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not (ctx.puede("gastos") or ctx.puede("ver_todo")):             # (R130)
        raise HTTPException(403, "Su rol no tiene acceso a los comprobantes recibidos")
    filas = s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == ctx.empresa.id)).all()
    return [recepcion.recibido_dict(r) for r in sorted(filas, key=lambda r: (r.respuesta is not None, r.fecha_limite, -r.id))]


@app.get("/api/recepcion/resumen")
def resumen_recepcion(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Para avisos: cuántos comprobantes recibidos faltan por responder y cuántos vencen pronto o ya vencieron."""
    hoy = ahora_cr().date().isoformat()
    pend = [r for r in s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == ctx.empresa.id)).all()
            if r.respuesta is None or (r.estado_mensaje in ("firmado", "error"))]   # respondidos que Hacienda aún no recibió también cuentan
    prox = (ahora_cr().date() + timedelta(days=3)).isoformat()
    return {"pendientes": len(pend), "vencidas": sum(1 for r in pend if r.fecha_limite and r.fecha_limite < hoy),
            "proximas": sum(1 for r in pend if r.fecha_limite and hoy <= r.fecha_limite <= prox)}


@app.post("/api/comprobantes/importar")
def importar_comprobantes(archivos: list[UploadFile] = File(...), listado: Optional[UploadFile] = File(None), credito: str = Form("pendientes"),
                          origen: str = Form("Sistema anterior"), ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    """Comprobantes de venta ya emitidos en otro sistema (3.27): XML firmados sueltos o en ZIP (con sus respuestas de Hacienda si
    las tiene) y, opcional, el listado de facturas del sistema anterior para saber cuánto falta cobrar de cada una."""
    from . import importacion
    if len(archivos) > 200:
        raise HTTPException(400, "Máximo 200 archivos por carga; use un ZIP para enviar más")
    try:
        crudos = [(a.filename or "archivo", _leer_subida(a, 120 * 1024 * 1024)) for a in archivos]
        xmls, avisos = importacion.expandir(crudos)
        lst = importacion.leer_listado(listado.filename or "listado.csv", _leer_subida(listado, 20 * 1024 * 1024)) if listado is not None and listado.filename else None
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if not xmls:
        raise HTTPException(400, "No llegó ningún XML: suba los XML firmados (o un ZIP con ellos)")
    origen = (origen or "Sistema anterior").strip()[:40] or "Sistema anterior"
    res = importacion.importar(s, ctx.empresa, XML_DIR, xmls, lst, "cobradas" if credito == "cobradas" else "pendientes", origen)
    res["descartados"] = avisos + res["descartados"]
    res["listado"] = len(lst) if lst is not None else None
    res["ambiente_empresa"] = ctx.empresa.ambiente
    if res["importados"]:
        modulos.recalcular_acreditado(s, ctx.empresa.id); s.commit()
    _auditar(ctx, "comprobantes_importados", f"{res['importados']} de {origen} ({res['desde']} a {res['hasta']}); {res['duplicados']} duplicados")
    return res


@app.post("/api/recepcion/cargar")
def cargar_recepcion(archivos: list[UploadFile] = File(...), historico: str = Form("0"), pagados: str = Form("0"), clasificacion: str = Form(""),
                     ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    """Carga manual de XML (o ZIP con XML) de comprobantes recibidos. 4.1: con `historico`, son del sistema anterior (Alegra u otro):
    quedan aceptados sin enviar nada a Hacienda (o como diga el Mensaje Receptor que se suba junto) y, con `pagados`, ya pagados."""
    hist, pag = historico in ("1", "true", "on"), pagados in ("1", "true", "on")
    res = {"nuevos": 0, "duplicados": 0, "descartados": [], "historicos": 0}
    if len(archivos) > 50:                                   # antes se descartaban en silencio los que pasaban de 50 (R304)
        raise HTTPException(400, f"Se recibieron {len(archivos)} archivos; el máximo por carga es 50. Súbalos en varias tandas")
    xmls = []
    for a in archivos:
        datos = _leer_subida(a, 2 * 1024 * 1024)
        nombre = (a.filename or "archivo").lower()
        if nombre.endswith(".zip"):
            import io as _io, zipfile
            try:
                with zipfile.ZipFile(_io.BytesIO(datos)) as z:
                    infos = z.infolist()
                    if len(infos) > 500 or sum(i.file_size for i in infos) > 60 * 1024 * 1024:      # (R127)
                        res["descartados"].append(f"{nombre}: el ZIP tiene demasiados archivos o pesa más de 60 MB al descomprimir"); continue
                    for n in z.namelist():
                        if n.lower().endswith(".xml") and z.getinfo(n).file_size <= 3 * 1024 * 1024:
                            xmls.append((n, z.read(n)))
            except zipfile.BadZipFile:
                res["descartados"].append(f"{nombre}: ZIP inválido")
            continue
        xmls.append((nombre, datos))
    mensajes = {}
    if hist:                                               # 4.1: los Mensajes Receptor del sistema anterior dicen cómo se respondió cada uno
        resto = []
        for n, x in xmls:
            m = recepcion.leer_mensaje_receptor(x)
            if m:
                mensajes[m["clave"]] = m
            else:
                resto.append((n, x))
        xmls = resto
    for n, x in xmls:
        r, m = recepcion.registrar(s, ctx.empresa, x)
        if m == "nuevo":
            res["nuevos"] += 1
        elif m == "duplicado":
            res["duplicados"] += 1
        else:
            res["descartados"].append(f"{n}: {m}")
            continue
        if hist and r is not None and recepcion.marcar_historico(r, mensajes.get(r.clave), pag, clasificacion if clasificacion in ("compra", "gasto") else None):
            s.add(r); s.commit()
            res["historicos"] += 1
    _auditar(ctx, "recepcion_carga", f"{res['nuevos']} comprobantes recibidos cargados, {res['duplicados']} duplicados"
             + (f", {res['historicos']} del sistema anterior{' (ya pagados)' if pag else ''}" if hist else ""))
    return res


@app.get("/api/recepcion/{rid}/xml")
def xml_recepcion(rid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not (ctx.puede("gastos") or ctx.puede("ver_todo")):             # 3.87: lo mismo que la lista (antes cualquier rol lo abría por número)
        raise HTTPException(403, "Su rol no tiene acceso a los comprobantes recibidos")
    r = _recibido(s, ctx.empresa.id, rid)
    return Response((recepcion.DIR_RECIBIDOS / r.xml_nombre).read_bytes(), media_type="application/xml",
                    headers={"Content-Disposition": f'inline; filename="{r.clave}.xml"'})


@app.get("/api/recepcion/{rid}/mensaje")
def mensaje_recepcion(rid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    if not (ctx.puede("gastos") or ctx.puede("ver_todo")):             # 3.87: lo mismo que la lista (antes cualquier rol lo abría por número)
        raise HTTPException(403, "Su rol no tiene acceso a los comprobantes recibidos")
    r = _recibido(s, ctx.empresa.id, rid)
    if not r.mensaje_xml_nombre:
        raise HTTPException(404, "Este comprobante aún no tiene mensaje de receptor")
    return Response((recepcion.DIR_RECIBIDOS / r.mensaje_xml_nombre).read_bytes(), media_type="application/xml",
                    headers={"Content-Disposition": f'inline; filename="{r.mensaje_xml_nombre}"'})


@app.get("/api/recepcion/{rid}/pdf")
def pdf_recepcion(rid: int, ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Representación del comprobante recibido (sin logo: es del proveedor)."""
    if not (ctx.puede("gastos") or ctx.puede("ver_todo")):             # 3.87: lo mismo que la lista (antes cualquier rol lo abría por número)
        raise HTTPException(403, "Su rol no tiene acceso a los comprobantes recibidos")
    r = _recibido(s, ctx.empresa.id, rid)
    xml = (recepcion.DIR_RECIBIDOS / r.xml_nombre).read_bytes()
    cfg = plantillas.obtener(pdf.datos_desde_xml(xml)["tipo"], ctx.empresa.id)
    cfg = {**cfg, "logo": False}
    return Response(pdf.generar_pdf(xml, None, {"recibido": True}, cfg=cfg, logo_path=None), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="{r.consecutivo or r.clave}.pdf"'})


@app.post("/api/recepcion/validar-anteriores")
def validar_recibidos_anteriores(ids: Optional[list[int]] = None, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    """4.2: valida en Hacienda los comprobantes cargados del sistema anterior (estado «importado»): que el comprobante del proveedor
    esté aceptado y, si se subió su mensaje de receptor, que la respuesta también lo esté. `ids` limita el lote; sin ids, los que
    aún no se han validado (hasta 50 por llamada)."""
    e = ctx.empresa
    q = select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == e.id, recepcion.Recibido.estado_mensaje == "importado")
    if ids:
        q = q.where(recepcion.Recibido.id.in_(ids[:50]))
    else:
        q = q.where(recepcion.Recibido.validacion.is_(None))   # noqa: E711
    lote = s.exec(q.order_by(recepcion.Recibido.id)).all()[:50]
    if not lote:
        return {"validados": 0, "ok": 0, "con_problema": 0, "pendientes": 0, "detalle": []}
    try:
        cli = _cliente_hacienda(e)
    except HTTPException:
        raise HTTPException(400, "Para validar en Hacienda configure el usuario y la contraseña de la API en Configuración › Facturación electrónica")
    res = {"validados": 0, "ok": 0, "con_problema": 0, "detalle": []}
    for r in lote:
        try:
            v = recepcion.validar_en_hacienda(cli, r)
        except hacienda.CredencialesInvalidas as ex:
            raise HTTPException(400, str(ex))
        except (httpx.HTTPError, RuntimeError) as ex:
            res["detalle"].append({"id": r.id, "consecutivo": r.consecutivo, "texto": f"Hacienda no respondió ({type(ex).__name__}); vuelva a intentar"})
            continue
        s.add(r)
        res["validados"] += 1
        res["ok" if v.get("ok") else "con_problema"] += 1
        res["detalle"].append({"id": r.id, "consecutivo": r.consecutivo, "emisor": r.emisor_nombre, "ok": v.get("ok"), "texto": v.get("texto")})
    s.commit()
    res["pendientes"] = len(s.exec(select(recepcion.Recibido.id).where(recepcion.Recibido.empresa_id == e.id, recepcion.Recibido.estado_mensaje == "importado",
                                                                     recepcion.Recibido.validacion.is_(None))).all())   # noqa: E711
    _auditar(ctx, "recepcion_validacion", f"{res['validados']} comprobantes del sistema anterior validados en Hacienda ({res['con_problema']} con problema)")
    return res


@app.post("/api/recepcion/{rid}/responder")
def responder_recepcion(rid: int, data: RespuestaRecepcionIn, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    """Genera, firma y envía el Mensaje Receptor (05 aceptado, 06 parcial, 07 rechazado)."""
    e = ctx.empresa
    r = _recibido(s, e.id, rid)
    if r.respuesta and r.estado_mensaje in ("enviado", "aceptado") and (r.ambiente or e.ambiente) == e.ambiente:
        raise HTTPException(409, f"Este comprobante ya fue respondido ({recepcion.MENSAJES[r.respuesta][1]}, {r.estado_mensaje})")
    r.ambiente = e.ambiente
    if not (e.p12_nombre and e.p12_pin):
        raise HTTPException(400, "Cargue la llave criptográfica (.p12) antes de responder comprobantes")
    if data.mensaje == "07" and not (data.detalle or "").strip():
        raise HTTPException(400, "Indique el motivo del rechazo en Detalle")
    cond = data.condicion_impuesto if data.mensaje in ("05", "06") else None
    if data.mensaje in ("05", "06") and r.impuesto and not cond:
        raise HTTPException(400, "Indique la condición del IVA (crédito total, parcial, bienes de capital, gasto corriente o proporcionalidad)")
    acreditar = gasto = None
    if cond:
        imp, tot = Decimal(str(recepcion.iva_recibido(r))), Decimal(str(r.total))      # 3.41: solo el IVA se acredita
        acreditar = {"01": imp, "03": imp, "04": Decimal(0)}.get(cond, Decimal(str(data.monto_impuesto_acreditar)) if data.monto_impuesto_acreditar is not None else imp)
        gasto = Decimal(str(data.monto_gasto_aplicable)) if data.monto_gasto_aplicable is not None else tot
        if acreditar < 0 or acreditar > imp + Decimal("0.00001"):
            raise HTTPException(400, f"El IVA a acreditar no puede superar el IVA del comprobante ({float(imp):,.2f})")
    numero = _siguiente_numero(s, e.id, data.mensaje, e.ambiente)
    consecutivo = generar_consecutivo(data.mensaje, numero, e.sucursal, e.terminal)
    root = recepcion.construir_mensaje_receptor(r, e, data.mensaje, consecutivo, cond, (data.detalle or "").strip() or None,
                                                acreditar, gasto, e.actividad)
    errores = validar(root, data.mensaje)
    if errores:
        raise HTTPException(400, {"mensaje": "El mensaje de receptor no cumple el esquema v4.4", "errores": errores})
    try:
        root = firma.firmar(root, secretos.descifrar_archivo(e.clave_cifrada, (CERT_DIR / e.p12_nombre).read_bytes()),
                            secretos.descifrar(e.clave_cifrada, e.p12_pin))
    except Exception as ex:
        raise HTTPException(400, f"Error al firmar el mensaje de receptor: {ex}")
    nombre = f"mensaje_{e.id}_{r.clave}_{consecutivo}.xml"
    (recepcion.DIR_RECIBIDOS / nombre).write_bytes(a_bytes(root))
    r.respuesta = data.mensaje; r.condicion_impuesto = cond; r.detalle_mensaje = (data.detalle or "").strip() or None
    if data.clasificacion:                                   # 4.3
        r.clasificacion = data.clasificacion; r.cuenta_contable = (data.cuenta_contable or "").strip() or None
    elif data.mensaje in ("05", "06") and r.tipo_documento in ("02", "03") and r.referencia_clave:   # la nota hereda de la factura referida
        ref = s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == e.id, recepcion.Recibido.clave == r.referencia_clave)).first()
        if ref is not None and ref.clasificacion:
            r.clasificacion, r.cuenta_contable = ref.clasificacion, ref.cuenta_contable
    r.monto_impuesto_acreditar = float(acreditar) if acreditar is not None else None
    r.monto_gasto_aplicable = float(gasto) if gasto is not None else None
    r.consecutivo_receptor = consecutivo; r.mensaje_xml_nombre = nombre; r.estado_mensaje = "firmado"; r.mensaje_hacienda = None
    r.respondido_en = ahora_cr().isoformat(timespec="seconds")
    s.add(r); s.commit(); s.refresh(r)
    _auditar(ctx, "recepcion_respuesta", f"{recepcion.MENSAJES[data.mensaje][1]} {r.emisor_nombre} {r.consecutivo} (mensaje {consecutivo})")
    _enviar_mensaje_receptor(s, e, r)
    return recepcion.recibido_dict(r)


def _enviar_mensaje_receptor(s: Session, e: Empresa, r: recepcion.Recibido) -> None:
    """POST /recepcion con el Mensaje Receptor firmado (clave del comprobante + consecutivoReceptor)."""
    try:
        fecha_msg = etree.fromstring((recepcion.DIR_RECIBIDOS / r.mensaje_xml_nombre).read_bytes()).findtext("{*}FechaEmisionDoc")
        cli = _cliente_hacienda(e)
        res = cli.enviar(r.clave, fecha_msg, {"tipo": r.emisor_tipo_id, "numero": r.emisor_id},
                         {"tipo": e.tipo_id, "numero": re.sub(r"[^A-Za-z0-9]", "", e.numero_id or "").upper()},
                         (recepcion.DIR_RECIBIDOS / r.mensaje_xml_nombre).read_bytes(), consecutivo_receptor=r.consecutivo_receptor)
        if res.get("ok"):
            r.estado_mensaje = "enviado"; r.mensaje_hacienda = "Recibido por Hacienda" + (" (ya estaba recibido)" if res.get("duplicado") else "")
        else:
            r.estado_mensaje = "error"; r.mensaje_hacienda = str(res.get("error") or res)[:500]
    except hacienda.CredencialesInvalidas as ex:
        r.estado_mensaje = "firmado"; r.mensaje_hacienda = f"Pendiente de envío: {ex}"
    except Exception as ex:  # noqa: BLE001  Hacienda caída o sin red: queda firmado y se reintenta
        r.estado_mensaje = "firmado"; r.mensaje_hacienda = f"Pendiente de envío: {type(ex).__name__}: {str(ex)[:200]}"
    s.add(r); s.commit(); s.refresh(r)


@app.post("/api/recepcion/{rid}/enviar")
def enviar_recepcion(rid: int, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    r = _recibido(s, ctx.empresa.id, rid)
    if not r.mensaje_xml_nombre or r.estado_mensaje not in ("firmado", "error"):
        raise HTTPException(409, "El mensaje de receptor no está pendiente de envío")
    _enviar_mensaje_receptor(s, ctx.empresa, r)
    return recepcion.recibido_dict(r)


@app.post("/api/recepcion/{rid}/consultar")
def consultar_recepcion(rid: int, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    r = _recibido(s, ctx.empresa.id, rid)
    if not r.consecutivo_receptor:
        raise HTTPException(409, "Este comprobante aún no tiene mensaje de receptor")
    try:
        _consultar_mensaje_receptor(ctx.empresa, r)
    except hacienda.CredencialesInvalidas as ex:
        raise HTTPException(400, str(ex))
    except RuntimeError as ex:
        raise HTTPException(502, str(ex))
    except httpx.HTTPError as ex:
        raise HTTPException(504, f"Hacienda no respondió la consulta ({type(ex).__name__}); se reintentará automáticamente")
    s.add(r); s.commit(); s.refresh(r)
    return recepcion.recibido_dict(r)


def _consultar_mensaje_receptor(e: Empresa, r: "recepcion.Recibido") -> None:
    """Consulta a Hacienda el estado del mensaje receptor y lo anota en `r` (lo usan el botón y la cola)."""
    cli = _cliente_hacienda(e)
    res = cli.consultar(f"{r.clave}-{r.consecutivo_receptor}")
    estado = res.get("estado")
    if estado == "no_encontrado":          # (antes se consultaba la clave del comprobante del PROVEEDOR y su 'aceptado' se copiaba al mensaje)
        r.mensaje_hacienda = "Hacienda aún no registra este mensaje de receptor; se vuelve a consultar en la siguiente pasada"
        return
    if estado in ("aceptado", "rechazado"):
        r.estado_mensaje = estado; r.mensaje_hacienda = (res.get("detalle") or res.get("mensaje") or estado)[:1000]
    elif estado == "error":
        r.estado_mensaje = "error"; r.mensaje_hacienda = str(res.get("error") or res.get("detalle") or res)[:500]
    elif estado in ("recibido", "procesando"):
        r.mensaje_hacienda = "Hacienda lo está procesando; consulte de nuevo en unos minutos"
    else:
        r.mensaje_hacienda = str(res.get("error") or res)[:500]


def _tipo_doc_referencia(tipo_documento: str, tipo_nota: str) -> str:
    """Código TipoDocIR del catálogo de referencias v4.4 a partir del tipo del comprobante referido: la factura de
    exportación es 19 y el recibo de pago 20 (09 y 10 significan otra cosa en ese catálogo); una nota sobre una factura de
    compra va como 17 (crédito) o 18 (débito) (R243)."""
    if tipo_documento == "09":
        return "19"
    if tipo_documento == "10":
        return "20"
    if tipo_documento == "08":
        return "17" if tipo_nota == "03" else "18"
    return tipo_documento


class CompraVinculoIn(BaseModel):
    compra_id: Optional[int] = None


@app.put("/api/recepcion/{rid}/compra")
def vincular_compra_recepcion(rid: int, data: CompraVinculoIn, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    """Guarda qué compra (registro 'compras') se creó a partir de este comprobante recibido: el botón no se repite (R140)."""
    r = _recibido(s, ctx.empresa.id, rid)
    r.compra_id = data.compra_id; s.add(r); s.commit()
    return {"ok": True, "compra_id": r.compra_id}


@app.delete("/api/recepcion/{rid}")
def eliminar_recepcion(rid: int, ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    r = _recibido(s, ctx.empresa.id, rid)
    if r.respuesta:
        raise HTTPException(409, "No se puede eliminar un comprobante ya respondido ante Hacienda")
    s.delete(r); s.commit()
    return {"ok": True}


@app.get("/api/recepcion/buzon")
def get_buzon(ctx: Contexto = Depends(contexto)):
    if not (ctx.puede("gastos") or ctx.puede("configurar")):            # (R130)
        raise HTTPException(403, "Su rol no tiene acceso al buzón")
    e = ctx.empresa
    oculto = lambda v: ("***" if v else None) if not ctx.puede("configurar") else v   # noqa: E731  host y usuario solo para configurar (R286)
    return {"imap_host": oculto(e.imap_host), "imap_puerto": e.imap_puerto, "imap_seguridad": e.imap_seguridad, "imap_usuario": oculto(e.imap_usuario),
            "imap_password": "***" if e.imap_password else None, "imap_carpeta": e.imap_carpeta, "imap_dias": e.imap_dias, "imap_ultima": e.imap_ultima, "imap_error": e.imap_error, "imap_intento": e.imap_intento}


# ----------------------------------------------------------------------------- Recursos humanos: correo y comprobantes de pago
class CorreoRRHHIn(BaseModel):
    smtp_host: Optional[str] = None; smtp_puerto: Optional[int] = 465; smtp_seguridad: Literal["ssl", "starttls", "ninguna"] = "ssl"
    smtp_usuario: Optional[str] = None; smtp_password: Optional[str] = None; smtp_remitente: Optional[str] = None
    smtp_nombre: Optional[str] = None; smtp_copia: Optional[str] = None; correo_auto: bool = True


def _cfg_smtp_rrhh(e: Empresa) -> correo.ConfigSMTP:
    """SMTP de Recursos humanos; sin él, el general de la empresa con Reply-To al remitente de RRHH si lo hay."""
    if e.rrhh_smtp_host and e.rrhh_smtp_remitente:
        try:
            clave = secretos.descifrar(e.clave_cifrada, e.rrhh_smtp_password)
        except ValueError as ex:
            raise HTTPException(400, f"No se pudo leer la contraseña del correo de Recursos humanos; vuelva a guardarla. {ex}")
        return correo.ConfigSMTP(e.rrhh_smtp_host, e.rrhh_smtp_puerto or (465 if (e.rrhh_smtp_seguridad or "ssl") == "ssl" else 587), e.rrhh_smtp_usuario,
                                 clave, e.rrhh_smtp_remitente, seguridad=e.rrhh_smtp_seguridad or "ssl", nombre=e.rrhh_smtp_nombre or None,
                                 copia=(e.rrhh_smtp_copia or "").strip() or None)
    if not (e.smtp_host and e.smtp_remitente):
        raise HTTPException(400, "Configure el correo de Recursos humanos (o el correo saliente general) en Configuración › Facturación electrónica")
    cfg = _cfg_smtp(e)
    cfg.responder_a = (e.rrhh_smtp_remitente or "").strip() or None
    cfg.nombre = e.rrhh_smtp_nombre or cfg.nombre
    return cfg


@app.put("/api/rrhh/correo")
def put_correo_rrhh(data: CorreoRRHHIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    secretos.asegurar_clave(e)
    e.rrhh_smtp_host = (data.smtp_host or "").strip() or None
    e.rrhh_smtp_puerto = data.smtp_puerto or (465 if data.smtp_seguridad == "ssl" else 587)
    e.rrhh_smtp_seguridad = data.smtp_seguridad
    e.rrhh_smtp_usuario = (data.smtp_usuario or "").strip() or None
    e.rrhh_smtp_remitente = (data.smtp_remitente or "").strip().lower() or None
    e.rrhh_smtp_nombre = (data.smtp_nombre or "").strip() or None
    e.rrhh_smtp_copia = (data.smtp_copia or "").strip() or None
    e.rrhh_correo_auto = bool(data.correo_auto)
    if data.smtp_password not in (None, "", "***"):
        e.rrhh_smtp_password = secretos.cifrar(e.clave_cifrada, data.smtp_password.strip("\r\n"))
    if e.rrhh_smtp_remitente and "@" not in e.rrhh_smtp_remitente:
        raise HTTPException(400, "El correo remitente de Recursos humanos no es válido")
    s.add(e); s.commit()
    auditar(s, "config_empresa", "Correo de Recursos humanos actualizado", ctx.usuario, e.id, ctx.request)
    return {"ok": True}


@app.post("/api/rrhh/correo/probar")
def probar_correo_rrhh(data: CorreoIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    para = _correos_de(data.para or ctx.usuario.correo)
    if not para:
        raise HTTPException(400, "Indique un correo de destino válido")
    try:
        correo.probar(_cfg_smtp_rrhh(e), para[0], (e.nombre_comercial or e.nombre) + " · Recursos humanos",
                      rem=_dz.de_empresa(e, nombre=(e.nombre_comercial or e.nombre) + " · Recursos humanos"))
    except correo.ErrorCorreo as ex:
        auditar(s, "correo_prueba", f"RRHH FALLÓ a {para[0]}: {ex}"[:500], ctx.usuario, e.id, ctx.request)
        raise HTTPException(502, str(ex))
    auditar(s, "correo_prueba", f"RRHH enviado a {para[0]}", ctx.usuario, e.id, ctx.request)
    return {"ok": True, "para": para[0], "detalle": "Correo de prueba de Recursos humanos enviado"}


class ConceptoPagoIn(BaseModel):
    concepto: str = Field("Concepto", max_length=100); monto: float = 0; salarial: bool = True


class LineaPagoIn(BaseModel):
    c: str = Field("", max_length=160); m: float = 0


class ComprobantePagoFila(BaseModel):
    nombre: str = Field(max_length=90); correo: Optional[str] = Field(None, max_length=200); numero_id: Optional[str] = Field(None, max_length=30); puesto: Optional[str] = Field(None, max_length=100)
    horas: float = 0; horas_extra: float = 0; ordinario: float = 0; extras: float = 0; otros_ingresos: float = 0; bruto: float = 0
    obrero: dict[str, float] = Field(default_factory=dict); renta: float = 0; otras_deducciones: float = 0; total_deducciones: float = 0; neto: float = 0
    feriado: float = 0; descuento_ausencia: float = 0; dias_ausencia: float = 0; no_salariales: float = 0
    detalle_deducciones: list[ConceptoPagoIn] = Field(default_factory=list, max_length=50); detalle_ingresos: list[ConceptoPagoIn] = Field(default_factory=list, max_length=50)
    detalle: list[LineaPagoIn] = Field(default_factory=list, max_length=60)       # líneas libres (aguinaldo, liquidación): sustituyen el desglose de planilla


class ComprobantesPagoIn(BaseModel):
    numero: str = Field(max_length=30); periodo: str = Field(max_length=40)
    desde: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$"); hasta: str = Field(pattern=r"^\d{4}-\d{2}-\d{2}$")
    pagada_en: Optional[str] = Field(None, pattern=r"^\d{4}-\d{2}-\d{2}$"); cuenta: Optional[str] = Field(None, max_length=80)
    concepto: Literal["planilla", "aguinaldo", "liquidacion"] = "planilla"
    complementaria_de: Optional[str] = Field(None, max_length=30)      # 4.7: número de la planilla original si esta es complementaria
    filas: list[ComprobantePagoFila] = Field(max_length=500)


_CONCEPTO_RRHH = {"planilla": ("Comprobante de pago", "Planilla", "planilla_correo", "comprobante_pago"),
                  "aguinaldo": ("Comprobante de aguinaldo", "Aguinaldo", "aguinaldo_correo", "comprobante_aguinaldo"),
                  "liquidacion": ("Liquidación laboral", "Liquidación", "liquidacion_correo", "liquidacion")}


def _fm_colones(v) -> str:
    try:
        return pdf.fmt(v, "CRC", con_codigo=False)
    except Exception:  # noqa: BLE001  montos absurdos (≥ 1e28) no tumban el envío de toda la planilla
        return str(v)


# 4.7: también la diferencia de la cuota obrera por la base mínima cuando la empresa decide rebajársela al trabajador
_OBRERO_COMPROBANTE = {"sem": "CCSS – Seguro de salud (SEM)", "ivm": "CCSS – Pensiones (IVM)", "banco_popular": "Banco Popular",
                       "base_minima": "CCSS – Diferencia por la base mínima contributiva"}


def _reporte_comprobante(e, cab, f: ComprobantePagoFila) -> "reportes.ReporteIn":
    """4.21: el comprobante de pago de un empleado (planilla, aguinaldo o liquidación) como reporte: el mismo para el correo
    (enviar_comprobantes_pago) y para la descarga (descargar_comprobante_pago). `cab` es la cabecera del documento: un
    ComprobantesPagoIn o un dict con concepto, numero, periodo, desde, hasta, pagada_en, cuenta y complementaria_de. `e` es la
    empresa (hoy no hace falta para armarlo: su encabezado lo pone reportes._pdf)."""
    data = types.SimpleNamespace(**{"concepto": "planilla", "pagada_en": None, "cuenta": None, "complementaria_de": None, **cab}) if isinstance(cab, dict) else cab
    fm, OBR = _fm_colones, _OBRERO_COMPROBANTE
    comp = (data.complementaria_de or "").strip() if data.concepto == "planilla" else ""    # 4.7: planilla complementaria de otra
    titulo_doc, nombre_doc, _accion, prefijo = _CONCEPTO_RRHH[data.concepto]
    if f.detalle:                                   # aguinaldo o liquidación: las líneas vienen hechas
        filas = [{"c": x.c[:120], "m": fm(x.m)} for x in f.detalle]
    else:
        filas = [{"c": "Salario ordinario (" + f"{f.horas:g}" + " h)", "m": fm(f.ordinario)}]
        if f.descuento_ausencia: filas.append({"c": f"− Días no pagados ({f.dias_ausencia:g} d)", "m": fm(f.descuento_ausencia)})
        if f.extras: filas.append({"c": f"Horas extra ({f.horas_extra:g} h)", "m": fm(f.extras)})
        if f.feriado: filas.append({"c": "Recargo por feriado trabajado", "m": fm(f.feriado)})
        ing_sal = [x for x in f.detalle_ingresos if x.salarial]
        for x in ing_sal:
            filas.append({"c": x.concepto[:100], "m": fm(x.monto)})
        resto_ing = round(f.otros_ingresos - sum(x.monto for x in ing_sal), 2)     # lo escrito a mano en la planilla
        if resto_ing > 0.005: filas.append({"c": "Otros ingresos", "m": fm(resto_ing)})
        filas.append({"c": "Salario bruto", "m": fm(f.bruto)})
        for k, v in (f.obrero or {}).items():
            filas.append({"c": "− " + (OBR.get(k) or str(k).replace("_", " ").capitalize()), "m": fm(v)})
        if f.renta: filas.append({"c": "− Impuesto sobre la renta", "m": fm(f.renta)})
        for x in f.detalle_deducciones:
            filas.append({"c": "− " + x.concepto[:100], "m": fm(x.monto)})
        resto = round(f.otras_deducciones - sum(x.monto for x in f.detalle_deducciones), 2)
        if resto > 0.005: filas.append({"c": "− Otras deducciones", "m": fm(resto)})
        filas.append({"c": "Total de deducciones", "m": fm(f.total_deducciones)})
        for x in f.detalle_ingresos:
            if not x.salarial: filas.append({"c": x.concepto[:100] + " (no salarial)", "m": fm(x.monto)})
        resto_ns = round(f.no_salariales - sum(x.monto for x in f.detalle_ingresos if not x.salarial), 2)
        if resto_ns > 0.005: filas.append({"c": "Subsidios y pagos no salariales (no cotizan)", "m": fm(resto_ns)})
    kpis = ([{"t": "Neto pagado", "v": fm(f.neto)}, {"t": "Salario bruto", "v": fm(f.bruto)}, {"t": "Deducciones", "v": fm(f.total_deducciones)}] if not f.detalle
            else [{"t": "Total pagado", "v": fm(f.neto)}]) + [{"t": "Fecha de pago", "v": pdf._fecha(data.pagada_en) if data.pagada_en else "—"}]
    return reportes.ReporteIn(titulo=f"{titulo_doc} · {f.nombre}", subtitulo=f"{nombre_doc} {data.numero} · {data.periodo}" + (f" · complementaria de {comp}" if comp else ""), periodo=f"{pdf._fecha(data.desde)} al {pdf._fecha(data.hasta)}",
                                kpis=kpis,
                                secciones=[{"titulo": "Datos", "columnas": [{"key": "d", "label": "Dato"}, {"key": "v", "label": "Valor"}],
                                            "filas": [{"d": "Empleado", "v": f.nombre}, {"d": "Identificación", "v": f.numero_id or "—"}, {"d": "Puesto", "v": f.puesto or "—"}, {"d": "Período", "v": f"{data.periodo}: {pdf._fecha(data.desde)} al {pdf._fecha(data.hasta)}"}, {"d": "Pagado", "v": (pdf._fecha(data.pagada_en) if data.pagada_en else "—") + (f" desde {data.cuenta}" if data.cuenta else "")}]
                                            + ([{"d": "Complementaria de", "v": f"{nombre_doc} {comp}: pagos adicionales del mismo período"}] if comp else [])},
                                           {"titulo": "Detalle del pago", "columnas": [{"key": "c", "label": "Concepto"}, {"key": "m", "label": "Monto (CRC)", "num": True}], "filas": filas, "totales": [{"t": "TOTAL PAGADO", "v": fm(f.neto)}]}],
                                nota=(f"Pago adicional del mismo período de la planilla {comp} (planilla complementaria). " if comp else "")
                                + ("Las cargas patronales las paga la empresa aparte y no se descuentan del salario. Conserve este comprobante." if data.concepto == "planilla" else "Conserve este documento como comprobante del pago recibido."),
                                archivo=f"{prefijo}_{data.numero}")


@app.post("/api/rrhh/comprobantes-pago")
def enviar_comprobantes_pago(data: ComprobantesPagoIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(get_session)):
    """Al marcar pagada una planilla: a cada empleado con correo se le envía su comprobante de pago (PDF) desde el correo de
    Recursos humanos (o el general con Reply-To a RRHH). Devuelve cuántos se enviaron, cuántos no tienen correo y los fallos."""
    e = s.get(Empresa, ctx.empresa.id)
    cfg = _cfg_smtp_rrhh(e)
    empresa_nombre = e.nombre_comercial or e.nombre
    comp = (data.complementaria_de or "").strip() if data.concepto == "planilla" else ""    # 4.7: planilla complementaria de otra
    fm = _fm_colones
    titulo_doc, nombre_doc, accion, prefijo = _CONCEPTO_RRHH[data.concepto]
    rem_rrhh = _dz.de_empresa(e)                                                       # 3.83: logo y color de la empresa
    enviados, sin_correo, fallidos = 0, [], []
    for f in data.filas:
        para = _correos_de(f.correo)
        if not para:
            sin_correo.append(f.nombre); continue
        try:
            rep = _reporte_comprobante(e, data, f)                # 4.21: el mismo reporte que la descarga del comprobante
            contenido = reportes._pdf(rep, e, pdf.logo_empresa(e))
            html = _dz.armar(rem_rrhh, titulo=f"Su {titulo_doc.lower()}", asunto=f"{titulo_doc} · {nombre_doc} {data.numero} · {empresa_nombre}",
                             preencabezado=f"Total pagado: CRC {fm(f.neto)}.", saludo=f"Estimado(a) {f.nombre}:",
                             parrafos_txt=[f"Le adjuntamos su {titulo_doc.lower()} en PDF." + (f" Es un pago adicional del mismo período de la planilla {comp}." if comp else "")],
                             datos=[(nombre_doc, data.numero), ("Período", data.periodo), ("Del", pdf._fecha(data.desde)), ("Al", pdf._fecha(data.hasta)),
                                    ("Total pagado", f"CRC {fm(f.neto)}")] + ([("Complementaria de", comp)] if comp else []),
                             nota="Si tiene alguna consulta, responda a este correo y Recursos humanos le atenderá.")   # 3.83
            texto = f"{empresa_nombre}\n\n{titulo_doc}: {nombre_doc.lower()} {data.numero} ({data.periodo}, del {pdf._fecha(data.desde)} al {pdf._fecha(data.hasta)}). Total pagado: CRC {fm(f.neto)}. Se adjunta el PDF." + (f" Es un pago adicional del mismo período de la planilla {comp} (planilla complementaria)." if comp else "")
            correo.enviar(cfg, para[:1], f"{titulo_doc} · {nombre_doc} {data.numero} · {empresa_nombre}", html, texto,
                          [(f"{prefijo}_{re.sub(r'[^A-Za-z0-9]', '', data.numero)}_{re.sub(r'[^A-Za-z0-9]', '', f.numero_id or '')}.pdf", contenido, "application", "pdf")])
            enviados += 1
        except (correo.ErrorCorreo, HTTPException) as ex:
            fallidos.append({"nombre": f.nombre, "error": str(getattr(ex, "detail", ex))[:200]})
        except Exception as ex:  # noqa: BLE001
            fallidos.append({"nombre": f.nombre, "error": f"{type(ex).__name__}: {ex}"[:200]})
    auditar(s, accion, f"{nombre_doc} {data.numero}: {enviados} comprobantes enviados, {len(sin_correo)} sin correo, {len(fallidos)} fallidos"[:500], ctx.usuario, e.id, ctx.request)
    return {"enviados": enviados, "sin_correo": sin_correo, "fallidos": fallidos}


# 4.21: descarga del comprobante de pago (el mismo PDF del correo) con lo GUARDADO. La cabecera y la fila se arman aquí como las arma
# la pantalla para el envío (planilla.js y aguinaldo.js › enviarComprobantes, liquidaciones.js › enviar): si cambian allá, cambian aquí.
_CLAVE_COMPROBANTE = {"planilla": "planillas", "aguinaldo": "rrhh_aguinaldos", "liquidacion": "liquidaciones"}
_PERIODO_COMPROBANTE = {**rrhh.NOMBRE_PERIODO, "manual": "Manual (por horas)"}     # como lo rotula la pantalla (periodoNombre) y sale en el correo


def _fecha_pantalla(iso) -> str:
    """La fecha como la escribe la pantalla (api.js › fecha): 1/12/2026, sin ceros a la izquierda."""
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", str(iso or ""))
    return f"{int(m.group(3))}/{int(m.group(2))}/{m.group(1)}" if m else str(iso or "")[:10]


def _cabecera_comprobante(concepto: str, doc: dict, emp: Optional[dict]) -> dict:
    """4.21: la cabecera del comprobante (número, período, fechas, pago) de una planilla, un aguinaldo o una liquidación guardados."""
    emp = emp if isinstance(emp, dict) else {}
    iso = lambda v: str(v)[:10] if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(v or "")[:10]) else ""   # noqa: E731
    cab = {"concepto": concepto, "numero": str(doc.get("numero") or doc.get("id") or ""), "desde": iso(doc.get("desde")), "hasta": iso(doc.get("hasta")),
           "pagada_en": iso(doc.get("pagada_en")) or None, "cuenta": str(doc.get("cuenta") or "")[:80] or None, "complementaria_de": None}
    if concepto == "planilla":
        cab["periodo"] = _PERIODO_COMPROBANTE.get(doc.get("periodo")) or str(doc.get("periodo") or "—")
        if doc.get("complementaria"):
            cab["complementaria_de"] = str(doc.get("referencia_numero") or "otra planilla")[:30]
    elif concepto == "aguinaldo":
        adicional = bool(doc.get("adicional"))
        cab["numero"] = f"AG-{doc.get('anio')}" + (f"-A{doc.get('id')}" if adicional else "")
        cab["periodo"] = f"Aguinaldo {doc.get('anio')}" + (" (adicional)" if adicional else "")
        cab["pagada_en"] = iso(doc.get("fecha")) or None
    else:
        cab["periodo"] = str(doc.get("motivo_nombre") or rrhh.MOTIVOS.get(doc.get("motivo")) or doc.get("motivo") or "—")
        cab["desde"], cab["hasta"] = iso(emp.get("fecha_ingreso")) or iso(doc.get("fecha_salida")), iso(doc.get("fecha_salida"))
    cab["numero"], cab["periodo"] = cab["numero"][:30], cab["periodo"][:40]
    return cab


def _fila_comprobante(concepto: str, doc: dict, fila: dict, emp: Optional[dict]) -> ComprobantePagoFila:
    """4.21: la fila del comprobante de un empleado con los montos GUARDADOS. `fila`: la suya en doc.filas (en una liquidación, la
    liquidación misma). `emp`: su ficha; si ya no existe quedan el nombre de la fila y lo demás en «—». Los números se leen como en
    la pantalla («+v || 0») y los textos se recortan a lo que admite el comprobante: un dato viejo no impide descargarlo."""
    emp = emp if isinstance(emp, dict) else {}
    n = lambda v: _num_rrhh(v) or 0.0                                                             # noqa: E731
    txt = lambda v, largo: str(v or "").strip()[:largo] or None                                   # noqa: E731
    de_ficha = " ".join(str(emp.get(k) or "").strip() for k in ("nombre", "apellidos")).strip()
    comun = {"nombre": (str(fila.get("nombre") or "").strip() or de_ficha or "—")[:90], "correo": txt(emp.get("correo") or fila.get("correo"), 200),
             "numero_id": txt(emp.get("numero_id") or fila.get("numero_id"), 30), "puesto": txt(emp.get("puesto") or fila.get("puesto"), 100)}
    if concepto == "planilla":
        def det(lista):
            return [ConceptoPagoIn(concepto=str(d.get("concepto") or "Concepto")[:100], monto=n(d.get("monto")), salarial=d.get("salarial") is not False)
                    for d in (lista if isinstance(lista, list) else []) if isinstance(d, dict)][:50]
        obrero = fila.get("obrero") if isinstance(fila.get("obrero"), dict) else {}
        num = {k: n(fila.get(k)) for k in ("horas", "horas_extra", "ordinario", "extras", "otros_ingresos", "bruto", "renta", "otras_deducciones", "neto",
                                           "feriado", "descuento_ausencia", "dias_ausencia", "no_salariales")}
        # las planillas anteriores a la 4.7 no guardaban el total de deducciones: la misma suma de reserva que usa la pantalla
        total_ded = n(fila.get("total_deducciones")) or (n(fila.get("total_obrero")) + num["renta"] + num["otras_deducciones"])
        return ComprobantePagoFila(**comun, **num, obrero={str(k): n(v) for k, v in obrero.items()}, total_deducciones=total_ded,
                                   detalle_deducciones=det(fila.get("detalle_deducciones")), detalle_ingresos=det(fila.get("detalle_ingresos")))
    if concepto == "aguinaldo":
        monto = n(fila.get("monto"))
        detalle = [LineaPagoIn(c=f"Salarios devengados del {_fecha_pantalla(doc.get('desde'))} al {_fecha_pantalla(doc.get('hasta'))}", m=n(fila.get("devengado")))]
        detalle += ([LineaPagoIn(c="Aguinaldo ya pagado", m=n(fila.get("ya_pagado"))), LineaPagoIn(c="Diferencia de aguinaldo (pago adicional)", m=monto)]
                    if doc.get("adicional") else [LineaPagoIn(c="Aguinaldo (devengado entre 12, Ley 2412)", m=monto)])
        return ComprobantePagoFila(**comun, neto=monto, detalle=detalle)
    rubros = [r for r in (doc.get("rubros") if isinstance(doc.get("rubros"), list) else []) if isinstance(r, dict)]
    detalle = [LineaPagoIn(c=(str(r.get("rubro") or "") + (f" ({reportes._cr(n(r.get('dias')))} d)" if n(r.get("dias")) else ""))[:160], m=n(r.get("monto"))) for r in rubros][:60]
    # sin rubros guardados (no debería pasar) el comprobante no puede salir con el desglose de una planilla: una sola línea con el total
    return ComprobantePagoFila(**comun, neto=n(doc.get("total")), detalle=detalle or [LineaPagoIn(c="Total de la liquidación", m=n(doc.get("total")))])


@app.get("/api/rrhh/comprobante-pago/{concepto}/{doc_id}/{empleado_id}")
def descargar_comprobante_pago(concepto: Literal["planilla", "aguinaldo", "liquidacion"], doc_id: int, empleado_id: int,
                               ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """4.21: el comprobante de pago de un empleado en PDF, el mismo que llega por correo, armado con lo GUARDADO en la planilla, el
    aguinaldo o la liquidación (nunca con montos que mande el navegador). Solo de lo ya pagado. Queda en el historial de operaciones
    sin montos (quién descargó el comprobante de quién)."""
    eid, clave = ctx.empresa.id, _CLAVE_COMPROBANTE[concepto]
    art, pag, _corregir = _RRHH_NOMBRE[clave]
    doc = _items_guardados(s, eid, clave, [doc_id]).get(doc_id)
    if not isinstance(doc, dict):
        raise HTTPException(404, f"{art} ya no existe: recargue la página")
    if not _rrhh_pagado(clave, doc):
        raise HTTPException(409, f"{art} todavía no está {pag}: el comprobante se descarga cuando esté {pag}")
    if concepto == "liquidacion":
        fila = doc if modulos._id_entero(doc.get("empleado_id")) == empleado_id else None
    else:
        fila = next((f for f in (doc.get("filas") if isinstance(doc.get("filas"), list) else [])
                     if isinstance(f, dict) and modulos._id_entero(f.get("empleado_id")) == empleado_id), None)
    if fila is None:
        raise HTTPException(404, f"Ese empleado no está en {art.lower()}")
    emp = _items_guardados(s, eid, "empleados", [empleado_id]).get(empleado_id)
    cab, f = _cabecera_comprobante(concepto, doc, emp), _fila_comprobante(concepto, doc, fila, emp)
    contenido = reportes._pdf(_reporte_comprobante(ctx.empresa, cab, f), ctx.empresa, pdf.logo_empresa(ctx.empresa))
    nombre_doc, prefijo = _CONCEPTO_RRHH[concepto][1], _CONCEPTO_RRHH[concepto][3]
    _auditar(ctx, "rrhh_comprobante_descargado", f"{nombre_doc} {cab['numero']}: empleado #{empleado_id} {f.nombre}"[:500])
    archivo = f"{prefijo}_{re.sub(r'[^A-Za-z0-9]', '', cab['numero'])}_{re.sub(r'[^A-Za-z0-9]', '', f.numero_id or '')}.pdf"
    return Response(contenido, media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{archivo}"'})


@app.get("/api/rrhh/empleados/{emp_id}/bitacora")
def bitacora_empleado(emp_id: int, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(get_session)):
    """4.21: bitácora de la ficha de un empleado: las filas «rrhh_ficha…» del historial de operaciones de esta empresa (tabla central,
    por eso get_session) cuyo detalle empieza con «#<id> ». Dicen quién, cuándo y QUÉ cambió (salario, cuenta, renta, riesgos); los
    valores no se anotan."""
    A = auth.Auditoria
    filas = s.exec(select(A).where(A.empresa_id == ctx.empresa.id, A.accion.startswith("rrhh_ficha"), A.detalle.startswith(f"#{emp_id} "))
                   .order_by(A.id.desc()).limit(100)).all()
    return [{"id": r.id, "fecha": r.fecha, "correo": r.correo, "accion": r.accion, "detalle": r.detalle} for r in filas]


def _esc_html(v) -> str:
    from html import escape
    return escape(str(v or ""))


@app.put("/api/recepcion/buzon")
def put_buzon(data: BuzonIn, ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    for k, v in data.model_dump().items():
        if k == "imap_password":
            if v in (None, "", "***"):
                continue
            v = secretos.cifrar(e.clave_cifrada, v.strip("\r\n"))
        setattr(e, k, v)
    s.add(e); s.commit()
    _auditar(ctx, "empresa_actualizada", f"Buzón de recepción: {data.imap_host or '(sin buzón)'}")
    return get_buzon(ctx)


@app.post("/api/recepcion/buzon/leer")
def leer_buzon(ctx: Contexto = Depends(requiere("gastos")), s: Session = Depends(sesion_empresa)):
    e = ctx.empresa
    if not (e.imap_host and e.imap_usuario and e.imap_password):
        raise HTTPException(400, "Configure el buzón (servidor, usuario y contraseña) antes de leer el correo")
    try:
        lectura = recepcion.leer_buzon(e, secretos.descifrar(e.clave_cifrada, e.imap_password) or "", dias=e.imap_dias or 60)
    except (RuntimeError, OSError, ValueError, UnicodeError) as ex:        # imaplib, red, codificación (R143)
        with Session(engine) as sc:
            ee = sc.get(Empresa, e.id); ee.imap_error = f"{type(ex).__name__}: {str(ex)[:300]}"; ee.imap_intento = ahora_cr().isoformat(timespec="seconds"); sc.add(ee); sc.commit()
        raise HTTPException(502, f"No se pudo leer el buzón: {ex}")
    res = recepcion.procesar_adjuntos(s, e, lectura["adjuntos"])
    res["correos"] = lectura["correos"]
    with Session(engine) as sc:
        ee = sc.get(Empresa, e.id); ee.imap_ultima = ahora_cr().isoformat(timespec="seconds"); ee.imap_error = None; ee.imap_intento = ee.imap_ultima; sc.add(ee); sc.commit()
    _auditar(ctx, "recepcion_buzon", f"{res['correos']} correos leídos, {res['nuevos']} comprobantes nuevos")
    return res


def leer_buzones_todas() -> int:
    """Lectura diaria de los buzones configurados (la llama la cola)."""
    from .db import engine_empresa
    total = 0
    hoy = ahora_cr().date().isoformat()
    with Session(engine) as sc:
        emps = [e for e in sc.exec(select(Empresa).where(Empresa.bloqueada == False)).all() if e.imap_host and e.imap_usuario and e.imap_password]  # noqa: E712
        for e in emps:
            if (e.imap_ultima or "")[:10] == hoy:
                continue
            if e.imap_error and e.imap_intento and (ahora_cr() - datetime.fromisoformat(e.imap_intento)).total_seconds() < 3600:
                continue                         # con error, un intento por hora (antes cada 5 min, en silencio) (R142)
            try:
                lectura = recepcion.leer_buzon(e, secretos.descifrar(e.clave_cifrada, e.imap_password) or "", dias=e.imap_dias or 60)
                with Session(engine_empresa(e.id)) as s:
                    r = recepcion.procesar_adjuntos(s, e, lectura["adjuntos"])
                total += r["nuevos"]
                e.imap_ultima = ahora_cr().isoformat(timespec="seconds"); e.imap_error = None; e.imap_intento = e.imap_ultima; sc.add(e); sc.commit()
            except Exception as ex:  # noqa: BLE001
                import logging; logging.getLogger(__name__).warning("Buzón de %s: %s", e.nombre, ex)
                e.imap_error = f"{type(ex).__name__}: {str(ex)[:300]}"; e.imap_intento = ahora_cr().isoformat(timespec="seconds"); sc.add(e); sc.commit()
    return total


# ---- exportación masiva (art. 5.4), respaldos y registro de clientes del proveedor de sistemas
@app.get("/api/exportar")
def exportar_empresa(desde: Optional[str] = None, hasta: Optional[str] = None, pdf_incluir: int = 0,
                     ctx: Contexto = Depends(requiere("configurar")), s: Session = Depends(sesion_empresa)):
    """ZIP con todo lo emitido y recibido de la empresa activa en el periodo (XML, respuestas, mensajes, CSV, registros)."""
    e = ctx.empresa
    try:
        datos = exportar.generar_zip(s, e, XML_DIR, desde, hasta, con_pdf=bool(pdf_incluir), render_pdf=lambda d: _pdf_de(d, e), ambiente=ctx.empresa.ambiente, permisos=set(ctx.permisos))
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    _auditar(ctx, "exportacion", f"Exportación {desde or 'inicio'} a {hasta or 'hoy'} ({len(datos) // 1024} KB{', con PDF' if pdf_incluir else ''})")
    nombre = f"exportacion_{re.sub(r'[^A-Za-z0-9]', '', e.numero_id or str(e.id))}_{(desde or 'inicio')}_{(hasta or 'hoy')}.zip"
    return Response(datos, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{nombre}"'})


# ---- factura automática del cobro del plan (3.65): empresa facturadora, ítem y cuenta
class FacturaPlanIn(BaseModel):
    activo: bool = False
    empresa_id: Optional[int] = None
    producto_id: Optional[int] = None
    cuenta: str = ""


def _factura_plan_items(eid) -> dict:
    if not eid:
        return {"items": [], "cuentas": []}
    with Session(engine_empresa(int(eid))) as se:
        items = [{"id": p.id, "nombre": p.nombre, "cabys": p.cabys, "precio": p.precio}
                 for p in se.exec(select(Producto).where(Producto.empresa_id == int(eid), Producto.activo == True, Producto.es_venta == True).order_by(Producto.nombre)).all()]  # noqa: E712
        bancos = modulos.leer(se, int(eid), "bancos", []) or []
    return {"items": items, "cuentas": [b.get("nombre") for b in bancos if isinstance(b, dict) and b.get("nombre")]}


@app.get("/api/admin/factura-plan")
def admin_factura_plan(u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    from . import factura_plan
    cfg = factura_plan.leer_config()
    eid = cfg.get("empresa_id")
    if eid and s.get(Empresa, int(eid)) is None:
        eid = None
    if eid and not auth.admin_ve_empresa(u, eid):
        # 3.87: la empresa que factura el plan está oculta para este administrador: ni su nombre, ni sus ítems, ni sus cuentas de
        # Bancos; tampoco la cambia (admin_guardar_factura_plan). La pantalla lo explica con «oculta».
        return {"activo": bool(cfg.get("activo")), "empresa_id": None, "producto_id": None, "cuenta": "", "items": [], "cuentas": [], "oculta": True}
    return {"activo": bool(cfg.get("activo")), "empresa_id": eid, "producto_id": cfg.get("producto_id"), "cuenta": cfg.get("cuenta") or "", **_factura_plan_items(eid)}


@app.get("/api/admin/factura-plan/items")
def admin_factura_plan_items(empresa_id: int, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    if s.get(Empresa, empresa_id) is None:
        raise HTTPException(404, "Empresa no encontrada")
    return _factura_plan_items(empresa_id)


@app.put("/api/admin/factura-plan")
def admin_guardar_factura_plan(data: FacturaPlanIn, request: Request, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    from . import factura_plan
    if data.activo and not (data.empresa_id and data.producto_id):
        raise HTTPException(400, "Elija la empresa que factura y el ítem con que se factura el plan")
    if data.empresa_id and (s.get(Empresa, data.empresa_id) is None or not auth.admin_ve_empresa(u, data.empresa_id)):   # 3.87: ni una oculta
        raise HTTPException(404, "Empresa no encontrada")
    actual = factura_plan.leer_config().get("empresa_id")
    if actual and s.get(Empresa, int(actual)) is not None and not auth.admin_ve_empresa(u, actual):
        raise HTTPException(403, "La empresa que factura el plan no es visible para usted: la cambia el super administrador")   # 3.87
    if data.producto_id and data.empresa_id:
        with Session(engine_empresa(int(data.empresa_id))) as se:
            prod = se.get(Producto, int(data.producto_id))
            if prod is None or prod.empresa_id != int(data.empresa_id):
                raise HTTPException(400, "El ítem no pertenece a esa empresa")
    factura_plan.guardar_config({"activo": bool(data.activo), "empresa_id": data.empresa_id, "producto_id": data.producto_id, "cuenta": (data.cuenta or "")[:80],
                                 "actualizado": ahora_cr().isoformat(timespec="seconds")})
    auth.auditar(s, "factura_plan_configurada", f"{'activa' if data.activo else 'inactiva'} · empresa {data.empresa_id} · ítem {data.producto_id}", u, None, request)
    return admin_factura_plan(u, s)


_NO_VE_TODAS = "El respaldo general incluye todas las empresas: solo lo maneja un administrador del sistema que las ve todas"


def _exigir_ve_todas(u, s: Session) -> set:
    """3.87: el respaldo general trae las bases de TODAS las empresas (y las claves del servidor si están en disco): un administrador
    del sistema con empresas ocultas no lo crea, no lo descarga ni lo borra. Un id de una empresa ya eliminada no cuenta (la lista no
    se depura al eliminarla), pero su base sigue dentro de los generales de antes: devuelve esos ids para revisar cada zip."""
    ocultas = auth.empresas_ocultas_de(u)
    if ocultas and set(s.exec(select(Empresa.id).where(Empresa.id.in_(ocultas))).all()):  # type: ignore[attr-defined]
        raise HTTPException(403, _NO_VE_TODAS)
    return ocultas


@app.get("/api/admin/respaldos")
def admin_respaldos(u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    nombres = {e.id: (e.nombre_comercial or e.nombre) for e in s.exec(select(Empresa)).all()}
    ocultas = auth.empresas_ocultas_de(u)              # 3.87: ni los respaldos de una empresa oculta ni su nombre
    empresas = [{**r, "nombre": nombres.get(r["empresa_id"], f"Empresa {r['empresa_id']} (eliminada)")} for r in respaldo.listar_empresas()
                if r["empresa_id"] not in ocultas]
    ocultas = {x for x in ocultas if x in nombres}     # 3.87: las ya eliminadas no limitan, salvo los generales que aún traen su base
    eliminadas = auth.empresas_ocultas_de(u) - ocultas
    generales = [r for r in respaldo.listar() if not respaldo.trae_empresas(r["nombre"], eliminadas)] if not ocultas else []
    return {"carpeta": str(respaldo.RESPALDOS_DIR), "conservar": respaldo.CONSERVAR, "respaldos": generales, "general": not ocultas,
            "ultimo": respaldo.MARCA.read_text(encoding="utf-8") if respaldo.MARCA.exists() and not ocultas else None,
            "ultimo_real": generales[0] if generales else None,          # 3.87: el zip más reciente que de verdad existe (la marca puede mentir)
            "dentro_app": not respaldo.ubicacion_segura(), "carpeta_sugerida": respaldo.carpeta_sugerida(),
            "ultima_descarga": respaldo.ultima_descarga() if not ocultas else None,
            "empresas": empresas, "maximo_empresa": respaldo.MAXIMO_EMPRESA}


@app.post("/api/admin/respaldos")
def admin_crear_respaldo(u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    _exigir_ve_todas(u, s)
    try:
        p = respaldo.ejecutar()
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(500, f"No se pudo crear el respaldo: {ex}")
    return {"ok": True, "nombre": p.name, "bytes": p.stat().st_size}


@app.get("/api/admin/respaldos/{nombre}")
def admin_descargar_respaldo(nombre: str, request: Request, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    eliminadas = _exigir_ve_todas(u, s)
    if not re.fullmatch(r"facturacr_\d{8}_\d{6}\.zip", nombre):
        raise HTTPException(404, "Respaldo no encontrado")
    p = respaldo.RESPALDOS_DIR / nombre
    if not p.exists():
        raise HTTPException(404, "Respaldo no encontrado")
    if respaldo.trae_empresas(nombre, eliminadas):
        raise HTTPException(403, _NO_VE_TODAS)
    respaldo.marcar_descarga(nombre, getattr(u, "correo", None))   # 3.87: la consola recuerda cuándo se sacó la última copia del servidor
    auth.auditar(s, "respaldo_descargado", f"Respaldo general descargado: {nombre}", u, None, request)
    return FileResponse(p, media_type="application/zip", filename=nombre)


@app.delete("/api/admin/respaldos/{nombre}")
def admin_eliminar_respaldo(nombre: str, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    """3.59: el administrador del sistema borra un respaldo general."""
    if respaldo.trae_empresas(nombre, _exigir_ve_todas(u, s)):
        raise HTTPException(403, _NO_VE_TODAS)
    if not respaldo.eliminar(nombre):
        raise HTTPException(404, "Respaldo no encontrado")
    return {"ok": True}


@app.get("/api/admin/respaldos/empresa/{eid}/{nombre}")
def admin_descargar_respaldo_empresa(eid: int, nombre: str, u=Depends(auth.superadmin)):
    p = respaldo.ruta_empresa(eid, nombre)
    if p is None:
        raise HTTPException(404, "Respaldo no encontrado")
    return FileResponse(p, media_type="application/zip", filename=nombre)


@app.delete("/api/admin/respaldos/empresa/{eid}/{nombre}")
def admin_eliminar_respaldo_empresa(eid: int, nombre: str, u=Depends(auth.superadmin)):
    if not respaldo.eliminar_empresa(eid, nombre):
        raise HTTPException(404, "Respaldo no encontrado")
    return {"ok": True}


# ---- respaldos de la propia empresa (3.59): Configuración › Respaldos, solo el Administrador de la empresa
def _ctx_respaldos(ctx: Contexto = Depends(requiere("configurar"))) -> Contexto:
    """3.87: el respaldo es la base COMPLETA de la empresa (también empleados, salarios y cuentas bancarias, que Exportar omite sin
    RRHH) y no se puede recortar por permiso: además de «configurar» exige «usuarios», que ya permite darse cualquier rol. Antes un
    rol personalizado con solo «configurar» se llevaba todo."""
    if not ctx.puede("usuarios"):
        raise HTTPException(403, "El respaldo trae todos los datos de la empresa: solo lo maneja un rol que también administra los usuarios, como el Administrador")
    return ctx


@app.get("/api/respaldos")
def respaldos_empresa(ctx: Contexto = Depends(_ctx_respaldos)):
    return {"respaldos": respaldo.listar_empresa(ctx.empresa.id), "maximo": respaldo.MAXIMO_EMPRESA}


@app.post("/api/respaldos")
def crear_respaldo_empresa(ctx: Contexto = Depends(_ctx_respaldos)):
    engine_empresa(ctx.empresa.id)                          # garantiza que exista la base de la empresa (recién creada, sin usar)
    try:
        p = respaldo.ejecutar_empresa(ctx.empresa)
    except ValueError as ex:
        raise HTTPException(409, str(ex))
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(500, f"No se pudo crear el respaldo: {ex}")
    tam = p.stat().st_size
    _auditar(ctx, "respaldo", f"Respaldo creado: {p.name} ({tam // 1024} KB)")
    return {"ok": True, "nombre": p.name, "bytes": tam}


@app.get("/api/respaldos/{nombre}")
def descargar_respaldo_empresa(nombre: str, ctx: Contexto = Depends(_ctx_respaldos)):
    p = respaldo.ruta_empresa(ctx.empresa.id, nombre)
    if p is None:
        raise HTTPException(404, "Respaldo no encontrado")
    _auditar(ctx, "respaldo", f"Respaldo descargado: {nombre}")
    return FileResponse(p, media_type="application/zip", filename=nombre)


@app.delete("/api/respaldos/{nombre}")
def eliminar_respaldo_empresa(nombre: str, ctx: Contexto = Depends(_ctx_respaldos)):
    if not respaldo.eliminar_empresa(ctx.empresa.id, nombre):
        raise HTTPException(404, "Respaldo no encontrado")
    _auditar(ctx, "respaldo", f"Respaldo eliminado: {nombre}")
    return {"ok": True}


# ---- restaurar y subir respaldos (3.63): la empresa restaura los suyos; el administrador del sistema, los de cualquiera
class RestaurarIn(BaseModel):
    confirmacion: str = ""


def _restaurar(e: Empresa, eid: int, nombre: str, data: RestaurarIn) -> dict:
    if (data.confirmacion or "").strip().upper() != "RESTAURAR":
        raise HTTPException(400, "Escriba RESTAURAR para confirmar")
    p = respaldo.ruta_empresa(eid, nombre)
    if p is None:
        raise HTTPException(404, "Respaldo no encontrado")
    try:
        r = respaldo.restaurar_empresa(e, p)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    except Exception as ex:  # noqa: BLE001
        raise HTTPException(500, f"No se pudo restaurar: {ex}")
    return {"ok": True, "nombre": nombre, **r}


def _subir_respaldo(eid: int, archivo: UploadFile) -> dict:
    contenido = archivo.file.read(300 * 1024 * 1024 + 1)
    if len(contenido) > 300 * 1024 * 1024:
        raise HTTPException(413, "El respaldo pesa más de 300 MB; súbalo al servidor por otro medio")
    if len(respaldo.listar_empresa(eid)) >= respaldo.MAXIMO_EMPRESA:
        raise HTTPException(409, f"Ya hay {respaldo.MAXIMO_EMPRESA} respaldos guardados; elimine alguno antes de subir otro")
    try:
        p = respaldo.guardar_subido(eid, contenido)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    return {"ok": True, "nombre": p.name, "bytes": p.stat().st_size}


@app.post("/api/respaldos/{nombre}/restaurar")
def restaurar_respaldo_empresa(nombre: str, data: RestaurarIn, ctx: Contexto = Depends(_ctx_respaldos), s: Session = Depends(get_session)):
    e = s.get(Empresa, ctx.empresa.id)
    r = _restaurar(e, e.id, nombre, data)
    _auditar(ctx, "respaldo", f"Empresa restaurada desde {nombre} (copia de seguridad previa: {r['seguridad']})")
    return r


@app.post("/api/respaldos/subir")
def subir_respaldo_empresa(archivo: UploadFile = File(...), ctx: Contexto = Depends(_ctx_respaldos)):
    r = _subir_respaldo(ctx.empresa.id, archivo)
    _auditar(ctx, "respaldo", f"Respaldo subido: {r['nombre']} ({r['bytes'] // 1024} KB)")
    return r


@app.post("/api/admin/respaldos/empresa/{eid}/{nombre}/restaurar")
def admin_restaurar_respaldo_empresa(eid: int, nombre: str, data: RestaurarIn, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    e = s.get(Empresa, eid)
    if e is None:
        raise HTTPException(404, "Empresa no encontrada")
    r = _restaurar(e, eid, nombre, data)
    auth.auditar(s, "respaldo_restaurado", f"{e.nombre}: restaurada desde {nombre} (seguridad: {r['seguridad']})", u, eid, None)
    return r


@app.post("/api/admin/respaldos/empresa/{eid}/subir")
def admin_subir_respaldo_empresa(eid: int, archivo: UploadFile = File(...), u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    if s.get(Empresa, eid) is None:
        raise HTTPException(404, "Empresa no encontrada")
    return _subir_respaldo(eid, archivo)


@app.get("/api/admin/registro-clientes")
def admin_registro_clientes(formato: str = "csv", u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    """Registro de clientes del proveedor de sistemas (Reglamento 44739-H art. 5): una fila por empresa, en CSV."""
    from .db import engine_empresa
    filas = []
    ocultas = auth.empresas_ocultas_de(u)              # 3.87: el administrador limitado no recibe las empresas que no ve (el super administrador, todas)
    for e in s.exec(select(Empresa)).all():
        if e.id in ocultas:
            continue
        usuarios = len(s.exec(select(auth.UsuarioEmpresa).where(auth.UsuarioEmpresa.empresa_id == e.id)).all())
        emitidos = primero = ultimo = None
        try:
            with Session(engine_empresa(e.id)) as se:
                prod = [d.fecha_emision for d in se.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.ambiente == "produccion")).all()]
                emitidos, primero, ultimo = len(prod), (min(prod)[:10] if prod else None), (max(prod)[:10] if prod else None)
        except Exception:  # noqa: BLE001
            pass
        filas.append({"identificacion": e.numero_id, "tipo_identificacion": e.tipo_id, "nombre": e.nombre, "nombre_comercial": e.nombre_comercial or "",
                      "correo": e.correo, "telefono": e.telefono or "", "ambiente": e.ambiente, "proveedor_sistemas": e.proveedor_sistemas or PROVEEDOR_SISTEMAS,
                      "alta": e.creada.isoformat(timespec="seconds") if e.creada else "", "bloqueada": "sí" if e.bloqueada else "no", "usuarios": usuarios,
                      "comprobantes_produccion": emitidos if emitidos is not None else "", "primer_comprobante": primero or "", "ultimo_comprobante": ultimo or ""})
    if formato == "json":                                              # 4.17: la consola lo ofrece en PDF, Excel y CSV
        return filas
    datos = exportar._csv(filas)
    return Response(datos, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="registro_clientes_{ahora_cr():%Y%m%d}.csv"'})


# ---- salud del sistema (3.87): tarjeta de la consola, «Procesar ahora», guía del cron y resumen diario por correo
@app.get("/api/admin/salud")
def admin_salud(request: Request, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    """Todo lo que dice si la instalación está sana (solo lectura, sin secretos, sin las empresas que este administrador no ve)."""
    from . import salud
    d = salud.estado(auth.empresas_ocultas_de(u), base_url=URL_PUBLICA or str(request.base_url).rstrip("/"))
    d["puede_configurar"] = auth.es_admin_principal(s, u)
    return d


@app.get("/api/admin/cron-guia")
def admin_cron_guia(request: Request, u=Depends(auth.superadmin)):
    """Comando para crear el cron en el hosting con la dirección y el registro de ESTE servidor; el token va como AQUI_EL_TOKEN."""
    from . import salud
    return salud.guia_cron(URL_PUBLICA or str(request.base_url).rstrip("/"))


def _pasada_consola(por):
    from . import cola
    try:
        cola.procesar_todas(origen="consola", por=por)
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).exception("Cola pedida desde la consola: fallo")


@app.post("/api/admin/cola/procesar")
def admin_procesar_cola(request: Request, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    """«Procesar ahora»: la misma pasada que el cron, con el mismo cerrojo, en un hilo para responder al instante (el servidor web corta
    las peticiones largas). El resultado se ve en la tarjeta de salud al actualizar."""
    from . import cola
    if cola.en_curso():
        raise HTTPException(409, "Ya hay una pasada de la cola en curso: espere un momento y actualice")
    threading.Thread(target=_pasada_consola, args=(getattr(u, "correo", None),), name="cola-consola", daemon=True).start()
    auth.auditar(s, "cola_procesada", "Pasada de la cola pedida desde la consola", u, None, request)
    return {"ok": True, "iniciada": True}


class ResumenDiarioIn(BaseModel):
    activo: bool


@app.put("/api/admin/salud/resumen")
def admin_resumen_diario(data: ResumenDiarioIn, request: Request, u=Depends(auth.superadmin), s: Session = Depends(get_session)):
    """Enciende o apaga el resumen diario por correo (llega a todos los administradores del sistema): solo el super administrador."""
    from . import salud
    if not auth.es_admin_principal(s, u):
        raise HTTPException(403, "Solo el super administrador enciende o apaga el resumen diario")
    salud.guardar_config({"resumen_diario": bool(data.activo)})
    auth.auditar(s, "resumen_diario", "Resumen diario por correo " + ("encendido" if data.activo else "apagado"), u, None, request)
    return {"ok": True, "activo": salud.resumen_activo()}


@app.get("/api/admin/salud/resumen/vista")
def admin_resumen_vista(request: Request, u=Depends(auth.superadmin)):
    """Cómo le llegaría hoy el resumen diario a este administrador (no envía nada)."""
    from . import salud
    asunto, html, _ = salud.armar_resumen(u, base_url=URL_PUBLICA or str(request.base_url).rstrip("/"))
    return {"asunto": asunto, "html": _dz.para_navegador(html)}


@app.get("/api/version")
def version_app(todo: int = 0, u=Depends(auth.solo_usuario)):
    """Versión instalada y novedades (NOVEDADES.txt, el archivo que viaja en el zip) para Configuración › Mi perfil › Versión.
    3.72: por defecto las últimas 12 versiones (el historial completo pesa ~200 KB); todo=1 lo trae entero."""
    h = version.historial()
    return {"actual": version.actual(), "historial": h if todo else h[:12], "total": len(h)}


class _Fila(types.SimpleNamespace):
    """3.87: fila leída con solo las columnas que usa un cálculo (sin objetos ORM: con miles de comprobantes era la mitad del tiempo de
    Inicio). Pedir una columna que no se leyó da un error claro en lugar de None: getattr con valor por defecto lo escondería y
    cambiaría las cifras sin avisar."""

    def __getattr__(self, k):
        if k.startswith("__"):
            raise AttributeError(k)
        raise LookupError(f"La fila se leyó sin la columna «{k}»")


def _filas(s: Session, modelo, columnas: tuple, *condiciones) -> list:
    """Filas de `modelo` con esas columnas (en el mismo orden en que las devolvía select(modelo)), como objetos _Fila."""
    t = modelo.__table__
    return [_Fila(**dict(zip(columnas, f))) for f in s.execute(sa_select(*[t.c[c] for c in columnas]).where(*condiciones)).all()]


# columnas que leen Inicio (alertas y cobros) y el resumen / reporte ejecutivo (resumen.calcular, sucursales.pertenece)
_COLS_ALERTAS = ("estado", "fecha_emision", "tipo_documento", "total", "pagado", "acreditado", "moneda", "tipo_cambio", "fecha_vencimiento",
                 "sucursal_id", "consecutivo")   # 4.5: + lo que lee sucursales.pertenece (una _Fila sin la columna lanza LookupError)
_COLS_RESUMEN = ("id", "tipo_documento", "estado", "fecha_emision", "fecha_vencimiento", "moneda", "tipo_cambio", "total", "impuesto", "pagado", "acreditado",
                 "otros_cargos", "condicion_venta", "consecutivo", "receptor_nombre", "cliente_id", "vendedor", "sucursal_id")
_COLS_LINEAS_RESUMEN = ("documento_id", "cantidad", "producto_id", "detalle", "total")


@app.get("/api/inicio/alertas")
def inicio_alertas(ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Inicio (1.38): lo que requiere atención hoy (según los permisos del rol) y los cobros esperados de los próximos 30 días."""
    from datetime import timedelta as _td
    e = ctx.empresa
    hoy = ahora_cr().date(); hs = hoy.isoformat()
    alertas = []

    def avisar(nivel, texto, enlace=None):
        alertas.append({"nivel": nivel, "texto": texto, "enlace": enlace})
    if e.prueba_hasta:
        dias = (date.fromisoformat(e.prueba_hasta[:10]) - hoy).days
        avisar("info" if dias > 7 else "warn", f"Prueba gratis: quedan {dias} día{'s' if dias != 1 else ''} (hasta el {e.prueba_hasta[8:10]}/{e.prueba_hasta[5:7]}). "
               "Escríbanos para activar su plan y conservar sus datos.")
    if e.es_demo:
        avisar("info", "Empresa de demostración: los datos son ficticios y los comprobantes no se envían a Hacienda.")
    ver_ventas = ctx.puede("facturar") or ctx.puede("cobros") or ctx.puede("reportes") or ctx.puede("ver_todo")
    docs = _filas(s, Documento, _COLS_ALERTAS, Documento.empresa_id == e.id, Documento.ambiente == e.ambiente) if ver_ventas else []   # 3.87: solo las columnas que usa
    suc = getattr(ctx, "sucursal", None)
    if suc is not None and getattr(ctx, "sucursal_fija", False):      # 4.5: el amarrado a una sucursal solo ve las alertas y los cobros de ella (como _documento_ctx y _pagos_visibles)
        docs = sucursales.filtrar(docs, suc)
    if ctx.puede("facturar"):
        hace30 = (hoy - _td(days=30)).isoformat()
        rech = [d for d in docs if d.estado in ("rechazado", "error") and (d.fecha_emision or "")[:10] >= hace30]
        if rech:
            avisar("err", f"{len(rech)} comprobante{'s' if len(rech) != 1 else ''} rechazado{'s' if len(rech) != 1 else ''} o con error en los últimos 30 días", "#/ventas/facturas")
        espera = [d for d in docs if d.estado in ("firmado", "enviado")]
        if espera:
            avisar("warn", f"{len(espera)} comprobante{'s' if len(espera) != 1 else ''} esperando respuesta de Hacienda", "#/ventas/facturas")
        pend = s.exec(select(modulos.FacturaPendiente).where(modulos.FacturaPendiente.empresa_id == e.id, modulos.FacturaPendiente.estado == "pendiente")).all()
        if pend:
            avisar("info", f"{len(pend)} factura{'s' if len(pend) != 1 else ''} recurrente{'s' if len(pend) != 1 else ''} pendiente{'s' if len(pend) != 1 else ''} de emitir", "#/ventas/recurrentes")
    # cobros: vencido y lo que vence en las próximas 4 semanas (en colones)
    flujo = None
    if ver_ventas:
        semanas = [0.0] * 5; vencido = 0.0; n_venc = 0
        for d in docs:
            if d.tipo_documento not in ("01", "04", "09") or (d.estado or "") in resumen.EXCLUIR_ESTADOS:
                continue
            saldo = modulos.saldo_documento(d)
            if saldo <= 0.01:
                continue
            monto = resumen._a_crc(d.moneda, saldo, resumen.tc_doc(d), None)
            v = (d.fecha_vencimiento or d.fecha_emision or "")[:10]
            if v < hs:
                vencido += monto; n_venc += 1
            else:
                k = (date.fromisoformat(v) - hoy).days // 7
                if k < 5:
                    semanas[k] += monto
        flujo = {"vencido": round(vencido, 2), "semanas": [{"desde": (hoy + _td(days=7 * i)).isoformat(), "monto": round(m, 2)} for i, m in enumerate(semanas[:4])]}
        if n_venc:
            avisar("warn", f"{n_venc} factura{'s' if n_venc != 1 else ''} vencida{'s' if n_venc != 1 else ''} por cobrar (₡{vencido:,.0f})".replace(",", "."), "#/ventas/facturas")
    if ctx.puede("gastos"):
        rec = s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == e.id, recepcion.Recibido.respuesta == None)).all()  # noqa: E711
        limite = (hoy + _td(days=5)).isoformat()
        prox = sorted(r.fecha_limite for r in rec if r.fecha_limite and hs <= r.fecha_limite <= limite)
        if prox:
            avisar("warn", f"{len(prox)} comprobante{'s' if len(prox) != 1 else ''} de proveedores por aceptar; el primer plazo vence el {prox[0][8:10]}/{prox[0][5:7]}", "#/gastos/recepcion")
    if ctx.puede("inventario") or ctx.puede("gastos"):                # 3.87: ítems en o bajo su existencia mínima (sin mínimo no cuentan)
        try:
            n_rep = len(inventario.por_reponer(s, e.id, suc.bodega_id if (suc is not None and getattr(ctx, "sucursal_fija", False)) else None, solo_conteo=True)["items"])   # 4.5: la bodega de su sucursal
        except Exception:  # noqa: BLE001  el aviso nunca impide cargar el Inicio
            n_rep = 0
        if n_rep:
            avisar("warn", f"{n_rep} ítem{'s' if n_rep != 1 else ''} por reponer (en o bajo su existencia mínima)", "#/inventario/reponer")
    if ctx.puede("configurar") and e.p12_vence:
        dias = (date.fromisoformat(e.p12_vence[:10]) - hoy).days
        if dias <= 60:
            avisar("err" if dias <= 15 else "warn", f"La llave criptográfica de Hacienda vence en {dias} días", "#/configuracion/hacienda")
    if ctx.puede("catalogos") or ctx.puede("facturar"):
        hasta = (hoy + _td(days=30)).isoformat()
        exo = s.exec(select(exoneraciones.ExoneracionCliente).where(exoneraciones.ExoneracionCliente.empresa_id == e.id,
                                                                    exoneraciones.ExoneracionCliente.activa == True)).all()  # noqa: E712
        por_vencer = [x for x in exo if x.fecha_vencimiento and hs <= x.fecha_vencimiento[:10] <= hasta]
        if por_vencer:
            avisar("info", f"{len(por_vencer)} exoneración{'es' if len(por_vencer) != 1 else ''} de clientes vence{'n' if len(por_vencer) != 1 else ''} en los próximos 30 días", "#/contactos")
    return {"alertas": alertas, "flujo": flujo}


@app.get("/api/resumen")
def resumen_negocio(request: Request, periodo: str = "mes", desde: Optional[str] = None, hasta: Optional[str] = None, detalle: int = 0,
                    ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Resumen del negocio (Inicio) y reporte ejecutivo: cifras del período en todas las monedas de la empresa (app/resumen.py)."""
    if not (ctx.puede("reportes") or ctx.puede("ver_todo")):            # Solo lectura también lo ve (R131)
        raise HTTPException(403, "Su rol no tiene acceso a los reportes")
    e = ctx.empresa
    hoy = ahora_cr().date()
    try:
        d1, d2, a1, a2 = resumen.rango(periodo, hoy, desde, hasta)
    except ValueError:
        raise HTTPException(400, "Fechas inválidas (use AAAA-MM-DD)")
    tc = None
    try:
        t = tipo_cambio.obtener()
        margen = e.margen_cambiario if e.margen_cambiario is not None else 5.0
        tc = tipo_cambio.aplicado(t.get("venta"), margen)
    except Exception:  # noqa: BLE001  sin tipo de cambio del día: se usa el de cada comprobante
        tc = None
    docs = sucursales.filtrar(_filas(s, Documento, _COLS_RESUMEN, Documento.empresa_id == e.id, Documento.ambiente == e.ambiente), getattr(ctx, "sucursal", None))   # 3.66; 3.87: columnas
    ids = [d.id for d in docs if d.tipo_documento in resumen.VENTAS and d1 <= (d.fecha_emision or "")[:10] <= d2 and (d.estado or "") not in resumen.EXCLUIR_ESTADOS]
    lineas = _filas(s, DocumentoLinea, _COLS_LINEAS_RESUMEN, DocumentoLinea.documento_id.in_(ids)) if ids else []
    recibidos = s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == e.id)).all()
    compras = modulos.leer(s, e.id, "compras", [])
    completo = ctx.puede("reportes") or ctx.puede("ver_todo")
    if not completo and detalle:
        raise HTTPException(403, "El reporte ejecutivo es para administradores, contadores y solo lectura")
    out = resumen.calcular(docs, lineas, recibidos, compras if isinstance(compras, list) else [], d1, d2, a1, a2, tc, hoy, con_detalle=bool(detalle))
    if completo:
        out["alcance"] = "completo"
    else:                                   # vendedores: solo lo suyo (ventas, cobros, clientes, ítems); sin gastos, IVA ni cuentas por pagar
        for k in ("cxp", "iva", "egresos", "egresos_docs", "gastos_por_proveedor"):
            out.pop(k, None)
        for d in out["por_dia"]:
            d["egresos"] = {"CRC": 0.0, "USD": 0.0, "nativo": {}}
        out["alcance"] = "ventas"
    return _json_rapido(request, resumen.finitos(out))   # ningún NaN o infinito llega a la respuesta; 3.87: vía rápida con gzip (reporte ejecutivo 1,9 MB → 160 KB)


@app.get("/api/resumen/iva")
def resumen_iva(desde: str, hasta: str, moneda: str = "", ctx: Contexto = Depends(contexto), s: Session = Depends(sesion_empresa)):
    """Ventas y compras del período por tarifa de IVA, en colones (Reportes › Fiscales › Declaración de IVA D-104). 4.3: con
    `moneda` (CRC o USD) solo lo hecho en esa moneda, en esa moneda."""
    if moneda and moneda.upper() not in ("CRC", "USD", "EUR"):
        raise HTTPException(400, "Moneda no válida")
    if not (ctx.puede("reportes") or ctx.puede("ver_todo")):
        raise HTTPException(403, "Su rol no tiene acceso a los reportes")
    e = ctx.empresa
    hoy = ahora_cr().date()
    try:
        if not desde or not hasta:
            raise ValueError("fechas")
        d1, d2, _a1, _a2 = resumen.rango("rango", hoy, desde, hasta)
    except ValueError:
        raise HTTPException(400, "Fechas inválidas (use AAAA-MM-DD)")
    tc = None
    try:
        t = tipo_cambio.obtener()
        margen = e.margen_cambiario if e.margen_cambiario is not None else 5.0
        tc = tipo_cambio.aplicado(t.get("venta"), margen)
    except Exception:  # noqa: BLE001
        tc = None
    tipos = resumen.VENTAS + resumen.DEVOLUCIONES + resumen.COMPRA_EMITIDA + ("10",)     # el REP aporta el IVA diferido
    docs = [d for d in s.exec(select(Documento).where(Documento.empresa_id == e.id, Documento.ambiente == e.ambiente)).all()
            if d.tipo_documento in tipos and d1 <= (d.fecha_emision or "")[:10] <= d2 and (d.estado or "") not in resumen.EXCLUIR_ESTADOS]
    ids = [d.id for d in docs]
    lineas = s.exec(select(DocumentoLinea).where(DocumentoLinea.documento_id.in_(ids))).all() if ids else []
    recibidos = s.exec(select(recepcion.Recibido).where(recepcion.Recibido.empresa_id == e.id)).all()
    compras = modulos.leer(s, e.id, "compras", [])
    filas = resumen.iva_por_tarifa(docs, lineas, recibidos, compras if isinstance(compras, list) else [], d1, d2, tc, moneda.upper() or None)
    return resumen.finitos({"desde": d1, "hasta": d2, "tc": tc, "tc_disponible": bool(tc), "moneda": moneda.upper() or "CRC", "filas": filas})


# ---- recursos humanos (app/rrhh.py): parámetros de la empresa, nómina, planilla y liquidación
class RrhhCalcIn(BaseModel):
    empleado: dict
    periodo: str = "mensual"
    horas: Optional[float] = None
    horas_extra: float = 0
    otros_ingresos: float = 0
    otras_deducciones: float = 0
    factor_manual: Optional[float] = None
    dias_vac_disfrutados: float = 0
    hasta: Optional[str] = None
    dias_ausencia: float = Field(0, ge=0)
    horas_feriado: float = Field(0, ge=0)
    no_salariales: float = Field(0, ge=0)
    deducciones: list[dict] = Field(default_factory=list, max_length=50)
    ingresos: list[dict] = Field(default_factory=list, max_length=50)


class RrhhPlanillaIn(BaseModel):
    periodo: str = "mensual"
    filas: list[dict] = []


class RrhhLiquidacionIn(BaseModel):
    empleado: dict
    fecha_salida: str
    motivo: str = "despido_con"
    dias_vac_disfrutados: float = 0
    dias_pendientes: float = 0
    salario_promedio_mensual: Optional[float] = None
    preaviso_otorgado: bool = False
    devengado_aguinaldo: Optional[float] = None
    # 4.7 (C1): lo ya pagado y retenido al empleado en el mes de la salida (planillas pagadas que cierran en ese mes): la renta del
    # salario pendiente y de las vacaciones va sobre el mes completo. Sin ellos, como si no se le hubiera pagado nada más en el mes
    bruto_previo: Optional[float] = Field(None, ge=0, le=1e13)
    renta_previa: Optional[float] = Field(0, ge=0, le=1e13)


def _rrhh_parametros(s: Session, eid: int) -> dict:
    ajustes = modulos.leer(s, eid, "rrhh_parametros", None)
    return rrhh.parametros_efectivos(ajustes if isinstance(ajustes, dict) else None)


@app.get("/api/rrhh/parametros")
def rrhh_parametros(ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    p = _rrhh_parametros(s, ctx.empresa.id)
    return {"efectivos": p, "referencia": rrhh.parametros_efectivos(None), "puestos": [{"nombre": n, "categoria": c} for n, c in rrhh.PUESTOS],
            "periodos": rrhh.NOMBRE_PERIODO, "motivos": rrhh.MOTIVOS, "tipos_ausencia": rrhh.TIPOS_AUSENCIA,
            # 4.7: la tasa patronal (sin la póliza del INS) descuenta el INA si la empresa no lo paga y suma el INS aparte de la póliza
            "tasas": {"obrero": rrhh.tasa_total(p["obrero"]), "patrono": round(rrhh.tasa_total(rrhh.tasas_patrono(p)) + float(p.get("ins_adicional") or 0), 4),
                      "provisiones": rrhh.tasa_total(p["provisiones"])},
            # 4.7: lo guardado en un año anterior que ya no se aplica (con su aviso), qué es legal y qué es de la empresa, y el orden en
            # que se aplican los rebajos cuando el salario no alcanza
            "avisos": p.get("avisos_parametros") or [], "ignorados": p.get("parametros_ignorados") or [], "anio_guardado": p.get("anio_guardado"),
            "clasificacion": {"legales": list(rrhh.CLAVES_LEGALES), "empresa": list(rrhh.CLAVES_EMPRESA)}, "orden_rebajos": list(rrhh.ORDEN_REBAJOS),
            "motor": rrhh.MOTOR_VERSION}


@app.post("/api/rrhh/calcular")
def rrhh_calcular(data: RrhhCalcIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    p = _rrhh_parametros(s, ctx.empresa.id)
    hoy = data.hasta or ahora_cr().date().isoformat()
    try:
        n = rrhh.calcular_nomina(data.empleado, p, data.periodo, data.horas, data.horas_extra, data.otros_ingresos, data.otras_deducciones, data.factor_manual,
                                 data.dias_ausencia, data.horas_feriado, data.no_salariales, data.deducciones, data.ingresos)
    except (ValueError, KeyError, TypeError) as ex:
        raise HTTPException(400, str(ex) or "Datos del empleado inválidos")
    n["vacaciones"] = rrhh.vacaciones(data.empleado.get("fecha_ingreso"), hoy, data.dias_vac_disfrutados, p)
    n["antiguedad"] = rrhh.antiguedad(data.empleado.get("fecha_ingreso"), hoy)
    n["provision_mensual"] = rrhh.provision_mensual(n["salario_mensual"], p)
    n["parametros_usados"] = rrhh.parametros_usados(p)                   # 4.7: con qué parámetros se calculó
    n["avisos_parametros"] = p.get("avisos_parametros") or []
    return n


@app.post("/api/rrhh/planilla")
def rrhh_planilla(data: RrhhPlanillaIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    p = _rrhh_parametros(s, ctx.empresa.id)
    if len(data.filas) > 500:
        raise HTTPException(400, "Una planilla admite hasta 500 empleados")
    try:
        return rrhh.calcular_planilla(data.filas, p, data.periodo)
    except (ValueError, KeyError, TypeError) as ex:
        raise HTTPException(400, str(ex) or "Datos de la planilla inválidos")


@app.post("/api/rrhh/liquidacion")
def rrhh_liquidacion(data: RrhhLiquidacionIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    p = _rrhh_parametros(s, ctx.empresa.id)
    try:
        return rrhh.liquidacion(data.empleado, p, data.fecha_salida, data.motivo, data.dias_vac_disfrutados, data.dias_pendientes, data.salario_promedio_mensual, data.preaviso_otorgado, data.devengado_aguinaldo,
                                bruto_previo=data.bruto_previo, renta_previa=data.renta_previa or 0)
    except (ValueError, KeyError, TypeError) as ex:
        raise HTTPException(400, str(ex) or "Datos de la liquidación inválidos")


# ---- 4.22: pago de las cargas del mes (CCSS, INS y renta retenida). El registro 'rrhh_pagos_cargas' lo escribe SOLO el servidor:
# [{id, mes 'AAAA-MM', tipo 'ccss' | 'ins' | 'renta', monto, detalle {ccss_obrero, ccss_patronal} (solo ccss), cuenta, fecha_pago,
# comprobante, ref_mov 'cargas:AAAA-MM:tipo', planillas y liquidaciones (los ids que sumaron), estado 'Pagado', registrado_por,
# registrado_en}]. El monto NUNCA viene del navegador: se calcula aquí con las planillas y las liquidaciones pagadas guardadas
# (rrhh.cargas_mes, los mismos campos con que el asiento contable deja esos pasivos). Un pago guardado no se cambia ni se borra.
_MESES_RRHH = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "setiembre", "octubre", "noviembre", "diciembre")
CLAVE_PAGOS_CARGAS = "rrhh_pagos_cargas"


def _mes_legible(mes) -> str:
    m = re.fullmatch(r"(\d{4})-(0[1-9]|1[0-2])", str(mes or ""))
    return f"{_MESES_RRHH[int(m.group(2)) - 1]} de {m.group(1)}" if m else str(mes or "")


def _nombre_pago_cargas(x: dict) -> str:
    """«CCSS de octubre de 2026»: cómo se nombra un pago de cargas en los mensajes y en el historial de operaciones."""
    return f"{rrhh.TIPOS_CARGA.get(x.get('tipo') if isinstance(x.get('tipo'), str) else '', 'cargas')} de {_mes_legible(x.get('mes'))}"


def _cargas_guardadas(s: Session, eid: int, mes: str) -> dict:
    """Las cargas del mes según las planillas y las liquidaciones guardadas (rrhh.cargas_mes, con la regla de «pagado» del servidor).
    Solo se leen los documentos que mencionan ese mes (no la lista completa, que puede ser de años)."""
    de = lambda clave: [x for x in _items_que_mencionan(s, eid, clave, [mes]) if isinstance(x, dict)]   # noqa: E731
    return rrhh.cargas_mes(mes, de("planillas"), de("liquidaciones"), _rrhh_pagado)


def _pagos_cargas(s: Session, eid: int) -> list:
    v = modulos.leer(s, eid, CLAVE_PAGOS_CARGAS, []) or []
    return [x for x in v if isinstance(x, dict)] if isinstance(v, list) else []


def _refs_en_bancos(s: Session, eid: int, refs) -> set:
    """De esas refs, las que tienen su movimiento en Bancos."""
    refs = {r for r in refs if isinstance(r, str) and r}
    return {m.get("ref") for m in _items_que_mencionan(s, eid, "movimientos", refs) if isinstance(m, dict) and m.get("ref") in refs}


def _sin_pagar_del_mes(c: dict) -> Optional[str]:
    """El aviso de lo que falta pagar del mes (planillas y liquidaciones), o None si todo lo del mes está pagado."""
    pl, lq = c["sin_pagar"]["planillas"], c["sin_pagar"]["liquidaciones"]
    if not pl and not lq:
        return None
    lista = lambda l: ", ".join(l[:6]) + (f" y {len(l) - 6} más" if len(l) > 6 else "")   # noqa: E731
    partes = ([f"{len(pl)} {'planilla' if len(pl) == 1 else 'planillas'} ({lista(pl)})"] if pl else []) + \
             ([f"{len(lq)} {'liquidación' if len(lq) == 1 else 'liquidaciones'} ({lista(lq)})"] if lq else [])
    return (f"Hay {' y '.join(partes)} de {_mes_legible(c['mes'])} sin pagar: el pago de las cargas se registra cuando todas las planillas y "
            "liquidaciones del mes están pagadas (o eliminadas), para que el monto del mes esté completo")


@app.get("/api/rrhh/cargas")
def rrhh_cargas(mes: str, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """4.22: las cargas de un mes (AAAA-MM) calculadas con lo guardado: por cada tipo (CCSS, INS y renta) el monto, su pago si ya
    se registró y si ese pago tiene su salida en Bancos; y si hay planillas o liquidaciones del mes sin pagar (con ellas no se
    registra el pago). `anterior`: el mes es de antes de que existiera esta función (rrhh.MES_INICIO_PAGO_CARGAS): sus cargas se
    pagaban a mano y la pantalla no las ofrece como «pendientes». No cambia nada."""
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", mes or ""):
        raise HTTPException(400, "Indique el mes como AAAA-MM")
    eid = ctx.empresa.id
    c = _cargas_guardadas(s, eid, mes)
    pagos = {p.get("tipo"): p for p in _pagos_cargas(s, eid) if p.get("mes") == mes}
    en_bancos = _refs_en_bancos(s, eid, [p.get("ref_mov") for p in pagos.values()])
    filas = []
    for tipo in rrhh.TIPOS_CARGA:
        p = pagos.get(tipo)
        filas.append({"tipo": tipo, "corto": rrhh.TIPOS_CARGA[tipo], "nombre": rrhh.NOMBRE_CARGA[tipo], "monto": rrhh.monto_carga(c, tipo),
                      "detalle": {"ccss_obrero": c["ccss_obrero"], "ccss_patronal": c["ccss_patronal"]} if tipo == "ccss" else None,
                      "pago": p, "en_bancos": (p.get("ref_mov") in en_bancos) if p else None})
    return {"mes": mes, "nombre_mes": _mes_legible(mes), "cargas": filas, "planillas": len(c["planillas"]), "liquidaciones": len(c["liquidaciones"]),
            "sin_pagar": c["sin_pagar"], "bloqueo": _sin_pagar_del_mes(c), "anterior": mes < rrhh.MES_INICIO_PAGO_CARGAS}


class PagoCargasIn(BaseModel):
    mes: str = ""
    tipo: str = ""
    cuenta: str = ""
    fecha_pago: str = ""
    comprobante: Optional[str] = ""
    confirma_anterior: bool = False        # 4.22: «este pago todavía no está registrado», para un mes anterior a esta función
    # 4.22: el monto que el usuario vio y confirmó en el cuadro. NO es el que se guarda (ese lo calcula siempre el servidor): solo se
    # compara, y si ya no coincide no se registra nada (entretanto se pagó otra planilla del mes). Sin él no se compara
    monto_esperado: Optional[float] = Field(None, allow_inf_nan=False)


def _movimiento_pago_cargas(s: Session, eid: int, p: dict, reemplazar: bool) -> bool:
    """La salida en Bancos de un pago de cargas guardado, con SUS datos (monto, cuenta, fecha y ref): True si quedó registrada."""
    comp = str(p.get("comprobante") or "").strip()
    return modulos.registrar_movimiento_banco(s, eid, str(p.get("cuenta") or ""), -float(p.get("monto") or 0), str(p.get("fecha_pago") or ""),
                                              f"Cargas {rrhh.TIPOS_CARGA.get(p.get('tipo'), '')} {p.get('mes')}".strip() + (f" · comprobante {comp}" if comp else ""),
                                              str(p.get("ref_mov") or ""), reemplazar, "CRC", 1)


@app.post("/api/rrhh/pago-cargas")
def rrhh_pagar_cargas(data: PagoCargasIn, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """4.22: registra el pago de las cargas de un mes (CCSS, INS o renta retenida). El MONTO lo calcula el servidor con las planillas y
    las liquidaciones pagadas guardadas (lo que mande el navegador en un «monto» no se lee; `monto_esperado`, el que el usuario vio
    en el cuadro, solo se compara: si ya no es el calculado responde 409 «cargas_monto_cambio» y no guarda nada). Rechaza (409) si el
    mes tiene planillas o liquidaciones sin pagar, si no hay nada que pagar de ese tipo o si ese mes y tipo ya se registró; y (400)
    si la cuenta no es una de Bancos en colones. Guarda el pago y, con sus datos, la salida en Bancos (ref 'cargas:AAAA-MM:tipo').
    La revisión y el guardado del pago van en un solo paso (candado de escritura): dos envíos a la vez no registran dos pagos. En el
    historial de operaciones queda el tipo, el mes y la cuenta, nunca el monto.
    Las cargas de un mes anterior a esta función (rrhh.MES_INICIO_PAGO_CARGAS) se pagaban a mano: sin `confirma_anterior` responde
    409 «cargas_mes_anterior» (registrarlas aquí duplicaría la salida en Bancos y el asiento, y un pago registrado no se elimina)."""
    eid = ctx.empresa.id
    mes, tipo, cuenta, fecha = str(data.mes or "").strip(), str(data.tipo or "").strip(), str(data.cuenta or "").strip(), str(data.fecha_pago or "").strip()
    comprobante = re.sub(r"\s+", " ", re.sub(r"[\x00-\x1f\x7f]", " ", str(data.comprobante or ""))).strip()
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", mes):
        raise HTTPException(400, "Indique el mes de las cargas como AAAA-MM")
    if tipo not in rrhh.TIPOS_CARGA:
        raise HTTPException(400, "Indique qué se paga: CCSS, INS o renta")
    if _fecha_iso_rrhh(fecha) is None:
        raise HTTPException(400, "La fecha de pago no es válida")
    # un pago registrado no se cambia: una fecha con el año mal escrito (2062, 2006) quedaría para siempre en Bancos y en los libros.
    # 4.22: tampoco una anterior al día 1 del mes que se paga (antes valía hasta un año antes: 05/11/2025 por 05/11/2026 pasaba, y las
    # cargas de un mes no se pagan antes de que ese mes empiece)
    if fecha > (ahora_cr().date() + timedelta(days=31)).isoformat() or fecha < mes + "-01":
        raise HTTPException(400, "Revise la fecha de pago: no puede ser anterior al mes que se paga ni estar a más de un mes de hoy")
    if len(comprobante) > 60:
        raise HTTPException(400, "El número de comprobante admite hasta 60 letras")
    if not cuenta or len(cuenta) > 80:
        raise HTTPException(400, "Seleccione la cuenta de Bancos de la que sale el pago")
    banco = modulos.cuenta_banco(s, eid, cuenta)
    if banco is None:
        raise HTTPException(400, f"La cuenta «{cuenta}» no existe en Bancos y cajas: elija una de la lista")
    if (banco.get("moneda") or "CRC") != "CRC" or banco.get("tipo") == "Tarjeta de crédito":
        raise HTTPException(400, "Las cargas se pagan en colones: elija una cuenta de banco o de efectivo en colones")
    nombre = _nombre_pago_cargas({"tipo": tipo, "mes": mes})
    if mes < rrhh.MES_INICIO_PAGO_CARGAS and data.confirma_anterior is not True:
        # 4.22: el sistema no sabe si las cargas de ese mes ya se pagaron a mano (un movimiento en Bancos y un asiento manual): quien
        # las registra aquí tiene que decir que no. La pantalla lo pregunta antes de enviar
        raise HTTPException(409, {"codigo": "cargas_mes_anterior", "mensaje": f"Las cargas de {nombre} son de un mes anterior a esta función ("
                                  f"{_mes_legible(rrhh.MES_INICIO_PAGO_CARGAS)}) y se pagaban fuera de ella. Si ese pago ya está en Bancos o en la contabilidad, no las "
                                  "registre aquí: quedaría dos veces y un pago registrado no se elimina. Para registrarlas, confirme que ese pago todavía no está registrado"})
    _candado_registro(s, eid, CLAVE_PAGOS_CARGAS)          # revisar que no esté pagado y guardarlo, en un solo paso
    ya = next((p for p in _pagos_cargas(s, eid) if p.get("mes") == mes and p.get("tipo") == tipo), None)
    if ya is not None:
        s.rollback()
        raise HTTPException(409, {"codigo": "cargas_ya_pagadas", "mensaje": f"Las cargas de {nombre} ya se registraron como pagadas"
                                  + (f" (el {_fecha_pantalla(ya.get('fecha_pago'))}" + (f" desde {ya.get('cuenta')}" if ya.get("cuenta") else "") + ")" if ya.get("fecha_pago") else "")
                                  + ": no se registró otro pago ni otra salida en Bancos"})
    c = _cargas_guardadas(s, eid, mes)
    falta = _sin_pagar_del_mes(c)
    if falta:
        s.rollback()
        raise HTTPException(409, falta)
    monto = rrhh.monto_carga(c, tipo)
    if not (math.isfinite(monto) and 0 < monto < 1e13):
        s.rollback()
        raise HTTPException(409, f"No hay {nombre} por pagar: las planillas y las liquidaciones pagadas de ese mes no dejaron ese monto")
    if data.monto_esperado is not None and abs(monto - data.monto_esperado) >= 0.005:
        # 4.22: el usuario confirmó otra cifra (la de su última lectura); un pago registrado no se deshace, así que no se guarda uno
        # por un monto que nadie vio. La pantalla relee, cierra el cuadro y muestra el monto de ahora
        s.rollback()
        raise HTTPException(409, {"codigo": "cargas_monto_cambio", "mensaje": f"El monto de {nombre} cambió: ahora es {rrhh._colones(monto)} y en pantalla decía "
                                  f"{rrhh._colones(data.monto_esperado)}. Revíselo y confirme de nuevo"})
    pago = {"mes": mes, "tipo": tipo, "monto": monto, "cuenta": cuenta, "fecha_pago": fecha, "comprobante": comprobante, "ref_mov": f"cargas:{mes}:{tipo}",
            "planillas": c["planillas"], "liquidaciones": c["liquidaciones"], "estado": "Pagado",
            "registrado_por": str(getattr(ctx.usuario, "correo", None) or ""), "registrado_en": ahora_cr().isoformat(timespec="seconds")}
    if tipo == "ccss":
        pago["detalle"] = {"ccss_obrero": c["ccss_obrero"], "ccss_patronal": c["ccss_patronal"]}
    from sqlalchemy.exc import IntegrityError
    from sqlalchemy.orm.exc import StaleDataError
    try:
        pago["id"] = _agregar_registros(s, eid, CLAVE_PAGOS_CARGAS, [pago])[0]
    except (IntegrityError, StaleDataError):
        s.rollback()
        raise HTTPException(409, "No se pudo guardar por cambios simultáneos: actualice la pantalla y, si el pago no aparece, regístrelo de nuevo")
    # el pago ya quedó guardado; su salida en Bancos se registra con SUS datos. Si esto fallara, el pago no se pierde ni se repite:
    # la pantalla avisa que falta la salida y la registra con /api/rrhh/pago-cargas/<id>/banco
    en_bancos = False
    try:
        en_bancos = _movimiento_pago_cargas(s, eid, pago, True)
    except Exception:  # noqa: BLE001
        s.rollback()
        logging.getLogger(__name__).exception("Empresa %s: el pago de cargas %s quedó guardado sin su salida en Bancos", eid, pago["ref_mov"])
    _auditar(ctx, "rrhh_cargas_pagadas", f"Cargas de {nombre} registradas como pagadas desde {cuenta}"[:500])
    return {"ok": True, "pago": pago, "en_bancos": en_bancos}


@app.post("/api/rrhh/pago-cargas/{pago_id}/banco")
def rrhh_pago_cargas_banco(pago_id: int, ctx: Contexto = Depends(requiere("rrhh")), s: Session = Depends(sesion_empresa)):
    """4.22: registra en Bancos la salida de un pago de cargas ya guardado que quedó sin ella (el servidor se detuvo entre guardar el
    pago y registrar la salida). Usa los datos del pago guardado, nada del navegador, y no duplica: si la salida ya está, no hace nada."""
    eid = ctx.empresa.id
    p = _items_guardados(s, eid, CLAVE_PAGOS_CARGAS, [pago_id]).get(pago_id)
    if not isinstance(p, dict):
        raise HTTPException(404, "El pago de cargas ya no existe: recargue la página")
    if p.get("ref_mov") in _refs_en_bancos(s, eid, [p.get("ref_mov")]):
        return {"ok": True, "ya": True}
    try:
        hecho = _movimiento_pago_cargas(s, eid, p, False)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if not hecho:
        if p.get("ref_mov") in _refs_en_bancos(s, eid, [p.get("ref_mov")]):   # otra petición la registró en ese instante
            return {"ok": True, "ya": True}
        raise HTTPException(409, f"No se pudo registrar la salida: la cuenta «{p.get('cuenta')}» ya no existe en Bancos y cajas. Regístrela a mano en Bancos")
    _auditar(ctx, "rrhh_cargas_banco", f"Salida en Bancos de las cargas de {_nombre_pago_cargas(p)} registrada desde {p.get('cuenta')}"[:500])
    return {"ok": True, "ya": False}


@app.post("/api/rrhh/empleados/importar")
def rrhh_importar_empleados(archivo: UploadFile = File(...), confirmar: bool = Form(False), ctx: Contexto = Depends(requiere("rrhh")),
                            s: Session = Depends(sesion_empresa)):
    """4.21: importa empleados NUEVOS desde un Excel (.xlsx) o un CSV de hasta 2 MB y 500 filas, con las columnas de la plantilla de
    Recursos humanos › Empleados › Importar. El archivo se lee en memoria y se descarta: no se guarda en ninguna parte. Sin
    `confirmar` devuelve la vista previa (una fila por empleado: Lista, Con avisos o Con errores, con sus mensajes) y no cambia nada.
    Con `confirmar` vuelve a leer y a validar el MISMO archivo (no confía en la vista previa del navegador) y agrega solo las filas
    sin errores. Toda la validación es de formato (rrhh.revisar_importacion_empleados). El límite de empleados del plan solo se
    informa. Queda una sola fila en el historial de operaciones, sin montos ni identificaciones."""
    nombre = str(archivo.filename or "").strip()
    ext = nombre.rsplit(".", 1)[-1].lower() if "." in nombre else ""
    if ext not in ("xlsx", "csv"):
        raise HTTPException(400, "Suba un archivo de Excel (.xlsx) o un CSV (.csv): puede descargar la plantilla en esta misma ventana")
    datos = _leer_subida(archivo, rrhh.MAX_BYTES_IMPORTAR)
    if ext == "xlsx" and not datos.startswith(b"PK"):
        raise HTTPException(400, "El archivo no es un Excel .xlsx válido: guárdelo de nuevo como «Libro de Excel (.xlsx)» o como CSV")
    try:
        # con los lectores de rrhh, que acotan las filas y las columnas que recorren (los de la importación de ítems, de la misma
        # firma, arman en memoria el archivo entero: una hoja muy ancha o un CSV de un millón de líneas son cientos de MB)
        tabla = rrhh.leer_xlsx_empleados(datos) if ext == "xlsx" else rrhh.leer_csv_empleados(datos)
        filas, ignoradas = rrhh.filas_importar_empleados(tabla)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    except Exception:  # noqa: BLE001  cualquier otra cosa al leerlo es un problema del archivo, no del servidor
        raise HTTPException(400, "No se pudo leer el archivo: guárdelo de nuevo desde Excel como «Libro de Excel (.xlsx)» o como CSV y súbalo otra vez")
    eid = ctx.empresa.id
    if confirmar:                                          # revisar contra los empleados que ya existen y agregar, en un solo paso: dos
        _candado_registro(s, eid, "empleados")             # importaciones del mismo archivo a la vez no meten dos veces a nadie
    params = _rrhh_parametros(s, eid)
    rev = rrhh.revisar_importacion_empleados(filas, modulos.leer(s, eid, "empleados", []) or [], params, modulos.leer(s, eid, "rrhh_departamentos", []) or [])
    importados = 0
    if confirmar and rev["empleados"]:
        hoy = ahora_cr().date().isoformat()
        items = [{**e, "historial": [{"fecha": hoy, "modo": e["modo_salario"], "salario": e["salario_mensual"] if e["modo_salario"] == "mensual" else e["salario_hora"],
                                      "mensual": rrhh.salario_mensual(e, params), "motivo": "Importación"}]} for e in rev["empleados"]]
        from sqlalchemy.exc import IntegrityError
        from sqlalchemy.orm.exc import StaleDataError
        try:
            importados = len(_agregar_registros(s, eid, "empleados", items))
        except (IntegrityError, StaleDataError):           # otra persona guardó empleados en el mismo instante: no entró ninguno
            s.rollback()
            raise HTTPException(409, "No se pudo guardar por cambios simultáneos: revise la lista de empleados y, si faltan, importe de nuevo (quien ya entró sale «ya existe»)")
        except ValueError as ex:
            s.rollback()
            raise HTTPException(400, str(ex))
        # el nombre del archivo, sin signos raros ni números largos (una cédula en el nombre no debe quedar en el historial)
        limpio = re.sub(r"\d{9,}", "…", re.sub(r"[^\w .()-]+", "_", nombre))[:80]
        _auditar(ctx, "rrhh_ficha_importada", f"{importados} {'empleado importado' if importados == 1 else 'empleados importados'} desde {limpio}")
    return {"filas": rev["filas"], "validas": rev["validas"], "con_error": rev["con_error"], "con_avisos": rev["con_avisos"], "columnas_ignoradas": ignoradas,
            "importados": importados, "plan": planes.empleados_plan(ctx.empresa, s)}


CSP = ("default-src 'self'; script-src 'self' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: blob: https://*.tile.openstreetmap.org; font-src 'self' data:; connect-src 'self' http://127.0.0.1:9800 http://localhost:9800; frame-src 'self' blob:; object-src 'none'; base-uri 'self'; "
       "form-action 'self'; frame-ancestors 'self'")
# página pública de un negocio con sus píxeles (3.58): además de lo propio, los scripts y avisos de Google y Meta
# 3.87: también los destinos de medición de Google Ads y de Google Signals (www.google.com/g/collect, *.g.doubleclick.net,
# googleadservices y el marco de remarketing td.doubleclick.net); los scripts siguen solo de googletagmanager y de Meta
CSP_PIXELES = ("default-src 'self'; script-src 'self' 'unsafe-eval' https://www.googletagmanager.com https://connect.facebook.net; style-src 'self' 'unsafe-inline'; "
               "img-src 'self' data: blob: https://*.tile.openstreetmap.org https://www.facebook.com https://www.google-analytics.com https://*.google-analytics.com https://www.googletagmanager.com "
               "https://www.google.com https://www.google.co.cr https://*.g.doubleclick.net https://www.googleadservices.com; font-src 'self' data:; "
               "connect-src 'self' https://www.google-analytics.com https://*.google-analytics.com https://*.analytics.google.com https://www.googletagmanager.com https://www.facebook.com https://connect.facebook.net "
               "https://www.google.com https://*.g.doubleclick.net https://www.googleadservices.com; "
               "frame-src 'self' blob: https://www.facebook.com https://td.doubleclick.net; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'")


# página pública con el widget Turnstile de Cloudflare (3.68): su script, su marco y su verificación
CSP_TURNSTILE = (CSP.replace("script-src 'self' 'unsafe-eval';", "script-src 'self' 'unsafe-eval' https://challenges.cloudflare.com;")
                 .replace("frame-src 'self' blob:;", "frame-src 'self' blob: https://challenges.cloudflare.com;")
                 .replace("connect-src 'self' ", "connect-src 'self' https://challenges.cloudflare.com "))
assert CSP_TURNSTILE.count("challenges.cloudflare.com") == 3


def _turnstile_en_app() -> bool:
    """3.84: la página de la aplicación deja cargar el recuadro de Cloudflare solo si hay una clave del sitio guardada."""
    try:
        return bool(sitio.turnstile_sitio())
    except Exception:  # noqa: BLE001
        return False


class _SinNumerosNoFinitos:
    """Rechaza (400) los cuerpos JSON con números no finitos (NaN, Infinity o un 1e999 que se vuelve infinito): Python los
    acepta al leer, pero guardados dejaban sin respuesta las lecturas de esos datos (la respuesta JSON no los admite).
    También pone un tope al tamaño del cuerpo JSON (413)."""
    TOPE = 30 * 1024 * 1024

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("method") not in ("POST", "PUT", "PATCH") or not scope.get("path", "").startswith("/api/"):
            return await self.app(scope, receive, send)
        cab = {k.lower(): v for k, v in (scope.get("headers") or [])}
        if b"json" not in cab.get(b"content-type", b"").lower():
            return await self.app(scope, receive, send)
        try:
            largo = int(cab.get(b"content-length", b"0") or 0)
        except ValueError:
            largo = 0
        if largo > self.TOPE:
            return await JSONResponse({"detail": "Los datos enviados son demasiado grandes"}, status_code=413)(scope, receive, send)
        trozos, total, mas = [], 0, True
        while mas:
            m = await receive()
            if m["type"] == "http.disconnect":       # el cliente se fue: la app recibe la desconexión y la maneja como siempre
                async def _desconectado():
                    return m
                return await self.app(scope, _desconectado, send)
            trozo = m.get("body", b""); trozos.append(trozo); total += len(trozo); mas = m.get("more_body", False)
            if total > self.TOPE:
                return await JSONResponse({"detail": "Los datos enviados son demasiado grandes"}, status_code=413)(scope, receive, send)
        cuerpo = b"".join(trozos)

        def _no(_c):
            raise OverflowError

        def _float(t):
            v = float(t)
            if not math.isfinite(v):
                raise OverflowError
            return v

        def _int(t):                                    # un entero de cientos de cifras tampoco se puede usar como monto
            if len(t) > 300:
                raise OverflowError
            return int(t)
        try:
            json.loads(cuerpo, parse_constant=_no, parse_float=_float, parse_int=_int)
        except OverflowError:
            return await JSONResponse({"detail": "Hay un número no válido (NaN o infinito) en los datos"}, status_code=400)(scope, receive, send)
        except (ValueError, RecursionError):
            pass                                        # JSON inválido o demasiado anidado: lo responde FastAPI como siempre
        entregado = False

        async def _receive():
            nonlocal entregado
            if not entregado:
                entregado = True
                return {"type": "http.request", "body": cuerpo, "more_body": False}
            return await receive()
        await self.app(scope, _receive, send)


app.add_middleware(_SinNumerosNoFinitos)


@app.exception_handler(OverflowError)
async def _numero_fuera_de_rango(request, exc):
    """Un entero demasiado grande para la base (más de 19 cifras en un campo numérico): 400 en lugar de error interno."""
    return JSONResponse({"detail": "Hay un número fuera de rango en los datos"}, status_code=400)


from starlette.exceptions import HTTPException as _HTTPExceptionStarlette  # noqa: E402


@app.exception_handler(_HTTPExceptionStarlette)
async def _pagina_no_encontrada(request, exc):
    """3.87: quien navega (pide HTML) a una dirección que no existe, o a la página de un negocio que ya no está, ve la página «no
    encontrada» del sitio con la marca y sus enlaces, en lugar de {"detail":"Not Found"}. La API, los archivos, los programas que no
    piden HTML y los demás errores siguen igual (JSON, con sus cabeceras)."""
    if (exc.status_code == 404 and request.method in ("GET", "HEAD") and not request.url.path.startswith("/api/")
            and "text/html" in request.headers.get("accept", "")):
        try:
            msg = exc.detail if isinstance(exc.detail, str) and exc.detail not in ("", "Not Found") else ""
            # 3.87: en el dominio o subdominio de un negocio, en /t/<negocio>, en el portal de soporte /soporte/<portal> y en los enlaces /p/
            # de comprobantes la ven sus clientes: va la variante neutra, sin la marca ni los botones de venta del sistema
            del_negocio = bool(_pedidos.negocio_de_host(request.headers.get("host", "")))
            neutra = del_negocio or request.url.path.startswith(("/p/", "/t/", "/soporte/"))
            from fastapi.responses import HTMLResponse
            return HTMLResponse(sitio.render_404(msg, neutra=neutra, con_inicio=del_negocio), status_code=404, headers={"X-Robots-Tag": "noindex"})
        except Exception:  # noqa: BLE001  si la página no se puede armar, la respuesta de siempre
            logging.getLogger(__name__).exception("No se pudo armar la página 404 del sitio")
    from fastapi.exception_handlers import http_exception_handler
    return await http_exception_handler(request, exc)


@app.middleware("http")
async def _cabeceras_seguridad(request, call_next):
    """Cabeceras de seguridad para exposición pública + sin caché para la interfaz (JS/CSS/HTML se sirven sin compilar)."""
    from .config import REDIRIGIR_PUBLICOS
    if REDIRIGIR_PUBLICOS and request.url.path.startswith("/p/") and re.fullmatch(r"/p/[A-Za-z0-9._~-]+(/(pdf|xml|respuesta))?", request.url.path):
        # este dominio ya no es el de producción: los enlaces de los correos enviados antes siguen funcionando en el nuevo
        from fastapi.responses import RedirectResponse
        return RedirectResponse(REDIRIGIR_PUBLICOS + request.url.path, status_code=301)
    # catálogo público de un negocio en grupofactura.com/<negocio> (FISITAAP, 3.47): un solo segmento sin punto que sea un
    # negocio publicado se sirve como /t/<negocio>; lo demás (app, docs, marcar.html, archivos) sigue igual
    m = re.fullmatch(r"/([a-z0-9][a-z0-9-]{1,59})/?", request.url.path)
    if m and request.method in ("GET", "HEAD") and m.group(1) not in _pedidos.RESERVADOS and _pedidos.slug_existe(m.group(1)):
        request.scope["path"] = "/t/" + m.group(1)
    # dominio propio o subdominio del negocio (3.58): www.minegocio.cr o minegocio.grupofactura.com muestran su página en la raíz;
    # el resto (api, archivos) se sirve igual. La primera visita por el dominio propio lo deja verificado.
    elif request.url.path in ("/", "") and request.method in ("GET", "HEAD"):
        neg = _pedidos.negocio_de_host(request.headers.get("host", ""))
        if neg:
            request.scope["path"] = "/t/" + neg[1]
            _pedidos.marcar_dominio_visitado(neg[0], request.headers.get("host", ""))
    _t0 = time.perf_counter()
    resp = await call_next(request)
    h = resp.headers
    if request.url.path.startswith("/api/"):
        h["Server-Timing"] = f"app;dur={(time.perf_counter() - _t0) * 1000:.0f}"   # 3.73: tiempo de servidor, visible en la pestaña Red del navegador
    if h.get("X-Pagina-Pixeles"):                                    # página de un negocio con etiqueta de Google o píxel de Meta (3.58)
        del h["X-Pagina-Pixeles"]
        h["Content-Security-Policy"] = CSP_PIXELES
        h["X-Content-Type-Options"] = "nosniff"; h["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return resp
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "SAMEORIGIN"
    h["Referrer-Policy"] = "strict-origin-when-cross-origin"
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=(self), payment=()"   # geolocation: el catálogo y el panel del motorizado usan el mapa (3.48)
    if h.get("X-Pagina-Turnstile"):
        del h["X-Pagina-Turnstile"]
        h["Content-Security-Policy"] = CSP_TURNSTILE
    elif request.url.path in ("/app/", "/app/index.html") and _turnstile_en_app():   # 3.84: inicio de sesión y prueba de las claves en el panel
        h["Content-Security-Policy"] = CSP_TURNSTILE
    else:
        h["Content-Security-Policy"] = CSP
    if PRODUCCION or request.url.scheme == "https" or request.headers.get("x-forwarded-proto") == "https":
        h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    p = request.url.path
    if p.startswith("/api/"):
        h["Cache-Control"] = "no-store"
    elif resp.status_code == 200 and p.startswith(("/js/vendor/", "/fonts/", "/img/sitio/")):   # 3.73: librerías fijas, fuentes e imágenes del sitio: 7 días sin volver a preguntar
        h["Cache-Control"] = "public, max-age=604800"
    else:
        h["Cache-Control"] = "no-cache"
    return resp


class _Estaticos(StaticFiles):
    """3.87: archivos fijos comprimidos con gzip cuando el navegador lo acepta (JS, CSS, HTML, SVG: unos 380 KB menos en la primera
    visita). Cada archivo se comprime una sola vez por fecha de modificación y queda en memoria; el ETag, el 304 y las cabeceras de caché
    siguen iguales. HEAD, rangos y archivos chicos o ya comprimidos (imágenes, fuentes) salen como siempre."""
    COMPRIMIR = (".js", ".mjs", ".css", ".html", ".svg", ".json", ".webmanifest", ".txt", ".xml")
    _gz: dict = {}

    def file_response(self, full_path, stat_result, scope, status_code=200):
        resp = super().file_response(full_path, stat_result, scope, status_code)
        if (status_code != 200 or resp.status_code != 200 or scope.get("method") != "GET" or not str(full_path).lower().endswith(self.COMPRIMIR)
                or not 1024 <= stat_result.st_size <= 4 * 1024 * 1024 or "content-encoding" in resp.headers):
            return resp
        resp.headers["Vary"] = "Accept-Encoding"
        from starlette.datastructures import Headers as _Cab
        cab = _Cab(scope=scope)
        if "gzip" not in (cab.get("accept-encoding") or "").lower() or cab.get("range"):
            return resp
        clave = (stat_result.st_mtime_ns, stat_result.st_size)
        hit = self._gz.get(str(full_path))
        if hit is None or hit[0] != clave:
            import gzip as _gzip
            with open(full_path, "rb") as f:
                hit = (clave, _gzip.compress(f.read(), 6, mtime=0))
            self._gz[str(full_path)] = hit
        h = {k: v for k, v in resp.headers.items() if k.lower() != "content-length"}
        h["Content-Encoding"] = "gzip"
        return Response(content=hit[1], status_code=200, headers=h)


_HUELLA_SW: dict = {"t": None, "h": ""}


def _huella_programa() -> str:
    """3.87: huella de los archivos del programa (todo app/static: ruta, fecha de modificación y tamaño). Cualquier archivo que cambie
    —una entrega, aunque esté a medio extraer, o un arreglo que no subió VERSION— la cambia. Se recalcula cada 10 s como mucho (unos 300
    archivos, un stat de cada uno)."""
    ahora = time.monotonic()
    if _HUELLA_SW["t"] is not None and ahora - _HUELLA_SW["t"] < 10:
        return _HUELLA_SW["h"]
    import hashlib as _hashlib
    h = _hashlib.sha1()
    for carpeta, dirs, archivos in os.walk(STATIC):
        dirs.sort()
        for a in sorted(archivos):
            ruta = os.path.join(carpeta, a)
            try:
                st = os.stat(ruta)
            except OSError:
                continue
            h.update(f"{os.path.relpath(ruta, STATIC)}|{st.st_mtime_ns}|{st.st_size}\n".encode("utf-8", "replace"))
    _HUELLA_SW.update(t=ahora, h=h.hexdigest()[:12])
    return _HUELLA_SW["h"]


_ARCHIVOS_APP: dict = {"h": None, "lista": []}


@app.get("/app-archivos.json", include_in_schema=False)
def archivos_app():
    """4.8: lista de los módulos de la aplicación (app/static/js, sin la carpeta de FISITAAP ni lo de desarrollo) para que el navegador
    los guarde de a uno, en segundo plano, después de entrar. En el hosting compartido, 8 o 10 archivos pedidos a la vez hacen que
    algunos esperen 5 a 6 segundos (se arranca otra copia del programa); de a uno llegan en ~100 ms. Son archivos públicos."""
    h = _huella_programa()
    if _ARCHIVOS_APP["h"] != h:
        base = STATIC / "js"
        lista = []
        for ruta in sorted(base.rglob("*.js")):
            rel = ruta.relative_to(STATIC).as_posix()
            if rel.startswith(("js/fis/", "js/vendor/leaflet")) or "/qa" in rel:
                continue
            lista.append("/" + rel)
        _ARCHIVOS_APP.update(h=h, lista=lista)
    return {"huella": h, "archivos": _ARCHIVOS_APP["lista"]}


@app.get("/sw-app.js", include_in_schema=False)
def sw_app(request: Request):
    """3.87: el service worker de la aplicación con HUELLA llena. Dentro de una versión el service worker ya no revalida cada archivo;
    con la huella, si un archivo cambia (también si alguien abrió el sistema mientras se extraía la entrega y se guardó una mezcla de
    archivos viejos y nuevos) cambia este archivo, el navegador lo instala de nuevo y guarda el programa otra vez."""
    texto = (STATIC / "sw-app.js").read_text(encoding="utf-8")
    cuerpo = texto.replace("const HUELLA = '';", f"const HUELLA = '-{_huella_programa()}';", 1).encode("utf-8")
    import hashlib as _hashlib
    etag = '"' + _hashlib.sha1(cuerpo).hexdigest()[:20] + '"'
    cab = {"ETag": etag, "Vary": "Accept-Encoding"}
    if etag in [x.strip() for x in (request.headers.get("if-none-match") or "").split(",")]:
        return Response(status_code=304, headers=cab)
    if "gzip" in (request.headers.get("accept-encoding") or "").lower():
        import gzip as _gzip
        return Response(content=_gzip.compress(cuerpo, 6, mtime=0), media_type="text/javascript; charset=utf-8", headers={**cab, "Content-Encoding": "gzip"})
    return Response(content=cuerpo, media_type="text/javascript; charset=utf-8", headers=cab)


# 3.87: los archivos fijos se buscan ANTES que las rutas de la API: así no recorren (ni construyen, en la primera petición del proceso) las
# casi 400 rutas. Ninguna ruta de la API vive bajo estos prefijos; /app/ (la página) también entra aquí, con su index.html, y los archivos
# sueltos de la raíz (ui.css, landing.css…; sw-app.js no: lo entrega sw_app con su huella).
from starlette.routing import BaseRoute as _BaseRoute, Match as _Match, Mount as _Mount, NoMatchFound as _NoMatchFound  # noqa: E402
try:
    from starlette._utils import get_route_path as _ruta_de  # noqa: E402  (módulo interno de Starlette: con respaldo si se mueve)
except ImportError:                                           # pragma: no cover
    def _ruta_de(scope) -> str:
        path, raiz = scope["path"], scope.get("root_path", "")
        return path[len(raiz):] if raiz and path.startswith(raiz + "/") else path


class _ArchivosRaiz(_BaseRoute):
    """Los archivos sueltos de app/static (no las carpetas): /ui.css, /landing.css… Cualquier otra ruta sigue de largo."""

    def __init__(self):
        self.app = _Estaticos(directory=STATIC)
        self.nombres = frozenset(x.name for x in STATIC.iterdir() if x.is_file()) - {"sw-app.js"}

    def matches(self, scope):
        if scope.get("type") == "http" and _ruta_de(scope)[1:] in self.nombres:
            return _Match.FULL, {}
        return _Match.NONE, {}

    def url_path_for(self, name, /, **path_params):           # no tiene nombre: que app.url_path_for / request.url_for sigan buscando
        raise _NoMatchFound(name, path_params)

    async def handle(self, scope, receive, send):
        await self.app(scope, receive, send)


app.router.routes.insert(0, _ArchivosRaiz())
for _pref, _html in (("js", False), ("fonts", False), ("img", False), ("fisitaap", False), ("app", True)):
    app.router.routes.insert(0, _Mount("/" + _pref, app=_Estaticos(directory=STATIC / _pref, html=_html), name="static_" + _pref))
app.mount("/", _Estaticos(directory=STATIC, html=True), name="static")
