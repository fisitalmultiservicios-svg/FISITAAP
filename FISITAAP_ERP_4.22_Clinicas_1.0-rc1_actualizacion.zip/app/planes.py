# -*- coding: utf-8 -*-
"""Planes, extras y límites por empresa (3.16; decisiones de Norman 19/10/2026).

Cada empresa tiene un tipo de negocio (facturación, comercio, hospitalidad), un plan de ese tipo, extras contratados y límites.
El administrador del sistema los asigna en Administración de cuentas. Sin plan asignado, en prueba gratis o en la empresa demo,
todo está encendido (así las cuentas que ya existían siguen igual).

  - Facturación: planes con límite de documentos al mes (pospago) o al año (prepago, como GTI); sin límite de usuarios.
    Extras: Contabilidad y Recursos humanos. Con cualquiera de los dos se enciende Reportes.
  - Comercio (punto de venta): mensual, sin límite de documentos; incluye cajas. Extras: Contabilidad y Recursos humanos.
  - Hospitalidad: mensual por habitación (mínimo 6); con integración de canales se cotiza. Extras: Punto de venta,
    Contabilidad, Recursos humanos, Hotel completo (servicios, eventos, lavandería, seguridad) y Canales.
  - Al llegar al límite de documentos no se emite más (403 limite_plan). 4.5 (decisión de Norman): cuentan SOLO los comprobantes
    electrónicos de producción (AMBIENTE_PLAN y ESTADOS_PLAN); los internos, los de pruebas y los importados ni cuentan ni se
    bloquean. Al vencer el plan la empresa queda en modo lectura
    (403 plan_vencido en todo lo que escribe) hasta que se renueve. Lo no contratado desaparece del menú y el servidor lo
    rechaza (403 sin_modulo). La instalación local hereda plan y extras de la nube pero no cuenta documentos (los cuenta la nube).
  - 4.9 (E4): en la instalación local el vencimiento solo deja la computadora en modo lectura si la nube lo confirmó después de
    pasar (sinc.fecha_confirmada). La fecha local es una copia que puede estar vieja (renovó en la nube sin internet en el local, o
    la nube le niega el acceso): sin poder confirmarla, la computadora sigue emitiendo.
"""
import json
import os
from datetime import datetime, timedelta
from typing import Optional

from fastapi import HTTPException
from sqlmodel import select

from .config import ahora_cr, nombre_sistema, dominio_sistema, correo_ventas
from .db import Documento

MODO_LOCAL = os.environ.get("FE_MODO_LOCAL", "") == "1"
TIPOS = ("facturacion", "comercio", "restaurante", "hospitalidad", "servicios")   # 3.51: paquetes Restaurante (FISITAAP) y Servicios/IT (TiKe)
MODULOS = ("clinicas", "contabilidad", "rrhh", "reportes", "pos", "hotel", "hotel_completo", "canales", "pedidos_online", "entregas", "tike", "sucursales", "grupo")
NOMBRES = {"clinicas": "Clínicas", "contabilidad": "Contabilidad", "rrhh": "Recursos humanos", "reportes": "Reportes", "pos": "Punto de venta", "hotel": "Hotel",
           "hotel_completo": "Hotel completo (servicios, eventos, lavandería y seguridad)", "canales": "Integración de canales",
           "pedidos_online": "Ventas en línea", "entregas": "Ventas en línea · Entregas", "tike": "TiKe · Tickets de soporte", "sucursales": "Sucursales", "grupo": "Grupo de empresas"}
BASE = {"facturacion": set(), "comercio": {"pos"}, "restaurante": {"pos", "pedidos_online"}, "hospitalidad": {"hotel"}, "servicios": {"tike"}}   # módulos que trae el plan base de cada tipo
# FISITAAP (3.47, decisión de Norman 1/11/2026): dos extras de ₡10.000 o USD 20 al mes para Comercio y Hospitalidad; Entregas requiere Pedidos en línea
EXTRAS_TIPO = {"facturacion": ["contabilidad", "rrhh", "tike", "sucursales", "grupo"], "comercio": ["contabilidad", "rrhh", "pedidos_online", "entregas", "tike", "sucursales", "grupo"],
               "restaurante": ["entregas", "contabilidad", "rrhh", "sucursales", "grupo"],
               "hospitalidad": ["pos", "contabilidad", "rrhh", "hotel_completo", "canales", "pedidos_online", "entregas"],
               "servicios": ["contabilidad", "rrhh", "sucursales", "grupo"]}
# precios en colones mensuales más IVA; documentos: 0 = sin límite; periodo: mes | anio (prepago anual)
PLANES = {
    "facturacion": [
        {"codigo": "fac_basico", "nombre": "Básico", "precio": 2500, "documentos": 10, "periodo": "mes"},
        {"codigo": "fac_emprendedor", "nombre": "Emprendedor", "precio": 4900, "documentos": 50, "periodo": "mes"},
        {"codigo": "fac_250", "nombre": "Pospago 250", "precio": 9900, "documentos": 250, "periodo": "mes"},
        {"codigo": "fac_500", "nombre": "Pospago 500", "precio": 19900, "documentos": 500, "periodo": "mes"},
        {"codigo": "fac_1000", "nombre": "Pospago 1.000", "precio": 32900, "documentos": 1000, "periodo": "mes"},
        {"codigo": "fac_pre24", "nombre": "Prepago 24 (anual)", "precio": 12900, "documentos": 24, "periodo": "anio"},
        {"codigo": "fac_pre60", "nombre": "Prepago 60 (anual)", "precio": 19900, "documentos": 60, "periodo": "anio"},
        {"codigo": "fac_pre150", "nombre": "Prepago 150 (anual)", "precio": 27900, "documentos": 150, "periodo": "anio"},
        {"codigo": "fac_fisica", "nombre": "Persona física ilimitado", "precio": 6900, "documentos": 0, "periodo": "mes"},
        {"codigo": "fac_simplificado", "nombre": "Régimen simplificado ilimitado", "precio": 2500, "documentos": 0, "periodo": "mes"},
    ],
    "comercio": [
        {"codigo": "pos_basico", "nombre": "Punto de venta básico", "precio": 9900, "documentos": 500, "periodo": "mes", "cajas": 1},
        {"codigo": "pos", "nombre": "Punto de venta", "precio": 19900, "documentos": 0, "periodo": "mes", "cajas": 2},
    ],
    # Restaurante · FISITAAP (3.51): punto de venta + mesas + monitor + pedidos en línea, sin recargo sobre la suma de hoy
    "restaurante": [
        {"codigo": "rest_basico", "nombre": "Restaurante básico · FISITAAP", "precio": 19900, "documentos": 500, "periodo": "mes", "cajas": 1},
        {"codigo": "rest", "nombre": "Restaurante · FISITAAP", "precio": 29900, "documentos": 0, "periodo": "mes", "cajas": 2},
    ],
    # Servicios / IT (3.51): facturación + TiKe (tickets de soporte, fase 6); precios propuestos, Norman los ajusta en Administración
    "servicios": [
        {"codigo": "serv_emprendedor", "nombre": "Servicios Emprendedor", "precio": 14900, "documentos": 50, "periodo": "mes"},
        {"codigo": "serv_250", "nombre": "Servicios 250", "precio": 19900, "documentos": 250, "periodo": "mes"},
        {"codigo": "serv_ilimitado", "nombre": "Servicios ilimitado", "precio": 29900, "documentos": 0, "periodo": "mes"},
    ],
    "hospitalidad": [
        # hasta 30 habitaciones: ₡6.000 por habitación y cada extra ₡1.000 por habitación (mismo porcentaje que la base)
        {"codigo": "hotel", "nombre": "Hotelería (por habitación, hasta 30)", "precio_habitacion": 6000, "extra_habitacion": 1000, "minimo_habitaciones": 6, "maximo_habitaciones": 30, "documentos": 0, "periodo": "mes"},
        {"codigo": "hotel_40", "nombre": "Hotelería hasta 40 habitaciones, todo incluido", "precio": 300000, "habitaciones": 40, "incluye_extras": True, "documentos": 0, "periodo": "mes"},
        {"codigo": "hotel_50", "nombre": "Hotelería hasta 50 habitaciones, todo incluido", "precio": 360000, "habitaciones": 50, "incluye_extras": True, "documentos": 0, "periodo": "mes"},
        {"codigo": "hotel_mas", "nombre": "Hotelería de más de 50 habitaciones (cotización)", "cotizacion": True, "incluye_extras": True, "documentos": 0, "periodo": "mes"},
    ],
}
# precio: facturación y comercio; precio_habitacion: hotelería hasta 30 (por habitación al mes); canales: en dólares, aparte
EXTRAS = {"sucursales": {"nombre": "Sucursales", "precio": 4900, "nota": "por cada sucursal adicional a la principal: caja, bodega, gente y consecutivo propios (3.66)"},
          "grupo": {"nombre": "Grupo de empresas", "precio": 4900, "nota": "traslados de inventario a otras empresas suyas con cédula distinta: factura al costo, compra y entrada a bodega en un paso (3.69)"},
          "contabilidad": {"nombre": "Contabilidad", "precio": 9900, "precio_habitacion": 1000},
          "rrhh": {"nombre": "Recursos humanos", "precio": 10000, "precio_habitacion": 1000, "nota": "hasta 10 empleados; ₡1.000 por empleado adicional"},   # 3.90
          "pos": {"nombre": "Punto de venta (hotel)", "precio": None, "precio_habitacion": 1000, "nota": "2 cajas"},
          "hotel_completo": {"nombre": "Hotel completo", "precio": None, "precio_habitacion": 1000},
          "canales": {"nombre": "Integración con administrador de canales", "precio": None, "precio_usd": 100, "nota": "USD 100 al mes, en cualquier paquete"},
          "pedidos_online": {"nombre": "Ventas en línea", "precio": 10000, "precio_usd_equivalente": 20, "nota": "página web del negocio, catálogo o menú, carrito, pedidos a la caja, clientes web, promociones y asistente; ₡10.000 o USD 20 al mes"},
          "tike": {"nombre": "TiKe · Tickets de soporte", "precio": 10000, "precio_usd_equivalente": 20, "nota": "tickets, SLA, portal del cliente, contratos y documentación; ₡10.000 o USD 20 al mes (incluido en Servicios)"},
          "entregas": {"nombre": "Ventas en línea · Entregas", "precio": 10000, "precio_usd_equivalente": 20, "requiere": "pedidos_online", "nota": "zonas, motorizados, liquidaciones y seguimiento; requiere FISITAAP; ₡10.000 o USD 20 al mes"}}
CLAVES_HOTEL_COMPLETO = ("hotel_servicios", "hotel_eventos", "hotel_salones", "hotel_lavanderia", "hotel_seg_")
CLAVES_LIMITADAS = ("hotel_habitaciones", "pos_config")
CAMPOS = ("plan", "extras", "docs_extra", "plan_inicio", "habitaciones", "cajas", "limite_usuarios", "vence")
RUTAS_LECTURA = ("/api/auth/", "/api/exportar", "/api/admin/", "/api/respaldos", "/api/sinc/", "/api/plan")   # permitidas con el plan vencido


# Funciones en prueba (3.58): algo nuevo se enciende en una o dos empresas antes que en todas. El administrador del sistema las marca
# por empresa (Administración › Plan y extras › Funciones en prueba); el código pregunta con funcion_activa(e, codigo) y la aplicación
# con sesion.tieneFuncion(codigo). Cuando una función madura, se vuelve parte del sistema y se quita de aquí.
FUNCIONES = {
    "clinicas": {"nombre": "Módulo Clínicas (piloto sobre 4.22)", "nota": "Pacientes, agenda y atención. Activación expresa; MFA y permisos propios. Sin tarifa automática nueva."},
    "subdominio": {"nombre": "Subdominio nombre-del-negocio.{dominio} para la página de ventas en línea", "nota": "se ofrece como dirección oficial solo cuando el servidor tiene el comodín configurado"},
    "ia_acciones": {"nombre": "Asistente con IA que cambia precios y agota ítems con confirmación (en desarrollo)", "nota": "el asistente propone el cambio y un usuario lo confirma"},
}


def funciones_de(e) -> list:
    try:
        v = json.loads(getattr(e, "funciones", None) or "[]")
    except ValueError:
        v = []
    return sorted(x for x in set(v) if x in FUNCIONES)


def funcion_activa(e, codigo: str) -> bool:
    return codigo in funciones_de(e)


def asignar_funciones(e, codigos) -> list:
    malos = [str(x) for x in (codigos or []) if x not in FUNCIONES]
    if malos:
        raise HTTPException(400, f"Función desconocida: {', '.join(malos)}")
    e.funciones = json.dumps(sorted({x for x in (codigos or [])}))
    return funciones_de(e)


def catalogo() -> dict:
    funciones = {k: {**v, "nombre": v["nombre"].format(dominio=dominio_sistema())} for k, v in FUNCIONES.items()}
    return {"planes": PLANES, "extras": EXTRAS, "extras_tipo": EXTRAS_TIPO, "nombres": NOMBRES, "funciones": funciones}


def tipo_de(e) -> str:
    t = getattr(e, "tipo_negocio", None) or "facturacion"
    return t if t in TIPOS else "facturacion"


def plan_de(e) -> Optional[dict]:
    codigo = getattr(e, "plan", None)
    if not codigo:
        return None
    for lista in PLANES.values():
        for p in lista:
            if p["codigo"] == codigo:
                return p
    return None


def _hoy() -> str:
    return ahora_cr().date().isoformat()


def en_prueba(e) -> bool:
    return bool(getattr(e, "prueba_hasta", None)) and _hoy() <= str(e.prueba_hasta)[:10]


def sin_restriccion(e) -> bool:
    """Todo encendido: sin plan asignado (cuentas de antes), prueba gratis vigente o empresa demo."""
    return not getattr(e, "plan", None) or bool(getattr(e, "es_demo", False)) or en_prueba(e)


def extras_de(e) -> list:
    try:
        v = json.loads(getattr(e, "extras", None) or "[]")
    except ValueError:
        v = []
    return [x for x in v if x in EXTRAS]


# 3.70: módulos apagados a mano. Por empresa (Empresa.modulos_ocultos) o por usuario (UsuarioEmpresa.modulos_ocultos): salen del menú y de
# los permisos, los datos no se tocan. Al crear una empresa se apagan los que no existen para su tipo de negocio (no se pueden comprar) y,
# en demos y pruebas gratis, también TiKe salvo en Servicios e IT: una demo de punto de venta no tiene por qué enseñar tickets.
SIEMPRE = {"reportes"}


def ocultos_de(e) -> list:
    try:
        v = json.loads(getattr(e, "modulos_ocultos", None) or "[]")
    except ValueError:
        v = []
    return sorted(x for x in v if x in MODULOS)


def ocultos_por_tipo(tipo: str, prueba: bool = False) -> list:
    """Módulos que no aplican a ese tipo de negocio; con `prueba` (demo o prueba gratis) también TiKe fuera de Servicios e IT."""
    if tipo not in BASE:
        return []
    propios = set(BASE[tipo]) | set(EXTRAS_TIPO.get(tipo, [])) | SIEMPRE | {"clinicas"}
    fuera = [m for m in MODULOS if m not in propios]
    if prueba and tipo != "servicios" and "tike" not in fuera:
        fuera.append("tike")
    return sorted(fuera)


def modulos_de(e) -> set:
    """Módulos encendidos: los del plan menos los apagados a mano en la empresa (3.70)."""
    return modulos_plan(e) - set(ocultos_de(e))


def modulos_plan(e) -> set:
    if sin_restriccion(e):
        return (set(MODULOS) - {"clinicas"}) | ({"clinicas"} if funcion_activa(e, "clinicas") else set())
    tipo = tipo_de(e)
    m = set(BASE.get(tipo, set())) | {x for x in extras_de(e) if x in EXTRAS_TIPO.get(tipo, [])}
    p = plan_de(e)
    if p and p.get("incluye_extras"):                   # paquetes de 40 y 50 habitaciones: todos los extras menos canales (se cobra aparte)
        m |= {x for x in EXTRAS_TIPO.get(tipo, []) if x != "canales"}
    if "contabilidad" in m or "rrhh" in m:
        m.add("reportes")
    if "entregas" in m and "pedidos_online" not in m:   # Entregas no funciona sin Pedidos en línea (3.47)
        m.discard("entregas")
    if funcion_activa(e, "clinicas"):
        m.add("clinicas")
    return m


def filtrar_permisos(e, permisos, ocultos_usuario=()) -> set:
    """Quita los permisos de los módulos que el plan no incluye o que están apagados para la empresa o para ese usuario (3.70)."""
    m = modulos_de(e) - set(ocultos_usuario or ())
    p = set(permisos or ())
    if "clinicas" not in m:
        p = {x for x in p if not x.startswith("clinicas")}
    for modulo, permiso in (("contabilidad", "contabilidad"), ("rrhh", "rrhh"), ("reportes", "reportes"), ("pos", "pos"), ("tike", "tike")):
        if modulo not in m:
            p.discard(permiso)
    return p


def permite_registro(e, clave: str) -> bool:
    """Si el plan incluye el módulo al que pertenece el registro (hotel completo, contabilidad, recursos humanos, reportes)."""
    m = modulos_de(e)
    if clave.startswith(CLAVES_HOTEL_COMPLETO):
        return "hotel_completo" in m
    from .auth import permiso_registro
    p = permiso_registro(clave)
    if p in ("contabilidad", "rrhh", "reportes"):
        return p in m
    return True


def modulo_de_registro(clave: str) -> str:
    if clave.startswith(CLAVES_HOTEL_COMPLETO):
        return "hotel_completo"
    from .auth import permiso_registro
    return permiso_registro(clave)


def exigir_modulo(e, modulo: str) -> None:
    if modulo not in modulos_de(e):
        raise HTTPException(403, {"codigo": "sin_modulo", "modulo": modulo,
                                  "mensaje": f"«{NOMBRES.get(modulo, modulo)}» no está incluido en su plan. Escríbanos para activarlo."})


def periodo(e) -> tuple[str, str]:
    """[inicio, fin) del periodo que cuenta documentos: el mes en curso, o el año del plan prepago desde plan_inicio."""
    p = plan_de(e)
    hoy = ahora_cr().date()
    if p and p.get("periodo") == "anio":
        try:
            inicio = datetime.fromisoformat(str(e.plan_inicio)[:10]).date() if getattr(e, "plan_inicio", None) else hoy.replace(day=1)
        except ValueError:
            inicio = hoy.replace(day=1)
        while inicio + timedelta(days=365) <= hoy:          # el prepago se renueva por años desde su inicio
            inicio += timedelta(days=365)
        return inicio.isoformat(), (inicio + timedelta(days=365)).isoformat()
    inicio = hoy.replace(day=1)
    fin = (inicio.replace(year=inicio.year + 1, month=1) if inicio.month == 12 else inicio.replace(month=inicio.month + 1))
    return inicio.isoformat(), fin.isoformat()


def limite_documentos(e) -> int:
    """Documentos permitidos en el periodo (0 = sin límite): los del plan más los paquetes adicionales comprados."""
    p = plan_de(e)
    if sin_restriccion(e) or not p or not p.get("documentos"):
        return 0
    return int(p["documentos"]) + int(getattr(e, "docs_extra", 0) or 0)


# 4.5 (decisión de Norman): el tope del plan cuenta SOLO comprobantes electrónicos de producción, es decir, los que salen a Hacienda:
# firmados en cola, enviados, aceptados, rechazados o con error de envío. No cuentan los internos (estado 'interno': empresa sin
# facturación electrónica, también sus notas de crédito), los del ambiente de pruebas, los importados de otro sistema (3.27) ni
# los que se quedaron en 'generado' (sin firma no viajan a Hacienda).
AMBIENTE_PLAN = "produccion"
ESTADOS_PLAN = ("firmado", "enviado", "aceptado")   # los rechazados y con error no son comprobantes válidos: no cuentan (decisión de Norman: «solo comprobantes»)


def cuenta_en_plan(e) -> bool:
    """4.5: lo que esta empresa emite ahora, ¿suma al tope? Solo en producción y con la facturación electrónica encendida."""
    return (getattr(e, "ambiente", "") or "") == AMBIENTE_PLAN and bool(getattr(e, "factura_electronica", True))


def documentos_usados(s, e) -> int:
    """Comprobantes electrónicos de producción emitidos en el periodo del plan (4.5: antes contaba todo documento no importado)."""
    inicio, fin = periodo(e)
    return len(s.exec(select(Documento.id).where(Documento.empresa_id == e.id, Documento.fecha_emision >= inicio, Documento.fecha_emision < fin,
                                                 Documento.importado_de == None,   # noqa: E711  los importados de otro sistema no cuentan (3.27)
                                                 Documento.ambiente == AMBIENTE_PLAN, Documento.estado.in_(ESTADOS_PLAN))).all())


def verificar_emision(s, e) -> None:
    """Antes de dar un consecutivo: si el plan tiene límite de documentos y ya se usó, 403 limite_plan."""
    if MODO_LOCAL:
        return                                   # la instalación local no cuenta: lo cuenta la nube al recibir lo que emitió
    if not cuenta_en_plan(e):
        return                                   # 4.5: interno o de pruebas no suma al tope, así que tampoco se bloquea
    lim = limite_documentos(e)
    if lim and documentos_usados(s, e) >= lim:
        p = plan_de(e) or {}
        raise HTTPException(403, {"codigo": "limite_plan", "limite": lim,
                                  "mensaje": f"Su plan {p.get('nombre', '')} llegó a su límite de {lim} comprobantes electrónicos "   # 4.5
                                             f"{'este año' if p.get('periodo') == 'anio' else 'este mes'}. Agregue un paquete de comprobantes o pase al plan siguiente."})


def _fecha_vale(e, fecha) -> bool:
    """4.9 (E4): en la nube una fecha del plan siempre vale. En la instalación local es una copia de la nube y solo bloquea si la
    nube la confirmó después de que pasó (sinc.fecha_confirmada: la última bajada buena es de un día posterior). Si la computadora
    no ha podido hablar con la nube desde entonces (sin internet o sin acceso), la empresa pudo haber renovado: sigue trabajando.
    Etapa 1 (decisión 11 del plan): esa espera tiene un tope de 7 días después de la fecha (sinc.DIAS_GRACIA_PLAN). Lo ya emitido se sigue
    enviando a Hacienda siempre."""
    if not MODO_LOCAL:
        return True
    try:
        from . import sinc
        return sinc.fecha_confirmada(getattr(e, "id", None), fecha)
    except Exception:  # noqa: BLE001
        return False                          # sin poder confirmarla, no se deja a la cajera sin vender


def vencido(e) -> bool:
    v = getattr(e, "vence", None)
    return bool(v) and _hoy() > str(v)[:10] and not sin_restriccion(e) and _fecha_vale(e, v)   # 4.9 (E4)


def verificar_vigencia(e, request, es_superadmin: bool = False) -> None:
    """Plan vencido: la empresa queda en modo lectura (ve y exporta; no emite ni guarda) hasta renovar."""
    if es_superadmin or request is None or not vencido(e):
        return
    if request.method in ("GET", "HEAD", "OPTIONS") or request.url.path.startswith(RUTAS_LECTURA):
        return
    raise HTTPException(403, {"codigo": "plan_vencido", "vence": e.vence,
                              "mensaje": f"Su plan venció el {str(e.vence)[:10]}. Puede consultar y exportar; para seguir emitiendo y guardando, renueve su plan."})


def verificar_usuarios(s, e, UsuarioEmpresa) -> None:
    lim = int(getattr(e, "limite_usuarios", 0) or 0)
    if not lim or sin_restriccion(e):
        return
    n = len(s.exec(select(UsuarioEmpresa.id).where(UsuarioEmpresa.empresa_id == e.id)).all())
    if n >= lim:
        raise HTTPException(403, {"codigo": "limite_plan", "mensaje": f"Su plan incluye {lim} usuarios y ya los tiene. Agregue un usuario adicional al plan."})


def verificar_registro(e, clave: str, total: int) -> None:
    """Límites sobre registros: habitaciones contratadas (hotel) y cajas (punto de venta)."""
    if sin_restriccion(e):
        return
    if clave == "hotel_habitaciones":
        lim = int(getattr(e, "habitaciones", 0) or 0)
        if lim and total > lim:
            raise HTTPException(403, {"codigo": "limite_plan", "mensaje": f"Su plan cubre {lim} habitaciones y está registrando {total}. Amplíe el plan para agregar más."})
    elif clave == "pos_config":
        lim = int(getattr(e, "cajas", 0) or 0)
        if lim and total > lim:
            raise HTTPException(403, {"codigo": "limite_plan", "mensaje": f"Su plan incluye {lim} cajas y está configurando {total}. Agregue una caja adicional al plan."})


def total_registro(clave: str, datos) -> int:
    """Cuántos elementos limitados hay en el valor que se guarda (habitaciones de la lista; cajas = terminales de pos_config)."""
    if clave == "hotel_habitaciones":
        return len(datos) if isinstance(datos, list) else 0
    if clave == "pos_config" and isinstance(datos, dict):
        return len(datos.get("terminales") or [])
    return 0


def asignar(e, data: dict) -> None:
    """Lo que fija el administrador del sistema por empresa: plan del tipo de negocio, extras válidos para ese tipo y límites."""
    tipo = tipo_de(e)
    codigo = (data.get("plan") or "").strip()
    if codigo and codigo not in {p["codigo"] for p in PLANES[tipo]}:
        raise HTTPException(400, f"El plan «{codigo}» no es del tipo {tipo}")
    extras = sorted({x for x in (data.get("extras") or []) if x in EXTRAS_TIPO[tipo]})
    previo = next((x for x in PLANES[tipo] if x["codigo"] == (getattr(e, "plan", None) or "")), None)   # 3.87: el plan que tenía
    for campo in ("docs_extra", "habitaciones", "cajas", "limite_usuarios"):
        v = data.get(campo)
        try:
            v = int(v or 0)
        except (TypeError, ValueError):
            raise HTTPException(400, f"{campo}: debe ser un número entero")
        if v < 0 or v > 1_000_000:
            raise HTTPException(400, f"{campo}: fuera de rango")
        setattr(e, campo, v)
    for campo in ("plan_inicio", "vence"):
        v = (data.get(campo) or "").strip()[:10] or None
        if v:
            try:
                datetime.fromisoformat(v)
            except ValueError:
                raise HTTPException(400, f"{campo}: fecha inválida (AAAA-MM-DD)")
        setattr(e, campo, v)
    p = next((x for x in PLANES[tipo] if x["codigo"] == codigo), None)
    if p and p.get("cajas") and (not e.cajas or (codigo != (getattr(e, "plan", None) or "") and e.cajas == int((previo or {}).get("cajas") or 0))):
        e.cajas = int(p["cajas"])       # 3.87: al cambiar de plan, las del plan nuevo (la consola manda las que tenía); un número distinto = cajas adicionales
    if p and p.get("minimo_habitaciones") and e.habitaciones and e.habitaciones < int(p["minimo_habitaciones"]):
        e.habitaciones = int(p["minimo_habitaciones"])
    if p and p.get("maximo_habitaciones") and e.habitaciones > int(p["maximo_habitaciones"]):
        raise HTTPException(400, f"El plan «{p['nombre']}» llega hasta {p['maximo_habitaciones']} habitaciones: use el paquete de 40 o de 50")
    if p and p.get("habitaciones"):
        e.habitaciones = int(p["habitaciones"])             # paquete con tope fijo de habitaciones
    if p and p.get("periodo") == "anio" and not e.plan_inicio:
        e.plan_inicio = _hoy()
    e.plan = codigo or None
    e.extras = json.dumps(extras)
    if "precio_acordado" in data:                        # 3.95: precio fijo por empresa (fixed fee) sobre los paquetes elegidos
        v = data.get("precio_acordado")
        try:
            v = float(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            raise HTTPException(400, "El precio acordado debe ser un número")
        if v is not None and (v < 0 or v > 100_000_000):
            raise HTTPException(400, "El precio acordado no es válido")
        e.precio_acordado = round(v, 2) if v else None
        e.precio_acordado_nota = str(data.get("precio_acordado_nota") or "").strip()[:120] if v else ""


def sumar_meses(fecha_iso: str, meses: int) -> str:
    """Misma fecha `meses` después (si el día no existe en ese mes, el último del mes)."""
    import calendar
    d = datetime.fromisoformat(str(fecha_iso)[:10]).date()
    y, m = divmod(d.month - 1 + int(meses), 12)
    y, m = d.year + y, m + 1
    return d.replace(year=y, month=m, day=min(d.day, calendar.monthrange(y, m)[1])).isoformat()


def registrar_pago(s, e, data: dict, usuario: str | None = None):
    """Pago del plan registrado por el administrador del sistema: extiende el vencimiento `meses` desde la fecha mayor entre hoy y
    el vencimiento actual, y cierra la prueba gratis si la había."""
    from .auth import PagoPlan
    if not getattr(e, "plan", None):
        raise HTTPException(400, "Asigne primero el plan de la empresa")
    try:
        monto, meses = float(data.get("monto") or 0), int(data.get("meses") or 1)
    except (TypeError, ValueError):
        raise HTTPException(400, "Monto o meses inválidos")
    if monto < 0 or monto > 100_000_000 or meses < 1 or meses > 36:
        raise HTTPException(400, "Monto o meses fuera de rango")
    fecha = (data.get("fecha") or _hoy())[:10]
    try:
        datetime.fromisoformat(fecha)
    except ValueError:
        raise HTTPException(400, "Fecha inválida (AAAA-MM-DD)")
    base = max(_hoy(), str(e.vence)[:10]) if e.vence else _hoy()
    nuevo = sumar_meses(base, meses)
    p = PagoPlan(empresa_id=e.id, fecha=fecha, monto=round(monto, 2), moneda=(data.get("moneda") or "CRC")[:3].upper(), medio=str(data.get("medio") or "")[:40],
                 referencia=str(data.get("referencia") or "")[:80] or None, meses=meses, vence_anterior=e.vence, vence_nuevo=nuevo,
                 nota=str(data.get("nota") or "")[:200] or None, usuario=usuario)
    e.vence, e.prueba_hasta, e.aviso_plan = nuevo, None, None
    s.add(p); s.add(e); s.commit(); s.refresh(p)
    try:                                            # 3.65: factura automática desde la empresa facturadora (si está configurada); un fallo no impide el pago
        from . import factura_plan
        factura_plan.facturar_pago(s, e, p, usuario)
    except Exception:  # noqa: BLE001
        pass
    return p


def _enviar_aviso(s, e, asunto: str, texto: str) -> bool:
    """Correo al dueño de la empresa (y copia a ventas) con el correo de la plataforma del sitio público."""
    from . import sitio, correo
    cfg = sitio.leer()
    smtp = sitio._smtp(s, cfg)
    destinos = [x for x in [e.correo] if x] + ((cfg.get("contacto") or {}).get("correos") or [])
    if not smtp or not destinos:
        return False
    from . import correo_diseno as _dz                                    # 3.83: diseño común
    from .config import URL_PUBLICA
    cuerpo = texto.strip()
    if cuerpo.endswith(nombre_sistema()):                                  # la firma ya va en el pie
        cuerpo = cuerpo[: -len(nombre_sistema())].rstrip()
    saludo, _, resto = cuerpo.partition("\n\n")
    html = _dz.armar(_dz.plataforma(), titulo=asunto, asunto=asunto, preencabezado=resto[:120], saludo=saludo if resto else "",
                     texto_libre=resto or cuerpo, boton_=(f"Entrar a {nombre_sistema()}", URL_PUBLICA.rstrip("/") + "/app/") if URL_PUBLICA else None)
    correo.enviar(smtp, destinos, asunto, html, texto, [])
    return True


def recordatorios_vencimiento(enviar=None) -> list:
    """Una pasada diaria (cola): avisa 7 días antes del vencimiento del plan y el día después de vencer, una sola vez por fecha."""
    from sqlmodel import Session
    from .db import Empresa, engine
    enviar = enviar or _enviar_aviso
    hoy = datetime.fromisoformat(_hoy()).date()
    out = []
    with Session(engine) as s:
        for e in s.exec(select(Empresa).where(Empresa.bloqueada == False)).all():  # noqa: E712
            if not e.plan or not e.vence or e.es_demo:
                continue
            try:
                vence = datetime.fromisoformat(str(e.vence)[:10]).date()
            except ValueError:
                continue
            dias = (vence - hoy).days
            nombre = e.nombre_comercial or e.nombre
            p = plan_de(e) or {}
            if 0 <= dias <= 7 and e.aviso_plan != f"7:{e.vence}":
                clave, asunto = f"7:{e.vence}", f"Su plan de {nombre_sistema()} vence el {vence:%d/%m/%Y}"
                texto = (f"Hola, {nombre}.\n\nSu plan {p.get('nombre', '')} vence el {vence:%d/%m/%Y}. Para seguir emitiendo y guardando sin interrupción, "
                         f"renueve antes de esa fecha: escríbanos a {correo_ventas()} o por WhatsApp.\n\nAl vencer, el sistema queda en modo consulta "
                         f"(puede ver y exportar) hasta que se renueve.\n\n{nombre_sistema()}")
            elif dias < 0 and e.aviso_plan != f"v:{e.vence}":
                clave, asunto = f"v:{e.vence}", f"Su plan de {nombre_sistema()} venció el {vence:%d/%m/%Y}"
                texto = (f"Hola, {nombre}.\n\nSu plan {p.get('nombre', '')} venció el {vence:%d/%m/%Y}. El sistema quedó en modo consulta: puede ver y exportar, "
                         f"pero no emitir ni guardar. Para reactivarlo escríbanos a {correo_ventas()} o por WhatsApp.\n\n{nombre_sistema()}")
            else:
                continue
            try:
                if enviar(s, e, asunto, texto):
                    e.aviso_plan = clave; s.add(e); s.commit()
                    out.append({"empresa_id": e.id, "aviso": clave})
            except Exception as ex:  # noqa: BLE001
                out.append({"empresa_id": e.id, "error": str(ex)[:200]})
    return out


# 3.87: el extra de Recursos humanos incluye hasta 15 empleados activos; cada adicional se cobra aparte. No se bloquea: la consola muestra
# el conteo para cobrar el excedente y la lista de Empleados avisa al pasar el límite.
EMPLEADOS_RRHH = 10                    # 3.90: antes 15
PRECIO_EMPLEADO_EXTRA = 1000           # 3.90: antes ₡300 (más IVA, como todos los precios)


def empleados_incluidos(e) -> int:
    """Empleados que incluye el plan (0 = sin límite: sin plan, en prueba, demo o sin Recursos humanos). Solo cuando Recursos humanos
    se compró como extra: en los paquetes de hotel «todo incluido» no se cobra el excedente (pendiente de que Norman lo decida)."""
    if sin_restriccion(e) or "rrhh" not in modulos_de(e) or "rrhh" not in extras_de(e) or (plan_de(e) or {}).get("incluye_extras"):
        return 0
    return EMPLEADOS_RRHH


def empleados_plan(e, s) -> Optional[dict]:
    """Empleados activos contra el límite del plan (s: sesión de la base de la empresa). None si la empresa no tiene Recursos humanos,
    o si no tiene límite y tampoco empleados (sin plan, en prueba o demo: la consola no muestra «0 activos» en cada una)."""
    if "rrhh" not in modulos_de(e):
        return None
    from . import modulos
    activos = len([x for x in (modulos.leer(s, e.id, "empleados", []) or []) if isinstance(x, dict) and x.get("activo") is not False])
    inc = empleados_incluidos(e)
    if not inc and not activos:
        return None
    exc = max(0, activos - inc) if inc else 0
    return {"activos": activos, "incluidos": inc, "excedente": exc, "cargo": exc * PRECIO_EMPLEADO_EXTRA}


def info(e, s=None) -> dict:
    """Lo que ven el panel y la aplicación: plan, módulos encendidos, límites, uso (si hay sesión de la empresa) y vencimiento."""
    p = plan_de(e)
    lim = limite_documentos(e)
    d = {"codigo": getattr(e, "plan", None), "nombre": p["nombre"] if p else None, "tipo": tipo_de(e), "sin_plan": not getattr(e, "plan", None),
         "prueba": en_prueba(e), "modulos": sorted(modulos_de(e)), "extras": extras_de(e), "limite_docs": lim, "periodo": (p or {}).get("periodo"),
         "docs_extra": int(getattr(e, "docs_extra", 0) or 0), "habitaciones": int(getattr(e, "habitaciones", 0) or 0), "cajas": int(getattr(e, "cajas", 0) or 0),
         "limite_usuarios": int(getattr(e, "limite_usuarios", 0) or 0), "vence": getattr(e, "vence", None), "vencido": vencido(e), "plan_inicio": getattr(e, "plan_inicio", None),
         "funciones": funciones_de(e),   # funciones en prueba encendidas en esta empresa (3.58)
         "ocultos": ocultos_de(e), "disponibles": sorted(modulos_plan(e)),   # 3.70: apagados a mano / lo que el plan trae antes de apagar
         "empleados_incluidos": empleados_incluidos(e), "precio_empleado_extra": PRECIO_EMPLEADO_EXTRA,   # 3.87: extra de Recursos humanos
         "precio_acordado": getattr(e, "precio_acordado", None), "precio_acordado_nota": getattr(e, "precio_acordado_nota", "") or ""}   # 3.95
    if s is not None and lim:
        ini, fin = periodo(e)
        d.update({"docs_usados": documentos_usados(s, e), "periodo_inicio": ini, "periodo_fin": fin})
    return d
