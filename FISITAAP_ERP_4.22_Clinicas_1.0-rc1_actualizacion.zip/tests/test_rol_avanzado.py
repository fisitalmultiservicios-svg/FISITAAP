"""3.32: rol base «Avanzado» y cambio de rol desde la consola de administración de cuentas."""
import json
import types

from fastapi.testclient import TestClient
from sqlmodel import Session, select

from app import auth
from app.db import init_db, engine
from app.main import app

init_db()


def _admin():
    admin = types.SimpleNamespace(id=None, correo="admin@example.test", es_superadmin=True, nombre="Admin")
    app.dependency_overrides[auth.superadmin] = lambda: admin
    return TestClient(app)


def test_consola_cambia_rol_y_lista_roles_de_la_empresa():
    c = _admin()
    try:
        r = c.post("/api/admin/cuentas", json={"correo": "dueno332@example.test", "password": "Clave-larga-de-prueba-332", "nombre_empresa": "Ferretería El Tornillo S.A.", "tipo_negocio": "comercio"})
        assert r.status_code == 200, r.text
        eid = r.json()["empresa_id"]
        r = c.post(f"/api/admin/cuentas/{eid}/usuarios", json={"correo": "caja332@example.test", "rol": "Cajero", "password": "Clave-larga-de-prueba-332"})
        assert r.status_code == 200, r.text
        uid = r.json()["usuario_id"]
        cuenta = next(x for x in c.get("/api/admin/cuentas").json() if x["id"] == eid)
        assert cuenta["roles"][:6] == auth.ROLES and "Supervisor de caja" in cuenta["roles"]
        # cajero → avanzado → rol propio de la empresa
        r = c.put(f"/api/admin/cuentas/{eid}/usuarios/{uid}/rol", json={"rol": "avanzado"})
        assert r.status_code == 200 and r.json()["rol"] == "Avanzado"
        r = c.put(f"/api/admin/cuentas/{eid}/usuarios/{uid}/rol", json={"rol": "Supervisor de caja"})
        assert r.status_code == 200 and r.json()["rol"] == "Supervisor de caja"
        assert c.put(f"/api/admin/cuentas/{eid}/usuarios/{uid}/rol", json={"rol": "Gerente inventado"}).status_code == 400
        # el único Administrador no puede quedar sin ese rol
        dueno = next(u for u in cuenta["usuarios"] if u["correo"] == "dueno332@example.test")
        assert c.put(f"/api/admin/cuentas/{eid}/usuarios/{dueno['id']}/rol", json={"rol": "Avanzado"}).status_code == 400
        assert c.put(f"/api/admin/cuentas/{eid}/usuarios/999999/rol", json={"rol": "Avanzado"}).status_code == 404
        with Session(engine) as s:
            assert auth.permisos_de_rol(s, eid, "Avanzado") == {p for p in auth.PERMISOS if not p.startswith("clinicas")} - {"configurar", "documentos", "usuarios"} | {"clinicas"}
            assert not auth.rol_exige_mfa(s, eid, "Avanzado")
    finally:
        app.dependency_overrides.clear()
