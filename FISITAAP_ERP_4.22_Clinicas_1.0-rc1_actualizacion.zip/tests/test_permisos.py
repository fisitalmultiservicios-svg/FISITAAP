"""Niveles de acceso por rol: el administrador puede todo, Solo lectura solo ve, y cada registro de la interfaz exige el permiso de su módulo."""
from app import auth


def permisos_de(rol):
    return {p for p, roles in auth.PERMISOS.items() if rol in roles}


def test_matriz_roles():
    assert set(auth.ROLES) == {"Administrador", "Avanzado", "Contador", "Vendedor", "Cajero", "Solo lectura"}
    av = permisos_de("Avanzado")                               # 3.32: todo menos configuración, formatos de impresión y usuarios
    assert av == {p for p in auth.PERMISOS if not p.startswith("clinicas")} - {"configurar", "documentos", "usuarios"} | {"clinicas"}
    assert not auth.solo_pos(av) and auth.puede_leer_registro(av, "empleados") and auth.puede_leer_registro(av, "bancos")
    assert permisos_de("Cajero") == {"ver", "pos"} and "pos" in permisos_de("Vendedor") and "pos" not in permisos_de("Contador")
    assert auth.solo_pos({"ver", "pos"}) and not auth.solo_pos({"ver", "pos", "cobros"}) and not auth.solo_pos({"ver"})
    assert auth.puede_leer_registro({"ver", "pos"}, "pos_espera") and auth.puede_leer_registro({"ver", "pos"}, "categorias")
    assert not auth.puede_leer_registro({"ver", "pos"}, "cotizaciones") and not auth.puede_leer_registro({"ver", "pos"}, "bancos")
    for roles in auth.PERMISOS.values():
        assert roles <= set(auth.ROLES)
    assert permisos_de("Administrador") == {p for p in auth.PERMISOS if not p.startswith("clinicas")} | {"clinicas", "clinicas_configurar"}
    assert permisos_de("Solo lectura") == {"ver", "ver_todo"}
    vend = permisos_de("Vendedor")
    assert {"ver", "facturar", "catalogos", "inventario", "cobros"} <= vend
    assert not ({"contabilidad", "gastos", "reportes", "configurar", "usuarios", "ver_todo"} & vend)
    cont = permisos_de("Contador")
    assert {"ver", "ver_todo", "cobros", "gastos", "contabilidad", "reportes", "documentos"} <= cont
    assert not ({"facturar", "configurar", "usuarios", "catalogos", "inventario"} & cont)
    assert set(auth.DESCRIPCION_ROLES) == set(auth.ROLES) and set(auth.PERMISOS_NOMBRE) == set(auth.PERMISOS)


def test_permiso_por_registro():
    assert auth.permiso_registro("asientos") == "contabilidad"
    assert auth.permiso_registro("periodos_2026") == "contabilidad"
    assert auth.permiso_registro("bancos") == "gastos" and auth.permiso_registro("pagos_gastos") == "gastos"
    assert auth.permiso_registro("cotizaciones") == "facturar"
    assert auth.permiso_registro("monedas") == "configurar"
    assert auth.permiso_registro("reportes_recientes") == "ver"
    assert auth.permiso_registro("algo_desconocido") == "escribir"
    assert "Solo lectura" not in auth.PERMISOS["escribir"]
