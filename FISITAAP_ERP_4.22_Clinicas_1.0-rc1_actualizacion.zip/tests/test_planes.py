"""Planes, extras y límites por empresa (3.16): el administrador del sistema asigna plan y extras; lo no contratado se quita de
los permisos y de los registros; límite de documentos por periodo, de usuarios, de habitaciones y de cajas; plan vencido en
modo lectura; sin plan, en prueba gratis o demo todo queda encendido."""
import types
from datetime import date, timedelta

from sqlmodel import Session

from app import auth, planes
from app.db import Documento, Empresa, engine, engine_empresa
from app.main import app
from tests.test_sinc import H, _admin_empresa, c


def _superadmin():
    app.dependency_overrides[auth.superadmin] = lambda: types.SimpleNamespace(id=None, correo="admin-planes@example.test", es_superadmin=True, nombre="Admin")


def _asignar(eid, **kw):
    r = c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": None, "extras": [], "docs_extra": 0, "habitaciones": 0, "cajas": 0, "limite_usuarios": 0, **kw})
    assert r.status_code == 200, r.text
    return r.json()["plan"]


def _permisos(tok):
    return set(c.get("/api/auth/yo", headers=H(tok)).json()["permisos"])


def test_planes_modulos_limites_y_vencimiento():
    eid, t = _admin_empresa("-plan")
    _superadmin()
    try:
        # sin plan: todo encendido
        info = c.get("/api/plan", headers=H(t)).json()
        assert info["sin_plan"] and set(info["modulos"]) == set(planes.MODULOS) - {"clinicas"} and info["limite_docs"] == 0
        assert {"contabilidad", "rrhh", "reportes"} <= _permisos(t)
        # 1) plan de facturación sin extras: contabilidad, recursos humanos y reportes desaparecen de los permisos y de los registros
        p = _asignar(eid, plan="fac_emprendedor")
        assert p["nombre"] == "Emprendedor" and "contabilidad" not in p["modulos"] and "reportes" not in p["modulos"] and p["limite_docs"] == 50
        assert not ({"contabilidad", "rrhh", "reportes"} & _permisos(t))
        r = c.put("/api/registros/catalogo", headers=H(t), json={"datos": [{"id": 1, "cuenta": "1-01", "nombre": "Caja"}]})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_modulo", r.text
        assert c.get("/api/registros?v=2", headers=H(t)).json()["datos"].get("catalogo") is None
        assert c.post("/api/admin/cuentas/" + str(eid) + "/plan", json={"plan": "hotel"}).status_code == 400     # plan de otro tipo
        # 2) extra Contabilidad: vuelve, y enciende Reportes
        p = _asignar(eid, plan="fac_emprendedor", extras=["contabilidad", "canales"])          # canales no es de facturación: se ignora
        assert {"contabilidad", "reportes"} <= set(p["modulos"]) and "rrhh" not in p["modulos"] and p["extras"] == ["contabilidad"]
        assert {"contabilidad", "reportes"} <= _permisos(t) and "rrhh" not in _permisos(t)
        assert c.put("/api/registros/catalogo", headers=H(t), json={"datos": [{"id": 1, "cuenta": "1-01", "nombre": "Caja"}]}).status_code == 200
        # 3) límite de documentos: prepago 24 al año desde hoy; con 24 emitidos no se emite el 25
        p = _asignar(eid, plan="fac_pre24")
        assert p["periodo"] == "anio" and p["plan_inicio"] == date.today().isoformat() or p["plan_inicio"]
        hoy = planes._hoy()
        with Session(engine_empresa(eid)) as s:
            for i in range(24):
                s.add(Documento(empresa_id=eid, tipo_documento="04", clave=f"5061910260031010000880010000104000000{i + 1:04d}1{i:08d}", consecutivo=f"0010000104{i + 1:010d}",
                                fecha_emision=f"{hoy}T10:00:00-06:00", moneda="CRC", tipo_cambio=1, total=100, impuesto=0, estado="aceptado", ambiente="produccion"))
            s.commit()
        with Session(engine) as sc:      # 4.5: el tope cuenta y se exige solo con comprobantes electrónicos de producción
            e = sc.get(Empresa, eid); e.ambiente = "produccion"; sc.add(e); sc.commit()
        info = c.get("/api/plan", headers=H(t)).json()
        assert info["docs_usados"] == 24 and info["limite_docs"] == 24
        doc = {"tipo_documento": "04", "condicion_venta": "01", "medio_pago": "01", "moneda": "CRC", "tipo_cambio": 1,
               "lineas": [{"detalle": "Servicio", "cabys": "8311000000000", "cantidad": 1, "precio_unitario": 1000, "descuento": 0, "codigo_tarifa": "08", "tarifa": 13, "es_servicio": True, "unidad_medida": "Sp"}]}
        r = c.post("/api/comprobantes", headers=H(t), json=doc)
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "limite_plan", r.text
        _asignar(eid, plan="fac_pre24", docs_extra=100)                                       # paquete de documentos: pasa el límite
        r = c.post("/api/comprobantes", headers=H(t), json=doc)
        assert not (r.status_code == 403 and isinstance(r.json().get("detail"), dict) and r.json()["detail"].get("codigo") == "limite_plan"), r.text
        with Session(engine) as sc:
            e = sc.get(Empresa, eid); e.ambiente = "sandbox"; sc.add(e); sc.commit()
        # 4) límite de usuarios
        _asignar(eid, plan="fac_pre24", limite_usuarios=1)
        r = c.post("/api/auth/usuarios", headers=H(t), json={"correo": "segundo-plan@example.test", "nombre": "Segundo", "rol": "Vendedor", "password_temporal": "Clave-Temporal-Plan-2026"})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "limite_plan", r.text
        # 5) plan vencido: modo lectura (GET sí, POST no); el administrador del sistema no se ve afectado
        _asignar(eid, plan="fac_pre24", vence="2020-01-01")
        assert c.get("/api/clientes", headers=H(t)).status_code == 200
        r = c.post("/api/clientes", headers=H(t), json={"nombre": "Nuevo", "tipo_id": "01", "numero_id": "101230123"})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "plan_vencido", r.text
        assert next(x for x in c.get("/api/auth/yo", headers=H(t)).json()["empresas"] if x["id"] == eid)["plan"]["vencido"] is True
        _asignar(eid, plan="fac_pre24", vence="2099-12-31")
        assert c.post("/api/clientes", headers=H(t), json={"nombre": "Nuevo", "tipo_id": "01", "numero_id": "101230123"}).status_code == 200
        # 6) en prueba gratis todo queda encendido aunque haya plan
        with Session(engine) as sc:
            e = sc.get(Empresa, eid); e.prueba_hasta = (date.today() + timedelta(days=10)).isoformat(); sc.add(e); sc.commit()
        assert set(c.get("/api/plan", headers=H(t)).json()["modulos"]) == set(planes.MODULOS) - {"clinicas"} and "rrhh" in _permisos(t)
        with Session(engine) as sc:
            e = sc.get(Empresa, eid); e.prueba_hasta = None; sc.add(e); sc.commit()
        # 7) hotelería: habitaciones contratadas, hotel completo y punto de venta como extras
        assert c.post(f"/api/admin/cuentas/{eid}/tipo", json={"tipo_negocio": "hospitalidad"}).status_code == 200
        p = _asignar(eid, plan="hotel", habitaciones=2)
        assert p["habitaciones"] == 6 and "hotel" in p["modulos"] and "pos" not in p["modulos"]       # mínimo de 6 habitaciones
        assert "pos" not in _permisos(t)
        habs = [{"id": i, "numero": str(100 + i), "categoria_id": 1, "activa": True} for i in range(1, 8)]
        r = c.put("/api/registros/hotel_habitaciones", headers=H(t), json={"datos": habs})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "limite_plan", r.text
        assert c.put("/api/registros/hotel_habitaciones", headers=H(t), json={"datos": habs[:6]}).status_code == 200
        r = c.put("/api/registros/hotel_salones", headers=H(t), json={"datos": [{"id": 1, "nombre": "Salón Jade", "capacidad": 50}]})
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_modulo"
        p = _asignar(eid, plan="hotel", habitaciones=10, extras=["pos", "hotel_completo"])
        assert {"pos", "hotel_completo"} <= set(p["modulos"]) and "pos" in _permisos(t)
        assert c.put("/api/registros/hotel_salones", headers=H(t), json={"datos": [{"id": 1, "nombre": "Salón Jade", "capacidad": 50}]}).status_code == 200
        r = c.get("/api/hotel/ical/enlaces", headers=H(t))
        assert r.status_code == 403 and r.json()["detail"]["codigo"] == "sin_modulo"                  # canales no contratados
        assert c.post(f"/api/admin/cuentas/{eid}/plan", json={"plan": "hotel", "habitaciones": 35}).status_code == 400     # hasta 30: paquete de 40
        p = _asignar(eid, plan="hotel_40")
        assert p["habitaciones"] == 40 and {"pos", "hotel_completo", "contabilidad", "rrhh", "reportes"} <= set(p["modulos"]) and "canales" not in p["modulos"]
        assert {"pos", "contabilidad", "rrhh", "reportes"} <= _permisos(t)
        p = _asignar(eid, plan="hotel_50", extras=["canales"])
        assert p["habitaciones"] == 50 and "canales" in p["modulos"] and c.get("/api/hotel/ical/enlaces", headers=H(t)).status_code == 200
        # 8) la página pública muestra los tres cuadros y el catálogo del panel lista los planes por tipo
        pagina = c.get("/precios").text
        assert "Hotelería" in pagina and "por habitación" in pagina and "Punto de venta" in pagina and "Prepago 24" in pagina
        cat = c.get("/api/admin/planes").json()
        assert [p["codigo"] for p in cat["planes"]["comercio"]] == ["pos_basico", "pos"] and cat["extras_tipo"]["hospitalidad"] == ["pos", "contabilidad", "rrhh", "hotel_completo", "canales", "pedidos_online", "entregas"]
        # 9) pagos del plan: extienden el vencimiento desde hoy (si ya venció) o desde el vencimiento vigente, y cierran la prueba
        _asignar(eid, plan="hotel_40", vence="2020-01-01")
        with Session(engine) as sc:
            e = sc.get(Empresa, eid); e.prueba_hasta = "2099-01-01"; sc.add(e); sc.commit()
        r = c.post(f"/api/admin/cuentas/{eid}/pagos", json={"monto": 300000, "medio": "SINPE", "referencia": "123", "meses": 1}); assert r.status_code == 200, r.text
        hoy = planes._hoy()
        assert r.json()["pago"]["vence_nuevo"] == planes.sumar_meses(hoy, 1) and r.json()["cuenta"]["plan"]["vence"] == planes.sumar_meses(hoy, 1) and r.json()["cuenta"]["prueba_hasta"] is None
        r = c.post(f"/api/admin/cuentas/{eid}/pagos", json={"monto": 3600000, "medio": "transferencia", "meses": 12}); assert r.status_code == 200, r.text
        assert r.json()["pago"]["vence_nuevo"] == planes.sumar_meses(planes.sumar_meses(hoy, 1), 12)
        assert len(c.get(f"/api/admin/cuentas/{eid}/pagos").json()) == 2
        assert planes.sumar_meses("2026-01-31", 1) == "2026-02-28"
        # 10) recordatorios: 7 días antes y al vencer, una vez por fecha
        enviados = []
        falso = lambda s, e, asunto, texto: enviados.append((e.id, asunto)) or True  # noqa: E731
        _asignar(eid, plan="hotel_40", vence=(date.today() + timedelta(days=7)).isoformat())
        assert [x for x in planes.recordatorios_vencimiento(falso) if x.get("empresa_id") == eid] and "vence el" in enviados[-1][1]
        n = len(enviados); planes.recordatorios_vencimiento(falso); assert len(enviados) == n                      # no repite
        _asignar(eid, plan="hotel_40", vence=(date.today() - timedelta(days=1)).isoformat())
        planes.recordatorios_vencimiento(falso); assert "venció" in enviados[-1][1]
        _asignar(eid, plan="hotel_40", vence="2099-12-31")
    finally:
        app.dependency_overrides.clear()
