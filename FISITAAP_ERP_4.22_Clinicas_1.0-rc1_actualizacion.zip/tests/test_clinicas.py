"""Clínicas: pruebas con el aislamiento de tests/conftest.py, nunca sobre datos del servidor."""
import json
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlmodel import Session, select

from app import auth, clinicas as C, inventario, modulos, planes, respaldo, secretos
from app.clinicas_modelos import ClinicaAdjunto, ClinicaAuditoria, ClinicaCargo, ClinicaEntrada, ClinicaLote, ClinicaPaciente
from app.config import ahora_cr
from app.db import Cliente, Documento, Empresa, Producto, engine, engine_empresa, init_db
from app.main import app


def clave():
    return str(uuid.uuid4())


@pytest.fixture
def entorno():
    init_db()
    with Session(engine) as s:
        e = Empresa(nombre="Clínica QA " + clave(), numero_id="3101000001", actividad="851101", correo="clinica-qa@example.test", factura_electronica=False,
                    funciones='["clinicas"]', clave_cifrada=secretos.nueva_clave_empresa())
        s.add(e); s.commit(); s.refresh(e)
        u = auth.Usuario(nombre="Profesional QA", correo=clave()+"@example.test", password_hash="no-login-qa", mfa_activo=True,
                         terminos_version=auth.TERMINOS_VERSION, consiente_factura=True, paleta="turquesa")
        s.add(u); s.commit(); s.refresh(u)
        s.add(auth.UsuarioEmpresa(usuario_id=u.id, empresa_id=e.id, rol="Administrador")); s.commit()
        s.refresh(e); s.refresh(u); s.expunge(e); s.expunge(u)
    permisos = set(C.PERMISOS) | {"ver", "facturar", "inventario", "configurar", "usuarios"}
    ctx = auth.Contexto(u, e, "Clínico QA", permisos=permisos)
    app.dependency_overrides[auth.contexto] = lambda: ctx
    c = TestClient(app)
    try:
        yield SimpleNamespace(c=c, ctx=ctx, e=e, u=u, permisos=permisos)
    finally:
        app.dependency_overrides.clear()


def ok(r, status=200):
    assert r.status_code == status, r.text
    return r.json()


def paciente(t, **extras):
    return ok(t.c.post('/api/clinicas/pacientes', json={"nombre": "Paciente QA", "documento": clave(), "consentimiento": "aceptado", **extras}))


def profesional(t, **extras):
    return ok(t.c.put('/api/clinicas/profesionales/0', json={"usuario_id": t.u.id, "nombre": "Profesional QA", "especialidad": "Medicina",
        "colegiado": "QA-123", "vence": (ahora_cr().date()+timedelta(days=800)).isoformat(), "horario": {str(d): [["08:00", "17:00"]] for d in range(7)}, **extras}))


def episodio(t):
    p = paciente(t); pro = profesional(t)
    ep = ok(t.c.post('/api/clinicas/episodios', json={"paciente_id": p['id'], "profesional_id": pro['id'], "clave": clave()}))
    return p, pro, ep


def entrada(t, ep, tipo="nota", datos=None, **extras):
    return t.c.post(f'/api/clinicas/episodios/{ep["id"]}/entradas', json={"tipo": tipo, "datos": datos or {"texto": "Nota confidencial QA"}, "clave": clave(), **extras})


def producto(t, servicio=False, moneda="CRC", cantidad=20):
    with t.ctx.sesion() as s:
        p = Producto(empresa_id=t.e.id, nombre="Servicio QA" if servicio else "Medicamento QA", cabys="", precio=1000 if moneda=="CRC" else 3,
                     moneda=moneda, tarifa=0, codigo_tarifa="01", es_servicio=servicio, inventariable=not servicio)
        s.add(p); s.flush()
        b = inventario.Bodega(empresa_id=t.e.id, nombre="Farmacia QA", principal=True)
        s.add(b); s.flush()
        if not servicio:
            inventario.registrar_movimiento(s, producto=p, bodega_id=b.id, tipo="compra", cantidad=cantidad, fecha=ahora_cr().date().isoformat(), costo_unitario=5)
        s.commit(); s.refresh(p); s.refresh(b)
        return p.id, b.id


def receta(t, ep, producto_id, cantidad=10, **extras):
    datos = {"medicamento": "Medicamento QA", "producto_id": producto_id, "cantidad": cantidad, "dosis": "Según indicación QA", "frecuencia": "QA",
             "via": "Oral", "duracion": "QA", "vence": (ahora_cr().date()+timedelta(days=10)).isoformat(), "revision_alergias": True, "revision_interacciones": True, **extras}
    return ok(entrada(t, ep, "receta", datos))


def lote(t, pid, bid, cantidad, dias, numero=None):
    return ok(t.c.post('/api/clinicas/lotes', json={"producto_id":pid,"bodega_id":bid,"numero":numero or clave(),
                           "cantidad":cantidad,"vence":(ahora_cr().date()+timedelta(days=dias)).isoformat()}))


def test_opt_in_preserva_planes_y_permisos(entorno):
    t=entorno
    for e in (Empresa(nombre="sin plan"), Empresa(nombre="demo", es_demo=True), Empresa(nombre="hotel", tipo_negocio="hospitalidad", plan="hotel_40")):
        assert "clinicas" not in planes.modulos_de(e)
    assert "clinicas" in planes.modulos_de(t.e)
    assert not ({"clinicas_atender","clinicas_mental","clinicas_farmacia"} & auth.permisos_de_rol(None, t.e.id, "Administrador"))
    t.ctx.permisos = {"ver", "clinicas"}
    assert t.c.get('/api/clinicas/pacientes/1/expediente').status_code == 403
    assert t.c.get('/api/clinicas/auditoria').status_code == 403
    t.e.funciones='[]'
    assert t.c.get('/api/clinicas/pacientes').status_code == 403


def test_mfa_token_local_y_clave(entorno, monkeypatch):
    t=entorno
    t.u.mfa_activo=False
    assert t.c.get('/api/clinicas/capacidades').json()['detail']['codigo']=='clinicas_mfa'
    t.u.mfa_activo=True
    t.ctx.token_api=SimpleNamespace(id=1)
    assert t.c.get('/api/clinicas/pacientes').status_code==403
    t.ctx.token_api=None
    monkeypatch.setenv('FE_MODO_LOCAL','1')
    assert t.c.get('/api/clinicas/pacientes').status_code==403
    monkeypatch.delenv('FE_MODO_LOCAL')
    original=t.e.clave_cifrada; t.e.clave_cifrada=None
    assert t.c.get('/api/clinicas/pacientes').status_code==409
    t.e.clave_cifrada=original


def test_sin_sesion_y_empresa_cambiada(entorno):
    t=entorno
    app.dependency_overrides.clear()
    assert t.c.get('/api/clinicas/pacientes').status_code==401
    with Session(engine) as s:
        u=s.get(auth.Usuario,t.u.id)
        ses=auth._respuesta(s,u,t.e.id)
    headers={"Authorization":"Bearer "+ses['token'],"X-Empresa":str(t.e.id+100)}
    assert t.c.get('/api/clinicas/pacientes',headers=headers).status_code==409
    headers['X-Empresa']=str(t.e.id)
    assert t.c.get('/api/clinicas/pacientes',headers=headers).status_code==200
    # El rol Administrador real no recibe permisos clínicos de atención.
    assert t.c.get('/api/clinicas/pacientes/1/expediente',headers=headers).status_code==403


def test_pacientes_cifrados_duplicados_version_y_auditoria(entorno):
    t=entorno
    p=paciente(t,documento="1-1234-5678")
    assert t.c.post('/api/clinicas/pacientes',json={"nombre":"Duplicado", "documento":"112345678"}).status_code==409
    with t.ctx.sesion() as s:
        r=s.get(ClinicaPaciente,p['id'])
        assert r.datos.startswith('enc:') and 'Paciente QA' not in r.datos and '1234' not in r.datos
    cambio={k:v for k,v in p.items() if k!='id'}; cambio['telefono']='88880000'
    assert ok(t.c.put(f'/api/clinicas/pacientes/{p["id"]}',json=cambio))['version']==2
    assert t.c.put(f'/api/clinicas/pacientes/{p["id"]}',json=cambio).status_code==409
    assert ok(t.c.get('/api/clinicas/pacientes?q=8888'))[0]['id']==p['id']
    logs=ok(t.c.get('/api/clinicas/auditoria'))
    assert all('Paciente QA' not in json.dumps(a) and '88880000' not in json.dumps(a) for a in logs)
    assert t.c.get('/api/clinicas/pacientes').headers['Cache-Control']=='no-store'
    assert t.c.post('/api/clinicas/pacientes',json={"nombre":"Futuro", "nacimiento":"2999-01-01"}).status_code==422


def test_aislamiento_fisico_por_empresa_y_claves(entorno):
    t=entorno; p,pro,ep=episodio(t); en=ok(entrada(t,ep))
    with Session(engine) as s:
        e=Empresa(nombre="Segunda clínica QA", funciones='["clinicas"]', clave_cifrada=secretos.nueva_clave_empresa()); s.add(e);s.commit();s.refresh(e);s.expunge(e)
    original=t.ctx.empresa; t.ctx.empresa=e
    assert ok(t.c.get('/api/clinicas/pacientes'))==[]
    assert t.c.get(f'/api/clinicas/pacientes/{p["id"]}/expediente').status_code==404
    assert t.c.post(f'/api/clinicas/episodios/{ep["id"]}/entradas',json={"tipo":"nota","datos":{"texto":"intruso"},"clave":clave()}).status_code==404
    t.ctx.empresa=original
    with t.ctx.sesion() as s:
        raw=s.get(ClinicaEntrada,en['id']).datos
        with pytest.raises(ValueError): secretos.descifrar(e.clave_cifrada,raw)


def test_agenda_idempotencia_horario_y_concurrencia(entorno):
    t=entorno; p=paciente(t); pro=profesional(t)
    dia=(ahora_cr().date()+timedelta(days=1)).isoformat()
    body={"paciente_id":p['id'],"profesional_id":pro['id'],"inicio":dia+'T09:00:00-06:00',"fin":dia+'T09:30:00-06:00',"clave":clave()}
    c=ok(t.c.post('/api/clinicas/citas',json=body))
    assert ok(t.c.post('/api/clinicas/citas',json=body))['id']==c['id']
    assert t.c.post('/api/clinicas/citas',json={**body,"fin":dia+'T09:45:00-06:00'}).status_code==409
    assert t.c.post('/api/clinicas/citas',json={**body,"clave":clave()}).status_code==409
    assert t.c.post('/api/clinicas/citas',json={**body,"clave":clave(),"inicio":dia+'T07:00:00-06:00',"fin":dia+'T07:30:00-06:00'}).status_code==409
    assert t.c.post('/api/clinicas/citas',json={**body,"clave":clave(),"inicio":dia+'T10:00:00',"fin":dia+'T10:30:00'}).status_code==422
    paralelo={**body,"inicio":dia+'T11:00:00-06:00',"fin":dia+'T11:30:00-06:00'}
    with ThreadPoolExecutor(2) as pool:
        resultados=list(pool.map(lambda _:t.c.post('/api/clinicas/citas',json={**paralelo,"clave":clave()}).status_code,range(2)))
    assert sorted(resultados)==[200,409]
    llegada=ok(t.c.post(f'/api/clinicas/citas/{c["id"]}/estado',json={"estado":"llegada","version":1}))
    assert llegada['version']==2
    assert t.c.post(f'/api/clinicas/citas/{c["id"]}/estado',json={"estado":"cancelada","version":1}).status_code==409
    ep=ok(t.c.post('/api/clinicas/episodios',json={"paciente_id":p['id'],"profesional_id":pro['id'],"cita_id":c['id'],"clave":clave()}))
    assert t.c.post('/api/clinicas/episodios',json={"paciente_id":p['id'],"profesional_id":pro['id'],"cita_id":c['id'],"clave":clave()}).status_code==409
    ok(entrada(t,ep)); ok(t.c.post(f'/api/clinicas/episodios/{ep["id"]}/cerrar',json={"estado":"finalizado","version":1}))
    assert ok(t.c.get('/api/clinicas/citas?dia='+dia))[0]['estado']=='atendida'


def test_credencial_usuario_y_sucursal(entorno):
    t=entorno; p=paciente(t)
    assert t.c.put('/api/clinicas/profesionales/0',json={"usuario_id":999999,"nombre":"Ajeno","especialidad":"QA","colegiado":"QA","vence":"2099-01-01"}).status_code==422
    pro=profesional(t,vence="2000-01-01")
    assert t.c.post('/api/clinicas/episodios',json={"paciente_id":p['id'],"profesional_id":pro['id'],"clave":clave()}).status_code==409
    t.ctx.sucursal_fija=True; t.ctx.sucursal=SimpleNamespace(id=99)
    assert t.c.post('/api/clinicas/episodios',json={"paciente_id":p['id'],"profesional_id":pro['id'],"clave":clave()}).status_code in (403,409)
    assert t.c.get('/api/clinicas/lotes').status_code==403


def test_fechas_y_horarios_rechazan_formatos_ambiguos(entorno):
    t=entorno
    for fecha in ['20990101', '2099-02-30']:
        r=t.c.put('/api/clinicas/profesionales/0',json={'usuario_id':t.u.id,'nombre':'Prueba QA','especialidad':'QA','colegiado':'QA','vence':fecha})
        assert r.status_code==422
    r=t.c.put('/api/clinicas/profesionales/0',json={'usuario_id':t.u.id,'nombre':'Prueba QA','especialidad':'QA','colegiado':'QA','vence':'2099-01-01',
        'horario':{'0':[['08:00+06:00','17:00+06:00']]}})
    assert r.status_code==422


def test_consentimiento_inmutabilidad_correcciones_y_mental(entorno):
    t=entorno; p,pro,ep=episodio(t)
    t.ctx.permisos.discard('clinicas_mental')
    assert entrada(t,ep,'mental').status_code==403
    assert entrada(t,ep,'soap',{'subjetivo':'incompleto'}).status_code==422
    en=ok(entrada(t,ep))
    with t.ctx.sesion() as s:
        with pytest.raises(IntegrityError):
            s.execute(text('UPDATE clinica_entrada SET datos=:d WHERE id=:i'),{'d':'borrar','i':en['id']});s.commit()
        s.rollback()
        with pytest.raises(IntegrityError):
            s.execute(text('DELETE FROM clinica_auditoria'));s.commit()
        s.rollback()
    ok(t.c.post(f'/api/clinicas/episodios/{ep["id"]}/cerrar',json={"estado":"finalizado","version":1}))
    assert entrada(t,ep).status_code==409
    cor=ok(entrada(t,ep,anterior_id=en['id'],datos={'texto':'Corrección QA'}))
    assert cor['anterior_id']==en['id']
    assert entrada(t,ep,anterior_id=en['id']).status_code==409
    t.ctx.permisos.add('clinicas_mental')
    # Las correcciones del episodio cerrado conservan el mismo tipo de entrada.
    exp=ok(t.c.get(f'/api/clinicas/pacientes/{p["id"]}/expediente'))
    assert len(exp['entradas'])==2
    assert t.c.delete(f'/api/clinicas/episodios/{ep["id"]}/entradas/{en["id"]}').status_code in (404,405)


def test_revocar_consentimiento_y_abac(entorno):
    t=entorno; p,pro,ep=episodio(t)
    cambio={k:v for k,v in p.items() if k!='id'}; cambio['consentimiento']='revocado'
    ok(t.c.put(f'/api/clinicas/pacientes/{p["id"]}',json=cambio))
    assert entrada(t,ep).status_code==409
    t.ctx.permisos.discard('clinicas_supervisar')
    t.ctx.usuario=SimpleNamespace(id=t.u.id+900, mfa_activo=True)
    assert ok(t.c.get(f'/api/clinicas/pacientes/{p["id"]}/expediente'))['episodios']==[]
    assert entrada(t,ep).status_code==403


def test_adjuntos_encriptados_y_protegidos(entorno):
    t=entorno; p,pro,ep=episodio(t)
    ruta=f'/api/clinicas/episodios/{ep["id"]}/adjuntos'
    assert t.c.post(ruta,files={'archivo':('fake.pdf',b'<script>hola</script>')}).status_code==422
    doc=ok(t.c.post(ruta,files={'archivo':('privado.pdf',b'%PDF-1.4\nConfidencial QA')},data={'mental':'true'}))
    with t.ctx.sesion() as s:
        a=s.get(ClinicaAdjunto,doc['id']); assert a.datos.startswith('enc:') and 'Confidencial' not in a.datos
    assert t.c.get('/api/clinicas/adjuntos/'+str(doc['id'])).content.startswith(b'%PDF-')
    t.ctx.permisos.discard('clinicas_mental')
    assert t.c.get('/api/clinicas/adjuntos/'+str(doc['id'])).status_code==403
    assert ok(t.c.get(f'/api/clinicas/pacientes/{p["id"]}/expediente'))['adjuntos']==[]
    assert t.c.post(ruta,files={'archivo':('grande.pdf',b'%PDF-'+b'x'*(5*1024*1024))}).status_code==413


def test_orden_muestra_resultado_critico(entorno):
    t=entorno; p,pro,ep=episodio(t)
    o=ok(t.c.post(f'/api/clinicas/episodios/{ep["id"]}/ordenes',json={'tipo':'laboratorio','detalle':'Estudio QA','clave':clave()}))
    ruta=f'/api/clinicas/ordenes/{o["id"]}'
    for v,estado in enumerate(['recolectada','recibida','en_proceso'],1):
        ok(t.c.post(ruta+'/estado',json={'estado':estado,'version':v}))
    cuerpo={'informe':'Resultado QA','critico':True,'notificado_a':'','version':4,'clave':clave()}
    assert t.c.post(ruta+'/resultado',json=cuerpo).status_code==422
    cuerpo['notificado_a']='Profesional de guardia QA'
    r=ok(t.c.post(ruta+'/resultado',json=cuerpo))
    assert r['estado']=='completada' and ok(t.c.post(ruta+'/resultado',json=cuerpo))['id']==r['id']
    assert any(e['tipo']=='resultado' for e in ok(t.c.get(f'/api/clinicas/pacientes/{p["id"]}/expediente'))['entradas'])


def test_fefo_stock_idempotencia_y_correccion_receta(entorno):
    t=entorno; p,pro,ep=episodio(t); pid,bid=producto(t)
    r=receta(t,ep,pid,cantidad=10)
    tarde=lote(t,pid,bid,10,90); temprano=lote(t,pid,bid,10,30)
    cuerpo={'receta_id':r['id'],'bodega_id':bid,'cantidad':6,'clave':clave()}
    disp=ok(t.c.post('/api/clinicas/dispensas',json=cuerpo)); assert disp['lotes'][0]['lote_id']==temprano['id']
    assert ok(t.c.post('/api/clinicas/dispensas',json=cuerpo))['id']==disp['id']
    with t.ctx.sesion() as s:
        assert inventario.existencia(s,pid,bid).cantidad==14
        assert s.get(ClinicaLote,temprano['id']).cantidad==4
        assert s.get(ClinicaLote,tarde['id']).cantidad==10
    assert t.c.post('/api/clinicas/dispensas',json={**cuerpo,'cantidad':5,'clave':clave()}).status_code==409
    corregida={**r['datos'],'dosis':'Corregida QA'}
    nueva=ok(entrada(t,ep,'receta',corregida,anterior_id=r['id']))
    assert t.c.post('/api/clinicas/dispensas',json={**cuerpo,'cantidad':1,'clave':clave()}).status_code==409
    assert t.c.post('/api/clinicas/dispensas',json={**cuerpo,'receta_id':nueva['id'],'cantidad':5,'clave':clave()}).status_code==409
    ok(t.c.post('/api/clinicas/dispensas',json={**cuerpo,'receta_id':nueva['id'],'cantidad':4,'clave':clave()}))
    with t.ctx.sesion() as s: assert inventario.existencia(s,pid,bid).cantidad==10


def test_lotes_vencidos_bloqueados_y_cantidades(entorno):
    t=entorno; p,pro,ep=episodio(t); pid,bid=producto(t,cantidad=10); r=receta(t,ep,pid)
    lote(t,pid,bid,5,-1); l=lote(t,pid,bid,5,10)
    cuerpo={'receta_id':r['id'],'bodega_id':bid,'cantidad':6,'clave':clave()}
    assert t.c.post('/api/clinicas/dispensas',json=cuerpo).status_code==409
    ok(t.c.post(f'/api/clinicas/lotes/{l["id"]}/estado',json={'estado':'bloqueado','version':1}))
    assert t.c.post(f'/api/clinicas/lotes/{l["id"]}/estado',json={'estado':'disponible','version':1}).status_code==409
    assert t.c.post('/api/clinicas/dispensas',json={**cuerpo,'cantidad':1}).status_code==409
    assert t.c.post('/api/clinicas/dispensas',json={**cuerpo,'cantidad':-1}).status_code==422
    assert t.c.post('/api/clinicas/dispensas',json={**cuerpo,'cantidad':'NaN'}).status_code==422
    assert t.c.post('/api/clinicas/lotes',json={'producto_id':pid,'bodega_id':bid,'numero':'exceso','vence':'2099-01-01','cantidad':1}).status_code==409


def test_dispensacion_concurrente_no_sobrevende(entorno):
    t=entorno; p,pro,ep=episodio(t); pid,bid=producto(t,cantidad=10);r=receta(t,ep,pid,cantidad=10);lote(t,pid,bid,10,30)
    with ThreadPoolExecutor(2) as pool:
        resultados=list(pool.map(lambda _:t.c.post('/api/clinicas/dispensas',json={'receta_id':r['id'],'bodega_id':bid,'cantidad':7,'clave':clave()}).status_code,range(2)))
    assert sorted(resultados)==[200,409]
    with t.ctx.sesion() as s: assert inventario.existencia(s,pid,bid).cantidad==3


@pytest.mark.parametrize('moneda',['CRC','USD'])
def test_cargos_borrador_emision_interna_reintento_y_anulacion(entorno,moneda):
    t=entorno;p,pro,ep=episodio(t);pid,bid=producto(t,servicio=True,moneda=moneda)
    ruta=f'/api/clinicas/episodios/{ep["id"]}'
    cargo=ok(t.c.post(ruta+'/cargos',json={'producto_id':pid,'cantidad':2,'clave':clave()}))
    facturacion={'moneda':moneda,**({'tipo_cambio':510} if moneda=='USD' else {})}
    if moneda=='USD': assert t.c.post(ruta+'/facturar',json={'moneda':moneda}).status_code==422
    b=ok(t.c.post(ruta+'/facturar',json=facturacion))
    assert t.c.post(ruta+'/facturar',json=facturacion).status_code==409
    with t.ctx.sesion() as s: datos=json.loads(s.get(modulos.Borrador,b['borrador_id']).datos)
    datos.update(borrador_id=b['borrador_id'],idempotencia=clave(),tipo_cambio=510 if moneda=='USD' else 1)
    assert t.c.put('/api/borradores/'+str(b['borrador_id']),json=datos).status_code==409
    copia=json.loads(json.dumps(datos));copia['lineas'][0]['cantidad']='3'
    assert t.c.post('/api/comprobantes',json=copia).status_code==409
    doc=ok(t.c.post('/api/comprobantes',json=datos));assert doc['estado']=='interno' and doc['moneda']==moneda
    assert ok(t.c.post('/api/comprobantes',json=datos))['id']==doc['id']
    with t.ctx.sesion() as s: assert s.get(ClinicaCargo,cargo['id']).documento_id==doc['id']
    assert 'Nota confidencial' not in json.dumps(doc)
    ok(t.c.post('/api/comprobantes/'+str(doc['id'])+'/anular'))
    assert ok(t.c.post(ruta+'/facturar',json=facturacion))['borrador_id']


def test_eliminar_borrador_libera_y_no_crea_inventario(entorno):
    t=entorno;p,pro,ep=episodio(t);pid,bid=producto(t,servicio=True);ruta=f'/api/clinicas/episodios/{ep["id"]}'
    ok(t.c.post(ruta+'/cargos',json={'producto_id':pid,'cantidad':1,'clave':clave()}));b=ok(t.c.post(ruta+'/facturar',json={}))
    ok(t.c.delete('/api/borradores/'+str(b['borrador_id'])))
    assert ok(t.c.post(ruta+'/facturar',json={}))['borrador_id']
    with t.ctx.sesion() as s: assert not s.exec(select(inventario.MovimientoInventario).where(inventario.MovimientoInventario.producto_id==pid)).all()


def test_exportacion_y_respaldo_clinico_no_se_renumera(entorno,tmp_path):
    t=entorno;p,pro,ep=episodio(t);ok(entrada(t,ep));backup=respaldo.ejecutar_empresa(t.e)
    import zipfile
    with zipfile.ZipFile(backup) as z:
        dbs=[n for n in z.namelist() if n.endswith('.db')]
        assert dbs
        destino=tmp_path/'copia.db';destino.write_bytes(z.read(dbs[0]))
    with pytest.raises(ValueError,match='misma empresa'): respaldo.renumerar_base(destino,t.e.id,t.e.id+100)
    r=t.c.get(f'/api/clinicas/pacientes/{p["id"]}/exportar');assert r.status_code==200
    assert r.json()['entradas'][0]['datos']['texto']=='Nota confidencial QA'
    assert r.headers['Cache-Control']=='no-store'


def test_auditoria_cadena_hmac_y_dental(entorno):
    t=entorno;p,pro,ep=episodio(t)
    assert entrada(t,ep,'dental',{'dientes':{'99':'inválido'}}).status_code==422
    ok(entrada(t,ep,'dental',{'dientes':{'11':'Hallazgo QA','55':'Temporal QA'}}))
    rows=ok(t.c.get('/api/clinicas/auditoria'));anterior='0'*64
    import hashlib,hmac
    for a in rows:
        assert a['previo']==anterior
        payload=f"{t.e.id}|{a['usuario_id']}|{a['accion']}|{a['objeto']}|{a['creado']}|{a['previo']}"
        assert hmac.compare_digest(a['huella'],hmac.new(auth.SECRET,payload.encode(),hashlib.sha256).hexdigest())
        anterior=a['huella']


def test_lote_reserva_stock_y_conciliacion_no_duplica_movimientos(entorno):
    t=entorno;pid,bid=producto(t,cantidad=20);l=lote(t,pid,bid,15,30)
    with t.ctx.sesion() as s:
        p=s.get(Producto,pid)
        inventario.registrar_movimiento(s,producto=p,bodega_id=bid,tipo='ajuste',cantidad=-5,fecha=ahora_cr().date().isoformat());s.commit()
        assert inventario.existencia(s,pid,bid).cantidad==15
        with pytest.raises(Exception) as ex:
            inventario.registrar_movimiento(s,producto=p,bodega_id=bid,tipo='ajuste',cantidad=-1,fecha=ahora_cr().date().isoformat())
        assert getattr(ex.value,'status_code',None)==409;s.rollback()
    ok(t.c.post(f'/api/clinicas/lotes/{l["id"]}/identificacion',json={'cantidad':10,'version':1,'motivo':'Conciliación de lote de prueba'}))
    with t.ctx.sesion() as s: assert inventario.existencia(s,pid,bid).cantidad==15
    assert t.c.post(f'/api/clinicas/lotes/{l["id"]}/identificacion',json={'cantidad':20,'version':2,'motivo':'Exceso de identificación QA'}).status_code==409


def test_anular_receta_y_cargo_conserva_historia(entorno):
    t=entorno;p,pro,ep=episodio(t);pid,bid=producto(t);r=receta(t,ep,pid);lote(t,pid,bid,10,30)
    ok(t.c.post(f'/api/clinicas/recetas/{r["id"]}/anular',json={'motivo':'Cambio clínico documentado QA'}))
    assert t.c.post('/api/clinicas/dispensas',json={'receta_id':r['id'],'bodega_id':bid,'cantidad':1,'clave':clave()}).status_code==409
    assert ok(t.c.get('/api/clinicas/recetas'))[0]['anulada']
    servicio,_=producto(t,servicio=True)
    cargo=ok(t.c.post(f'/api/clinicas/episodios/{ep["id"]}/cargos',json={'producto_id':servicio,'cantidad':1,'clave':clave()}))
    ok(t.c.post(f'/api/clinicas/cargos/{cargo["id"]}/anular',json={'motivo':'Cargo registrado por error QA'}))
    assert t.c.post(f'/api/clinicas/episodios/{ep["id"]}/facturar',json={}).status_code==409
    with t.ctx.sesion() as s:
        assert s.get(ClinicaCargo,cargo['id']).anulado
        assert s.get(ClinicaEntrada,r['id']) is not None


def test_claves_preservadas_migracion_aditiva_y_pdf(entorno):
    import sqlite3
    from app import db
    from app.config import DATA_DIR
    t=entorno;pid,bid=producto(t,servicio=True)
    clave_empresa=t.e.clave_cifrada
    claves={p.name:p.read_bytes() for p in [DATA_DIR/'master.key',DATA_DIR/'secret.key'] if p.exists()}
    # Simula una base anterior que ya tiene productos ERP pero todavía no tablas clínicas.
    motor,_=db._engines.pop(t.e.id);motor.dispose()
    ruta=db.EMPRESAS_DIR/f'empresa_{t.e.id}.db'
    with sqlite3.connect(ruta) as con:
        tablas=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'clinica_%'")]
        for nombre in tablas: con.execute(f'DROP TABLE "{nombre}"')
        con.execute('PRAGMA user_version=0');con.commit()
    db.engine_empresa(t.e.id)
    with t.ctx.sesion() as s: assert s.get(Producto,pid).nombre=='Servicio QA'
    assert t.e.clave_cifrada==clave_empresa
    assert claves=={p.name:p.read_bytes() for p in [DATA_DIR/'master.key',DATA_DIR/'secret.key'] if p.exists()}
    p,pro,ep=episodio(t);ok(entrada(t,ep))
    r=t.c.get(f'/api/clinicas/pacientes/{p["id"]}/pdf');assert r.status_code==200 and r.content.startswith(b'%PDF-')
    assert r.headers['Cache-Control']=='no-store'


def test_plan_vencido_clinicas_sigue_lectura_y_bloquea_escritura(entorno):
    t=entorno;app.dependency_overrides.clear()
    with Session(engine) as s:
        e=s.get(Empresa,t.e.id);e.plan='fac_basico';e.vence='2000-01-01';s.add(e);s.commit()
        ses=auth._respuesta(s,s.get(auth.Usuario,t.u.id),t.e.id)
    h={'Authorization':'Bearer '+ses['token'],'X-Empresa':str(t.e.id)}
    assert t.c.get('/api/clinicas/pacientes',headers=h).status_code==200
    r=t.c.post('/api/clinicas/pacientes',headers=h,json={'nombre':'Bloqueado QA'})
    assert r.status_code==403 and r.json()['detail']['codigo']=='plan_vencido'


def test_fe_activa_no_simula_emision_sin_cabys(entorno):
    t=entorno;p,pro,ep=episodio(t);pid,bid=producto(t,servicio=True)
    t.e.factura_electronica=True
    ok(t.c.post(f'/api/clinicas/episodios/{ep["id"]}/cargos',json={'producto_id':pid,'cantidad':1,'clave':clave()}))
    b=ok(t.c.post(f'/api/clinicas/episodios/{ep["id"]}/facturar',json={}))
    with t.ctx.sesion() as s: datos=json.loads(s.get(modulos.Borrador,b['borrador_id']).datos)
    datos.update(borrador_id=b['borrador_id'],idempotencia=clave())
    assert t.c.post('/api/comprobantes',json=datos).status_code==400
    with t.ctx.sesion() as s:
        assert s.get(modulos.Borrador,b['borrador_id']) is not None
        assert not s.exec(select(Documento)).all()


def test_preflight_detecta_personalizaciones_y_enlaces(tmp_path):
    import hashlib
    from tools.verificar_clinicas import verificar
    raiz=tmp_path/'root';(raiz/'app').mkdir(parents=True)
    p=raiz/'app'/'archivo.py';p.write_text('base')
    hash_=lambda x:hashlib.sha256(x.encode()).hexdigest()
    m=tmp_path/'manifest.json';m.write_text(json.dumps({'archivos':[{'ruta':'app/archivo.py','antes':hash_('base'),'despues':hash_('nuevo')}]}))
    assert verificar(raiz,m)==0
    p.write_text('personalizado');assert verificar(raiz,m)==1
    p.unlink();p.symlink_to(tmp_path/'otro');(tmp_path/'otro').write_text('base')
    assert verificar(raiz,m)==1
